# Coco Working

Open source digital co-working space with isometric pixel art (Habbo Hotel inspired).

## Architecture

Monorepo (Turborepo + pnpm):
- `packages/client` — HTML/CSS DOM renderer + React + TypeScript (Vite)
- `packages/server` — Socket.IO + TypeScript
- `packages/shared` — Shared types and pure game logic (isometric math, movement, proximity)

## Commands

```bash
pnpm install                # Install all dependencies
pnpm -w run dev             # Start client (3000) + server (2567)
pnpm -w run test            # Run all unit + integration tests
pnpm -w run test:unit       # Unit tests only (Vitest)
pnpm -w run test:e2e        # E2E tests (Playwright)
pnpm -w run build           # Build all packages
```

## Testing (TDD)

- Unit tests: Vitest — game logic in `shared/`, validation in `server/`
- Integration tests: Vitest + socket.io-client — full server behavior
- E2E tests: Playwright (future) — full client+server scenarios
- Always write tests BEFORE implementation
- Game logic MUST be separated from DOM rendering for testability
- Server integration tests in `server/src/__tests__/integration/`

## Code style

- TypeScript strict mode everywhere
- Pure functions for game logic (isometric math, pathfinding, validation)
- Room rendering classes only call into pure game-logic functions
- Server validates all client input

## Key patterns

- Isometric: grid coords (x, y) → screen coords via `gridToScreen()` in shared
- Depth sorting: `getDepth(pos)` returns render order
- Movement: held WASD/arrows and touch/click paths support eight directions, derived on the server by `directionForMove()`. `shared/src/walking.ts` checks height and both adjacent routes for diagonals.
- Multiplayer: Socket.IO, server broadcasts state changes, clients render
- Events: `player:join`, `player:leave`, `player:move`, `chat:send`, `chat:message`, `peer:id`
- Proximity: PeerJS WebRTC, audio/video auto-connect within 3 tiles, volume scales with distance
- Furniture: Base sofa + Base table + Stool use shared footprints in `shared/src/furniture.ts`. Canonical unique ownership, inventory placement and room deletion live in `shared/src/ownedWorld.ts`.
- Room ownership stays with the saved creator profile; disconnects never transfer ownership. Room owners edit placed furniture; players place/collect their own inventory; collection/deletion returns each item to its existing owner.
- Persistence: `server/src/state/WorldStore.ts` saves profiles, hashed anonymous credentials, room and item locations atomically. Never publish `packages/server/data/` or include it in exports.

- Stacking uses integer height levels and support IDs; table height 2, Stool height 1. Resolve placement on the server. Block support edits while occupied. Player ascent is at most one level per adjacent tile.

- Avatars use a stable CSS skin rig plus removable layers. Appearance data is strictly validated in `shared/src/avatar.ts`; `avatar:save` changes only the authenticated profile and broadcasts `player:appearance`. Optional `habboFigure` uses an intact online-rendered figure, never mixed with CSS clothing. Native directions are 0..7; walk frames are cached before display. Keep raw asset imports and NFT ownership verification separate.
- Child windows use the shared `theme/ChildWindow.ts` and bounded HeatherOS geometry. Preserve mouse, touch and keyboard resizing. Wardrobe and room information use non-modal dialogs with no backdrop; keep background room interaction available. Optional `breastSize` is a validated integer 0–100, with missing legacy values normalised to 0. It changes CSS silhouette and clothing only, never external Habbo artwork. Do not modify the vendored HeatherOS CSS; change palette or interaction geometry separately.

- Sofa sitting is transient per live player, never an inventory mutation. Shared seating.ts validates front approaches, seat occupancy and exits; player:posture broadcasts full authoritative posture. Keep room IDs in posture requests. CSS sofas have two cushion anchors and foreground occlusion; use the same sitting action for external Habbo figures.

- Sitting is automatic on a validated seat-entry movement; pathfinding treats a cushion as an endpoint, never a through-route. Sofa placement may cover one standing avatar per cushion only at its current support height. Apply automatic postures after successful world persistence; a failed save must leave both furniture and avatars unchanged.
- Habbo name lookup uses only allowlisted official hotel hosts and the returned validated figureString. Cancel stale requests when closing or switching modes; preview before saving the appearance.
