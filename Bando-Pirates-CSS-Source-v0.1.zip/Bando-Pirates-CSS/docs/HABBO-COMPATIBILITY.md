# Habbo asset compatibility

Checked 8 November 2026. The default artwork remains original CSS. An optional intact Habbo figure renderer is now available; raw clothing/furniture imports and NFT ownership checks are separate work.

## Implemented figure renderer

- In the wardrobe, choose **Habbo figure**. Enter a figure string and click **Preview figure**, or select Habbo.com/Habbo.nl and look up a Habbo name. The public `/api/public/users?name=...` response supplies `figureString`. Only this validated outfit is used, with no credentials or unrelated profile data retained. Lookup results preview until Wear/Save. Wear/Save persists that string in the existing appearance profile. The server strictly validates the bounded string, not an arbitrary image URL.
- Requests go only to `https://www.habbo.com/habbo-imaging/avatarimage`, using the figure, native body/head direction, normal 64×110 canvas, standing/sitting/walking action and frame. Four walking frames are loaded once per direction before display to avoid cancelling requests during animation. This requires a working internet connection and the upstream renderer.
- Native direction order: 0 northeast, 1 east, 2 southeast, 3 south, 4 southwest, 5 west, 6 northwest, 7 north. Our CSS rig uses the same foot anchor and direction boundary. The [Nitro renderer direction definitions](https://github.com/billsonnn/nitro-renderer/blob/main/src/api/nitro/avatar/enum/AvatarDirectionAngle.ts) document its 45-degree steps and mirrored directions 4–6.
- The external figure is displayed intact. Our CSS clothing controls edit the CSS avatar only. Image failures fall back to our original rig. No downloaded Habbo artwork is included in this repository or the standalone HTML files. Availability of an online image is not a grant of reuse rights.
- Browser verification loaded real standing and sitting figures at 64×110 and observed distinct `wlk` frame URLs and displayed frames; direct endpoint checks confirmed four different image responses.

This does not parse SWF or `.nitro` packs, import individual Habbo clothes into the CSS wardrobe, implement Habbo furniture, or establish NFT ownership. The application does not claim Habbo affiliation.

## Separate NFT integration: published sources

- [Habbo NFT guidelines](https://collectibles.habbo.com/guidelines/) describe third-party avatar display with cryptographic ownership verification, retention of the intact avatar, and rights ending after transfer.
- [General NFT licence, sections 4.3 and 4.5](https://www.habbox.game/terms/) describe verified-owner display in third-party applications, removal when the owner leaves, and restrictions on separating or adapting the combined artwork. The [PDF](https://collectibles.habbo.com/HabboTC.pdf) is labelled November 2021; collection-specific and later terms must be checked before shipping an integration.
- [Habbo's ecosystem overview](https://collectibles.habbo.com/about/) places premium collections, including Genesis and Crafted Avatars, on Ethereum mainnet.
- [Habbo's Immutable guide](https://collectibles.habbo.com/imx/) states that regular collectibles, including furniture, now use Immutable zkEVM. An old Immutable X-only implementation would miss the current network.

These sources do not establish a blanket right to copy Habbo's ordinary furniture catalogue, split avatar clothing into our wardrobe, or reuse a marketplace thumbnail as a four-direction animated game asset. A specific furniture collection's applicable licence and usable assets still need to be identified. No official drop-in game renderer or licensed animation pack was verified in this investigation.

## Proposed NFT integration

1. Keep our CSS wardrobe and player profiles independent of external NFTs. An NFT appearance would use a separate renderer and never be represented as editable CSS clothing.
2. Add wallet sign-in with a short-lived, single-use signed challenge bound to the server session and site. Verify the signature on the server. Merely entering a public address or token ID cannot establish ownership.
3. Use an explicit allowlist of verified chain and collection contracts. Check current ownership/balance on the correct network. Key every entitlement by chain, contract and token ID; handle quantities where applicable.
4. Resolve reviewed metadata and authorised images/sprites through a controlled asset adapter. Map furniture footprint, elevation, collision, stacking, rotation and animation explicitly. A token image alone does not define game behaviour.
5. Recheck ownership during active sessions and remove the external appearance/placed representation when access expires, the owner leaves, or ownership changes. Never mint extra owned CSS inventory copies from an NFT. Room deletion removes its game placement; it does not transfer the token.

The smallest useful pilot would display one verified avatar intact. NFT-specific animated avatars and furniture remain a separate integration, dependent on the exact collections and authorised rendering assets. The ordinary figure-image adapter above is not an NFT entitlement check.
