# Habbo asset compatibility

Checked 8 November 2026. The default artwork remains original CSS. An optional intact Habbo figure renderer is now available; a MetaMask ownership integration is also available. Verified furniture NFTs can also use native transparent floor-furniture sprites and live placement data.

## Implemented figure renderer

- In the wardrobe, choose **Habbo figure**. Enter a figure string and click **Preview figure**, or select Habbo.com/Habbo.nl and look up a Habbo name. The public `/api/public/users?name=...` response supplies `figureString`. Only this validated outfit is used, with no credentials or unrelated profile data retained. Lookup results preview until Wear/Save. Wear/Save persists that string in the existing appearance profile. The server strictly validates the bounded string, not an arbitrary image URL.
- Requests go only to `https://www.habbo.com/habbo-imaging/avatarimage`, using the figure, native body/head direction, normal 64×110 canvas, standing/sitting/walking action and frame. Four walking frames are loaded once per direction before display to avoid cancelling requests during animation. This requires a working internet connection and the upstream renderer.
- Native direction order: 0 northeast, 1 east, 2 southeast, 3 south, 4 southwest, 5 west, 6 northwest, 7 north. Our CSS rig uses the same foot anchor and direction boundary. The [Nitro renderer direction definitions](https://github.com/billsonnn/nitro-renderer/blob/main/src/api/nitro/avatar/enum/AvatarDirectionAngle.ts) document its 45-degree steps and mirrored directions 4–6.
- The external figure is displayed intact. Our CSS clothing controls edit the CSS avatar only. Image failures fall back to our original rig. No downloaded Habbo artwork is included in this repository or the standalone HTML files. Availability of an online image is not a grant of reuse rights.
- Browser verification loaded real standing and sitting figures at 64×110 and observed distinct `wlk` frame URLs and displayed frames; direct endpoint checks confirmed four different image responses.

This figure renderer does not parse SWF or `.nitro` packs or import individual Habbo clothes into the CSS wardrobe. NFT ownership and native furniture use the separate integration below. The application does not claim Habbo affiliation.

## Separate NFT integration: published sources

- [Habbo NFT guidelines](https://collectibles.habbo.com/guidelines/) describe third-party avatar display with cryptographic ownership verification, retention of the intact avatar, and rights ending after transfer.
- [General NFT licence, sections 4.3 and 4.5](https://www.habbox.game/terms/) describe verified-owner display in third-party applications, removal when the owner leaves, and restrictions on separating or adapting the combined artwork. The [PDF](https://collectibles.habbo.com/HabboTC.pdf) is labelled November 2021; collection-specific and later terms must be checked before shipping an integration.
- [Habbo's ecosystem overview](https://collectibles.habbo.com/about/) places premium collections, including Genesis and Crafted Avatars, on Ethereum mainnet.
- [Habbo's Immutable guide](https://collectibles.habbo.com/imx/) states that regular collectibles, including furniture, now use Immutable zkEVM. An old Immutable X-only implementation would miss the current network.

These sources do not establish a blanket right to copy Habbo's ordinary furniture catalogue, split avatar clothing into our wardrobe, or reuse a marketplace thumbnail as a four-direction animated game asset. A specific furniture collection's applicable licence and usable assets still need to be identified. No official drop-in game renderer or licensed animation pack was verified in this investigation.

## Implemented MetaMask integration

Open **Wallet & collectibles** in the hosted multiplayer game. Connect MetaMask, approve account access and sign the short-lived login challenge. On Android, the HTTPS game provides **Open game in MetaMask**, which opens the same page in MetaMask’s app browser. The browser extension and MetaMask in-app provider are supported; cross-app WalletConnect/QR pairing is not implemented.

For a MetaMask login, the server verifies an EIP-191 personal signature over a SIWE-style message bound to the exact website origin, authenticated player/socket, address, chain, random one-use nonce and five-minute expiration. The connected session expires after one hour. No private keys, seed phrases, token approvals, transactions or token transfers are requested. Wallets must be EOA accounts capable of personal_sign; EIP-1271 contract-wallet signatures are not supported.

The wallet and inventory are separate from the saved player identity. A wallet grants no access to another player’s furniture. One verified game session per wallet prevents verified tabs from creating duplicate room representations. Unverified test sessions are kept separate and do not evict verified users.

### Address-only test mode

Choose a collection and click **Try Heather’s wallet** to use the prefilled public sample `0x71a780c3a25dd7a22901781764f1200fa24e8e15`. Alternatively, paste any 0x address into **Test wallet address (no signature)**, choose **Test wallet address**, then **Load wallet collectibles** or **Find token**. The server fetches real inventory for that address; the player does not prove control. Sessions and rendered NFT items/avatars are labelled **unverified test wallet** / **test wallet**. The server retains up to 512 server-fetched assets as demo copies for that one-hour session. Reuse of these demos does not require fresh RPC ownership reads; reload the test wallet to refresh its snapshot. Switching wallets, expiry or disconnect clears it. Signed sessions never use the test cache.

This prototype deliberately permits this mode for testing. It grants no spending permissions, token transfers, signed-in account identity or saved CSS inventory access. The test session lasts one hour; changing addresses, leaving or disconnecting clears its NFT usage. It can wear supported avatar previews and place supported floor furniture through the same geometry system. Verified MetaMask login remains available, and test logins cannot kick a verified wallet session out. The standalone HTML can use Heather’s saved public sample without a server. It displays the snapshot date and does not claim current ownership. It includes three Genesis avatars and the first 12 furniture records; ten sample items have one of five validated native floor definitions. Only metadata and image URLs are embedded. Image loading still needs internet. The downloaded file does not support live inventory for arbitrary addresses or MetaMask verification; use the linked multiplayer game for those.

### Supported collections

Contract addresses were checked against the public `runtimeConfig` in https://collectibles.habbo.com/traits/editor/ on 8 November 2026. The tracked registry is in `packages/shared/src/collectibles.ts`. Only these explicit ERC-721 collections are accepted: Genesis and Crafted avatars on Ethereum; furniture, clothes, pets, add-ons and tokens on Immutable zkEVM. Other contracts, ERC-1155 variants, custodial Collector Wallets not controlled by this MetaMask address, and old Immutable X assets are not imported. Never add a collection solely because its name matches Habbo.

Genesis/Crafted inventory discovery uses the contract’s enumeration functions with pagination. zkEVM inventory uses Immutable’s official account NFT API, filtered by contract. Discovery checks ownerOf against the configured RPC. **Find a collectible by token ID** also checks ownership and helps when discovery is incomplete. Signed sessions verify again before equipping or placing furniture; unsigned sessions can reuse their server-fetched demo snapshot. Metadata/images come from the official Habbo and Immutable endpoints. The metadata image must be an approved PNG or GIF URL on nft-tokens.habbo.com. Arbitrary URLs, HTML/SVG animation embeds and unapproved collections are not accepted.

### Native furniture in the room

Choose **Wallet & collectibles → Furniture**, select an owned token (or look it up by token ID), choose **Place furniture…**, then tap a valid floor tile or support. There is no display stand. The placed object uses the ordinary room selection, move, rotate and pick-up controls. The room owner can move/rotate pieces; their individual owners can pick them up. **Pick up placed furniture** in the wallet window also removes the selected token's room representation. The NFT itself never leaves the wallet.

The server matches a Furniture ERC-721 token’s official metadata image basename to an exact `nft_` classname, or a unique exact normalized official NFT floor name for legacy image basenames in [Habbo's live floor-furniture catalogue](https://www.habbo.com/gamedata/furnidata_json/1). It reads tile dimensions, height and sitting/standing/stacking flags from that catalogue. The JSON is bounded to 16 MiB and cached for six hours; no catalogue or furniture artwork is bundled in this project.

The [HabboAssets public imager](https://www.habboassets.com/api) supplies available directions, sprite states and native transparent 64px images. This is a community provider, separate from Sulake. The server pins a matching revision; it does not silently use another design when the match fails. Image/info requests need no API key. Provider availability and rate limits still apply. An unavailable sprite reports an image error.

- Floor placement uses the actual rectangular footprint and height. Rotation cycles only the views supplied for that item; many items have four, some have fewer. The furniture renders at the same native room scale as the 64×32 grid.
- Sitting flags create real seats with automatic occupancy, safe adjacent approaches and exits in every direction and synchronized posture. Moving onto a seat, or putting an unoccupied seat beneath a player, seats that player. Rear-facing backrests draw in front of seated avatars. This is a basic intact-sprite adapter; individual armrest masks and furniture-specific seat offsets are not decoded.
- Supports use the catalogue's stacking flag. NFT-on-CSS and NFT-on-NFT stacks work, with exact support heights and the existing one-level climb rule for table-like surfaces. Native saved CSS inventory furniture cannot use temporary NFT supports. This prevents a saved stack from depending on a disconnected wallet.
- Available image states can be cycled with **Use / change state**. This changes the sprite state; specialized gameplay, teleporters, wired logic, games, lying down and automatic furniture animations are not implemented.
- The server accepts up to 32 furniture NFTs per wallet session and one placed representation per token. Unknown classnames, wall items and collectibles without an exact floor-furniture match cannot be placed. Clothing, pets, add-ons and tokens remain inventory previews; they are not substituted with floor furniture.
- Disconnecting, leaving the game, switching wallet accounts/networks or session expiration removes active NFT appearances and furniture. In signed sessions, failed ownership reads or detected transfer also remove them, with rechecks roughly every minute and on use. Unsigned sessions reuse their server-fetched demo snapshot until refreshed, expired or disconnected. Removal also clears dependent NFT stacks and releases seated players safely. Deleting the room clears NFT placements. These are session placements; reconnects and restarts require verification and placement again.

### NFT avatars and artwork

**Wear selected avatar** resolves the collectible’s outfit with the set and palette IDs published by Habbo’s Avatar Editor. The resulting figure uses the existing Habbo image renderer for standing, walking, turning and sitting. It applies for the wallet session and **Use wardrobe avatar** restores the saved look. Unmapped figures remain available for preview. The wallet icon keeps colour, ornament, sparkles, branding and artwork in separate layers. Matched furniture uses Habbo’s transparent inventory sprites, including supported wall item previews. Original previews are used when native artwork is unavailable.

Ownership verification does not create broader artwork rights. No third-party NFT artwork is bundled in the source ZIP or standalone previews. Collection-specific terms still apply to external artwork.

### Hosting configuration

| Variable | Use |
| --- | --- |
| BANDO_PUBLIC_URL | Exact public HTTPS game origin. Required outside localhost unless Render supplies RENDER_EXTERNAL_URL. Set explicitly for a custom domain. |
| ETHEREUM_RPC_URL | Optional dedicated Ethereum mainnet RPC; defaults to https://ethereum-rpc.publicnode.com. |
| IMMUTABLE_RPC_URL | Optional dedicated Immutable zkEVM mainnet RPC; defaults to https://rpc.immutable.com. |
| IMMUTABLE_API_KEY | Optional server-only Immutable API key if required by the provider’s limits. |

The server checks RPC chain IDs (1 and 13371) before reading ownership. Keep provider keys on the server. Public endpoints can rate-limit; failed initial loads report an error. In signed sessions, failed rechecks remove active NFT access until verification succeeds again. Unsigned demo snapshots survive background RPC failures until their session ends. Render’s ZIP build/start commands remain the same. The self-contained HTML game includes an unsigned saved sample. Live inventory and signed ownership verification still use the multiplayer server.

### Validation

Tests exercise real generated EIP-191 signatures, replay/session/origin/expiration checks, forged ownership, wrong RPC networks, account changes, transfer revocation, disconnect races, single-wallet sessions, late visitors and metadata URL restrictions. Furniture tests cover official classname/revision matching, native image URLs, real footprints/heights, rotation, collision, stepping, stacking, state changes, room-owner controls, occupied-seat revocation and dependent-stack removal. The production client build and server TypeScript checks are also run.

Live read-only checks verified official furniture geometry and the public imager's native Diamond HC Sofa in all four directions. A browser rendering fixture checked CSS and ordinary Habbo seated avatars against those views, including rear backrest layering. Multiplayer ownership/placement and movement were tested with generated-wallet signatures and a mock gateway in the protocol harness. A browser check opened an address-only test session without a signature. The supplied public address was then tested without signatures: its three Genesis avatars and first 12 Furniture records loaded, Habbo #8599 was worn, and Bronze Cornucopia was placed in a local multiplayer room with a loaded 58×39 native sprite. Real Cornucopia, cake and GIF Confetti metadata matched their exact live floor definitions. Tests cover RPC outages during unsigned sessions, cache clearing on disconnect/verified upgrade and unchanged signed-session revocation. No token approval, transfer or financial transaction was performed. Signed MetaMask use still needs testing on the deployed HTTPS game.
