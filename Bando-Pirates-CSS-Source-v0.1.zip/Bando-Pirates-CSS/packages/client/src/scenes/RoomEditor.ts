import {directionForMove} from '@cocoworking/shared';
import { element, makeAvatar,setAvatarDirection,setAvatarWalking,disposeAvatar, makeFurniture, populateRoom, position, ARTWORK_KEYS, ARTWORK_NAMES } from '../artwork/elements';
import { ROOM_LAYOUT, type LayoutItem } from './roomLayout';
import '../artwork/artwork.css';
import '../artwork/studio.css';

/** Original CSS artwork studio, also used by the portable offline preview. */
export class RoomEditor {
  private root: HTMLElement;
  private viewport: HTMLElement;
  private world: HTMLElement;
  private items: LayoutItem[] = ROOM_LAYOUT.map(item => ({ ...item }));
  private selected = 0;
  private selectionLabel: HTMLElement;
  private nodes: HTMLElement[] = [];
  private actor: HTMLElement;
  private avatarGrid = { x: 5, y: 6 };
  private avatarTimer?: ReturnType<typeof setTimeout>;
  private observer?: ResizeObserver;
  constructor(parent: HTMLElement) {
    this.root = element('css-room artwork-studio', parent);
    const header = element('studio-header', this.root);
    const heading = document.createElement('h1'); heading.textContent = 'Bando Pirates'; header.append(heading);
    const subtitle = document.createElement('p'); subtitle.textContent = 'Original CSS artwork · Coco Working source fork'; header.append(subtitle);
    this.viewport = element('studio-viewport', this.root);
    this.world = element('css-world', this.viewport); populateRoom(this.world);
    this.actor = makeAvatar('Heather', 0xe995c4); this.world.append(this.actor);
    position(this.actor, this.avatarGrid.x, this.avatarGrid.y, 0, 1);
    const panel = element('studio-panel', this.root);
    const title = document.createElement('h2'); title.textContent = 'Make it yours'; panel.append(title);
    const hint = document.createElement('p'); hint.textContent = 'Every shape stays live CSS. Choose colours, select furniture, or click the floor to walk.'; panel.append(hint);
    const colours = element('studio-colours', panel);
    for (const [label, name, value] of [['Wall', '--wall', '#ded6ef'], ['Floor', '--wood', '#e8c9a5'], ['Hair', '--hair', '#eac26d'], ['Clothing', '--shirt', '#e995c4']]) {
      const row = document.createElement('label'); row.textContent = label; colours.append(row);
      const input = document.createElement('input'); input.type = 'color'; input.value = value; input.setAttribute('aria-label', label); row.append(input);
      input.addEventListener('input', () => {
        this.root.style.setProperty(name, input.value);
        if (name === '--shirt' || name === '--hair') this.actor.style.setProperty(name, input.value);
      });
    }
    const paletteTitle = document.createElement('h3'); paletteTitle.textContent = 'Add artwork'; panel.append(paletteTitle);
    const palette = element('studio-palette', panel);
    for (const key of ARTWORK_KEYS) this.button(palette, ARTWORK_NAMES[key], () => {
      this.items.push({ gx: 4, gy: 4, texture: key, originX: .5, originY: .75, yOffset: 0, depth:0, rotation:0 });
      this.selected = this.items.length - 1; this.draw();
    });
    this.selectionLabel = element('studio-selection', panel);
    const controls = element('studio-controls', panel);
    for (const [label, dx, dy] of [['X −', -1, 0], ['X +', 1, 0], ['Y −', 0, -1], ['Y +', 0, 1]] as const) this.button(controls, label, () => {
      const item = this.items[this.selected]; if (!item) return;
      item.gx = Math.max(0, Math.min(9, item.gx + dx)); item.gy = Math.max(0, Math.min(9, item.gy + dy)); this.draw();
    });
    this.button(controls, 'Rotate furniture ↻', () => { const item = this.items[this.selected]; if (item) { item.rotation = ((item.rotation || 0)+1)%4; this.draw(); } });
    this.button(controls, 'Remove', () => { this.items.splice(this.selected, 1); this.selected = Math.max(0, this.selected - 1); this.draw(); });
    const actions = element('studio-actions', panel);
    this.button(actions, 'Download colour CSS', () => {
      const css = `.css-room {\n${this.root.style.cssText.split(';').map(s => s.trim()).filter(Boolean).map(s => `  ${s};`).join('\n')}\n}\n.css-avatar { --shirt: ${this.actor.style.getPropertyValue('--shirt')}; }\n`;
      this.download('Bando-Pirates-Colours.css', css, 'text/css');
    });
    this.button(actions, 'Export room layout', () => this.download('Bando-Pirates-Room.json', JSON.stringify(this.items, null, 2), 'application/json'));
    this.button(actions, 'Reset room', () => { this.items = ROOM_LAYOUT.map(item => ({ ...item })); this.selected = 0; this.draw(); });
    const note = document.createElement('p'); note.className = 'studio-note'; note.textContent = 'Artwork preview only. Live multiplayer is in the source project. Room exports contain artwork positions. Stacking, inventory and height-aware walking are available in the game preview.'; panel.append(note);
    this.viewport.addEventListener('click', this.handleClick);
    window.addEventListener('resize', this.fit);
    if (typeof ResizeObserver !== 'undefined') { this.observer = new ResizeObserver(this.fit); this.observer.observe(this.viewport); }
    this.draw(); this.fit();
  }
  private button(parent: HTMLElement, text: string, onClick: () => void) {
    const button = document.createElement('button'); button.type = 'button'; button.textContent = text; button.addEventListener('click', onClick); parent.append(button);
  }
  private draw() {
    for (const node of this.nodes) node.remove(); this.nodes = [];
    for (const [i, item] of this.items.entries()) {
      const node = makeFurniture(item.texture,item.rotation || 0); node.dataset.item = String(i);
      node.classList.toggle('is-selected', i === this.selected); node.style.pointerEvents = 'auto';
      node.setAttribute('role', 'button'); node.setAttribute('tabindex', '0'); node.setAttribute('aria-label', `Select ${ARTWORK_NAMES[item.texture]}`);
      node.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); this.selected = i; this.draw(); } });
      position(node,item.gx + (item.texture==='base-sofa'&&(item.rotation || 0)%2 ? .5 : 0),item.gy + (item.texture==='base-sofa'&&(item.rotation || 0)%2===0 ? .5 : 0),item.yOffset,item.depth); this.world.append(node); this.nodes.push(node);
    }
    const selected = this.items[this.selected];
    this.selectionLabel.textContent = selected ? `${ARTWORK_NAMES[selected.texture]} · X ${selected.gx}, Y ${selected.gy} · Rotation ${(selected.rotation || 0)+1} / 4` : 'No furniture selected';
  }
  private handleClick = (event: MouseEvent) => {
    const target = event.target as HTMLElement;
    const item = target.closest<HTMLElement>('[data-item]');
    if (item) { this.selected = Number(item.dataset.item); this.draw(); return; }
    const tile = target.closest<HTMLElement>('.floor-tile'); if (!tile) return;
    const grid = { x: Number(tile.dataset.x), y: Number(tile.dataset.y) };
    setAvatarDirection(this.actor,directionForMove(this.avatarGrid,grid));
    this.avatarGrid = grid; position(this.actor, grid.x, grid.y, 0, 1); setAvatarWalking(this.actor,true);
    clearTimeout(this.avatarTimer); this.avatarTimer = setTimeout(() => setAvatarWalking(this.actor,false),240);
  };
  private fit = () => {
    const width = this.viewport.clientWidth || 700, height = this.viewport.clientHeight || 500;
    const scale = Math.max(.25, Math.min((width - 28) / 680, (height - 30) / 450, 1.65));
    this.world.style.left = `${width / 2}px`; this.world.style.top = `${height / 2 - 100 * scale}px`; this.world.style.transform = `scale(${scale})`;
  };
  private download(name: string, content: string, type: string) {
    const url = URL.createObjectURL(new Blob([content], { type })); const link = document.createElement('a'); link.href = url; link.download = name; link.click(); setTimeout(() => URL.revokeObjectURL(url), 2000);
  }
  destroy() { disposeAvatar(this.actor);clearTimeout(this.avatarTimer); this.observer?.disconnect(); window.removeEventListener('resize', this.fit); this.viewport.removeEventListener('click', this.handleClick); this.root.remove(); }
}
