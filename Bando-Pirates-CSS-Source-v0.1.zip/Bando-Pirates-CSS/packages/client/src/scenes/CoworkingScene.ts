import {DEFAULT_FLOOR,EMPTY_SPLITS,PUBLIC_STREET,PUBLIC_STREET_ID,PUBLIC_STREET_ENTRANCE,PUBLIC_STREET_FLOOR,PUBLIC_STREET_SPAWN,heatherAppearance,tileAt,tileFromId,nextFloorTile,type FloorTile,type RoomDestination} from '@cocoworking/shared';
import {floorAtScreen} from '../artwork/floorPicking';
import {MicroverseWindow} from '../artwork/MicroverseWindow';
import { directionForMove,defaultAppearance,type AvatarAppearance,canStep, findWalkPath, surfaceAt, isSurface, resolvePlacement, HEIGHT_PIXELS, furnitureTiles, furnitureCenter, placementError, FURNITURE_NAMES, type FurnitureState, type RoomOwner, type RoomInfo, type InventoryEntry, getMoveDelta, applyMove, type KeyDirection, type Player, type ChatMessage, type Direction, type DJState, type Position } from '@cocoworking/shared';
import { NetworkManager } from '../game-logic/NetworkManager';
import { element, makeAvatar, applyAvatarAppearance,setAvatarDirection,setAvatarWalking,disposeAvatar,makeFurniture, populateRoom, populateFloor,worldDepth, position, tilePosition } from '../artwork/elements';
import '../artwork/artwork.css';
import {Wardrobe} from '../artwork/Wardrobe';
import {ChildWindow} from '../theme/ChildWindow';
import {sofaSeats,findPlayerPath,movePlayer,sofaSeatAnchor,type SofaSeatState} from '@cocoworking/shared';
import {setAvatarSitting,applyCollectibleAvatar} from '../artwork/avatar';
import {CollectiblesWindow} from '../artwork/CollectiblesWindow';
import {furnitureName,furnitureRotationCount,furnitureDirection,isSeat,type CollectibleAsset} from '@cocoworking/shared';
import {makeHabboFurniture} from '../artwork/habboFurniture';
import {AvatarMotion,WALK_STEP_MS} from '../artwork/AvatarMotion';
import {RoomScaleWindow} from '../artwork/RoomScaleWindow';
import {RoomCameraGestures,type CameraGesture} from '../artwork/RoomCameraGestures';
import {chatBounds} from '../ui/hudLayout';
import {Taskbar} from '../ui/Taskbar';
import {NavigationWindow} from '../ui/NavigationWindow';
import {windowArea} from '../theme/workArea';
import {projectChatAnchor,type PositionedChatMessage} from '../ui/chatLayout';

interface Actor { node: HTMLElement; grid: Position;seat?:SofaSeatState;motion:AvatarMotion; timer?: ReturnType<typeof setTimeout> }

/** The network and UI-facing API is retained; the artwork is live HTML/CSS. */
export class CoworkingScene {
  private viewport: HTMLElement;
  private world: HTMLElement;
  private cameraGestures: RoomCameraGestures;
  private camera = {x: 0, y: 0, scale: 1};
  private cameraOffset = {x: 0, y: 0};
  private local: Actor;
  private wardrobe:Wardrobe;
  private navigation?:NavigationWindow;
  private walletWindow?:CollectiblesWindow;private placingCollectible?:CollectibleAsset;private interactButton!:HTMLButtonElement;
  private scaleWindow?:RoomScaleWindow;private roomZoom=100;private perspectiveLevel=1;private focus?:FloorTile;private microWindow?:MicroverseWindow;private microMarker?:HTMLElement;
  private appearance:AvatarAppearance=defaultAppearance();
  private remotes = new Map<string, Actor>();
  private network: NetworkManager;
  private observer?: ResizeObserver;
  private timers = new Set<ReturnType<typeof setTimeout>>();
  private disposed = false;
  private lastMove = 0;
  private heldKeys=new Set<KeyDirection>();private keyTimer?:ReturnType<typeof setTimeout>;private taskbar?:Taskbar;
  private routeTimer?:ReturnType<typeof setTimeout>;
  private route:Position[]=[];
  private afterStand?:()=>void;private standButton!:HTMLButtonElement;
  private messages: PositionedChatMessage[] = [];
  private dj?: DJState;
  private onChat?: (messages: PositionedChatMessage[]) => void;
  private onCount?: (n: number) => void;
  private onDJ?: (state: DJState) => void;
  private status: HTMLElement;
  private furniture: FurnitureState[] = [];
  private room:RoomInfo|null=null;
  private inventory:InventoryEntry[]=[];
  private placingId:string|null=null;
  private confirmingDelete=false;
  private furnitureNodes: HTMLElement[] = [];
  private selectedId = 'base-sofa';
  private owner: RoomOwner = {id:null,name:null};
  private connected = false;
  private moveMode = false;
  private furnitureMessage = '';
  private picker!: HTMLSelectElement;
  private moveButton!: HTMLButtonElement;
  private rotateButton!: HTMLButtonElement;
  private ownerLabel!: HTMLElement;
  private furnitureStatus!: HTMLElement;
  private furnitureDetails!: HTMLElement;
  private markers: HTMLElement[] = [];
  private ghostMarkers: HTMLElement[] = [];
  private controls!:HTMLDialogElement;private roomWindow!:ChildWindow;private roomLauncher!:HTMLButtonElement;private controlsBody!:HTMLElement;private roomTitle!:HTMLElement;private roomFields!:HTMLElement;
  private pickupButton!:HTMLButtonElement;private deleteButton!:HTMLButtonElement;private deleteConfirmation!:HTMLElement;private createButton!:HTMLButtonElement;
  private inventoryDetails!:HTMLDetailsElement;private inventorySummary!:HTMLElement;private inventoryPicker!:HTMLSelectElement;private inventoryEmpty!:HTMLElement;private placeButton!:HTMLButtonElement;
  private placementToolbar!:HTMLElement;private emptyRoom!:HTMLElement;

  constructor(parent: HTMLElement, playerName: string, playerColor: number, private offline = false, onLogout?: () => void, private publicStreet = false, onTravel?: (room:RoomDestination)=>void) {
    this.viewport = element('css-room css-room-viewport', parent);
    this.viewport.tabIndex = 0;
    this.viewport.classList.toggle('public-street',publicStreet);
    this.viewport.setAttribute('aria-label', (publicStreet?'Public Street. ':'Isometric room. ')+'Tap a tile to walk, drag to pan, or pinch to zoom.');
    const surface = element('room-camera-surface', this.viewport);
    this.world = element('css-world', surface);
    this.cameraGestures = new RoomCameraGestures(surface, this.moveCamera);
    populateRoom(this.world,this.splits,this.floor);
    this.local = this.createActor(playerName, playerColor, publicStreet?PUBLIC_STREET_SPAWN:{x:5,y:5}, 'south');
    this.wardrobe=new Wardrobe(this.viewport,appearance=>{if(this.connected)this.network.saveAvatar(appearance);else this.wardrobe.failed('Reconnect before saving your look.');});
    const wardrobeButton=this.button(this.viewport,'Wardrobe',()=>{this.cancelRoute();this.wardrobe.open(this.appearance);});wardrobeButton.className='wardrobe-launch';
    this.createFurnitureControls();
    this.standButton=this.button(this.viewport,'Stand up',()=>{this.cancelRoute();this.network.stand();});this.standButton.className='stand-up-launch';this.standButton.hidden=true;
    this.drawFurniture();
    const help = element('room-help', this.viewport);
    help.textContent = 'BANDO PIRATES · Click a tile to walk · Click a sofa to sit · Arrows / WASD';
    this.status = element('room-status', this.viewport);
    this.status.textContent = 'Connecting to room…';
    this.viewport.addEventListener('click', this.handleClick);
    this.viewport.addEventListener('pointermove',this.handlePointerMove);
    this.viewport.addEventListener('pointerleave',this.clearGhost);
    window.addEventListener('keydown', this.handleKey);window.addEventListener('keyup',this.handleKeyUp);window.addEventListener('blur',this.clearHeldKeys);
    window.addEventListener('resize', this.fit);
    window.addEventListener('bando-work-area-change', this.fit);
    if (typeof ResizeObserver !== 'undefined') {
      this.observer = new ResizeObserver(this.fit); this.observer.observe(parent);
    }
    this.fit();
    if(onTravel)this.navigation=new NavigationWindow(this.viewport,publicStreet?PUBLIC_STREET_ID:'player-room',onTravel);
    // In development Vite proxies Socket.IO to the existing Node server.
    this.network = new NetworkManager(window.location.origin, playerName, {
      onWalletState:state=>this.walletWindow?.setState(state),
      onCollectibleAvatar:(id,asset)=>{const actor=id===this.network.getSocketId()?this.local:this.remotes.get(id);if(actor)applyCollectibleAvatar(actor.node,asset);},
      onPosture:player=>this.applyPosture(player),
      onPostureBlocked:message=>{this.cancelRoute();this.furnitureMessage=message;this.updateFurnitureControls();},
      onAppearance:(id,appearance)=>{const actor=id===this.network.getSocketId()?this.local:this.remotes.get(id);if(actor)applyAvatarAppearance(actor.node,appearance);if(id===this.network.getSocketId())this.appearance={...appearance};},
      onAvatarSaved:()=>this.wardrobe.saved(),
      onAvatarBlocked:(message)=>{this.wardrobe.failed(message);if(!this.wardrobe.isOpen())this.status.textContent=message;},
      onRoomState: (players) => this.reconcile(players),
      onIdentity:()=>this.updateFurnitureControls(),
      onRoomDirectory:rooms=>this.navigation?.setRooms(rooms),
      onRoomInfo:(room)=>{
        const changed=this.room?.id!==room?.id;this.room=room;this.confirmingDelete=false;this.cancelRoute();
        if(changed){this.focus=undefined;this.perspectiveLevel=1;this.roomZoom=100;this.cameraOffset={x:0,y:0};this.scaleWindow?.setView(100,1);}populateFloor(this.world,this.splits,this.floor);this.fit();this.positionActor(this.local);for(const actor of this.remotes.values())this.positionActor(actor);
        if(!room){this.resetPlacement();this.messages=[];this.onChat?.([]);for(const bubble of this.world.querySelectorAll('.speech-bubble'))bubble.remove();}
        this.updateFurnitureControls();
      },
      onInventory:(items)=>{this.inventory=items.map(item=>({...item}));this.updateFurnitureControls();},
      onWorldNotice:(message)=>{this.furnitureMessage=message;this.updateFurnitureControls();},
      onFurnitureState: (furniture) => {
        this.cancelRoute();this.furniture=furniture.map(item=>({...item}));this.resetPlacement();this.furnitureMessage='';this.drawFurniture();this.positionActor(this.local);for(const actor of this.remotes.values())this.positionActor(actor);
      },
      onRoomOwner: (owner) => {
        this.owner={...owner};
        if(this.moveMode&&owner.id!==this.network?.getUserId())this.resetPlacement();
        this.updateFurnitureControls();
      },
      onFurnitureBlocked: (message) => { this.furnitureMessage=message; this.updateFurnitureControls(); },
      onPlayerCorrect: (pos) => { this.cancelRoute();this.local.grid = {...pos}; this.positionActor(this.local); },
      onPlayerJoin: (player) => { this.addRemote(player); this.updateCount(); },
      onPlayerLeave: (id) => { this.removeRemote(id); this.updateCount(); },
      onPlayerMove: (id, x, y,direction) => {
        const actor = this.remotes.get(id); if (!actor) return;
        this.moveActor(actor, { x, y },direction);
      },
      onChat: (message) => {
        const actor=message.playerId===this.network.getSocketId()?this.local:this.remotes.get(message.playerId),position={...(message.position||actor?.grid||{x:5,y:5})};
        const anchorX=projectChatAnchor(position,this.viewport.clientWidth||window.innerWidth,this.camera.x,this.camera.scale);
        this.messages = [...this.messages,{...message,position,anchorX}].slice(-50);
        this.onChat?.([...this.messages]);
      },
      onDJState: (state) => { this.dj = state; this.onDJ?.(state); },
      onConnection: (connected) => {
        this.navigation?.setConnected(connected);
        this.connected=connected;this.taskbar?.setConnection(connected,this.offline,this.remotes.size+1);if(!connected){applyCollectibleAvatar(this.local.node,null);for(const actor of this.remotes.values())applyCollectibleAvatar(actor.node,null);const removed=new Set(this.furniture.filter(i=>i.nft).map(i=>i.id));this.furniture=this.furniture.filter(i=>!i.nft);for(const actor of [this.local,...this.remotes.values()]){if(actor.seat&&removed.has(actor.seat.furnitureId)){actor.seat=undefined;setAvatarSitting(actor.node,false);}this.positionActor(actor);}this.drawFurniture();}
        this.status.textContent=connected ? (this.offline ? 'Local preview · offline' : 'Connected · live multiplayer') : 'Disconnected · reconnecting…';
        if(!connected){this.resetPlacement();this.cancelRoute();}
        this.updateFurnitureControls();
      },
    }, this.offline,defaultAppearance(playerColor),publicStreet);
    this.walletWindow=new CollectiblesWindow(this.viewport,this.network,offline,asset=>{if(publicStreet)throw Error('Furniture placement is available in the player room.');if(!this.room||!this.connected)throw Error('Enter a room before placing furniture.');this.cancelRoute();this.resetPlacement();this.placingCollectible=asset;this.furnitureMessage='';this.updateFurnitureControls();});
    const walletButton=this.button(this.viewport,'Wallet & collectibles',()=>{this.cancelRoute();this.walletWindow?.open();});walletButton.className='wallet-launch';
    this.scaleWindow=new RoomScaleWindow(this.viewport,percent=>this.setRoomZoom(percent),level=>this.setPerspective(level));const scaleButton=this.button(this.viewport,'Scale',()=>this.scaleWindow?.open(Math.round(this.roomZoom)));scaleButton.className='room-scale-launch';
    const callsButton=this.button(this.viewport,'Calls',()=>this.network.getCalls().open());callsButton.className='room-calls-launch';
    this.microWindow=new MicroverseWindow(this.viewport,()=>this.canEdit(),id=>{this.cancelRoute();this.resetPlacement();this.network.splitTile(id);},tile=>{this.microMarker?.remove();this.microMarker=tile?this.marker(tile,'microverse-marker',0,tile.size):undefined;},tile=>{this.focus=tile||undefined;this.perspectiveLevel=tile?Math.min(8,tile.depth+2):1;this.roomZoom=100;this.cameraOffset={x:0,y:0};this.scaleWindow?.setView(100,this.perspectiveLevel);this.fit();},this.floor,publicStreet?PUBLIC_STREET_ENTRANCE:undefined);
    const microButton=this.button(this.viewport,'Microverse',()=>this.microWindow?.open());microButton.className='room-microverse-launch';
    const menuItems = Array.from(this.viewport.querySelectorAll<HTMLButtonElement>('.wardrobe-launch,.room-info-launch,.wallet-launch,.room-scale-launch,.room-calls-launch,.room-microverse-launch'));
    if(this.navigation){
      const navigationButton=this.button(this.viewport,'Navigation',()=>this.navigation?.open());
      navigationButton.dataset.program='navigation';
      menuItems.push(navigationButton);
    }
    if(onLogout){
      const logoutButton=this.button(this.viewport,'Log out',onLogout);
      logoutButton.dataset.program='logout';
      menuItems.push(logoutButton);
    }
    this.taskbar=new Taskbar(this.viewport,menuItems);this.taskbar.setConnection(this.connected,this.offline,this.remotes.size+1);if(!publicStreet)this.scaleWindow.open(this.roomZoom);this.fit();
  }
  private get splits(){return this.room?.tileSplits||(this.publicStreet?PUBLIC_STREET.tileSplits:EMPTY_SPLITS);}
  private get floor(){return this.publicStreet?PUBLIC_STREET_FLOOR:DEFAULT_FLOOR;}
  private canEdit(){return !this.publicStreet&&this.connected&&!!this.room&&this.owner.id===this.network?.getUserId();}
  private selectedFurniture(){return this.furniture.find(item=>item.id===this.selectedId);}
  private isPlacing(){return this.moveMode||this.placingId!==null||!!this.placingCollectible;}
  private resetPlacement(){this.moveMode=false;this.placingId=null;this.placingCollectible=undefined;this.clearGhost();}
  private button(parent:HTMLElement,text:string,action:()=>void){const button=document.createElement('button');button.type='button';button.textContent=text;button.addEventListener('click',action);parent.append(button);return button;}
  private createFurnitureControls(){
    this.controls=document.createElement('dialog');this.controls.className='furniture-controls window active bevel';this.controls.id='room-info-window';this.controls.setAttribute('aria-label','Room information');this.viewport.append(this.controls);
    const header=element('titlebar',this.controls);this.roomTitle=element('window-title room-title',header);const buttons=element('window-controls',header);
    const close=this.button(buttons,'×',()=>this.closeRoomWindow());close.className='window-control window-close';close.setAttribute('aria-label','Close room information');
    const body=element('window-body',this.controls);this.ownerLabel=element('room-owner',body);
    this.controlsBody=element('furniture-body',body);
    this.roomFields=element('room-furniture-fields',this.controlsBody);
    const label=document.createElement('label');label.htmlFor='furniture-picker';label.textContent='Furniture';this.roomFields.append(label);
    this.picker=document.createElement('select');this.picker.id='furniture-picker';this.roomFields.append(this.picker);this.picker.addEventListener('change',()=>this.selectFurniture(this.picker.value));
    this.moveButton=this.button(this.roomFields,'Move furniture',()=>{if(!this.canEdit())return;this.cancelRoute();this.moveMode=true;this.placingId=null;this.furnitureMessage='';this.clearGhost();this.updateFurnitureControls();});
    this.rotateButton=this.button(this.roomFields,'Rotate furniture ↻',()=>{if(!this.canEdit())return;this.resetPlacement();this.network.rotateFurniture(this.selectedId);});
    this.interactButton=this.button(this.roomFields,'Use / change state',()=>{const item=this.selectedFurniture();if(item?.nft&&this.canEdit())this.network.interactFurniture(item.id);});
    this.pickupButton=this.button(this.roomFields,'Pick up',()=>{const item=this.selectedFurniture();if(item&&(this.canEdit()||item.ownerId===this.network.getUserId()))this.network.pickUpFurniture(item.id);});
    this.furnitureDetails=element('furniture-details',this.roomFields);
    this.deleteButton=this.button(this.roomFields,'Delete room',()=>{if(this.canEdit()){this.confirmingDelete=true;this.updateFurnitureControls();}});
    this.deleteConfirmation=element('room-delete-confirmation',this.roomFields);
    const warning=element('delete-room-copy',this.deleteConfirmation);warning.textContent='Delete this room? All furniture will return to its owners’ inventories.';
    this.button(this.deleteConfirmation,'Delete room and return furniture',()=>{if(this.canEdit()){this.confirmingDelete=false;this.network.deleteRoom();}});
    this.button(this.deleteConfirmation,'Keep room',()=>{this.confirmingDelete=false;this.updateFurnitureControls();});
    this.createButton=this.button(this.controlsBody,'Create room',()=>{if(this.connected&&!this.room)this.network.createRoom();});
    this.inventoryDetails=document.createElement('details');this.inventoryDetails.className='inventory-controls';this.controlsBody.append(this.inventoryDetails);
    this.inventorySummary=document.createElement('summary');this.inventoryDetails.append(this.inventorySummary);
    const inventoryLabel=document.createElement('label');inventoryLabel.htmlFor='inventory-picker';inventoryLabel.textContent='Your inventory';this.inventoryDetails.append(inventoryLabel);
    this.inventoryPicker=document.createElement('select');this.inventoryPicker.id='inventory-picker';this.inventoryDetails.append(this.inventoryPicker);
    this.placeButton=this.button(this.inventoryDetails,'Place from inventory',()=>{
      if(this.publicStreet||!this.connected||!this.room||!this.inventoryPicker.value)return;
      this.cancelRoute();this.resetPlacement();this.placingId=this.inventoryPicker.value;this.furnitureMessage='';this.updateFurnitureControls();
    });
    this.inventoryEmpty=element('inventory-empty',this.inventoryDetails);this.inventoryEmpty.textContent='Your inventory is empty.';
    this.placementToolbar=element('placement-toolbar',body);this.button(this.placementToolbar,'Cancel placement',()=>{this.resetPlacement();this.furnitureMessage='';this.updateFurnitureControls();});
    this.furnitureStatus=element('furniture-instruction',body);this.furnitureStatus.setAttribute('aria-live','polite');
    this.emptyRoom=element('empty-room',this.viewport);const title=element('empty-room-title',this.emptyRoom);title.textContent='No room is open';
    const copy=element('empty-room-copy',this.emptyRoom);copy.textContent='Your furniture is safe in your inventory. Create a room to place it.';
    this.roomWindow=new ChildWindow(this.controls);this.roomLauncher=this.button(this.viewport,'Room info',()=>this.openRoomWindow());this.roomLauncher.className='room-info-launch';this.roomLauncher.setAttribute('aria-controls',this.controls.id);
    this.controls.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();this.closeRoomWindow();}});
    if(!this.publicStreet)this.openRoomWindow();
  }
  private openRoomWindow(){if(!this.controls.open){if(typeof this.controls.show==='function')this.controls.show();else this.controls.setAttribute('open','');}this.roomWindow.open({x:window.innerWidth-376,y:chatBounds(window.innerWidth,window.innerHeight).h+12,w:360,h:480});this.roomLauncher.setAttribute('aria-expanded','true');}
  private closeRoomWindow(){this.roomWindow.close();this.resetPlacement();this.confirmingDelete=false;this.updateFurnitureControls();if(typeof this.controls.close==='function')this.controls.close();else this.controls.removeAttribute('open');this.roomLauncher.setAttribute('aria-expanded','false');this.roomLauncher.focus();}
  private updateFurnitureControls(){
    this.microWindow?.update(this.room,this.furnitureMessage);
    const selected=this.selectedFurniture(),canEdit=this.canEdit(),placing=this.isPlacing(),me=this.network?.getUserId();
    this.roomTitle.textContent=this.room?.name||'Rooms';
    this.controls.setAttribute('aria-label',`${this.room?.name||'Rooms'} · Room information`);
    this.ownerLabel.textContent=this.room?(this.publicStreet?'Public room · open to everyone':this.owner.id===me?'You own this room':`Room owner: ${this.owner.name||this.room.ownerName}`):'No room is open';
    this.world.hidden=!this.room;this.emptyRoom.hidden=!!this.room;
    this.controlsBody.hidden=placing;this.placementToolbar.hidden=!placing;this.roomFields.hidden=!this.room||this.publicStreet;this.createButton.hidden=!!this.room;this.createButton.disabled=!this.connected;
    this.picker.value=this.selectedId;this.picker.disabled=!selected;
    this.moveButton.disabled=!canEdit||!selected;this.rotateButton.disabled=!canEdit||!selected;
    this.pickupButton.disabled=!this.connected||!selected||!(canEdit||selected.ownerId===me);
    if(this.standButton)this.standButton.hidden=!this.local.seat;
    this.deleteButton.disabled=!canEdit;this.deleteConfirmation.hidden=!this.confirmingDelete||!canEdit;
    this.interactButton.hidden=!selected?.nft;this.interactButton.disabled=!canEdit||!selected?.nft||selected.nft.definition.states.length<2;
    this.furnitureDetails.textContent=selected?`Owned by ${selected.ownerName||'unknown player'} · Rotation ${selected.rotation+1} / ${furnitureRotationCount(selected)} · Tile ${selected.gx}, ${selected.gy} · Level ${selected.z??0}`:'';
    this.inventorySummary.textContent=`Inventory (${this.inventory.length})`;
    const previous=this.inventoryPicker.value;this.inventoryPicker.replaceChildren();
    for(const item of this.inventory){const option=document.createElement('option');option.value=item.id;option.textContent=FURNITURE_NAMES[item.kind];this.inventoryPicker.append(option);}
    if(this.inventory.some(item=>item.id===previous))this.inventoryPicker.value=previous;
    this.inventoryPicker.hidden=this.inventory.length===0;this.inventoryEmpty.hidden=this.inventory.length>0;this.placeButton.hidden=this.publicStreet||this.inventory.length===0;
    this.placeButton.disabled=this.publicStreet||!this.connected||!this.room||this.inventory.length===0;
    const placementItem=this.placingId?this.inventory.find(item=>item.id===this.placingId):selected;
    this.furnitureStatus.textContent=this.furnitureMessage||(placing?`Tap a tile, table or Stool to place ${this.placingCollectible?.name||(placementItem?FURNITURE_NAMES[placementItem.kind]:'the furniture')}. Escape cancels.`:!this.room?'Create a room or inspect your inventory.':this.publicStreet?'Explore the 64-tile microverse at the entrance.':canEdit?'Place on tables to stack. Walk up one level at a time: floor → Stool → table.':'You can place or collect your own items. The room owner can move and rotate furniture.');
  }
  private selectFurniture(id:string){if(!this.furniture.some(item=>item.id===id))return;this.selectedId=id;this.resetPlacement();this.furnitureMessage='';this.drawFurniture();}
  private marker(pos:Position,className:string,z=0,size=tileAt(pos,this.splits,this.floor)?.size||1){const marker=element(`floor-marker ${className}`,this.world),p=tilePosition(pos.x,pos.y);marker.style.left=`${p.left}px`;marker.style.top=`${p.top-z*HEIGHT_PIXELS}px`;Object.assign(marker.style,{width:64*size+'px',height:32*size+'px',marginLeft:-32*size+'px',marginTop:-16*size+'px'});marker.setAttribute('aria-hidden','true');return marker;}
  private drawFurniture(){
    for(const node of this.furnitureNodes)node.remove();this.furnitureNodes=[];for(const marker of this.markers)marker.remove();this.markers=[];
    if(!this.selectedFurniture())this.selectedId=this.furniture[0]?.id||'';this.picker.replaceChildren();
    for(const item of this.furniture){
      const option=document.createElement('option');option.value=item.id;option.textContent=`${furnitureName(item)}${item.ownerName?` · ${item.ownerName}`:''} · ${item.gx},${item.gy} · level ${item.z??0}`;this.picker.append(option);
      const art=item.nft?makeHabboFurniture(item):makeFurniture(item.kind,item.rotation),center=furnitureCenter(item),size=item.scale??1,shell=element('furniture-instance');shell.append(art);art.style.left='0px';art.style.top='0px';shell.style.transform='scale('+size+')';shell.dataset.scale=String(size);
      shell.dataset.furnitureId=item.id;shell.dataset.ownerId=item.ownerId||'';shell.dataset.gx=String(item.gx);shell.dataset.gy=String(item.gy);shell.dataset.z=String(item.z??0);shell.dataset.supportId=item.supportId||'';
      shell.setAttribute('role','button');shell.setAttribute('tabindex','0');shell.setAttribute('aria-label','Select '+furnitureName(item));
      shell.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();this.selectFurniture(item.id);}});
      position(shell,center.x,center.y,-(item.z??0)*HEIGHT_PIXELS,.5*size+(item.z??0)*.1);this.world.append(shell);this.furnitureNodes.push(shell);
      if(item.kind==='base-sofa'){
        const foreground=makeFurniture(item.kind,item.rotation),frontShell=element('furniture-instance');foreground.classList.add('sofa-foreground');frontShell.setAttribute('aria-hidden','true');foreground.dataset.sofaForeground=item.id;frontShell.append(foreground);foreground.style.left='0px';foreground.style.top='0px';frontShell.style.transform='scale('+size+')';
        const arms=foreground.querySelectorAll('.arm');arms[(item.rotation===0||item.rotation===3)?0:1]?.classList.add('sofa-front-part');if(item.rotation>=2)foreground.querySelector('.backrest')?.classList.add('sofa-front-part');
        frontShell.style.left=shell.style.left;frontShell.style.top=shell.style.top;frontShell.style.zIndex=String(Number(shell.style.zIndex)+2);this.world.append(frontShell);this.furnitureNodes.push(frontShell);
      }
      if(item.id===this.selectedId)for(const tile of furnitureTiles(item))this.markers.push(this.marker(tile,'selected-marker',item.z??0));
    }this.updateFurnitureControls();
  }
  private playerPositions(){return [this.local.grid,...[...this.remotes.values()].map(actor=>actor.grid)];}
  private clearGhost=()=>{for(const marker of this.ghostMarkers)marker.remove();this.ghostMarkers=[];};
  private candidate(gx:number,gy:number):FurnitureState|undefined{
    if(this.placingCollectible?.furniture){const asset=this.placingCollectible;return resolvePlacement({id:'preview-collectible',kind:'habbo-nft',gx,gy,rotation:0,nft:{asset,definition:asset.furniture!}},gx,gy,this.furniture,this.splits);}
    if(this.placingId){const item=this.inventory.find(item=>item.id===this.placingId);if(item)return resolvePlacement({...item,gx,gy,rotation:0},gx,gy,this.furniture,this.splits);}
    const selected=this.selectedFurniture();return selected?resolvePlacement(selected,gx,gy,this.furniture,this.splits):undefined;
  }
  private placeAt(gx:number,gy:number){if(!this.room||!this.connected)return;if(this.placingCollectible){const asset=this.placingCollectible;void this.network.walletRequest('wallet:place',{collection:asset.collection,tokenId:asset.tokenId,gx,gy}).then(()=>{if(this.disposed)return;this.resetPlacement();this.updateFurnitureControls();}).catch(error=>{if(this.disposed)return;this.furnitureMessage=error instanceof Error?error.message:'Could not place NFT furniture.';this.updateFurnitureControls();});return;}if(this.placingId)this.network.placeFurniture(this.placingId,gx,gy);else if(this.moveMode&&this.canEdit())this.network.moveFurniture(this.selectedId,gx,gy);}
  private handlePointerMove=(event:PointerEvent)=>{
    if(!this.isPlacing()||this.cameraGestures.active)return;const target=event.target as HTMLElement,tile=target.closest<HTMLElement>('.floor-tile'),node=target.closest<HTMLElement>('[data-furniture-id]');this.clearGhost();
    const item=this.furniture.find(i=>i.id===node?.dataset.furnitureId);
    const gx=item?.gx??(tile?Number(tile.dataset.x):NaN),gy=item?.gy??(tile?Number(tile.dataset.y):NaN);if(!Number.isFinite(gx)||!Number.isFinite(gy))return;
    const candidate=this.candidate(gx,gy);if(!candidate)return;
    const invalid=placementError(candidate,this.furniture,this.playerPositions(),this.splits);for(const pos of furnitureTiles(candidate))this.ghostMarkers.push(this.marker(pos,invalid?'invalid-marker':'valid-marker',candidate.z??0));
  };
  private fit = () => this.renderCamera();
  private moveCamera = (gesture: CameraGesture) => {
    this.clearGhost();
    const zoom = Math.min(250, Math.max(25, this.roomZoom * gesture.zoom));
    if (zoom !== this.roomZoom) {
      this.roomZoom = zoom;
      this.scaleWindow?.setView(Math.round(zoom), this.perspectiveLevel);
    }
    this.renderCamera(gesture);
  };
  private renderCamera(gesture?: CameraGesture) {
    const width = this.viewport.clientWidth || window.innerWidth;
    const height = this.viewport.clientHeight || windowArea(this.viewport).height;
    const fitted = Math.max(.25, Math.min((width - 32) / (this.publicStreet?288:680), (height - 190) / (this.publicStreet?200:440), 1.6));
    const scale=fitted*this.roomZoom/100*2**(this.perspectiveLevel-1),centerY=70+110*fitted+Math.max(0,height-190-430*fitted)/2+160*fitted;
    const following=this.perspectiveLevel>1,point=this.focus?tilePosition(this.focus.x,this.focus.y):following?{left:parseFloat(this.local.node.style.left)||0,top:parseFloat(this.local.node.style.top)||0}:this.publicStreet?tilePosition(5,4.5):{left:0,top:160};
    const chatHeight=chatBounds(width,height).h;
    const viewCenter=following||this.publicStreet?chatHeight+(height-chatHeight)*.5:centerY;
    const baseX = width / 2 - point.left * scale;
    const baseY = viewCenter - point.top * scale;
    if (gesture) {
      const bounds = this.viewport.getBoundingClientRect();
      const x = gesture.anchor.x - bounds.left;
      const y = gesture.anchor.y - bounds.top;
      const ratio = scale / this.camera.scale;
      this.cameraOffset = {
        x: x + (this.camera.x - x) * ratio + gesture.dx - baseX,
        y: y + (this.camera.y - y) * ratio + gesture.dy - baseY,
      };
    }
    this.camera = {x: baseX + this.cameraOffset.x, y: baseY + this.cameraOffset.y, scale};
    this.world.style.left = `${this.camera.x}px`;
    this.world.style.top = `${this.camera.y}px`;
    this.world.style.transform = `scale(${scale})`;this.world.style.setProperty('--world-scale',String(scale));this.world.dataset.perspective=String(this.perspectiveLevel);
  }
  setRoomZoom(percent:number){if(Number.isFinite(percent))this.roomZoom=Math.min(250,Math.max(25,Math.round(percent)));this.scaleWindow?.setView(this.roomZoom,this.perspectiveLevel);this.fit();return this.roomZoom;}
  setPerspective(level:number){this.perspectiveLevel=Math.max(1,Math.min(8,Math.round(level)||1));this.focus=undefined;this.roomZoom=100;this.cameraOffset={x:0,y:0};this.scaleWindow?.setView(100,this.perspectiveLevel);this.fit();return this.perspectiveLevel;}
  private createActor(name: string, color: number, grid: Position, direction: Direction,appearance?:AvatarAppearance): Actor {
    const node = makeAvatar(name, color,appearance); setAvatarDirection(node,direction);
    const height=surfaceAt(grid,this.furniture).height;node.dataset.height=String(height);position(node,grid.x,grid.y,-height*HEIGHT_PIXELS,1+height*.1);this.world.append(node);
    return { node, grid: { ...grid },motion:new AvatarMotion(node,()=>{if(this.local?.node===node&&this.perspectiveLevel>1)this.fit();}) };
  }
  private reconcile(players: Record<string, Player>) {
    const id = this.network.getSocketId();
    for (const remoteId of this.remotes.keys()) if (!players[remoteId] || remoteId === id) this.removeRemote(remoteId);
    for (const player of Object.values(players)) {
      if (player.id === id) { this.cancelRoute();this.local.grid = { ...player.position };this.local.seat=player.seat;setAvatarSitting(this.local.node,!!player.seat); this.positionActor(this.local);setAvatarDirection(this.local.node,player.direction);if(player.appearance){this.appearance={...player.appearance};applyAvatarAppearance(this.local.node,player.appearance);} }
      else if (this.remotes.has(player.id)) {const actor=this.remotes.get(player.id)!;actor.seat=player.seat;setAvatarSitting(actor.node,!!player.seat);if(player.seat){actor.grid={...player.position};setAvatarDirection(actor.node,player.direction);this.positionActor(actor);}else this.moveActor(actor,player.position,player.direction);if(player.appearance)applyAvatarAppearance(actor.node,player.appearance);}
      else this.addRemote(player);
      const actor=player.id===id?this.local:this.remotes.get(player.id);if(actor)applyCollectibleAvatar(actor.node,player.collectibleAvatar||null);
    }
    this.updateCount();

  }
  private addRemote(player: Player) {
    if (player.id === this.network.getSocketId() || this.remotes.has(player.id)) return;
    const colors = [0xff9ff3, 0x48dbfb, 0xfeca57, 0x54a0ff];
    let hash = 0; for (const c of player.id) hash = (hash * 31 + c.charCodeAt(0)) | 0;
    const actor = this.createActor(player.name, colors[Math.abs(hash) % colors.length], player.position, player.direction,player.appearance);
    applyCollectibleAvatar(actor.node,player.collectibleAvatar||null);actor.seat=player.seat;setAvatarSitting(actor.node,!!player.seat);this.positionActor(actor);
    this.remotes.set(player.id, actor);
  }
  private removeRemote(id: string) {
    const actor = this.remotes.get(id); if (!actor) return;
    if (actor.timer) { clearTimeout(actor.timer); this.timers.delete(actor.timer); }
    actor.motion.destroy();disposeAvatar(actor.node);actor.node.remove(); this.remotes.delete(id);
  }
  private moveActor(actor: Actor, grid: Position, direction?: Direction) {
    actor.seat=undefined;setAvatarSitting(actor.node,false);
    setAvatarDirection(actor.node,direction||directionForMove(actor.grid,grid));
    actor.grid = { ...grid }; this.positionActor(actor,true);
    setAvatarWalking(actor.node,true);
    if (actor.timer) { clearTimeout(actor.timer); this.timers.delete(actor.timer); }
    actor.timer = this.later(() => setAvatarWalking(actor.node,false), 240);
  }
  private positionActor(actor:Actor,animate=false){
    const sofa=actor.seat&&this.furniture.find(i=>i.id===actor.seat!.furnitureId);const height=sofa?(sofa.z??0):surfaceAt(actor.grid,this.furniture).height,size=sofa?.scale??tileAt(actor.grid,this.splits,this.floor)?.size??1;actor.node.style.transformOrigin='0 0';actor.node.style.transform='scale('+size+')';actor.node.dataset.scale=String(size);actor.node.dataset.height=String(height);actor.node.dataset.gx=String(actor.grid.x);actor.node.dataset.gy=String(actor.grid.y);
    if(sofa&&actor.seat){const anchor=sofaSeatAnchor(sofa,actor.seat,this.splits);position(actor.node,anchor.center.x,anchor.center.y,-height*HEIGHT_PIXELS,.5*size+height*.1);actor.node.style.left=`${tilePosition(anchor.center.x,anchor.center.y).left+anchor.x}px`;actor.node.style.top=`${tilePosition(anchor.center.x,anchor.center.y).top-height*HEIGHT_PIXELS+anchor.y+24*size}px`;if(sofa.nft){const center=furnitureCenter(sofa),behind=[6,0].includes(furnitureDirection(sofa));actor.node.style.zIndex=String(worldDepth(center.x,center.y,.5*size+height*.1)+(behind?-1:1));}else actor.node.style.zIndex=String(Number(actor.node.style.zIndex)+1);}
    else position(actor.node,actor.grid.x,actor.grid.y,-height*HEIGHT_PIXELS,size+height*.1);
    actor.motion.to({x:parseFloat(actor.node.style.left),y:parseFloat(actor.node.style.top),depth:Number(actor.node.style.zIndex)},animate);
  }
  private applyPosture(player:Player){const actor=player.id===this.network.getSocketId()?this.local:this.remotes.get(player.id);if(!actor)return;const after=actor===this.local?this.afterStand:undefined;if(actor===this.local)this.cancelRoute();if(actor.timer){clearTimeout(actor.timer);this.timers.delete(actor.timer);}actor.grid={...player.position};actor.seat=player.seat;setAvatarWalking(actor.node,false);setAvatarDirection(actor.node,player.direction);setAvatarSitting(actor.node,!!player.seat);this.positionActor(actor);this.updateFurnitureControls();if(!player.seat)after?.();}
  private seatingPlayers():Player[]{return [this.local,...this.remotes.values()].map((a,index)=>({id:index===0?this.network.getSocketId()||'local':`remote-${index}`,name:'',position:a.grid,direction:'south',seat:a.seat}));}
  private requestSit(id:string){
    this.cancelRoute();if(!this.room||!this.connected)return;if(this.local.seat){this.afterStand=()=>this.requestSit(id);this.network.stand();return;}
    const sofa=this.furniture.find(i=>i.id===id);if(!sofa||!isSeat(sofa))return;
    const candidates=sofaSeats(sofa,this.splits).map(s=>({...s,path:findPlayerPath(this.local.grid,s.tile,this.furniture,this.seatingPlayers(),this.splits,this.floor)})).filter(s=>s.path!==null).sort((a,b)=>a.path!.length-b.path!.length);
    const chosen=candidates[0];if(!chosen){this.furnitureMessage='No free, reachable seat. Clear an adjacent space at the same level.';this.updateFurnitureControls();return;}
    this.walkTo(chosen.tile);
  }
  private cancelRoute(){if(this.routeTimer){clearTimeout(this.routeTimer);this.timers.delete(this.routeTimer);}this.routeTimer=undefined;this.route=[];this.afterStand=undefined;}
  private walkTo(grid:Position){
    this.clearHeldKeys();this.cancelRoute();if(!this.room||!this.connected)return;if(this.local.seat){this.afterStand=()=>this.walkTo(grid);this.network.stand(grid);return;}const path=findPlayerPath(this.local.grid,grid,this.furniture,this.seatingPlayers(),this.splits,this.floor);
    if(path===null){this.furnitureMessage='No walking route. Use a lower Stool or another one-level step to climb.';this.updateFurnitureControls();return;}
    this.furnitureMessage='';this.updateFurnitureControls();this.route=path;this.advanceRoute();
  }
  private advanceRoute=()=>{
    this.routeTimer=undefined;if(!this.route.length)return;
    const delay=WALK_STEP_MS-(Date.now()-this.lastMove);if(delay>0){this.routeTimer=this.later(this.advanceRoute,delay+5);return;}
    const next=this.route.shift()!;if(!this.moveLocal(next)){this.cancelRoute();return;}
    if(this.route.length)this.routeTimer=this.later(this.advanceRoute,WALK_STEP_MS);
  };
  private moveLocal(grid: Position, direction?: Direction):boolean {
    if(!this.room||!this.connected||this.local.seat||Date.now()-this.lastMove<WALK_STEP_MS)return false;
    const player:Player={id:this.network.getSocketId()||'local',name:'',position:this.local.grid,direction:'south'};const result=movePlayer(player,grid,this.furniture,this.seatingPlayers(),this.splits,this.floor);if(!result.ok)return false;
    this.lastMove=Date.now();if(!result.player.seat)this.moveActor(this.local,grid);
    this.network.sendMove(grid.x,grid.y,result.player.direction);return true;
  }
  private pointerTile(event:MouseEvent){const r=this.viewport.getBoundingClientRect();return floorAtScreen(event.clientX,event.clientY,r.left+this.camera.x,r.top+this.camera.y,this.camera.scale,this.splits,this.floor);}
  private handleClick=(event:MouseEvent)=>{
    const target=event.target as HTMLElement;if(target.closest('.hotel-child-window,.taskbar,button,input,select,textarea,a,.empty-room'))return;
    const node=target.closest<HTMLElement>('[data-furniture-id]'),item=node&&this.furniture.find(f=>f.id===node.dataset.furnitureId),direct=target.closest<HTMLElement>('.floor-tile');
    const tile=event.clientX||event.clientY?this.pointerTile(event):direct?tileAt({x:Number(direct.dataset.x),y:Number(direct.dataset.y)},this.splits,this.floor):null;
    if(tile){if(this.microWindow?.chooseFromFloor(tile.id))return;if(this.isPlacing()){this.placeAt(tile.x,tile.y);return;}if(item)this.selectFurniture(item.id);this.viewport.focus({preventScroll:true});this.walkTo({x:tile.x,y:tile.y});return;}
    if(item){if(this.isPlacing())this.placeAt(item.gx,item.gy);else{this.selectFurniture(item.id);if(isSeat(item))this.requestSit(item.id);else if(isSurface(item))this.walkTo({x:item.gx,y:item.gy});}}
  };
  private handleKey = (event: KeyboardEvent) => {
    if(event.key==='Escape'&&this.isPlacing()){event.preventDefault();this.resetPlacement();this.furnitureMessage='';this.updateFurnitureControls();return;}
    const target = event.target as HTMLElement;
    if (target.closest('dialog,input,textarea,select,button,[contenteditable=true],[role=log]') || event.altKey || event.ctrlKey || event.metaKey) return;
    const keys: Record<string, KeyDirection> = { ArrowUp: 'up', w: 'up', ArrowDown: 'down', s: 'down', ArrowLeft: 'left', a: 'left', ArrowRight: 'right', d: 'right' };
    const key = keys[event.key]; if (!key) return; event.preventDefault();
    if(this.local.seat){this.cancelRoute();const delta=getMoveDelta(key);this.network.stand(nextFloorTile(this.local.grid,delta,this.splits,this.floor));return;}
    this.cancelRoute();if(this.heldKeys.has(key))return;this.heldKeys.add(key);if(!this.keyTimer)this.advanceHeldKeys();
  };
  private advanceHeldKeys=()=>{this.keyTimer=undefined;if(!this.heldKeys.size)return;const target=document.activeElement as HTMLElement|null;if(target?.closest('input,textarea,select,[contenteditable]')){this.clearHeldKeys();return;}const delta={dx:Number(this.heldKeys.has('right'))-Number(this.heldKeys.has('left')),dy:Number(this.heldKeys.has('down'))-Number(this.heldKeys.has('up'))};if(delta.dx||delta.dy)this.moveLocal(nextFloorTile(this.local.grid,delta,this.splits,this.floor));this.keyTimer=this.later(this.advanceHeldKeys,WALK_STEP_MS);};
  private clearHeldKeys=()=>{this.heldKeys.clear();if(this.keyTimer){clearTimeout(this.keyTimer);this.timers.delete(this.keyTimer);}this.keyTimer=undefined;};
  private handleKeyUp=(event:KeyboardEvent)=>{const keys:Record<string,KeyDirection>={ArrowUp:'up',w:'up',ArrowDown:'down',s:'down',ArrowLeft:'left',a:'left',ArrowRight:'right',d:'right'};if(keys[event.key])this.heldKeys.delete(keys[event.key]);if(!this.heldKeys.size)this.clearHeldKeys();};
  private later(fn: () => void, delay: number) {
    const timer = setTimeout(() => { this.timers.delete(timer); if (!this.disposed) fn(); }, delay);
    this.timers.add(timer); return timer;
  }
  private updateCount() { this.onCount?.(this.remotes.size + 1);this.taskbar?.setPlayerCount(this.remotes.size+1); }
  setChatCallback(cb: (messages: PositionedChatMessage[]) => void) { this.onChat = cb; cb([...this.messages]); }
  getTaskbarVolumeHost(){return this.taskbar!.volumeHost;}
  setPlayerCountCallback(cb: (n: number) => void) { this.onCount = cb; this.updateCount(); }
  setDJCallback(cb: (state: DJState) => void) { this.onDJ = cb; if (this.dj) cb(this.dj); }
  sendChat(content: string) {
    if(content.trim()===':admin 369'){
      if(this.connected)this.network.saveAvatar(heatherAppearance());
      else this.status.textContent='Reconnect before changing your outfit.';
      return;
    }
    if(this.room)this.network.sendChat(content);
    else {this.furnitureMessage="Create a room before chatting.";this.updateFurnitureControls();}
  }
  getOverlayParent(){return this.viewport;}
  getNetwork() { return this.network; }
  destroy() {
    if (this.disposed) return; this.disposed = true;
    this.cameraGestures.destroy();
    for (const timer of this.timers) clearTimeout(timer);
    this.timers.clear(); this.observer?.disconnect();
    this.viewport.removeEventListener('click', this.handleClick);
    this.viewport.removeEventListener('pointermove',this.handlePointerMove);
    this.viewport.removeEventListener('pointerleave',this.clearGhost);
    window.removeEventListener('keydown', this.handleKey);window.removeEventListener('keyup',this.handleKeyUp);window.removeEventListener('blur',this.clearHeldKeys); window.removeEventListener('resize', this.fit);window.removeEventListener('bando-work-area-change',this.fit);
    this.local.motion.destroy();disposeAvatar(this.local.node);for(const actor of this.remotes.values()){actor.motion.destroy();disposeAvatar(actor.node);}this.taskbar?.destroy();this.navigation?.destroy();this.scaleWindow?.destroy();this.microWindow?.destroy();this.wardrobe.destroy();this.walletWindow?.destroy();this.roomWindow.destroy();this.network.disconnect(); this.viewport.remove();
  }
}
