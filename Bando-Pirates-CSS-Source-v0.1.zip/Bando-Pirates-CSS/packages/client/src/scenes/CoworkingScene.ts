import { directionForMove,defaultAppearance,type AvatarAppearance,canStep, findWalkPath, surfaceAt, isSurface, resolvePlacement, HEIGHT_PIXELS, furnitureTiles, furnitureCenter, placementError, FURNITURE_NAMES, type FurnitureState, type RoomOwner, type RoomInfo, type InventoryEntry, getMoveDelta, applyMove, type KeyDirection, type Player, type ChatMessage, type Direction, type DJState, type PomodoroState, type Position } from '@cocoworking/shared';
import { NetworkManager } from '../game-logic/NetworkManager';
import { ProximityManager } from '../game-logic/ProximityManager';
import { element, makeAvatar, applyAvatarAppearance,setAvatarDirection,setAvatarWalking,disposeAvatar,makeFurniture, populateRoom, position, tilePosition } from '../artwork/elements';
import '../artwork/artwork.css';
import {Wardrobe} from '../artwork/Wardrobe';
import {ChildWindow} from '../theme/ChildWindow';
import {sofaSeats,findPlayerPath,movePlayer,sofaSeatAnchor,type SofaSeatState} from '@cocoworking/shared';
import {setAvatarSitting} from '../artwork/avatar';

interface Actor { node: HTMLElement; grid: Position;seat?:SofaSeatState; timer?: ReturnType<typeof setTimeout> }

/** The network and UI-facing API is retained; the artwork is live HTML/CSS. */
export class CoworkingScene {
  private viewport: HTMLElement;
  private world: HTMLElement;
  private local: Actor;
  private wardrobe:Wardrobe;
  private appearance:AvatarAppearance=defaultAppearance();
  private remotes = new Map<string, Actor>();
  private network: NetworkManager;
  private proximity = new ProximityManager();
  private observer?: ResizeObserver;
  private timers = new Set<ReturnType<typeof setTimeout>>();
  private disposed = false;
  private lastMove = 0;
  private heldKeys=new Set<KeyDirection>();
  private routeTimer?:ReturnType<typeof setTimeout>;
  private route:Position[]=[];
  private afterStand?:()=>void;private standButton!:HTMLButtonElement;
  private messages: ChatMessage[] = [];
  private dj?: DJState;
  private pomodoro?: PomodoroState;
  private onChat?: (messages: ChatMessage[]) => void;
  private onCount?: (n: number) => void;
  private onDJ?: (state: DJState) => void;
  private onPomodoro?: (state: PomodoroState) => void;
  private onPomodoroEnd?: () => void;
  private onProximity?: (ids: string[]) => void;
  private status: HTMLElement;
  private furniture: FurnitureState[] = [];
  private room:RoomInfo|null=null;
  private inventory:InventoryEntry[]=[];
  private placingId:string|null=null;
  private confirmingDelete=false;
  private furnitureNodes: HTMLElement[] = [];
  private selectedId = 'base-sofa';
  private owner: RoomOwner = {id:null,name:null};
  private connected = false;
  private moveMode = false;
  private furnitureMessage = '';
  private picker!: HTMLSelectElement;
  private moveButton!: HTMLButtonElement;
  private rotateButton!: HTMLButtonElement;
  private ownerLabel!: HTMLElement;
  private furnitureStatus!: HTMLElement;
  private furnitureDetails!: HTMLElement;
  private markers: HTMLElement[] = [];
  private ghostMarkers: HTMLElement[] = [];
  private controls!:HTMLDialogElement;private roomWindow!:ChildWindow;private roomLauncher!:HTMLButtonElement;private controlsBody!:HTMLElement;private roomTitle!:HTMLElement;private roomFields!:HTMLElement;
  private pickupButton!:HTMLButtonElement;private deleteButton!:HTMLButtonElement;private deleteConfirmation!:HTMLElement;private createButton!:HTMLButtonElement;
  private inventoryDetails!:HTMLDetailsElement;private inventorySummary!:HTMLElement;private inventoryPicker!:HTMLSelectElement;private inventoryEmpty!:HTMLElement;private placeButton!:HTMLButtonElement;
  private placementToolbar!:HTMLElement;private emptyRoom!:HTMLElement;

  constructor(parent: HTMLElement, playerName: string, playerColor: number, private offline = false) {
    this.viewport = element('css-room css-room-viewport', parent);
    this.viewport.tabIndex = 0;
    this.viewport.setAttribute('aria-label', 'Isometric room. Click a floor tile or use arrow keys to walk.');
    this.world = element('css-world', this.viewport);
    populateRoom(this.world);
    this.local = this.createActor(playerName, playerColor, { x: 5, y: 5 }, 'south');
    this.wardrobe=new Wardrobe(this.viewport,appearance=>{if(this.connected)this.network.saveAvatar(appearance);else this.wardrobe.failed('Reconnect before saving your look.');});
    const wardrobeButton=this.button(this.viewport,'Wardrobe',()=>{this.cancelRoute();this.wardrobe.open(this.appearance);});wardrobeButton.className='wardrobe-launch';
    this.createFurnitureControls();
    this.standButton=this.button(this.viewport,'Stand up',()=>{this.cancelRoute();this.network.stand();});this.standButton.className='stand-up-launch';this.standButton.hidden=true;
    this.drawFurniture();
    const help = element('room-help', this.viewport);
    help.textContent = 'BANDO PIRATES · Click a tile to walk · Click a sofa to sit · Arrows / WASD';
    this.status = element('room-status', this.viewport);
    this.status.textContent = 'Connecting to room…';
    this.viewport.addEventListener('click', this.handleClick);
    this.viewport.addEventListener('pointermove',this.handlePointerMove);
    this.viewport.addEventListener('pointerleave',this.clearGhost);
    window.addEventListener('keydown', this.handleKey);window.addEventListener('keyup',this.handleKeyUp);window.addEventListener('blur',this.clearHeldKeys);
    window.addEventListener('resize', this.fit);
    if (typeof ResizeObserver !== 'undefined') {
      this.observer = new ResizeObserver(this.fit); this.observer.observe(parent);
    }
    this.fit();
    // In development Vite proxies Socket.IO to the existing Node server.
    this.network = new NetworkManager(window.location.origin, playerName, {
      onPosture:player=>this.applyPosture(player),
      onPostureBlocked:message=>{this.cancelRoute();this.furnitureMessage=message;this.updateFurnitureControls();},
      onAppearance:(id,appearance)=>{const actor=id===this.network.getSocketId()?this.local:this.remotes.get(id);if(actor)applyAvatarAppearance(actor.node,appearance);if(id===this.network.getSocketId())this.appearance={...appearance};},
      onAvatarSaved:()=>this.wardrobe.saved(),
      onAvatarBlocked:(message)=>this.wardrobe.failed(message),
      onRoomState: (players) => this.reconcile(players),
      onIdentity:()=>this.updateFurnitureControls(),
      onRoomInfo:(room)=>{
        this.room=room;this.confirmingDelete=false;
        if(!room){this.resetPlacement();this.messages=[];this.onChat?.([]);for(const bubble of this.world.querySelectorAll('.speech-bubble'))bubble.remove();}
        this.updateFurnitureControls();
      },
      onInventory:(items)=>{this.inventory=items.map(item=>({...item}));this.updateFurnitureControls();},
      onWorldNotice:(message)=>{this.furnitureMessage=message;this.updateFurnitureControls();},
      onFurnitureState: (furniture) => {
        this.cancelRoute();this.furniture=furniture.map(item=>({...item}));this.resetPlacement();this.furnitureMessage='';this.drawFurniture();this.positionActor(this.local);for(const actor of this.remotes.values())this.positionActor(actor);
      },
      onRoomOwner: (owner) => {
        this.owner={...owner};
        if(this.moveMode&&owner.id!==this.network?.getUserId())this.resetPlacement();
        this.updateFurnitureControls();
      },
      onFurnitureBlocked: (message) => { this.furnitureMessage=message; this.updateFurnitureControls(); },
      onPlayerCorrect: (pos) => { this.cancelRoute();this.local.grid = {...pos}; this.positionActor(this.local); },
      onPlayerJoin: (player) => { this.addRemote(player); this.updateCount(); },
      onPlayerLeave: (id) => { this.removeRemote(id); this.updateCount(); },
      onPlayerMove: (id, x, y,direction) => {
        const actor = this.remotes.get(id); if (!actor) return;
        this.moveActor(actor, { x, y },direction);
        this.proximity.updateRemotePlayer(id, `coco-${id}`, { x, y });
      },
      onChat: (message) => {
        this.messages = [...this.messages, message].slice(-50);
        this.onChat?.([...this.messages]);
        const actor = message.playerId === this.network.getSocketId() ? this.local : this.remotes.get(message.playerId);
        if (actor) this.showBubble(actor, message.content);
      },
      onPeerId: (id, peerId) => {
        const actor = this.remotes.get(id); if (actor) this.proximity.updateRemotePlayer(id, peerId, actor.grid);
      },
      onDJState: (state) => { this.dj = state; this.onDJ?.(state); },
      onPomodoroUpdate: (state) => { this.pomodoro = state; this.onPomodoro?.(state); },
      onPomodoroEnd: () => { this.pomodoro = undefined; this.onPomodoroEnd?.(); },
      onConnection: (connected) => {
        this.connected=connected;
        this.status.textContent=connected ? (this.offline ? 'Local preview · offline' : 'Connected · live multiplayer') : 'Disconnected · reconnecting…';
        if(!connected){this.resetPlacement();this.cancelRoute();}
        this.updateFurnitureControls();
      },
    }, this.offline,defaultAppearance(playerColor));
  }
  private canEdit(){return this.connected&&!!this.room&&this.owner.id===this.network?.getUserId();}
  private selectedFurniture(){return this.furniture.find(item=>item.id===this.selectedId);}
  private isPlacing(){return this.moveMode||this.placingId!==null;}
  private resetPlacement(){this.moveMode=false;this.placingId=null;this.clearGhost();}
  private button(parent:HTMLElement,text:string,action:()=>void){const button=document.createElement('button');button.type='button';button.textContent=text;button.addEventListener('click',action);parent.append(button);return button;}
  private createFurnitureControls(){
    this.controls=document.createElement('dialog');this.controls.className='furniture-controls window active bevel';this.controls.id='room-info-window';this.controls.setAttribute('aria-label','Room information');this.viewport.append(this.controls);
    const header=element('titlebar',this.controls);this.roomTitle=element('window-title room-title',header);const buttons=element('window-controls',header);
    const close=this.button(buttons,'×',()=>this.closeRoomWindow());close.className='window-control window-close';close.setAttribute('aria-label','Close room information');
    const body=element('window-body',this.controls);this.ownerLabel=element('room-owner',body);
    this.controlsBody=element('furniture-body',body);
    this.roomFields=element('room-furniture-fields',this.controlsBody);
    const label=document.createElement('label');label.htmlFor='furniture-picker';label.textContent='Furniture';this.roomFields.append(label);
    this.picker=document.createElement('select');this.picker.id='furniture-picker';this.roomFields.append(this.picker);this.picker.addEventListener('change',()=>this.selectFurniture(this.picker.value));
    this.moveButton=this.button(this.roomFields,'Move furniture',()=>{if(!this.canEdit())return;this.cancelRoute();this.moveMode=true;this.placingId=null;this.furnitureMessage='';this.clearGhost();this.updateFurnitureControls();});
    this.rotateButton=this.button(this.roomFields,'Rotate furniture ↻',()=>{if(!this.canEdit())return;this.resetPlacement();this.network.rotateFurniture(this.selectedId);});
    this.pickupButton=this.button(this.roomFields,'Pick up',()=>{const item=this.selectedFurniture();if(item&&(this.canEdit()||item.ownerId===this.network.getUserId()))this.network.pickUpFurniture(item.id);});
    this.furnitureDetails=element('furniture-details',this.roomFields);
    this.deleteButton=this.button(this.roomFields,'Delete room',()=>{if(this.canEdit()){this.confirmingDelete=true;this.updateFurnitureControls();}});
    this.deleteConfirmation=element('room-delete-confirmation',this.roomFields);
    const warning=element('delete-room-copy',this.deleteConfirmation);warning.textContent='Delete this room? All furniture will return to its owners’ inventories.';
    this.button(this.deleteConfirmation,'Delete room and return furniture',()=>{if(this.canEdit()){this.confirmingDelete=false;this.network.deleteRoom();}});
    this.button(this.deleteConfirmation,'Keep room',()=>{this.confirmingDelete=false;this.updateFurnitureControls();});
    this.createButton=this.button(this.controlsBody,'Create room',()=>{if(this.connected&&!this.room)this.network.createRoom();});
    this.inventoryDetails=document.createElement('details');this.inventoryDetails.className='inventory-controls';this.controlsBody.append(this.inventoryDetails);
    this.inventorySummary=document.createElement('summary');this.inventoryDetails.append(this.inventorySummary);
    const inventoryLabel=document.createElement('label');inventoryLabel.htmlFor='inventory-picker';inventoryLabel.textContent='Your inventory';this.inventoryDetails.append(inventoryLabel);
    this.inventoryPicker=document.createElement('select');this.inventoryPicker.id='inventory-picker';this.inventoryDetails.append(this.inventoryPicker);
    this.placeButton=this.button(this.inventoryDetails,'Place from inventory',()=>{
      if(!this.connected||!this.room||!this.inventoryPicker.value)return;
      this.cancelRoute();this.resetPlacement();this.placingId=this.inventoryPicker.value;this.furnitureMessage='';this.updateFurnitureControls();
    });
    this.inventoryEmpty=element('inventory-empty',this.inventoryDetails);this.inventoryEmpty.textContent='Your inventory is empty.';
    this.placementToolbar=element('placement-toolbar',body);this.button(this.placementToolbar,'Cancel placement',()=>{this.resetPlacement();this.furnitureMessage='';this.updateFurnitureControls();});
    this.furnitureStatus=element('furniture-instruction',body);this.furnitureStatus.setAttribute('aria-live','polite');
    this.emptyRoom=element('empty-room',this.viewport);const title=element('empty-room-title',this.emptyRoom);title.textContent='No room is open';
    const copy=element('empty-room-copy',this.emptyRoom);copy.textContent='Your furniture is safe in your inventory. Create a room to place it.';
    this.roomWindow=new ChildWindow(this.controls);this.roomLauncher=this.button(this.viewport,'Room info',()=>this.openRoomWindow());this.roomLauncher.className='room-info-launch';this.roomLauncher.setAttribute('aria-controls',this.controls.id);
    this.controls.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();this.closeRoomWindow();}});
    this.openRoomWindow();
  }
  private openRoomWindow(){if(!this.controls.open){if(typeof this.controls.show==='function')this.controls.show();else this.controls.setAttribute('open','');}this.roomWindow.open({x:window.innerWidth-376,y:65,w:360,h:480});this.roomLauncher.setAttribute('aria-expanded','true');}
  private closeRoomWindow(){this.roomWindow.close();this.resetPlacement();this.confirmingDelete=false;this.updateFurnitureControls();if(typeof this.controls.close==='function')this.controls.close();else this.controls.removeAttribute('open');this.roomLauncher.setAttribute('aria-expanded','false');this.roomLauncher.focus();}
  private updateFurnitureControls(){
    const selected=this.selectedFurniture(),canEdit=this.canEdit(),placing=this.isPlacing(),me=this.network?.getUserId();
    this.roomTitle.textContent=this.room?.name||'Rooms';
    this.controls.setAttribute('aria-label',`${this.room?.name||'Rooms'} · Room information`);
    this.ownerLabel.textContent=this.room?(this.owner.id===me?'You own this room':`Room owner: ${this.owner.name||this.room.ownerName}`):'No room is open';
    this.world.hidden=!this.room;this.emptyRoom.hidden=!!this.room;
    this.controlsBody.hidden=placing;this.placementToolbar.hidden=!placing;this.roomFields.hidden=!this.room;this.createButton.hidden=!!this.room;this.createButton.disabled=!this.connected;
    this.picker.value=this.selectedId;this.picker.disabled=!selected;
    this.moveButton.disabled=!canEdit||!selected;this.rotateButton.disabled=!canEdit||!selected;
    this.pickupButton.disabled=!this.connected||!selected||!(canEdit||selected.ownerId===me);
    if(this.standButton)this.standButton.hidden=!this.local.seat;
    this.deleteButton.disabled=!canEdit;this.deleteConfirmation.hidden=!this.confirmingDelete||!canEdit;
    this.furnitureDetails.textContent=selected?`Owned by ${selected.ownerName||'unknown player'} · Rotation ${selected.rotation+1} / 4 · Tile ${selected.gx}, ${selected.gy} · Level ${selected.z??0}`:'';
    this.inventorySummary.textContent=`Inventory (${this.inventory.length})`;
    const previous=this.inventoryPicker.value;this.inventoryPicker.replaceChildren();
    for(const item of this.inventory){const option=document.createElement('option');option.value=item.id;option.textContent=FURNITURE_NAMES[item.kind];this.inventoryPicker.append(option);}
    if(this.inventory.some(item=>item.id===previous))this.inventoryPicker.value=previous;
    this.inventoryPicker.hidden=this.inventory.length===0;this.inventoryEmpty.hidden=this.inventory.length>0;this.placeButton.hidden=this.inventory.length===0;
    this.placeButton.disabled=!this.connected||!this.room||this.inventory.length===0;
    const placementItem=this.placingId?this.inventory.find(item=>item.id===this.placingId):selected;
    this.furnitureStatus.textContent=this.furnitureMessage||(placing?`Tap a tile, table or Stool to place ${placementItem?FURNITURE_NAMES[placementItem.kind]:'the furniture'}. Escape cancels.`:!this.room?'Create a room or inspect your inventory.':canEdit?'Place on tables to stack. Walk up one level at a time: floor → Stool → table.':'You can place or collect your own items. The room owner can move and rotate furniture.');
  }
  private selectFurniture(id:string){if(!this.furniture.some(item=>item.id===id))return;this.selectedId=id;this.resetPlacement();this.furnitureMessage='';this.drawFurniture();}
  private marker(pos:Position,className:string,z=0){const marker=element(`floor-marker ${className}`,this.world),p=tilePosition(pos.x,pos.y);marker.style.left=`${p.left}px`;marker.style.top=`${p.top-z*HEIGHT_PIXELS}px`;marker.setAttribute('aria-hidden','true');return marker;}
  private drawFurniture(){
    for(const node of this.furnitureNodes)node.remove();this.furnitureNodes=[];for(const marker of this.markers)marker.remove();this.markers=[];
    if(!this.selectedFurniture())this.selectedId=this.furniture[0]?.id||'';this.picker.replaceChildren();
    for(const item of this.furniture){
      const option=document.createElement('option');option.value=item.id;option.textContent=`${FURNITURE_NAMES[item.kind]}${item.ownerName?` · ${item.ownerName}`:''} · ${item.gx},${item.gy} · level ${item.z??0}`;this.picker.append(option);
      const art=makeFurniture(item.kind,item.rotation),center=furnitureCenter(item);art.dataset.furnitureId=item.id;art.dataset.ownerId=item.ownerId||'';art.dataset.gx=String(item.gx);art.dataset.gy=String(item.gy);art.dataset.z=String(item.z??0);art.dataset.supportId=item.supportId||'';
      art.setAttribute('role','button');art.setAttribute('tabindex','0');art.setAttribute('aria-label',`Select ${FURNITURE_NAMES[item.kind]}`);
      art.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();this.selectFurniture(item.id);}});
      position(art,center.x,center.y,-(item.z??0)*HEIGHT_PIXELS,.5+(item.z??0)*.1);this.world.append(art);this.furnitureNodes.push(art);
      if(item.kind==='base-sofa'){
        const foreground=makeFurniture(item.kind,item.rotation);foreground.classList.add('sofa-foreground');foreground.setAttribute('aria-hidden','true');foreground.dataset.sofaForeground=item.id;
        const arms=foreground.querySelectorAll('.arm');arms[(item.rotation===0||item.rotation===3)?0:1]?.classList.add('sofa-front-part');if(item.rotation>=2)foreground.querySelector('.backrest')?.classList.add('sofa-front-part');
        foreground.style.left=art.style.left;foreground.style.top=art.style.top;foreground.style.zIndex=String(Number(art.style.zIndex)+2);this.world.append(foreground);this.furnitureNodes.push(foreground);
      }
      if(item.id===this.selectedId)for(const tile of furnitureTiles(item))this.markers.push(this.marker(tile,'selected-marker',item.z??0));
    }this.updateFurnitureControls();
  }
  private playerPositions(){return [this.local.grid,...[...this.remotes.values()].map(actor=>actor.grid)];}
  private clearGhost=()=>{for(const marker of this.ghostMarkers)marker.remove();this.ghostMarkers=[];};
  private candidate(gx:number,gy:number):FurnitureState|undefined{
    if(this.placingId){const item=this.inventory.find(item=>item.id===this.placingId);if(item)return resolvePlacement({...item,gx,gy,rotation:0},gx,gy,this.furniture);}
    const selected=this.selectedFurniture();return selected?resolvePlacement(selected,gx,gy,this.furniture):undefined;
  }
  private placeAt(gx:number,gy:number){if(!this.room||!this.connected)return;if(this.placingId)this.network.placeFurniture(this.placingId,gx,gy);else if(this.moveMode&&this.canEdit())this.network.moveFurniture(this.selectedId,gx,gy);}
  private handlePointerMove=(event:PointerEvent)=>{
    if(!this.isPlacing())return;const target=event.target as HTMLElement,tile=target.closest<HTMLElement>('.floor-tile'),node=target.closest<HTMLElement>('[data-furniture-id]');this.clearGhost();
    const item=this.furniture.find(i=>i.id===node?.dataset.furnitureId);
    const gx=item?.gx??(tile?Number(tile.dataset.x):NaN),gy=item?.gy??(tile?Number(tile.dataset.y):NaN);if(!Number.isFinite(gx)||!Number.isFinite(gy))return;
    const candidate=this.candidate(gx,gy);if(!candidate)return;
    const invalid=placementError(candidate,this.furniture,this.playerPositions());for(const pos of furnitureTiles(candidate))this.ghostMarkers.push(this.marker(pos,invalid?'invalid-marker':'valid-marker',candidate.z??0));
  };
  private fit = () => {
    const width = this.viewport.clientWidth || window.innerWidth;
    const height = this.viewport.clientHeight || window.innerHeight;
    const scale = Math.max(.25, Math.min((width - 32) / 680, (height - 190) / 440, 1.6));
    this.world.style.left = `${width / 2}px`;
    this.world.style.top = `${70 + 110 * scale + Math.max(0, height - 190 - 430 * scale) / 2}px`;
    this.world.style.transform = `scale(${scale})`;
  };
  private createActor(name: string, color: number, grid: Position, direction: Direction,appearance?:AvatarAppearance): Actor {
    const node = makeAvatar(name, color,appearance); setAvatarDirection(node,direction);
    const height=surfaceAt(grid,this.furniture).height;node.dataset.height=String(height);position(node,grid.x,grid.y,-height*HEIGHT_PIXELS,1+height*.1);this.world.append(node);
    return { node, grid: { ...grid } };
  }
  private reconcile(players: Record<string, Player>) {
    const id = this.network.getSocketId();
    for (const remoteId of this.remotes.keys()) if (!players[remoteId] || remoteId === id) this.removeRemote(remoteId);
    for (const player of Object.values(players)) {
      if (player.id === id) { this.cancelRoute();this.local.grid = { ...player.position };this.local.seat=player.seat;setAvatarSitting(this.local.node,!!player.seat); this.positionActor(this.local);setAvatarDirection(this.local.node,player.direction);if(player.appearance){this.appearance={...player.appearance};applyAvatarAppearance(this.local.node,player.appearance);} }
      else if (this.remotes.has(player.id)) {const actor=this.remotes.get(player.id)!;actor.seat=player.seat;setAvatarSitting(actor.node,!!player.seat);if(player.seat){actor.grid={...player.position};setAvatarDirection(actor.node,player.direction);this.positionActor(actor);}else this.moveActor(actor,player.position,player.direction);if(player.appearance)applyAvatarAppearance(actor.node,player.appearance);}
      else this.addRemote(player);
    }
    this.updateCount();
    if (this.offline) return;
    this.proximity.destroy();
    void this.proximity.init(id || '').then((peerId) => {
      if (this.disposed) { this.proximity.destroy(); return; }
      this.network.sendPeerId(peerId);
      this.proximity.setLocalPosition(this.local.grid);
      this.proximity.setProximityCallback((ids) => this.onProximity?.(ids));
    }).catch(() => { /* Optional proximity service does not block room/chat. */ });
  }
  private addRemote(player: Player) {
    if (player.id === this.network.getSocketId() || this.remotes.has(player.id)) return;
    const colors = [0xff9ff3, 0x48dbfb, 0xfeca57, 0x54a0ff];
    let hash = 0; for (const c of player.id) hash = (hash * 31 + c.charCodeAt(0)) | 0;
    const actor = this.createActor(player.name, colors[Math.abs(hash) % colors.length], player.position, player.direction,player.appearance);
    actor.seat=player.seat;setAvatarSitting(actor.node,!!player.seat);this.positionActor(actor);
    this.remotes.set(player.id, actor);
    this.proximity.updateRemotePlayer(player.id, `coco-${player.id}`, player.position);
  }
  private removeRemote(id: string) {
    const actor = this.remotes.get(id); if (!actor) return;
    if (actor.timer) { clearTimeout(actor.timer); this.timers.delete(actor.timer); }
    disposeAvatar(actor.node);actor.node.remove(); this.remotes.delete(id); this.proximity.removeRemotePlayer(id);
  }
  private moveActor(actor: Actor, grid: Position, direction?: Direction) {
    actor.seat=undefined;setAvatarSitting(actor.node,false);
    setAvatarDirection(actor.node,direction||directionForMove(actor.grid,grid));
    actor.grid = { ...grid }; this.positionActor(actor);
    setAvatarWalking(actor.node,true);
    if (actor.timer) { clearTimeout(actor.timer); this.timers.delete(actor.timer); }
    actor.timer = this.later(() => setAvatarWalking(actor.node,false), 240);
  }
  private positionActor(actor:Actor){
    const sofa=actor.seat&&this.furniture.find(i=>i.id===actor.seat!.furnitureId);const height=sofa?(sofa.z??0):surfaceAt(actor.grid,this.furniture).height;actor.node.dataset.height=String(height);actor.node.dataset.gx=String(actor.grid.x);actor.node.dataset.gy=String(actor.grid.y);
    if(sofa&&actor.seat){const anchor=sofaSeatAnchor(sofa,actor.seat);position(actor.node,anchor.center.x,anchor.center.y,-height*HEIGHT_PIXELS,.5+height*.1);actor.node.style.left=`${tilePosition(anchor.center.x,anchor.center.y).left+anchor.x}px`;actor.node.style.top=`${tilePosition(anchor.center.x,anchor.center.y).top-height*HEIGHT_PIXELS+anchor.y+24}px`;actor.node.style.zIndex=String(Number(actor.node.style.zIndex)+1);}
    else position(actor.node,actor.grid.x,actor.grid.y,-height*HEIGHT_PIXELS,1+height*.1);
  }
  private applyPosture(player:Player){const actor=player.id===this.network.getSocketId()?this.local:this.remotes.get(player.id);if(!actor)return;const after=actor===this.local?this.afterStand:undefined;if(actor===this.local)this.cancelRoute();if(actor.timer){clearTimeout(actor.timer);this.timers.delete(actor.timer);}actor.grid={...player.position};actor.seat=player.seat;setAvatarWalking(actor.node,false);setAvatarDirection(actor.node,player.direction);setAvatarSitting(actor.node,!!player.seat);this.positionActor(actor);this.updateFurnitureControls();if(!player.seat)after?.();}
  private seatingPlayers():Player[]{return [this.local,...this.remotes.values()].map((a,index)=>({id:index===0?this.network.getSocketId()||'local':`remote-${index}`,name:'',position:a.grid,direction:'south',seat:a.seat}));}
  private requestSit(id:string){
    this.cancelRoute();if(!this.room||!this.connected)return;if(this.local.seat){this.afterStand=()=>this.requestSit(id);this.network.stand();return;}
    const sofa=this.furniture.find(i=>i.id===id);if(!sofa||sofa.kind!=='base-sofa')return;
    const candidates=sofaSeats(sofa).map(s=>({...s,path:findPlayerPath(this.local.grid,s.tile,this.furniture,this.seatingPlayers())})).filter(s=>s.path!==null).sort((a,b)=>a.path!.length-b.path!.length);
    const chosen=candidates[0];if(!chosen){this.furnitureMessage='No free, reachable sofa seat. Clear a path to its front at the same level.';this.updateFurnitureControls();return;}
    this.walkTo(chosen.tile);
  }
  private cancelRoute(){if(this.routeTimer){clearTimeout(this.routeTimer);this.timers.delete(this.routeTimer);}this.routeTimer=undefined;this.route=[];this.afterStand=undefined;}
  private walkTo(grid:Position){
    this.cancelRoute();if(!this.room||!this.connected)return;if(this.local.seat){this.afterStand=()=>this.walkTo(grid);this.network.stand();return;}const path=findPlayerPath(this.local.grid,grid,this.furniture,this.seatingPlayers());
    if(path===null){this.furnitureMessage='No walking route. Use a lower Stool or another one-level step to climb.';this.updateFurnitureControls();return;}
    this.furnitureMessage='';this.updateFurnitureControls();this.route=path;this.advanceRoute();
  }
  private advanceRoute=()=>{
    this.routeTimer=undefined;if(!this.route.length)return;
    const delay=180-(Date.now()-this.lastMove);if(delay>0){this.routeTimer=this.later(this.advanceRoute,delay+5);return;}
    const next=this.route.shift()!;if(!this.moveLocal(next)){this.cancelRoute();return;}
    if(this.route.length)this.routeTimer=this.later(this.advanceRoute,190);
  };
  private moveLocal(grid: Position, direction?: Direction):boolean {
    if(!this.room||!this.connected||this.local.seat||Date.now()-this.lastMove<180)return false;
    const player:Player={id:this.network.getSocketId()||'local',name:'',position:this.local.grid,direction:'south'};const result=movePlayer(player,grid,this.furniture,this.seatingPlayers());if(!result.ok)return false;
    this.lastMove=Date.now();if(!result.player.seat)this.moveActor(this.local,grid);
    this.network.sendMove(grid.x,grid.y,result.player.direction);this.proximity.setLocalPosition(grid);return true;
  }
  private handleClick=(event:MouseEvent)=>{
    const target=event.target as HTMLElement,item=target.closest<HTMLElement>('[data-furniture-id]');
    if(item){if(this.isPlacing()){const occupied=this.furniture.find(f=>f.id===item.dataset.furnitureId);if(occupied)this.placeAt(occupied.gx,occupied.gy);}else {const selected=this.furniture.find(f=>f.id===item.dataset.furnitureId);this.selectFurniture(item.dataset.furnitureId!);if(selected?.kind==='base-sofa')this.requestSit(selected.id);else if(selected&&isSurface(selected))this.walkTo({x:selected.gx,y:selected.gy});}return;}
    const tile=target.closest<HTMLElement>('.floor-tile');if(!tile)return;const gx=Number(tile.dataset.x),gy=Number(tile.dataset.y);
    if(this.isPlacing()){this.placeAt(gx,gy);return;}this.viewport.focus({preventScroll:true});this.walkTo({x:gx,y:gy});
  };
  private handleKey = (event: KeyboardEvent) => {
    if(event.key==='Escape'&&this.isPlacing()){event.preventDefault();this.resetPlacement();this.furnitureMessage='';this.updateFurnitureControls();return;}
    const target = event.target as HTMLElement;
    if (target.closest('dialog,input,textarea,select,button,[contenteditable=true]') || event.altKey || event.ctrlKey || event.metaKey) return;
    const keys: Record<string, KeyDirection> = { ArrowUp: 'up', w: 'up', ArrowDown: 'down', s: 'down', ArrowLeft: 'left', a: 'left', ArrowRight: 'right', d: 'right' };
    const key = keys[event.key]; if (!key) return; event.preventDefault();
    if(this.local.seat){this.cancelRoute();this.network.stand();return;}
    this.cancelRoute();this.heldKeys.add(key);const delta={dx:Number(this.heldKeys.has('right'))-Number(this.heldKeys.has('left')),dy:Number(this.heldKeys.has('down'))-Number(this.heldKeys.has('up'))};
    this.moveLocal(applyMove(this.local.grid,delta,10,10));
  };
  private clearHeldKeys=()=>{this.heldKeys.clear();};
  private handleKeyUp=(event:KeyboardEvent)=>{const keys:Record<string,KeyDirection>={ArrowUp:'up',w:'up',ArrowDown:'down',s:'down',ArrowLeft:'left',a:'left',ArrowRight:'right',d:'right'};if(keys[event.key])this.heldKeys.delete(keys[event.key]);};
  private later(fn: () => void, delay: number) {
    const timer = setTimeout(() => { this.timers.delete(timer); if (!this.disposed) fn(); }, delay);
    this.timers.add(timer); return timer;
  }
  private showBubble(actor: Actor, content: string) {
    actor.node.querySelector('.speech-bubble')?.remove();
    const bubble = element('speech-bubble', actor.node); bubble.textContent = content;
    this.later(() => bubble.remove(), 4500);
  }
  private updateCount() { this.onCount?.(this.remotes.size + 1); }
  setChatCallback(cb: (messages: ChatMessage[]) => void) { this.onChat = cb; cb([...this.messages]); }
  setPlayerCountCallback(cb: (n: number) => void) { this.onCount = cb; this.updateCount(); }
  setProximityCallback(cb: (ids: string[]) => void) { this.onProximity = cb; }
  setDJCallback(cb: (state: DJState) => void) { this.onDJ = cb; if (this.dj) cb(this.dj); }
  setPomodoroCallbacks(update: (state: PomodoroState) => void, end: () => void) { this.onPomodoro = update; this.onPomodoroEnd = end; if (this.pomodoro) update(this.pomodoro); }
  sendChat(content: string) { if(this.room)this.network.sendChat(content);else {this.furnitureMessage="Create a room before chatting.";this.updateFurnitureControls();} }
  getNetwork() { return this.network; }
  getProximityManager() { return this.proximity; }
  destroy() {
    if (this.disposed) return; this.disposed = true;
    for (const timer of this.timers) clearTimeout(timer);
    this.timers.clear(); this.observer?.disconnect();
    this.viewport.removeEventListener('click', this.handleClick);
    this.viewport.removeEventListener('pointermove',this.handlePointerMove);
    this.viewport.removeEventListener('pointerleave',this.clearGhost);
    window.removeEventListener('keydown', this.handleKey);window.removeEventListener('keyup',this.handleKeyUp);window.removeEventListener('blur',this.clearHeldKeys); window.removeEventListener('resize', this.fit);
    disposeAvatar(this.local.node);for(const actor of this.remotes.values())disposeAvatar(actor.node);this.wardrobe.destroy();this.roomWindow.destroy();this.network.disconnect(); this.proximity.destroy(); this.viewport.remove();
  }
}
