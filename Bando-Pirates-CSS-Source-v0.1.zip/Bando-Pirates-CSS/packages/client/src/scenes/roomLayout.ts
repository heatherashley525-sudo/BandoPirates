import { createRoomFurniture, furnitureObstacles } from '@cocoworking/shared';
export interface LayoutItem {
  gx:number;gy:number;texture:string;
  originX:number;originY:number;yOffset:number;depth:number;rotation?:number;
}
export const ROOM_LAYOUT: LayoutItem[] = createRoomFurniture().map(item=>({gx:item.gx,gy:item.gy,texture:item.kind,rotation:item.rotation,originX:.5,originY:1,yOffset:0,depth:0}));
export const OBSTACLE_POSITIONS=[...furnitureObstacles(createRoomFurniture())];
