import { afterEach, describe, expect, it, vi } from 'vitest';
import type { NetworkEvents } from '../../game-logic/NetworkManager';
const fake = vi.hoisted(() => ({ events: null as NetworkEvents | null, disconnect: vi.fn(), sendMove: vi.fn(),sit:vi.fn(),stand:vi.fn(), moveFurniture:vi.fn(), rotateFurniture:vi.fn(), placeFurniture:vi.fn(), pickUpFurniture:vi.fn(), deleteRoom:vi.fn(), createRoom:vi.fn() }));
vi.mock('../../game-logic/NetworkManager', () => ({ NetworkManager: class {
  constructor(_url: string, _name: string, events: NetworkEvents) { fake.events = events; }
  getSocketId() { return 'local'; }
  getUserId() { return 'local'; }
  disconnect = fake.disconnect;
  sendMove = fake.sendMove;
  sit=fake.sit;stand=fake.stand;
  moveFurniture=fake.moveFurniture;
  rotateFurniture=fake.rotateFurniture;
  placeFurniture=fake.placeFurniture;
  pickUpFurniture=fake.pickUpFurniture;
  deleteRoom=fake.deleteRoom;
  createRoom=fake.createRoom;
  sendPeerId() {}
} }));
vi.mock('../../game-logic/ProximityManager', () => ({ ProximityManager: class {
  init() { return Promise.resolve('peer'); }
  setLocalPosition() {}
  updateRemotePlayer() {}
  removeRemotePlayer() {}
  setProximityCallback() {}
  destroy() {}
} }));
import { createRoomFurniture } from '@cocoworking/shared';
import { CoworkingScene } from '../CoworkingScene';
let scene: CoworkingScene | undefined;
afterEach(() => { scene?.destroy(); document.body.replaceChildren(); vi.clearAllMocks(); vi.useRealTimers(); });
describe('CSS renderer with existing networking', () => {
  it('walks onto the sofa without a Sit button or explicit Sit request and stands before walking away',()=>{
    vi.useFakeTimers();vi.setSystemTime(new Date('2026-11-08T12:00:00Z'));const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);
    fake.events!.onConnection?.(true);fake.events!.onRoomInfo?.({id:'room',name:'Room',ownerId:'local',ownerName:'Heather'});fake.events!.onFurnitureState?.(createRoomFurniture());
    expect([...host.querySelectorAll('button')].some(b=>b.textContent==='Sit on sofa')).toBe(false);host.querySelector<HTMLElement>('[data-furniture-id="base-sofa"]')!.click();vi.advanceTimersByTime(1500);expect(fake.sit).not.toHaveBeenCalled();
    const last=fake.sendMove.mock.calls.at(-1)!,index=(last[1]===3?0:1) as 0|1,position={x:3,y:3+index};expect(last.slice(0,2)).toEqual([3,3+index]);fake.events!.onPosture?.({id:'local',name:'Heather',position,direction:'south-east',seat:{furnitureId:'base-sofa',index}});
    expect(host.querySelector<HTMLElement>('.css-world .css-avatar')!.dataset.posture).toBe('sit');host.querySelector<HTMLElement>('.floor-tile[data-x="8"][data-y="8"]')!.click();expect(fake.stand).toHaveBeenCalled();
    fake.events!.onPosture?.({id:'local',name:'Heather',position:{x:4,y:4},direction:'south-east'});vi.advanceTimersByTime(1500);expect(host.querySelector<HTMLElement>('.css-world .css-avatar')!.dataset.posture).toBe('stand');
  });
  it('opens room information as a reusable child window and permits walking with the wardrobe open',()=>{
    const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);
    fake.events!.onConnection?.(true);fake.events!.onRoomInfo?.({id:'room',name:"Heather's room",ownerId:'local',ownerName:'Heather'});
    const room=host.querySelector<HTMLDialogElement>('.furniture-controls')!;expect(room.open).toBe(true);expect(room.querySelector('.titlebar')?.textContent).toContain("Heather's room");expect(room.querySelectorAll('.resize-handle')).toHaveLength(8);
    host.querySelector<HTMLButtonElement>('[aria-label="Close room information"]')!.click();expect(room.open).toBe(false);host.querySelector<HTMLButtonElement>('.room-info-launch')!.click();expect(room.open).toBe(true);
    host.querySelector<HTMLButtonElement>('.wardrobe-launch')!.click();expect(host.querySelector<HTMLDialogElement>('.wardrobe')!.open).toBe(true);
    host.querySelector<HTMLElement>('.css-room-viewport')!.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowDown',bubbles:true}));expect(fake.sendMove).toHaveBeenCalledWith(5,6,'south-west');
    host.querySelector('.wardrobe')!.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}));expect(host.querySelector<HTMLDialogElement>('.wardrobe')!.open).toBe(false);expect(room.open).toBe(true);
  });
  it('reconciles a full room snapshot after reconnection', () => {
    const host = document.createElement('div'); document.body.append(host);
    scene = new CoworkingScene(host, 'Heather', 0xff9ff3);
    const player = (id: string) => ({ id, name: id, position: { x: 4, y: 4 }, direction: 'south' as const });
    fake.events!.onRoomState({ local: player('local'), guest: player('guest') });
    expect(host.querySelectorAll('.css-world .css-avatar')).toHaveLength(2);
    fake.events!.onRoomState({ local: player('local') });
    expect(host.querySelectorAll('.css-world .css-avatar')).toHaveLength(1);
    expect(host.querySelector('img,svg,canvas')).toBeNull();
  });
  it('enables editing only for the owner and moves the selected furniture', () => {
    const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);
    fake.events!.onConnection?.(true);fake.events!.onRoomInfo?.({id:'room',name:'Test room',ownerId:'local',ownerName:'Heather'});fake.events!.onRoomOwner?.({id:'local',name:'Heather'});fake.events!.onFurnitureState?.(createRoomFurniture().map(i=>({...i,ownerId:'local',ownerName:'Heather'})));
    const picker=host.querySelector<HTMLSelectElement>('#furniture-picker')!;
    expect(picker.options).toHaveLength(3);picker.value='base-table';picker.dispatchEvent(new Event('change'));
    const move=[...host.querySelectorAll('button')].find(button=>button.textContent==='Move furniture')!;
    expect(move.disabled).toBe(false);move.click();
    host.querySelector<HTMLElement>('.floor-tile[data-x="7"][data-y="6"]')!.click();
    expect(fake.moveFurniture).toHaveBeenCalledWith('base-table',7,6);expect(fake.sendMove).not.toHaveBeenCalled();
    host.querySelector<HTMLElement>('[data-furniture-id="base-sofa"]')!.click();
    expect(fake.moveFurniture).toHaveBeenLastCalledWith('base-table',3,3);expect(picker.value).toBe('base-table');
    const items=createRoomFurniture();items[1]={...items[1],gx:7,gy:6};fake.events!.onFurnitureState?.(items);
    expect(host.querySelector('[data-furniture-id="base-table"]')?.getAttribute('data-gx')).toBe('7');
    fake.events!.onRoomOwner?.({id:'guest',name:'Guest'});expect(move.disabled).toBe(true);
  });
  it('keeps guest edit controls disabled', () => {
    const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Guest',0xff9ff3);
    fake.events!.onConnection?.(true);fake.events!.onRoomInfo?.({id:'room',name:'Test room',ownerId:'other',ownerName:'Heather'});fake.events!.onRoomOwner?.({id:'other',name:'Heather'});fake.events!.onFurnitureState?.(createRoomFurniture().map(i=>({...i,ownerId:'other',ownerName:'Heather'})));
    for(const name of ['Move furniture','Rotate furniture ↻','Pick up','Delete room']){const button=[...host.querySelectorAll('button')].find(b=>b.textContent===name)!;expect(button.disabled).toBe(true);}
  });
  it('places an owned inventory item and keeps inventories available after room deletion',()=>{
    const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);
    fake.events!.onConnection?.(true);fake.events!.onRoomInfo?.({id:'room',name:'Test room',ownerId:'other',ownerName:'Other'});fake.events!.onRoomOwner?.({id:'other',name:'Other'});
    fake.events!.onInventory?.([{id:'owned-table',kind:'base-table',ownerId:'local'}]);
    const place=[...host.querySelectorAll('button')].find(b=>b.textContent==='Place from inventory')!;expect(place.disabled).toBe(false);place.click();
    host.querySelector<HTMLElement>('.floor-tile[data-x="7"][data-y="7"]')!.click();expect(fake.placeFurniture).toHaveBeenCalledWith('owned-table',7,7);
    fake.events!.onRoomInfo?.(null);expect(host.querySelector<HTMLElement>('.css-world')!.hidden).toBe(true);expect(host.querySelector('.inventory-controls summary')!.textContent).toBe('Inventory (1)');
  });
  it('allows collecting your own furniture while keeping room editing restricted',()=>{
    const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);
    fake.events!.onConnection?.(true);fake.events!.onRoomInfo?.({id:'room',name:'Test room',ownerId:'other',ownerName:'Other'});fake.events!.onRoomOwner?.({id:'other',name:'Other'});
    fake.events!.onFurnitureState?.([{...createRoomFurniture()[1],ownerId:'local',ownerName:'Heather'}]);
    const pickup=[...host.querySelectorAll('button')].find(b=>b.textContent==='Pick up')!;expect(pickup.disabled).toBe(false);pickup.click();expect(fake.pickUpFurniture).toHaveBeenCalledWith('base-table');
    const move=[...host.querySelectorAll('button')].find(b=>b.textContent==='Move furniture')!;expect(move.disabled).toBe(true);
  });
  it('walks to a table through a Stool and renders the avatar on its top',()=>{
    vi.useFakeTimers();vi.setSystemTime(new Date('2026-11-08T12:00:00Z'));
    const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);
    fake.events!.onConnection?.(true);fake.events!.onRoomInfo?.({id:'room',name:'Test room',ownerId:'local',ownerName:'Heather'});
    fake.events!.onFurnitureState?.(createRoomFurniture());
    host.querySelector<HTMLElement>('[data-furniture-id="base-table"]')!.click();
    vi.advanceTimersByTime(1000);
    expect(fake.sendMove.mock.calls.map(c=>c.slice(0,2))).toEqual([[6,4],[6,3]]);
    expect(host.querySelector<HTMLElement>('.css-avatar')!.dataset.height).toBe('2');
    expect(host.querySelector<HTMLElement>('.css-avatar')!.style.top).toBe('112px');
  });
  it('renders elevated furniture and cancels a stale walking route after a layout change',()=>{
    vi.useFakeTimers();vi.setSystemTime(new Date('2026-11-08T12:00:00Z'));
    const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);
    fake.events!.onConnection?.(true);fake.events!.onRoomInfo?.({id:'room',name:'Test room',ownerId:'local',ownerName:'Heather'});
    const items=createRoomFurniture();items.push({...items[1],id:'upper-table',z:2,supportId:'base-table'});fake.events!.onFurnitureState?.(items);
    expect(host.querySelector<HTMLElement>('[data-furniture-id="upper-table"]')!.dataset.z).toBe('2');
    host.querySelector<HTMLElement>('.floor-tile[data-x="8"][data-y="8"]')!.click();
    const steps=fake.sendMove.mock.calls.length;fake.events!.onFurnitureState?.(items);vi.advanceTimersByTime(2000);expect(fake.sendMove).toHaveBeenCalledTimes(steps);
  });
  it('keeps gait animation running across touch-style click paths and stops at the destination',()=>{
    vi.useFakeTimers();vi.setSystemTime(new Date('2026-11-08T12:00:00Z'));
    const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);
    fake.events!.onConnection?.(true);fake.events!.onRoomInfo?.({id:'room',name:'Test room',ownerId:'local',ownerName:'Heather'});fake.events!.onFurnitureState?.(createRoomFurniture());
    host.querySelector<HTMLElement>('.floor-tile[data-x="8"][data-y="8"]')!.click();vi.advanceTimersByTime(245);
    const actor=host.querySelector<HTMLElement>('.css-world .css-avatar')!;expect(actor.classList.contains('is-walking')).toBe(true);expect(actor.dataset.direction).toBe('south');vi.advanceTimersByTime(1000);expect(actor.classList.contains('is-walking')).toBe(false);
  });
  it('publishes initial callbacks even if the socket connected first', () => {
    const host = document.createElement('div'); document.body.append(host);
    scene = new CoworkingScene(host, 'Heather', 0xff9ff3);
    fake.events!.onChat({ id: 'one', playerId: 'local', playerName: 'Heather', content: '<b>Hello</b>', timestamp: 1 });
    const cb = vi.fn(); scene.setChatCallback(cb);
    expect(cb.mock.calls[0][0][0].content).toBe('<b>Hello</b>');
    expect(host.querySelector('.speech-bubble b')).toBeNull();
    scene.destroy(); scene = undefined;
    expect(fake.disconnect).toHaveBeenCalledOnce();
    expect(host.children).toHaveLength(0);
  });
});
