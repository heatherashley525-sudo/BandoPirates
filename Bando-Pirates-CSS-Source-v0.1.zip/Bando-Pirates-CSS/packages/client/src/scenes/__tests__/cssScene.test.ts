import { afterEach, describe, expect, it, vi } from 'vitest';
import type { NetworkEvents } from '../../game-logic/NetworkManager';
const fake = vi.hoisted(() => ({ events: null as NetworkEvents | null, disconnect: vi.fn(), sendMove: vi.fn(), sendChat:vi.fn(), saveAvatar:vi.fn(),sit:vi.fn(),stand:vi.fn(), moveFurniture:vi.fn(), rotateFurniture:vi.fn(), placeFurniture:vi.fn(), pickUpFurniture:vi.fn(), deleteRoom:vi.fn(), createRoom:vi.fn() }));
vi.mock('../../game-logic/NetworkManager', () => ({ NetworkManager: class {
  constructor(_url: string, _name: string, events: NetworkEvents) { fake.events = events; }
  getSocketId() { return 'local'; }
  getUserId() { return 'local'; }
  disconnect = fake.disconnect;
  sendMove = fake.sendMove;
  sendChat = fake.sendChat;
  saveAvatar = fake.saveAvatar;
  sit=fake.sit;stand=fake.stand;
  moveFurniture=fake.moveFurniture;
  rotateFurniture=fake.rotateFurniture;
  placeFurniture=fake.placeFurniture;
  pickUpFurniture=fake.pickUpFurniture;
  deleteRoom=fake.deleteRoom;
  createRoom=fake.createRoom;
  splitTile=vi.fn();
  sendPeerId() {}
} }));
vi.mock('../../game-logic/ProximityManager', () => ({ ProximityManager: class {
  init() { return Promise.resolve('peer'); }
  setLocalPosition() {}
  updateRemotePlayer() {}
  removeRemotePlayer() {}
  setProximityCallback() {}
  destroy() {}
} }));
import { createRoomFurniture, defaultAppearance, heatherAppearance, PUBLIC_STREET } from '@cocoworking/shared';
import { CoworkingScene } from '../CoworkingScene';
let scene: CoworkingScene | undefined;
afterEach(() => { scene?.destroy(); document.body.replaceChildren(); vi.clearAllMocks(); vi.useRealTimers(); });
describe('CSS renderer with existing networking', () => {
  it('equips the Heather outfit through chat without sending the command to the room',()=>{
    const host=document.createElement('div');document.body.append(host);
    scene=new CoworkingScene(host,'Player',0xff9ff3);
    fake.events!.onConnection?.(true);
    fake.events!.onRoomInfo?.({id:'room',name:'Room',ownerId:'local',ownerName:'Player'});
    const avatar=host.querySelector<HTMLElement>('.css-world .css-avatar')!;
    scene.sendChat(':admin 369');
    expect(fake.saveAvatar).toHaveBeenCalledWith(heatherAppearance());
    expect(fake.sendChat).not.toHaveBeenCalled();
    fake.events!.onAppearance?.('local',heatherAppearance());
    expect(avatar.dataset.preset).toBe('heather');
    fake.events!.onAppearance?.('local',defaultAppearance());
    expect(avatar.dataset.preset).toBeUndefined();
    scene.sendChat('Hello');
    expect(fake.sendChat).toHaveBeenCalledWith('Hello');
  });
  it('renders only the Public Street corridor and lists the entrance in Microverse',()=>{
    const host=document.createElement('div');
    document.body.append(host);
    scene=new CoworkingScene(host,'Heather',0xff9ff3,false,undefined,true);
    fake.events!.onConnection?.(true);
    fake.events!.onRoomInfo?.(PUBLIC_STREET);
    expect(host.querySelectorAll('.floor-tile[data-depth="0"]')).toHaveLength(17);
    expect(host.querySelectorAll('.floor-tile[data-depth="3"][data-tile-id^="5,7/"]')).toHaveLength(64);
    expect(host.querySelectorAll('.floor-tile')).toHaveLength(81);
    expect(host.querySelector('.room-wall')).toBeNull();
    host.querySelector<HTMLButtonElement>('.room-microverse-launch')!.click();
    const root=host.querySelector<HTMLSelectElement>('[aria-label="Microverse root tile"]')!;
    expect(root.options).toHaveLength(18);
    expect(root.value).toBe('5,7');
  });
  it('pans and pinches around the pointer without walking until the next tap',()=>{
    const host=document.createElement('div');
    document.body.append(host);
    scene=new CoworkingScene(host,'Heather',0xff9ff3);
    fake.events!.onConnection?.(true);
    fake.events!.onRoomInfo?.({id:'room',name:'Room',ownerId:'local',ownerName:'Heather'});
    const world=host.querySelector<HTMLElement>('.css-world')!;
    const tile=world.querySelector<HTMLElement>('.floor-tile[data-x="6"][data-y="5"]')!;
    const origin=()=>({x:parseFloat(world.style.left),y:parseFloat(world.style.top)});
    const scale=()=>Number(world.style.getPropertyValue('--world-scale'));
    const pointOnTile=()=>({x:origin().x+32*scale(),y:origin().y+176*scale()});
    const pointer=(type:string,id:number,x:number,y:number)=>{
      const event=new MouseEvent(type,{bubbles:true,button:0,clientX:x,clientY:y});
      Object.defineProperty(event,'pointerId',{value:id});
      tile.dispatchEvent(event);
    };
    const click=()=>{
      const {x,y}=pointOnTile();
      tile.dispatchEvent(new MouseEvent('click',{bubbles:true,detail:1,clientX:x,clientY:y}));
    };
    const start=origin(),initialScale=scale();
    pointer('pointerdown',1,300,400);
    pointer('pointermove',1,345,430);
    pointer('pointerup',1,345,430);
    click();
    expect(origin()).toEqual({x:start.x+45,y:start.y+30});
    expect(fake.sendMove).not.toHaveBeenCalled();

    const beforePinch=origin();
    pointer('pointerdown',2,300,400);
    pointer('pointerdown',3,400,400);
    pointer('pointermove',3,500,400);
    pointer('pointerup',3,500,400);
    pointer('pointerup',2,300,400);
    click();
    expect(scale()).toBeCloseTo(initialScale*2);
    expect(origin().x).toBeCloseTo(400+(beforePinch.x-350)*2);
    expect(origin().y).toBeCloseTo(400+(beforePinch.y-400)*2);
    expect(host.querySelector<HTMLInputElement>('#room-zoom')!.value).toBe('200');
    expect(fake.sendMove).not.toHaveBeenCalled();

    const tap=pointOnTile();
    pointer('pointerdown',4,tap.x,tap.y);
    pointer('pointerup',4,tap.x,tap.y);
    click();
    expect(fake.sendMove).toHaveBeenCalledWith(6,5,'south-east');
  });
  it('renders recursive leaves, scales avatars and furniture and focuses a selected micro tile',()=>{
    const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);fake.events!.onConnection?.(true);fake.events!.onRoomOwner?.({id:'local',name:'Heather'});fake.events!.onRoomInfo?.({id:'room',name:'Room',ownerId:'local',ownerName:'Heather',tileSplits:['2,2','2,2/0']});
    expect(host.querySelectorAll('.floor-tile[data-tile-id]')).toHaveLength(87);expect(host.querySelector('.floor-tile[data-tile-id="2,2"]')).toBeNull();expect(host.querySelector<HTMLElement>('.floor-tile[data-tile-id="2,2/00"]')!.style.width).toBe('16px');
    fake.events!.onRoomState({local:{id:'local',name:'Heather',position:{x:1.625,y:1.625},direction:'south'}});expect(host.querySelector<HTMLElement>('.css-world>.css-avatar')!.style.transform).toBe('scale(0.25)');
    fake.events!.onFurnitureState?.([{id:'tiny-table',kind:'base-table',gx:1.875,gy:1.625,scale:.25,rotation:0}]);expect(host.querySelector<HTMLElement>('[data-furniture-id="tiny-table"]')!.style.transform).toBe('scale(0.25)');
    host.querySelector<HTMLButtonElement>('.room-microverse-launch')!.click();const micro=host.querySelector<HTMLElement>('.microverse-window')!;micro.querySelector<HTMLButtonElement>('[aria-label="Select north-west child"]')!.click();micro.querySelector<HTMLButtonElement>('[aria-label="Select north-west child"]')!.click();const before=host.querySelector<HTMLElement>('.css-world')!.style.transform;micro.querySelector<HTMLButtonElement>('[aria-label="Focus selected tile"]')!.click();expect(host.querySelector<HTMLElement>('.css-world')!.style.transform).not.toBe(before);expect(micro.querySelector('.window-maximize')).toBeNull();
  });
  it('freezes chat anchors at send time rather than following a walking speaker or later zoom changes',()=>{
    const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);const seen:any[]=[];scene.setChatCallback(messages=>seen.push(messages));const source={x:3,y:7};fake.events!.onChat({id:'one',playerId:'local',playerName:'Heather',content:'Here',timestamp:1,position:source});const first=seen.at(-1)[0];source.x=8;fake.events!.onRoomState({local:{id:'local',name:'Heather',position:{x:8,y:2},direction:'south'}});scene.setRoomZoom(200);fake.events!.onChat({id:'two',playerId:'local',playerName:'Heather',content:'There',timestamp:2,position:{x:8,y:2}});const messages=seen.at(-1);expect(messages[0].position).toEqual({x:3,y:7});expect(messages[0].anchorX).toBe(first.anchorX);expect(messages[1].anchorX).toBeGreaterThan(messages[0].anchorX);expect(host.querySelector('.speech-bubble')).toBeNull();
  });
  it('moves every room tool into the Start menu and removes the floating tool panel',()=>{
    const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);expect(host.querySelector('[data-floating-panel="room-tools"]')).toBeNull();const menu=host.querySelector<HTMLElement>('[role=menu]')!;expect(menu.hidden).toBe(true);expect([...menu.querySelectorAll('.menu-label')].map(item=>item.textContent)).toEqual(['Wardrobe','Room info','Wallet & collectibles','Scale','Calls','Microverse']);host.querySelector<HTMLButtonElement>('[aria-label=Start]')!.click();menu.querySelector<HTMLButtonElement>('.wardrobe-launch')!.click();expect(menu.hidden).toBe(true);expect(host.querySelector<HTMLDialogElement>('.wardrobe')!.open).toBe(true);
  });
  it('keeps zoom separate from eight microverse perspectives and resets zoom when changing perspective',()=>{
    const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);const world=host.querySelector<HTMLElement>('.css-world')!,avatar=world.querySelector<HTMLElement>('.css-avatar')!;const scale=()=>Number(world.style.transform.match(/scale\(([^)]+)\)/)![1]),base=scale(),center=parseFloat(world.style.top)+160*base,position=avatar.style.cssText;
    host.querySelector<HTMLButtonElement>('.room-scale-launch')!.click();const dialog=host.querySelector<HTMLDialogElement>('.room-scale-window')!,slider=dialog.querySelector<HTMLInputElement>('[aria-label="Room zoom"]')!;expect(dialog.open).toBe(true);expect(dialog.style.left).toBe('16px');expect(dialog.style.width).toBe('88px');expect(slider.getAttribute('aria-orientation')).toBe('vertical');expect(dialog.querySelector('.titlebar .window-close')).not.toBeNull();expect(slider.value).toBe('100');slider.value='150';slider.dispatchEvent(new Event('input',{bubbles:true}));expect(scale()/base).toBeCloseTo(1.5);expect(parseFloat(world.style.top)+160*scale()).toBeCloseTo(center);expect(avatar.style.cssText).toBe(position);expect(fake.sendMove).not.toHaveBeenCalled();const percentage=dialog.querySelector<HTMLInputElement>('[aria-label="Zoom percentage"]')!,levels=dialog.querySelector<HTMLSelectElement>('[aria-label="Perspective level"]')!;expect(percentage.value).toBe('150');expect(levels.querySelectorAll('option[data-level]')).toHaveLength(8);expect(levels.value).toBe('1');expect(dialog.textContent).not.toContain('Room zoom');expect(dialog.textContent).not.toContain('Fit');percentage.value='137';percentage.dispatchEvent(new Event('change',{bubbles:true}));expect(scale()/base).toBeCloseTo(1.37);expect(levels.value).toBe('1');percentage.value='';percentage.dispatchEvent(new Event('blur'));expect(percentage.value).toBe('137');levels.value='3';levels.dispatchEvent(new Event('change',{bubbles:true}));expect(percentage.value).toBe('100');expect(scale()/base).toBeCloseTo(4);expect(world.dataset.perspective).toBe('3');levels.value='1';levels.dispatchEvent(new Event('change',{bubbles:true}));
    expect(scale()).toBeCloseTo(base);expect(scene.setRoomZoom(999)).toBe(250);expect(scene.setRoomZoom(-1)).toBe(25);expect(scene.setRoomZoom(NaN)).toBe(25);dialog.querySelector<HTMLButtonElement>('[aria-label="Close room scale"]')!.click();expect(dialog.open).toBe(false);
  });
  it('picks the floor square under a covering furniture sprite rather than its origin',()=>{
    vi.useFakeTimers();const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);fake.events!.onConnection?.(true);fake.events!.onRoomInfo?.({id:'room',name:'Room',ownerId:'local',ownerName:'Heather'});fake.events!.onFurnitureState?.(createRoomFurniture());const world=host.querySelector<HTMLElement>('.css-world')!,scale=Number(world.style.transform.match(/scale\(([^)]+)\)/)![1]),x=parseFloat(world.style.left)+32*scale,y=parseFloat(world.style.top)+176*scale;
    host.querySelector<HTMLElement>('[data-furniture-id="base-sofa"]')!.dispatchEvent(new MouseEvent('click',{bubbles:true,clientX:x,clientY:y}));expect(fake.sendMove).toHaveBeenCalledWith(6,5,'south-east');expect(fake.sit).not.toHaveBeenCalled();
  });
  it('renders intermediate walking positions and keeps keyboard repeats independent of OS key repeat',()=>{
    vi.useFakeTimers();vi.setSystemTime(new Date('2026-11-08T12:00:00Z'));const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);fake.events!.onConnection?.(true);fake.events!.onRoomInfo?.({id:'room',name:'Room',ownerId:'local',ownerName:'Heather'});fake.events!.onFurnitureState?.(createRoomFurniture());
    const viewport=host.querySelector<HTMLElement>('.css-room-viewport')!,avatar=host.querySelector<HTMLElement>('.css-world .css-avatar')!;
    viewport.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowDown',bubbles:true}));vi.advanceTimersByTime(95);expect(parseFloat(avatar.style.left)).toBeLessThan(0);expect(parseFloat(avatar.style.left)).toBeGreaterThan(-32);
    vi.advanceTimersByTime(300);expect(fake.sendMove.mock.calls.length).toBeGreaterThanOrEqual(3);window.dispatchEvent(new KeyboardEvent('keyup',{key:'ArrowDown',bubbles:true}));const count=fake.sendMove.mock.calls.length;vi.advanceTimersByTime(400);expect(fake.sendMove.mock.calls).toHaveLength(count);
  });
  it('walks onto the sofa without a Sit button or explicit Sit request and stands before walking away',()=>{
    vi.useFakeTimers();vi.setSystemTime(new Date('2026-11-08T12:00:00Z'));const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);
    fake.events!.onConnection?.(true);fake.events!.onRoomInfo?.({id:'room',name:'Room',ownerId:'local',ownerName:'Heather'});fake.events!.onFurnitureState?.(createRoomFurniture());
    expect([...host.querySelectorAll('button')].some(b=>b.textContent==='Sit on sofa')).toBe(false);host.querySelector<HTMLElement>('[data-furniture-id="base-sofa"]')!.click();vi.advanceTimersByTime(1500);expect(fake.sit).not.toHaveBeenCalled();
    const last=fake.sendMove.mock.calls.at(-1)!,index=(last[1]===3?0:1) as 0|1,position={x:3,y:3+index};expect(last.slice(0,2)).toEqual([3,3+index]);fake.events!.onPosture?.({id:'local',name:'Heather',position,direction:'south-east',seat:{furnitureId:'base-sofa',index}});
    expect(host.querySelector<HTMLElement>('.css-world .css-avatar')!.dataset.posture).toBe('sit');host.querySelector<HTMLElement>('.floor-tile[data-x="8"][data-y="8"]')!.click();expect(fake.stand).toHaveBeenCalled();
    fake.events!.onPosture?.({id:'local',name:'Heather',position:{x:4,y:4},direction:'south-east'});vi.advanceTimersByTime(1500);expect(host.querySelector<HTMLElement>('.css-world .css-avatar')!.dataset.posture).toBe('stand');
  });
  it('opens room information as a reusable child window and permits walking with the wardrobe open',()=>{
    const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);
    fake.events!.onConnection?.(true);fake.events!.onRoomInfo?.({id:'room',name:"Heather's room",ownerId:'local',ownerName:'Heather'});
    const room=host.querySelector<HTMLDialogElement>('.furniture-controls')!;expect(room.open).toBe(true);expect(room.querySelector('.titlebar')?.textContent).toContain("Heather's room");expect(room.querySelectorAll('.resize-handle')).toHaveLength(1);
    host.querySelector<HTMLButtonElement>('[aria-label="Close room information"]')!.click();expect(room.open).toBe(false);host.querySelector<HTMLButtonElement>('.room-info-launch')!.click();expect(room.open).toBe(true);
    host.querySelector<HTMLButtonElement>('.wardrobe-launch')!.click();expect(host.querySelector<HTMLDialogElement>('.wardrobe')!.open).toBe(true);
    host.querySelector<HTMLElement>('.css-room-viewport')!.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowDown',bubbles:true}));expect(fake.sendMove).toHaveBeenCalledWith(5,6,'south-west');
    host.querySelector('.wardrobe')!.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}));expect(host.querySelector<HTMLDialogElement>('.wardrobe')!.open).toBe(false);expect(room.open).toBe(true);
  });
  it('reconciles a full room snapshot after reconnection', () => {
    const host = document.createElement('div'); document.body.append(host);
    scene = new CoworkingScene(host, 'Heather', 0xff9ff3);
    const player = (id: string) => ({ id, name: id, position: { x: 4, y: 4 }, direction: 'south' as const });
    fake.events!.onRoomState({ local: player('local'), guest: player('guest') });
    expect(host.querySelectorAll('.css-world .css-avatar')).toHaveLength(2);
    fake.events!.onRoomState({ local: player('local') });
    expect(host.querySelectorAll('.css-world .css-avatar')).toHaveLength(1);
    expect(host.querySelector('.css-world img,.css-world svg,.css-world canvas')).toBeNull();
  });
  it('enables editing only for the owner and moves the selected furniture', () => {
    const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);
    fake.events!.onConnection?.(true);fake.events!.onRoomInfo?.({id:'room',name:'Test room',ownerId:'local',ownerName:'Heather'});fake.events!.onRoomOwner?.({id:'local',name:'Heather'});fake.events!.onFurnitureState?.(createRoomFurniture().map(i=>({...i,ownerId:'local',ownerName:'Heather'})));
    const picker=host.querySelector<HTMLSelectElement>('#furniture-picker')!;
    expect(picker.options).toHaveLength(3);picker.value='base-table';picker.dispatchEvent(new Event('change'));
    const move=[...host.querySelectorAll('button')].find(button=>button.textContent==='Move furniture')!;
    expect(move.disabled).toBe(false);move.click();
    host.querySelector<HTMLElement>('.floor-tile[data-x="7"][data-y="6"]')!.click();
    expect(fake.moveFurniture).toHaveBeenCalledWith('base-table',7,6);expect(fake.sendMove).not.toHaveBeenCalled();
    host.querySelector<HTMLElement>('[data-furniture-id="base-sofa"]')!.click();
    expect(fake.moveFurniture).toHaveBeenLastCalledWith('base-table',3,3);expect(picker.value).toBe('base-table');
    const items=createRoomFurniture();items[1]={...items[1],gx:7,gy:6};fake.events!.onFurnitureState?.(items);
    expect(host.querySelector('[data-furniture-id="base-table"]')?.getAttribute('data-gx')).toBe('7');
    fake.events!.onRoomOwner?.({id:'guest',name:'Guest'});expect(move.disabled).toBe(true);
  });
  it('keeps guest edit controls disabled', () => {
    const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Guest',0xff9ff3);
    fake.events!.onConnection?.(true);fake.events!.onRoomInfo?.({id:'room',name:'Test room',ownerId:'other',ownerName:'Heather'});fake.events!.onRoomOwner?.({id:'other',name:'Heather'});fake.events!.onFurnitureState?.(createRoomFurniture().map(i=>({...i,ownerId:'other',ownerName:'Heather'})));
    for(const name of ['Move furniture','Rotate furniture ↻','Pick up','Delete room']){const button=[...host.querySelectorAll('button')].find(b=>b.textContent===name)!;expect(button.disabled).toBe(true);}
  });
  it('places an owned inventory item and keeps inventories available after room deletion',()=>{
    const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);
    fake.events!.onConnection?.(true);fake.events!.onRoomInfo?.({id:'room',name:'Test room',ownerId:'other',ownerName:'Other'});fake.events!.onRoomOwner?.({id:'other',name:'Other'});
    fake.events!.onInventory?.([{id:'owned-table',kind:'base-table',ownerId:'local'}]);
    const place=[...host.querySelectorAll('button')].find(b=>b.textContent==='Place from inventory')!;expect(place.disabled).toBe(false);place.click();
    host.querySelector<HTMLElement>('.floor-tile[data-x="7"][data-y="7"]')!.click();expect(fake.placeFurniture).toHaveBeenCalledWith('owned-table',7,7);
    fake.events!.onRoomInfo?.(null);expect(host.querySelector<HTMLElement>('.css-world')!.hidden).toBe(true);expect(host.querySelector('.inventory-controls summary')!.textContent).toBe('Inventory (1)');
  });
  it('allows collecting your own furniture while keeping room editing restricted',()=>{
    const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);
    fake.events!.onConnection?.(true);fake.events!.onRoomInfo?.({id:'room',name:'Test room',ownerId:'other',ownerName:'Other'});fake.events!.onRoomOwner?.({id:'other',name:'Other'});
    fake.events!.onFurnitureState?.([{...createRoomFurniture()[1],ownerId:'local',ownerName:'Heather'}]);
    const pickup=[...host.querySelectorAll('button')].find(b=>b.textContent==='Pick up')!;expect(pickup.disabled).toBe(false);pickup.click();expect(fake.pickUpFurniture).toHaveBeenCalledWith('base-table');
    const move=[...host.querySelectorAll('button')].find(b=>b.textContent==='Move furniture')!;expect(move.disabled).toBe(true);
  });
  it('walks to a table through a Stool and renders the avatar on its top',()=>{
    vi.useFakeTimers();vi.setSystemTime(new Date('2026-11-08T12:00:00Z'));
    const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);
    fake.events!.onConnection?.(true);fake.events!.onRoomInfo?.({id:'room',name:'Test room',ownerId:'local',ownerName:'Heather'});
    fake.events!.onFurnitureState?.(createRoomFurniture());
    host.querySelector<HTMLElement>('[data-furniture-id="base-table"]')!.click();
    vi.advanceTimersByTime(1000);
    expect(fake.sendMove.mock.calls.map(c=>c.slice(0,2))).toEqual([[6,4],[6,3]]);
    expect(host.querySelector<HTMLElement>('.css-avatar')!.dataset.height).toBe('2');
    expect(host.querySelector<HTMLElement>('.css-avatar')!.style.top).toBe('112px');
  });
  it('renders elevated furniture and cancels a stale walking route after a layout change',()=>{
    vi.useFakeTimers();vi.setSystemTime(new Date('2026-11-08T12:00:00Z'));
    const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);
    fake.events!.onConnection?.(true);fake.events!.onRoomInfo?.({id:'room',name:'Test room',ownerId:'local',ownerName:'Heather'});
    const items=createRoomFurniture();items.push({...items[1],id:'upper-table',z:2,supportId:'base-table'});fake.events!.onFurnitureState?.(items);
    expect(host.querySelector<HTMLElement>('[data-furniture-id="upper-table"]')!.dataset.z).toBe('2');
    host.querySelector<HTMLElement>('.floor-tile[data-x="8"][data-y="8"]')!.click();
    const steps=fake.sendMove.mock.calls.length;fake.events!.onFurnitureState?.(items);vi.advanceTimersByTime(2000);expect(fake.sendMove).toHaveBeenCalledTimes(steps);
  });
  it('keeps gait animation running across touch-style click paths and stops at the destination',()=>{
    vi.useFakeTimers();vi.setSystemTime(new Date('2026-11-08T12:00:00Z'));
    const host=document.createElement('div');document.body.append(host);scene=new CoworkingScene(host,'Heather',0xff9ff3);
    fake.events!.onConnection?.(true);fake.events!.onRoomInfo?.({id:'room',name:'Test room',ownerId:'local',ownerName:'Heather'});fake.events!.onFurnitureState?.(createRoomFurniture());
    host.querySelector<HTMLElement>('.floor-tile[data-x="8"][data-y="8"]')!.click();vi.advanceTimersByTime(245);
    const actor=host.querySelector<HTMLElement>('.css-world .css-avatar')!;expect(actor.classList.contains('is-walking')).toBe(true);expect(actor.dataset.direction).toBe('south');vi.advanceTimersByTime(1000);expect(actor.classList.contains('is-walking')).toBe(false);
  });
  it('publishes initial callbacks even if the socket connected first', () => {
    const host = document.createElement('div'); document.body.append(host);
    scene = new CoworkingScene(host, 'Heather', 0xff9ff3);
    fake.events!.onChat({ id: 'one', playerId: 'local', playerName: 'Heather', content: '<b>Hello</b>', timestamp: 1 });
    const cb = vi.fn(); scene.setChatCallback(cb);
    expect(cb.mock.calls[0][0][0].content).toBe('<b>Hello</b>');
    expect(host.querySelector('.speech-bubble b')).toBeNull();
    scene.destroy(); scene = undefined;
    expect(fake.disconnect).toHaveBeenCalledOnce();
    expect(host.children).toHaveLength(0);
  });
});
