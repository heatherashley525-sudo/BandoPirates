import React,{act} from 'react';
import {createRoot} from 'react-dom/client';
import {describe,it,expect,vi} from 'vitest';
import {AudioControl} from '../AudioControl';
(globalThis as any).IS_REACT_ACT_ENVIRONMENT=true;
describe('volume tray',()=>{
 it('opens from the tray, preserves levels while muting and dismisses on outside click',async()=>{
  const host=document.createElement('div');document.body.append(host);const root=createRoot(host),volume=vi.fn(),mute=vi.fn();try{
   await act(async()=>root.render(<AudioControl host={host} onVolumeChange={volume} onMuteToggle={mute}/>));const button=host.querySelector<HTMLButtonElement>('[aria-label=Volume]')!;expect(button.getAttribute('aria-expanded')).toBe('false');expect(host.querySelector('[data-floating-panel=audio]')).toBeNull();await act(async()=>button.click());expect(host.querySelector('[aria-label="Master volume"]')).not.toBeNull();expect(host.querySelector('[aria-label="DJ volume"]')).not.toBeNull();const checkbox=host.querySelector<HTMLInputElement>('[type=checkbox]')!;
   await act(async()=>checkbox.click());expect(volume).toHaveBeenLastCalledWith(0);expect(button.dataset.silent).toBe('true');await act(async()=>checkbox.click());expect(volume).toHaveBeenLastCalledWith(50);await act(async()=>document.body.dispatchEvent(new MouseEvent('pointerdown',{bubbles:true})));expect(host.querySelector('.volume-popup')).toBeNull();expect(button.getAttribute('aria-expanded')).toBe('false');
  }finally{await act(async()=>root.unmount());host.remove();}
 });
});
