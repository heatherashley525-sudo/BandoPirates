import {afterEach,describe,it,expect,vi} from 'vitest';
import {StartMenu} from '../StartMenu';
let menu:StartMenu|undefined;
afterEach(()=>{menu?.destroy();menu=undefined;document.body.replaceChildren();});
describe('Bando Pirates Start menu',()=>{
 it('opens the existing actions, supports keyboard navigation and dismisses before launching',()=>{
  const action=vi.fn(()=>expect(document.querySelector<HTMLElement>('[role=menu]')!.hidden).toBe(true));
  const buttons=['Wardrobe','Room info','Wallet & collectibles','Scale','Calls','Microverse'].map(name=>{const button=document.createElement('button');button.textContent=name;button.onclick=action;return button;});menu=new StartMenu(document.body,buttons);
  const trigger=document.querySelector<HTMLButtonElement>('[aria-label=Start]')!,panel=document.querySelector<HTMLElement>('[role=menu]')!;expect(panel.hidden).toBe(true);expect(trigger.querySelector('img')!.src).toMatch(/^data:image\/png;base64,/);expect(panel.querySelectorAll('[role=menuitem]')).toHaveLength(6);
  trigger.click();expect(trigger.getAttribute('aria-expanded')).toBe('true');expect(document.activeElement).toBe(buttons[0]);
  buttons[0].dispatchEvent(new KeyboardEvent('keydown',{key:'End',bubbles:true}));expect(document.activeElement).toBe(buttons[5]);buttons[5].dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowDown',bubbles:true}));expect(document.activeElement).toBe(buttons[0]);buttons[0].dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}));expect(panel.hidden).toBe(true);expect(document.activeElement).toBe(trigger);
  trigger.click();buttons[3].click();expect(action).toHaveBeenCalledOnce();expect(trigger.getAttribute('aria-expanded')).toBe('false');
  trigger.click();document.body.dispatchEvent(new MouseEvent('pointerdown',{bubbles:true}));expect(panel.hidden).toBe(true);
  document.dispatchEvent(new KeyboardEvent('keydown',{ctrlKey:true,key:'Escape',bubbles:true}));expect(panel.hidden).toBe(false);const external=document.createElement('button');document.body.append(external);external.focus();expect(panel.hidden).toBe(true);
 });
 it('removes global shortcuts when the scene is destroyed',()=>{
  const action=document.createElement('button');action.textContent='Scale';menu=new StartMenu(document.body,[action]);const panel=document.querySelector<HTMLElement>('[role=menu]')!;menu.destroy();menu=undefined;document.dispatchEvent(new KeyboardEvent('keydown',{ctrlKey:true,key:'Escape',bubbles:true}));expect(panel.hidden).toBe(true);expect(document.querySelector('.bando-start')).toBeNull();
 });
});
