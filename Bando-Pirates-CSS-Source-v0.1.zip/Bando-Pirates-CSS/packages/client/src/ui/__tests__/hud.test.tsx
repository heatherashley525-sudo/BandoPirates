import React,{act} from 'react';
import {createRoot} from 'react-dom/client';
import {describe,it,expect,vi} from 'vitest';
const music=vi.hoisted(()=>({init:vi.fn(async()=>{}),destroy:vi.fn()}));
vi.mock('../../game-logic/YouTubePlayer',()=>({YouTubePlayer:class{init=music.init;destroy=music.destroy;setOnTitleLoaded(){}setOnTrackEnded(){}loadVideo(){}play(){}pause(){}setVolume(){}}}));
import {GameHUD} from '../GameHUD';
import {CallManager} from '../../game-logic/CallManager';
(globalThis as any).IS_REACT_ACT_ENVIRONMENT=true;
describe('floating game controls',()=>{
 it('starts chat across the top and distinguishes clicking the fixed-size music icon from dragging it',async()=>{
  const host=document.createElement('div');document.body.append(host);const root=createRoot(host);const calls=new CallManager({request:async()=>undefined as any,signal:()=>{},id:()=> 'local',room:()=> 'room'}),network={getSocketId:()=> 'local',getCalls:()=>calls};const scene={getOverlayParent:()=>host,getTaskbarVolumeHost:()=>host,getNetwork:()=>network,setChatCallback:(cb:Function)=>cb([]),setPlayerCountCallback:(cb:Function)=>cb(1),setDJCallback:()=>{},sendChat:vi.fn()};
  try{
   await act(async()=>root.render(<GameHUD scene={scene as any}/>));const chat=host.querySelector<HTMLElement>('[data-floating-panel="chat-spatial"]')!;expect(parseFloat(chat.style.top)).toBe(0);expect(parseFloat(chat.style.width)).toBe(window.innerWidth);expect(parseFloat(chat.style.left)).toBe(0);expect(chat.querySelector('.hud-caption')).toBeNull();expect(chat.querySelector('.titlebar')).toBeNull();expect(chat.querySelector('.chat-grip')).toBeNull();expect(host.textContent).not.toContain('Pomodoro');expect(host.textContent).not.toContain('GitHub');expect(host.querySelector('[aria-label="Open DJ"]')).not.toBeNull();expect(host.querySelector('[data-floating-panel="dj-window"]')).toBeNull();
   const pointer=(type:string,x:number,y:number)=>{const e=new MouseEvent(type,{bubbles:true,button:0,clientX:x,clientY:y});Object.defineProperty(e,'pointerId',{value:1});return e;};
   chat.querySelector('input')!.dispatchEvent(pointer('pointerdown',700,200));expect(chat.dataset.windowGesture).toBeUndefined();
   chat.dispatchEvent(pointer('pointerdown',700,20));chat.dispatchEvent(pointer('pointermove',700,50));chat.dispatchEvent(pointer('pointerup',700,50));expect(parseFloat(chat.style.top)).toBe(30);
   const before=parseFloat(chat.style.width);chat.querySelector('[data-edge="sw"]')!.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowRight',bubbles:true}));expect(parseFloat(chat.style.width)).toBe(before-8);
   const icon=host.querySelector<HTMLElement>('[data-floating-panel="dj-icon-compact"]')!,button=icon.querySelector('button')!;expect(icon.style.width).toBe('44px');expect(icon.style.height).toBe('44px');expect(icon.querySelector('.resize-handle')).toBeNull();const originalLeft=parseFloat(icon.style.left),originalTop=parseFloat(icon.style.top);
   await act(async()=>{button.dispatchEvent(pointer('pointerdown',36,window.innerHeight-38));button.dispatchEvent(pointer('pointermove',116,window.innerHeight-68));button.dispatchEvent(pointer('pointerup',116,window.innerHeight-68));button.click();});expect(parseFloat(icon.style.left)).toBe(originalLeft+80);expect(parseFloat(icon.style.top)).toBe(originalTop-30);expect(host.querySelector('[data-floating-panel="dj-window"]')).toBeNull();
   await act(async()=>{await new Promise(resolve=>setTimeout(resolve,0));button.click();});expect(host.querySelector('[data-floating-panel="dj-window"]')).not.toBeNull();expect(host.querySelector('[aria-label="Playlist"]')).not.toBeNull();await act(async()=>host.querySelector<HTMLButtonElement>('[aria-label="Collapse DJ"]')!.click());expect(host.querySelector('[aria-label="Open DJ"]')).not.toBeNull();expect(music.init).toHaveBeenCalledTimes(1);
  }finally{await act(async()=>root.unmount());host.remove();}
 });
});
