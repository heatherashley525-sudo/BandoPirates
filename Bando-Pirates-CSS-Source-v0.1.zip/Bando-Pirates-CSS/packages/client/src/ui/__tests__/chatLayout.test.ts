import {describe,it,expect} from 'vitest';
import {layoutChatBubbles,projectChatAnchor,CHAT_OVERLAP,type PositionedChatMessage} from '../chatLayout';
const message=(id:string,anchorX:number):PositionedChatMessage=>({id,playerId:id,playerName:id,content:'Hello',timestamp:1,anchorX});
describe('spatial chat ordering',()=>{
 it('projects send-time tiles onto the actual room view and clamps offscreen positions',()=>{
  expect(projectChatAnchor({x:5,y:5},1000,500,1.5)).toBe(.5);expect(projectChatAnchor({x:2,y:7},1000,500,1.5)).toBe(.26);expect(projectChatAnchor({x:7,y:2},1000,500,1.5)).toBe(.74);expect(projectChatAnchor({x:9,y:1},390,195,3)).toBe(1);
 });
 it('allows only a small overlap while preserving both chronological edges for short and wrapped bubbles',()=>{
  const messages=[message('a',.1),message('b',.8),message('c',.5),message('d',0)],sizes={a:{width:160,height:92},b:{width:100,height:30},c:{width:420,height:130},d:{width:90,height:24}};
  for(const width of [390,1360]){const {placements:p}=layoutChatBubbles(messages,sizes,width,300);for(let i=1;i<p.length;i++){expect(p[i].top).toBeGreaterThan(p[i-1].top);expect(p[i].top+p[i].height).toBeGreaterThan(p[i-1].top+p[i-1].height);expect(p[i-1].top+p[i-1].height-p[i].top).toBeLessThanOrEqual(CHAT_OVERLAP);}for(const bubble of p){expect(bubble.left).toBeGreaterThanOrEqual(8);expect(bubble.left+bubble.width).toBeLessThanOrEqual(width-8);}expect(p[0].left).toBeLessThan(p[1].left);}
 });
 it('puts new arrivals at the bottom rather than sorting by sender location or client timestamps',()=>{
  const messages=[message('old',.9),{...message('new',.1),timestamp:0}],result=layoutChatBubbles(messages,{},700,300);expect(result.placements[1].top).toBeGreaterThan(result.placements[0].top);expect(result.placements.at(-1)!.top+result.placements.at(-1)!.height).toBe(290);
 });
});
