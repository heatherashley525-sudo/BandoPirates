import React,{act,useCallback,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {expect,it,vi} from 'vitest';
import {PublicStreetMusic} from '../PublicStreetMusic';

(globalThis as any).IS_REACT_ACT_ENVIRONMENT=true;

it('attempts the quiet arrival track once when visible and offers play if autoplay is blocked',async()=>{
  let onVisible:IntersectionObserverCallback|undefined;
  let events:Record<string,(event?:any)=>void>={};
  const media={
    cueVideoById:vi.fn(),
    loadVideoById:vi.fn(),
    setVolume:vi.fn(),
    playVideo:vi.fn(),
    getPlayerState:()=>-1,
    destroy:vi.fn(),
  };
  vi.stubGlobal('YT',{
    PlayerState:{PLAYING:1,ENDED:0},
    Player:class {
      constructor(mount:HTMLElement,options:{events:typeof events}){
        mount.replaceWith(document.createElement('iframe'));
        events=options.events;
        queueMicrotask(()=>events.onReady());
        return media;
      }
    },
  });
  vi.stubGlobal('IntersectionObserver',class{
    constructor(callback:IntersectionObserverCallback){onVisible=callback;}
    observe(){}
    disconnect(){}
  });
  const visibility=vi.spyOn(document,'hidden','get').mockReturnValue(false);
  const host=document.createElement('div');
  document.body.append(host);
  const root=createRoot(host);
  const Harness=({volume}:{volume:number})=>{
    const [done,setDone]=useState(false);
    const close=useCallback(()=>setDone(true),[]);
    return done?null:<PublicStreetMusic volume={volume} onDone={close}/>;
  };
  const show=(ratio:number)=>onVisible?.([{isIntersecting:ratio>0,intersectionRatio:ratio} as IntersectionObserverEntry],{} as IntersectionObserver);
  try{
    await act(async()=>root.render(<Harness volume={8}/>));
    expect(media.cueVideoById).toHaveBeenCalledWith('-n2KrXS5Lmc');
    show(.4);
    expect(media.loadVideoById).not.toHaveBeenCalled();
    show(1);
    show(.9);
    expect(media.loadVideoById).toHaveBeenCalledExactlyOnceWith('-n2KrXS5Lmc');
    expect(media.setVolume).toHaveBeenCalledWith(8);
    expect(media.setVolume.mock.invocationCallOrder[0]).toBeLessThan(media.loadVideoById.mock.invocationCallOrder[0]);
    await act(async()=>events.onAutoplayBlocked());
    const play=[...host.querySelectorAll('button')].find(button=>button.textContent==='Play music')!;
    play.click();
    expect(media.playVideo).toHaveBeenCalledOnce();
    await act(async()=>root.render(<Harness volume={0}/>));
    expect(media.setVolume).toHaveBeenLastCalledWith(0);
    expect(media.loadVideoById).toHaveBeenCalledOnce();
    await act(async()=>events.onStateChange({data:0}));
    expect(host.querySelector('[data-floating-panel="public-street-music"]')).toBeNull();
    expect(media.destroy).toHaveBeenCalledOnce();
  }finally{
    await act(async()=>root.unmount());
    host.remove();
    visibility.mockRestore();
    vi.unstubAllGlobals();
  }
});
