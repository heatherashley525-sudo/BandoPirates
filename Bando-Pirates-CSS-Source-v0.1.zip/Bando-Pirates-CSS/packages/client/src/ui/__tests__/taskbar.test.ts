import {afterEach,describe,it,expect,vi} from 'vitest';
import {Taskbar} from '../Taskbar';
import {ChildWindow} from '../../theme/ChildWindow';
import {taskbarHeight,taskbarLayout,windowArea} from '../../theme/workArea';
let bar:Taskbar|undefined;const controls:ChildWindow[]=[];
afterEach(()=>{bar?.destroy();bar=undefined;controls.splice(0).forEach(c=>c.destroy());document.body.replaceChildren();vi.useRealTimers();});
function host(){const p=document.createElement('div');document.body.append(p);bar=new Taskbar(p,[]);return p;}
function program(parent:HTMLElement,name:string){const win=document.createElement('dialog');win.className=name;win.innerHTML='<header class="titlebar"><span class="window-title">'+name+'</span></header>';parent.append(win);const c=new ChildWindow(win,{maximizable:true});controls.push(c);win.setAttribute('open','');c.open({x:100,y:100,w:420,h:300});return {win,c};}
describe('HeatherOS game taskbar',()=>{
 it('tracks open programs, shares their icons, and minimizes/restores without closing them',()=>{
  const p=host(),{win,c}=program(p,'wardrobe'),button=p.querySelector<HTMLButtonElement>('.task-button')!;expect(p.querySelector('[aria-label="Show desktop"]')).toBeNull();expect(button.getAttribute('aria-pressed')).toBe('true');expect(button.querySelector('img')!.src).toBe(win.querySelector('header img')!.getAttribute('src'));
  button.click();expect(c.isOpen()).toBe(true);expect(c.isMinimized()).toBe(true);expect(win.hidden).toBe(true);expect(win.open).toBe(true);button.click();expect(win.hidden).toBe(false);expect(c.isMinimized()).toBe(false);expect(win.style.width).toBe('420px');c.minimize();c.open();expect(win.hidden).toBe(false);
  c.toggleMaximize();expect(parseInt(win.style.height)).toBe(window.innerHeight-taskbarHeight(window.innerWidth));c.close();win.removeAttribute('open');expect(p.querySelector('.task-button')).toBeNull();
 });
 it('shows a ticking clock, calendar and truthful room connection status',()=>{
  vi.useFakeTimers();vi.setSystemTime(new Date('2026-11-08T22:15:06Z'));const p=host();bar!.setConnection(true,false,4);expect(p.querySelector('.tray-network')!.getAttribute('aria-label')).toContain('Connected');expect(p.querySelector('.tray-network-popup')!.textContent).toContain('4 players');bar!.setConnection(true,true);expect(p.querySelector<HTMLElement>('.tray-network')!.dataset.online).toBe('false');expect(p.querySelector('.tray-network')!.getAttribute('aria-label')).toContain('Local preview');
  const clock=p.querySelector<HTMLButtonElement>('.tray-clock')!,before=clock.textContent;vi.advanceTimersByTime(1000);expect(clock.textContent).not.toBe(before);expect(clock.textContent).toMatch(/\d\d:\d\d:\d\d/);clock.click();const date=p.querySelector<HTMLDialogElement>('.date-time-window')!;expect(date.open).toBe(true);expect(date.querySelectorAll('[aria-current=date]')).toHaveLength(1);expect(date.querySelector('.calendar-month strong')!.textContent).toContain('2026');expect([...p.querySelectorAll('.task-button')].some(b=>b.textContent==='Date and time')).toBe(true);
  date.querySelector<HTMLButtonElement>('[aria-label="Next month"]')!.click();expect(date.querySelectorAll('[aria-current=date]')).toHaveLength(0);date.querySelector<HTMLButtonElement>('[aria-label="Close date and time"]')!.click();expect(date.open).toBe(false);
 });
 it('refits already open windows when the taskbar first reserves its strip',()=>{
  const p=document.createElement('div');document.body.append(p);const {win,c}=program(p,'wardrobe');c.open();win.style.top='600px';c.toggleMaximize();expect(parseInt(win.style.height)).toBe(window.innerHeight);bar=new Taskbar(p,[]);expect(parseInt(win.style.height)).toBe(window.innerHeight-taskbarHeight(window.innerWidth));
 });
 it('allows task ordering and reserves the mobile work area above the bar',()=>{
  const p=host();program(p,'wardrobe');program(p,'room-scale-window');const buttons=p.querySelectorAll<HTMLButtonElement>('.task-button');buttons[1].dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowLeft',ctrlKey:true,shiftKey:true,bubbles:true}));expect(p.querySelector('.task-button')).toBe(buttons[1]);expect(taskbarHeight(390)).toBe(44);expect(taskbarHeight(1366)).toBe(44);expect(windowArea(p).height).toBe(window.innerHeight-taskbarHeight(window.innerWidth));
 });
 it('adds a row only after capacity is filled, and removes it when a program closes',()=>{
  expect(taskbarLayout(390,5,198)).toEqual({columns:5,rows:1,height:44});expect(taskbarLayout(390,6,198)).toEqual({columns:5,rows:2,height:81});expect(taskbarLayout(390,11,198).rows).toBe(3);expect(taskbarLayout(1366,10,900).rows).toBe(2);
  const p=host();Object.defineProperty(p.querySelector('.tasks'),'clientWidth',{value:160,configurable:true});const a=program(p,'wardrobe');expect(p.dataset.taskbarHeight).toBe('44');const b=program(p,'room-scale-window');expect(p.dataset.taskbarHeight).toBe('81');expect(windowArea(p).height).toBe(window.innerHeight-81);b.c.close();b.win.removeAttribute('open');expect(p.dataset.taskbarHeight).toBe('44');expect(a.c.isOpen()).toBe(true);
 });
});
