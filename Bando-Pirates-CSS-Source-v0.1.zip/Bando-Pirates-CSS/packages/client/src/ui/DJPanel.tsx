import React,{useEffect,useRef,useState} from 'react';
import {getCurrentTrack,type DJState} from '@cocoworking/shared';
import {YouTubePlayer} from '../game-logic/YouTubePlayer';
import {FloatingPanel} from './FloatingPanel';
import {musicIconBounds} from './hudLayout';
import {PROGRAM_ICONS} from './programIcons';
interface DJPanelProps {
 djState:DJState;isLocalDJ:boolean;offline?:boolean;deferPlayback?:boolean;onClaim:()=>void;onRelease:()=>void;onPlay:()=>void;onPause:()=>void;onNext:()=>void;onPrev:()=>void;onVolume:(vol:number)=>void;onAddTrack:(url:string)=>void;onUpdateTitle:(id:string,title:string)=>void;onPlayerReady?:(player:YouTubePlayer)=>void;
}
export function DJPanel({djState,isLocalDJ,offline=false,deferPlayback=false,onClaim,onRelease,onPlay,onPause,onNext,onPrev,onVolume,onAddTrack,onUpdateTitle,onPlayerReady}:DJPanelProps){
 const [expanded,setExpanded]=useState(false),[url,setUrl]=useState(''),[ready,setReady]=useState(false);
 const player=useRef<YouTubePlayer|null>(null),lastTrack=useRef<string|null>(null),current=useRef(djState);current.current=djState;
 const track=getCurrentTrack(djState),hasDJ=!!djState.djId;
 useEffect(()=>{if(offline||deferPlayback)return;let disposed=false;const music=new YouTubePlayer('yt-dj-player');player.current=music;void music.init().then(()=>{if(disposed)return;music.setOnTitleLoaded(title=>{const playing=getCurrentTrack(current.current);if(playing)onUpdateTitle(playing.youtubeId,title);});onPlayerReady?.(music);setReady(true);}).catch(()=>{});return()=>{disposed=true;music.destroy();player.current=null;};},[offline,deferPlayback]);
 useEffect(()=>{const music=player.current;if(!music||!ready)return;if(track&&track.youtubeId!==lastTrack.current){if(djState.isPlaying)music.loadVideo(track.youtubeId);else music.cueVideo(track.youtubeId);lastTrack.current=track.youtubeId;return;}if(djState.isPlaying)music.play();else music.pause();},[ready,djState.isPlaying,djState.currentTrackIndex,djState.volume,track?.youtubeId]);
 useEffect(()=>{player.current?.setOnTrackEnded(()=>{if(isLocalDJ)onNext();});},[ready,isLocalDJ,onNext]);
 if(!expanded)return <FloatingPanel id="dj-icon-compact" label="DJ launcher" initial={musicIconBounds} minWidth={44} minHeight={44} resizable={false} dragButtons className="music-launcher"><button type="button" className="hud-dj-icon" aria-label="Open DJ" title="DJ" aria-expanded="false" onClick={()=>setExpanded(true)}><img src={PROGRAM_ICONS.dj} className="program-launch-icon" alt="" draggable={false}/></button></FloatingPanel>;
 return <FloatingPanel id="dj-window" label="DJ" initial={(_w,h)=>({x:16,y:Math.max(16,h-406),w:310,h:390})} minWidth={240} minHeight={260} className="hud-dj">
  <div className="dj-tools"><p className="hud-caption">♫ DJ</p><button type="button" aria-label="Collapse DJ" onClick={()=>setExpanded(false)}>▁</button></div>
  <div className="dj-track"><strong>{track?.title||'No music'}</strong><span className="hud-muted">{track?.artist||''}</span></div>
  <p className="hud-muted">{hasDJ?'DJ: '+djState.djName:'DJ booth available'} · {djState.playlist.length} tracks</p>
  <ol className="dj-playlist" aria-label="Playlist" data-no-drag>{djState.playlist.map((item,index)=><li key={index} aria-current={index===djState.currentTrackIndex?'true':undefined}>{item.title}</li>)}</ol>
  {offline?<p className="hud-muted">DJ playback and shared controls need the hosted multiplayer game.</p>:isLocalDJ?<>
   <div className="dj-tools"><button type="button" aria-label="Previous track" onClick={onPrev}>⏮</button><button type="button" aria-label={djState.isPlaying?'Pause music':'Play music'} onClick={djState.isPlaying?onPause:onPlay}>{djState.isPlaying?'⏸':'▶'}</button><button type="button" aria-label="Next track" onClick={onNext}>⏭</button><input type="range" aria-label="Room music volume" min={0} max={100} value={djState.volume} onChange={event=>onVolume(Number(event.target.value))}/></div>
   <form className="dj-add" onSubmit={event=>{event.preventDefault();if(url.trim()){onAddTrack(url.trim());setUrl('');}}}><input aria-label="YouTube link" placeholder="Paste a YouTube link…" value={url} onChange={event=>setUrl(event.target.value)}/><button type="submit" aria-label="Add track">+</button></form><button type="button" onClick={onRelease}>Stop DJ</button>
  </>:!hasDJ?<button type="button" onClick={onClaim}>Become DJ</button>:<p className="hud-muted">Use the volume control for your own sound.</p>}
 </FloatingPanel>;
}
