import {BANDO_PIRATES_ICON} from './bandoIcon';
import {programIcon,type ProgramIcon} from './programIcons';
import '../theme/heatheros-start-menu.css';
import './start-menu.css';

/** HeatherOS shell menu, with the existing room actions and Bando branding. */
export class StartMenu {
 private root:HTMLElement;private menu:HTMLElement;private trigger:HTMLButtonElement;private items:HTMLButtonElement[];private opened=false;
 constructor(parent:HTMLElement,items:HTMLButtonElement[]){
  this.items=items;this.root=document.createElement('div');this.root.className='bando-start';parent.append(this.root);
  this.trigger=document.createElement('button');this.trigger.type='button';this.trigger.className='start-button';this.trigger.setAttribute('aria-label','Start');this.trigger.setAttribute('aria-haspopup','menu');this.trigger.setAttribute('aria-expanded','false');this.trigger.setAttribute('aria-controls','bando-start-menu');
  const icon=document.createElement('img');icon.className='start-symbol';icon.src=BANDO_PIRATES_ICON;icon.alt='';const label=document.createElement('span');label.className='start-label';label.textContent='Start';this.trigger.append(icon,label);this.root.append(this.trigger);
  this.menu=document.createElement('nav');this.menu.id='bando-start-menu';this.menu.className='menu start-menu bevel';this.menu.setAttribute('role','menu');this.menu.setAttribute('aria-label','Bando Pirates Start menu');this.menu.hidden=true;
  const icons:ProgramIcon[]=['wardrobe','room','wallet','scale','calls','microverse','logout'];
  items.forEach((button,index)=>{const text=button.textContent||'';button.classList.add('menu-row');button.setAttribute('role','menuitem');button.tabIndex=-1;const program=button.dataset.program as ProgramIcon|undefined;const image=programIcon(program||icons[index]||'room');const name=document.createElement('span');name.className='menu-label';name.textContent=text;button.replaceChildren(image,name);this.menu.append(button);});this.root.append(this.menu);
  this.trigger.addEventListener('click',this.toggle);this.trigger.addEventListener('keydown',this.triggerKey);this.menu.addEventListener('keydown',this.menuKey);this.menu.addEventListener('click',this.activate,true);this.menu.addEventListener('pointerover',this.hover);this.menu.addEventListener('focusin',this.highlight);document.addEventListener('pointerdown',this.outside,true);document.addEventListener('focusin',this.focusOutside);document.addEventListener('keydown',this.shortcut);
 }
 private show(last=false){this.opened=true;this.menu.hidden=false;this.trigger.classList.add('pressed');this.trigger.setAttribute('aria-expanded','true');const enabled=this.items.filter(item=>!item.disabled);(last?enabled.at(-1):enabled[0])?.focus();}
 private close(restoreFocus=false){this.opened=false;this.menu.hidden=true;this.trigger.classList.remove('pressed');this.trigger.setAttribute('aria-expanded','false');this.items.forEach(item=>item.classList.remove('is-highlighted'));if(restoreFocus)this.trigger.focus();}
 private toggle=()=>{if(this.opened)this.close(true);else this.show();};
 private activate=(event:MouseEvent)=>{if((event.target as HTMLElement).closest('[role=menuitem]'))this.close();};
 private mark(item:HTMLElement|null){this.items.forEach(button=>button.classList.toggle('is-highlighted',button===item));}
 private hover=(event:PointerEvent)=>this.mark((event.target as HTMLElement).closest<HTMLButtonElement>('[role=menuitem]'));
 private highlight=(event:FocusEvent)=>this.mark(event.target as HTMLElement);
 private outside=(event:PointerEvent)=>{if(this.opened&&!this.root.contains(event.target as Node))this.close();};
 private focusOutside=(event:FocusEvent)=>{if(this.opened&&!this.root.contains(event.target as Node))this.close();};
 private triggerKey=(event:KeyboardEvent)=>{if(event.key==='ArrowDown'||event.key==='ArrowUp'){event.preventDefault();event.stopPropagation();this.show(event.key==='ArrowUp');}};
 private shortcut=(event:KeyboardEvent)=>{if(event.ctrlKey&&event.key==='Escape'){event.preventDefault();event.stopPropagation();this.toggle();}};
 private menuKey=(event:KeyboardEvent)=>{
  event.stopPropagation();if(event.key==='Escape'){event.preventDefault();this.close(true);return;}if(event.key==='Tab'){this.close();return;}
  const enabled=this.items.filter(item=>!item.disabled),index=enabled.indexOf(document.activeElement as HTMLButtonElement);let next:number|undefined;
  if(event.key==='ArrowDown')next=(index+1)%enabled.length;else if(event.key==='ArrowUp')next=(index-1+enabled.length)%enabled.length;else if(event.key==='Home')next=0;else if(event.key==='End')next=enabled.length-1;
  if(next!==undefined){event.preventDefault();enabled[next]?.focus();}
 };
 destroy(){document.removeEventListener('pointerdown',this.outside,true);document.removeEventListener('focusin',this.focusOutside);document.removeEventListener('keydown',this.shortcut);this.root.remove();}
}
