import React,{useEffect,useRef,useState,useSyncExternalStore} from 'react';
import type {CallManager} from '../game-logic/CallManager';
import {FloatingPanel} from './FloatingPanel';
function Feed({stream,name,local=false,video,status}:{stream?:MediaStream;name:string;local?:boolean;video:boolean;status?:string}){
 const ref=useRef<HTMLVideoElement>(null),[blocked,setBlocked]=useState(false);
 const play=()=>{const element=ref.current;if(element?.srcObject)void element.play().then(()=>setBlocked(false)).catch(()=>setBlocked(true));};
 useEffect(()=>{const element=ref.current;if(!element)return;element.srcObject=stream||null;play();const refresh=()=>{element.srcObject=null;element.srcObject=stream||null;play();};stream?.addEventListener('addtrack',refresh);return()=>{stream?.removeEventListener('addtrack',refresh);element.pause();element.srcObject=null;};},[stream]);
 return <div className="call-feed" data-no-drag><video ref={ref} autoPlay playsInline muted={local} aria-label={name+(local?' local preview':' call video')} style={{opacity:video?1:0}}/>{!video&&<span className="call-voice-mark" aria-hidden="true">♫</span>}<div className="call-feed-caption"><strong>{name}{local?' (you)':''}</strong>{status&&<small>{status}</small>}</div>{blocked&&<button className="call-play" onClick={play}>Play audio / video</button>}</div>;
}
export function CallPanel({manager,localId,offline=false}:{manager:CallManager;localId?:string;offline?:boolean}){
 const state=useSyncExternalStore(manager.subscribe,manager.getSnapshot),[audio,setAudio]=useState(true),[video,setVideo]=useState(false),[to,setTo]=useState('');
 useEffect(()=>{const leave=()=>manager.leave();window.addEventListener('pagehide',leave);return()=>window.removeEventListener('pagehide',leave);},[manager]);
 if(!state.open)return null;
 const call=state.call,broadcast=state.roster.broadcast,viewer=call?.kind==='broadcast'&&call.presenterId!==localId;
 const others=state.roster.players.filter(p=>p.id!==localId&&!call?.invited.some(i=>i.id===p.id)),target=others.some(p=>p.id===to&&!p.busy)?to:others.find(p=>!p.busy)?.id||'',disabled=offline||!state.connected||state.pending;
 const picker=<label className="call-select">Player<select aria-label="Player to call" value={target} onChange={e=>setTo(e.target.value)} disabled={disabled}><option value="">Choose a player</option>{others.map(p=><option key={p.id} value={p.id} disabled={p.busy}>{p.name}{p.busy?' · In a call':''}</option>)}</select></label>;
 const label=call?.kind==='broadcast'?'Room broadcast':call?.kind==='room'?'Room call':call&&call.members.length>2?'Private group call':'Private call';
 const feeds=call?.members.filter(m=>m.id!==localId&&(call.kind!=='broadcast'||m.id===call.presenterId))||[];
 return <FloatingPanel id="calls" label="Voice and webcam calls" className="hud-calls window active" minWidth={280} minHeight={300} initial={(w,h)=>({x:Math.max(8,w-430),y:Math.min(100,Math.max(0,h-490)),w:Math.min(414,w-16),h:Math.min(480,h-16)})}>
  <header className="titlebar"><span className="window-title">Voice & webcam</span><div className="window-controls"><button type="button" className="window-control window-close" aria-label="Close calls and leave call" onClick={()=>manager.close()}>×</button></div></header>
  <div className="call-body" data-no-drag>
   {offline&&<p className="hud-muted">Calls are available in the hosted multiplayer game.</p>}
   {state.error&&<p role="alert" className="call-error">{state.error}</p>}
   {call?<>
    <p className="hud-caption">{label} · {call.kind==='broadcast'?call.members.length-1+' watching':call.members.length+' people'}</p>
    {call.kind==='private'&&call.members.length===1&&<p role="status">Waiting for invited players…</p>}
    <div className="call-feeds">{!viewer&&<Feed name="You" stream={state.local} local video={state.video} status={state.audio?'Microphone on':'Microphone off'}/>}
     {feeds.map(member=>{const peer=state.peers.find(p=>p.id===member.id);return <Feed key={member.id} name={member.name} stream={peer?.stream} video={member.video} status={(peer?.status||'Connecting…')+(member.audio?'':' · Mic off')}/>;})}
    </div>
    {viewer?<p className="hud-muted">Watching only. Your microphone and camera stay off.</p>:<div className="call-actions">
     <button disabled={state.pending||state.switchingCamera} aria-pressed={state.audio} onClick={()=>void manager.toggle('audio')}>{state.audio?'Mute microphone':'Enable microphone'}</button>
     <button disabled={state.pending||state.switchingCamera} aria-pressed={state.video} onClick={()=>void manager.toggle('video')}>{state.video?'Turn camera off':'Turn camera on'}</button>
     {(state.video||state.switchingCamera)&&<button type="button" disabled={state.pending||state.switchingCamera} onClick={()=>void manager.switchCamera()}>{state.switchingCamera?'Switching camera…':'Switch camera'}</button>}
    </div>}
    {call.kind==='broadcast'&&call.presenterId===localId&&<p className="hud-muted">{state.peers.filter(p=>p.status==='Connected').length} of {state.peers.length} viewers connected</p>}
    {call.kind==='private'&&<div className="call-section"><p className="hud-caption">Invite to this call</p><div className="call-select-row">{picker}<button disabled={disabled||!target} onClick={()=>void manager.addInvite(target)}>Invite player</button></div>{call.invited.length>0&&<p className="call-pending">Invited: {call.invited.map(i=>i.name).join(', ')}</p>}</div>}
    {call.kind!=='broadcast'&&<p className="call-members">{call.members.map(m=>m.name).join(', ')}</p>}
    <button onClick={()=>manager.leave()}>{call.kind==='broadcast'&&call.presenterId===localId?'End broadcast':call.kind==='broadcast'?'Stop watching':call.kind==='private'&&call.members.length===1?'Cancel call':'Leave call'}</button>
   </>:<>
    {state.invite&&<p role="status"><strong>{state.invite.fromName}</strong> is inviting you to a private call.</p>}
    <fieldset disabled={disabled}><legend>Share when joining</legend><label><input type="checkbox" checked={audio} onChange={e=>setAudio(e.target.checked)}/> Microphone</label><label><input type="checkbox" checked={video} onChange={e=>setVideo(e.target.checked)}/> Camera</label></fieldset>
    {state.pending?<div className="call-actions"><p role="status">Preparing your call…</p><button onClick={()=>manager.leave()}>Cancel</button></div>:state.invite?<div className="call-actions"><button disabled={disabled} onClick={()=>void manager.start('accept',{audio,video})}>Accept invitation</button><button onClick={()=>void manager.decline()}>Decline</button></div>:<>
     <div className="call-section"><p className="hud-caption">Private call</p><div className="call-select-row">{picker}<button disabled={disabled||!target} onClick={()=>void manager.start('private',{audio,video},target)}>Invite player</button></div></div>
     <div className="call-section"><p className="hud-caption">Room call · Everyone in the room</p><button disabled={disabled} onClick={()=>void manager.start('room',{audio,video})}>Join room call ({state.roster.roomCount})</button></div>
     <div className="call-section"><p className="hud-caption">Room broadcast</p>{broadcast?<><p>{broadcast.presenterName} is presenting · {broadcast.viewers} watching</p><button disabled={disabled} onClick={()=>void manager.start('watch',{audio:false,video:false})}>{broadcast.video?'Watch broadcast':'Listen to broadcast'}</button></>:<><button disabled={disabled} onClick={()=>void manager.start('broadcast',{audio,video})}>Start broadcast</button></>}</div>
    </>}
    <p className="hud-muted">Both devices off = listen only. Close or leave to stop sharing.</p>
   </>}
   {state.notice&&<p className="hud-muted" role="status">{state.notice}</p>}
  </div>
 </FloatingPanel>;
}
