import type {WindowBounds} from '../theme/windowGeometry';
export const compactHUD=(width:number)=>width<1120;
export function chatBounds(width:number,height:number):WindowBounds{return{x:0,y:0,w:width,h:Math.min(360,Math.max(240,height*.36))};}
export function chatComposeBounds(width:number,height:number):WindowBounds{
 const w=Math.min(380,width-16),h=46;
 return {x:width-w-8,y:height-h-8,w,h};
}
export function onlineBounds(width:number,height:number):WindowBounds{return{x:16,y:chatBounds(width,height).h+12,w:110,h:40};}
export function musicIconBounds(width:number,height:number):WindowBounds{return{x:16,y:height-52,w:44,h:44};}
export function audioBounds(width:number,height:number):WindowBounds{const x=compactHUD(width)?128:184;return{x,y:height-64,w:Math.min(224,width-x-16),h:56};}
