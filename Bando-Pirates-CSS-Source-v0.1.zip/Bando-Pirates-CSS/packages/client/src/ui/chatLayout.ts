import type {ChatMessage,Position} from '@cocoworking/shared';
export interface PositionedChatMessage extends ChatMessage {anchorX?:number}
export interface BubbleSize {width:number;height:number}
export interface BubblePlacement extends BubbleSize {left:number;top:number;tail:number}
export const CHAT_OVERLAP=2;
export function projectChatAnchor(position:Position,width:number,origin:number,scale:number){
 if(!Number.isFinite(position.x)||!Number.isFinite(position.y)||width<=0)return .5;
 return Math.max(0,Math.min(1,(origin+(position.x-position.y)*32*scale)/width));
}
/** Preserve arrival order in both vertical edges, with at most a two-pixel overlap. */
export function layoutChatBubbles(messages:readonly PositionedChatMessage[],sizes:Record<string,BubbleSize>,width:number,height:number){
 const placements:BubblePlacement[]=[];let top=8;
 for(const message of messages){
  const size=sizes[message.id]||{width:Math.min(260,width-16),height:20},w=Math.max(1,Math.min(size.width,width-16)),h=Math.max(20,size.height),anchor=Math.max(0,Math.min(1,Number.isFinite(message.anchorX)?message.anchorX!:.5))*width;
  const left=Math.max(8,Math.min(Math.max(8,width-w-8),anchor-w/2));
  placements.push({left,top,width:w,height:h,tail:Math.max(12,Math.min(w-12,anchor-left))});top+=h-CHAT_OVERLAP;
 }
 const contentHeight=placements.length?placements.at(-1)!.top+placements.at(-1)!.height+10:height,offset=Math.max(0,height-contentHeight);
 return {height:Math.max(height,contentHeight),placements:placements.map(p=>({...p,top:p.top+offset}))};
}
