import React,{useEffect,useRef,useState} from 'react';
import {createGame} from '../game-logic/createGame';
import type {CoworkingScene} from '../scenes/CoworkingScene';
import {Lobby} from './Lobby';
import {GameHUD} from './GameHUD';
export function App({offline=false,skipLobby=false}:{offline?:boolean;skipLobby?:boolean}){
 const container=useRef<HTMLDivElement>(null);const [player,setPlayer]=useState<{name:string;color:number}|null>(skipLobby?{name:'Heather',color:0xe995c4}:null);const [scene,setScene]=useState<CoworkingScene|null>(null);
 useEffect(()=>{if(!player||!container.current)return;const game=createGame(container.current,player.name,player.color,offline);setScene(game.scene.getScene('CoworkingScene'));return()=>game.destroy();},[player,offline]);
 if(!player)return <Lobby onJoin={(name,color)=>setPlayer({name,color})}/>;
 return <><div ref={container} style={{width:'100%',height:'100%'}}/>{scene&&<GameHUD scene={scene} offline={offline} onChangePlayer={skipLobby?undefined:()=>{setScene(null);setPlayer(null);}}/>}</>;
}
