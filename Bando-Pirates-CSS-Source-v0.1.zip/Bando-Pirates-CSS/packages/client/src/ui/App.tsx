import React,{useEffect,useRef,useState} from 'react';
import {createGame} from '../game-logic/createGame';
import type {CoworkingScene} from '../scenes/CoworkingScene';
import {Lobby} from './Lobby';
import {GameHUD} from './GameHUD';
import {PUBLIC_STREET_ID} from '@cocoworking/shared';
export function App({offline=false,skipLobby=false}:{offline?:boolean;skipLobby?:boolean}){
 const container=useRef<HTMLDivElement>(null);const [player,setPlayer]=useState<{name:string;color:number;publicStreet:boolean}|null>(skipLobby?{name:'Heather',color:0xe995c4,publicStreet:false}:null);const [scene,setScene]=useState<CoworkingScene|null>(null);
 useEffect(()=>{
  if(!player||!container.current)return;
  const game=createGame(container.current,player.name,player.color,offline,()=>{
   setScene(null);
   setPlayer(null);
  },player.publicStreet,destination=>{
   const publicStreet=destination===PUBLIC_STREET_ID;
   if(publicStreet===player.publicStreet)return;
   setScene(null);
   setPlayer({...player,publicStreet});
  });
  setScene(game.scene.getScene('CoworkingScene'));
  return()=>game.destroy();
 },[player,offline]);
 if(!player)return <Lobby onJoin={(name,color,publicStreet)=>setPlayer({name,color,publicStreet})}/>;
 return <><div ref={container} style={{width:'100%',height:'100%'}}/>{scene&&<GameHUD scene={scene} offline={offline} publicStreet={player.publicStreet}/>}</>;
}
