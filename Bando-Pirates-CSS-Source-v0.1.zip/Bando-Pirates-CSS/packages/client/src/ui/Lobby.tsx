import { getActiveProfile,listProfiles,activateProfile,createLocalProfile,updateProfile } from "../game-logic/playerProfiles";
import React, { useState } from "react";

const COLOR_OPTIONS = [
  { name: "Rouge", value: 0xff6b6b },
  { name: "Bleu", value: 0x48dbfb },
  { name: "Jaune", value: 0xfeca57 },
  { name: "Rose", value: 0xff9ff3 },
  { name: "Indigo", value: 0x54a0ff },
  { name: "Violet", value: 0x5f27cd },
  { name: "Teal", value: 0x01a3a4 },
  { name: "Magenta", value: 0xf368e0 },
];

interface LobbyProps {
  onJoin: (name: string, color: number) => void;
}

function loadSaved() { return getActiveProfile(); }
function saveProfile(name:string,color:number) { const current=getActiveProfile();updateProfile(current.localId,{name,color}); }

export function Lobby({ onJoin }: LobbyProps) {
  const saved = loadSaved();
  const [name, setName] = useState(saved.name);
  const [profileId,setProfileId]=useState(saved.localId);
  const [profiles,setProfiles]=useState(listProfiles());
  const [selectedColor, setSelectedColor] = useState(saved.color);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = name.trim() || `Guest${Math.floor(Math.random() * 999)}`;
    saveProfile(trimmed, selectedColor);
    onJoin(trimmed, selectedColor);
  };

  return (
    <div style={styles.overlay}>
      <div style={styles.card}>
        <h1 style={styles.title}>Bando Pirates</h1>
        <p style={styles.subtitle}>Original CSS artwork edition</p>

        <form onSubmit={handleSubmit} style={styles.form}>
          <label htmlFor="player-profile" style={styles.label}>Player profile</label>
          <select id="player-profile" style={{...styles.input,colorScheme:'light'}} value={profileId} onChange={event=>{
            activateProfile(event.target.value);const profile=getActiveProfile();setProfileId(profile.localId);setName(profile.name);setSelectedColor(profile.color);
          }}>{profiles.map((profile,index)=><option key={profile.localId} value={profile.localId}>{profile.name||`New player ${index+1}`}</option>)}</select>
          <button type="button" style={{...styles.joinBtn,marginTop:8,marginBottom:18}} onClick={()=>{
            const profile=createLocalProfile();setProfiles(listProfiles());setProfileId(profile.localId);setName('');setSelectedColor(profile.color);
          }}>New player</button>
          <label htmlFor="player-name" style={styles.label}>Your name</label>
          <input
            id="player-name"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Heather"
            maxLength={20}
            style={styles.input}
            autoFocus
          />

          <label style={{ ...styles.label, marginTop: 16 }}>Your color</label>
          <div style={styles.colors}>
            {COLOR_OPTIONS.map((c) => (
              <button
                key={c.value}
                className="swatch"
                type="button"
                onClick={() => setSelectedColor(c.value)}
                style={{
                  ...styles.colorBtn,
                  backgroundColor: `#${c.value.toString(16).padStart(6, "0")}`,
                  outline: selectedColor === c.value ? "2px solid #fff" : "2px solid transparent",
                  transform: selectedColor === c.value ? "scale(1.2)" : "scale(1)",
                }}
                title={c.name}
              />
            ))}
          </div>

          <button type="submit" style={styles.joinBtn}>
            Join
          </button>
        </form>

        <p style={styles.hint}>Profiles are remembered on this browser.<br/>WASD or arrow keys to move</p>
      </div>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  overlay: {
    position: "absolute",
    inset: 0,
    background: "#18343b",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontFamily: "Tahoma, 'MS Sans Serif', Arial, sans-serif",
    color: "var(--ui-text)",
  },
  card: {
    background: "var(--ui-window-background)",
    border: "1px solid rgba(255, 255, 255, 0.1)",
    borderRadius: 12,
    padding: "40px 48px",
    textAlign: "center",
    maxWidth: 380,
    width: "100%",
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    margin: 0,
    letterSpacing: 2,
  },
  subtitle: {
    fontSize: 12,
    color: "var(--hotel-muted)",
    marginTop: 8,
    marginBottom: 32,
  },
  form: {
    display: "flex",
    flexDirection: "column",
  },
  label: {
    fontSize: 11,
    textTransform: "uppercase" as const,
    letterSpacing: 1,
    color: "var(--hotel-muted)",
    textAlign: "left",
    marginBottom: 6,
  },
  input: {
    },
  colors: {
    display: "flex",
    gap: 8,
    justifyContent: "center",
    flexWrap: "wrap" as const,
  },
  colorBtn: {
    width: 32,
    height: 32,
    borderRadius: "50%",
    border: "none",
    cursor: "pointer",
    transition: "transform 0.15s, outline 0.15s",
  },
  joinBtn: {
    marginTop: 24,
    },
  hint: {
    marginTop: 20,
    fontSize: 10,
    color: "var(--hotel-muted)",
  },
};
