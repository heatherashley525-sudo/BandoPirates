import React, { useState, useCallback } from "react";

interface AudioControlProps {
  onVolumeChange: (volume: number) => void;
  onMuteToggle: (muted: boolean) => void;
}

export function AudioControl({ onVolumeChange, onMuteToggle }: AudioControlProps) {
  const [volume, setVolume] = useState(50);
  const [muted, setMuted] = useState(false);
  const [prevVolume, setPrevVolume] = useState(50);

  const handleVolumeChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const v = Number(e.target.value);
    setVolume(v);
    setMuted(v === 0);
    onVolumeChange(v);
    onMuteToggle(v === 0);
  }, [onVolumeChange, onMuteToggle]);

  const toggleMute = useCallback(() => {
    if (muted) {
      setMuted(false);
      setVolume(prevVolume || 50);
      onVolumeChange(prevVolume || 50);
      onMuteToggle(false);
    } else {
      setPrevVolume(volume);
      setMuted(true);
      setVolume(0);
      onVolumeChange(0);
      onMuteToggle(true);
    }
  }, [muted, volume, prevVolume, onVolumeChange, onMuteToggle]);

  return (
    <div style={styles.container}>
      <button onClick={toggleMute} style={styles.muteBtn} title={muted ? "Unmute" : "Mute"}>
        {muted || volume === 0 ? "🔇" : volume < 30 ? "🔈" : volume < 70 ? "🔉" : "🔊"}
      </button>
      <input
        type="range"
        min={0}
        max={100}
        value={volume}
        onChange={handleVolumeChange}
        style={styles.slider}
        title={`Volume: ${volume}%`}
      />
      <span style={styles.value}>{volume}</span>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  container: {
    position: "absolute",
    bottom: 16,
    left: 290,
    background:"var(--ui-window-background)",
    borderRadius:0,
    padding: "6px 10px",
    display: "flex",
    alignItems: "center",
    gap: 8,
    border:"2px solid var(--ui-button-shadow)",
    zIndex: 50,
  },
  muteBtn: {
    lineHeight: 1,
  },
  slider: {
    width: 80,
    height: 4,
    accentColor: "var(--ui-scrollbar-thumb)",
  },
  value: {
    fontFamily: "Tahoma, 'MS Sans Serif', Arial, sans-serif",
    fontSize: 10,
    color: "var(--hotel-muted)",
    width: 20,
    textAlign: "right" as const,
  },
};
