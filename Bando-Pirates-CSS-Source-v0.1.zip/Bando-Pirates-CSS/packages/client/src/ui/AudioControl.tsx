import React,{useEffect,useRef,useState} from 'react';
import {createPortal} from 'react-dom';
import {FloatingPanel} from './FloatingPanel';
import {PROGRAM_ICONS} from './programIcons';
export function AudioControl({host,onVolumeChange,onMuteToggle}:{host:HTMLElement;onVolumeChange:(volume:number)=>void;onMuteToggle:(muted:boolean)=>void}){
 const [open,setOpen]=useState(false),[master,setMaster]=useState(50),[music,setMusic]=useState(100),[muted,setMuted]=useState(false),[pinned,setPinned]=useState(false);const root=useRef<HTMLSpanElement>(null),trigger=useRef<HTMLButtonElement>(null);
 const volume=muted?0:Math.round(master*music/100);
 useEffect(()=>{onVolumeChange(volume);onMuteToggle(volume===0);},[volume,onVolumeChange,onMuteToggle]);
 useEffect(()=>{if(!open)return;const outside=(event:PointerEvent)=>{if(!pinned&&!root.current?.contains(event.target as Node))setOpen(false);};document.addEventListener('pointerdown',outside);return()=>document.removeEventListener('pointerdown',outside);},[open,pinned]);
 const close=()=>{setOpen(false);trigger.current?.focus();};
 return createPortal(<span ref={root} className="tray-volume-root" onKeyDown={event=>{event.stopPropagation();if(event.key==='Escape'){event.preventDefault();close();}}}>
  <button ref={trigger} type="button" className="tray-control tray-volume" aria-label="Volume" title={volume?'Volume: '+volume+'%':'Volume muted'} aria-haspopup="dialog" aria-expanded={open} data-silent={volume===0} onClick={()=>{setOpen(!open);setPinned(false);}}><span className="tray-speaker" aria-hidden="true"/></button>
  {open&&<FloatingPanel id="volume-mixer" label="Volume mixer" initial={(w,h)=>({x:Math.max(0,w-310),y:Math.max(0,h-230),w:300,h:220})} minWidth={240} minHeight={200} resizable={false} onUserBoundsChange={()=>setPinned(true)} className="volume-popup tray-volume-mixer">
   <div className="tray-mixer-title"><span>Volume</span><button type="button" aria-label="Close volume mixer" onClick={close}>×</button></div>
   <div className="volume-content"><div className="volume-app"><div className="volume-app-label"><img src={PROGRAM_ICONS.dj} alt=""/> DJ</div><input type="range" aria-label="DJ volume" min={0} max={100} value={music} onChange={event=>setMusic(Number(event.target.value))}/><output>{music}%</output><p className="volume-muted">Your room music volume</p></div><div className="volume-master"><strong>Master</strong><input type="range" aria-label="Master volume" aria-orientation="vertical" min={0} max={100} value={master} onChange={event=>setMaster(Number(event.target.value))}/><output>{master}%</output><label><input type="checkbox" checked={muted} onChange={event=>setMuted(event.target.checked)}/> Mute</label></div></div>
  </FloatingPanel>}
 </span>,host);
}
