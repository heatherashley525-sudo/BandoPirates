import React,{useLayoutEffect,useMemo,useRef,useState} from 'react';
import {ChatPortrait,chatShirtColour} from './ChatPortrait';
import {FloatingPanel} from './FloatingPanel';
import {chatBounds} from './hudLayout';
import {layoutChatBubbles,type PositionedChatMessage,type BubbleSize} from './chatLayout';
interface Metrics {width:number;height:number;sizes:Record<string,BubbleSize>}
export function Chat({messages,onSend}:{messages:PositionedChatMessage[];onSend:(content:string)=>void}){
 const [input,setInput]=useState(''),[metrics,setMetrics]=useState<Metrics>({width:1,height:200,sizes:{}});
 const list=useRef<HTMLDivElement>(null),bubbles=useRef(new Map<string,HTMLDivElement>()),followTail=useRef(true);
 useLayoutEffect(()=>{
  const viewport=list.current;if(!viewport)return;
  const measure=()=>{const parent=viewport.closest<HTMLElement>('[data-floating-panel]'),width=Math.max(1,viewport.clientWidth||parseFloat(parent?.style.width||'')-20||window.innerWidth-20),height=viewport.clientHeight||200,sizes:Record<string,BubbleSize>={};
   for(const message of messages){const rect=bubbles.current.get(message.id)?.getBoundingClientRect();sizes[message.id]={width:Math.ceil(rect?.width||Math.min(420,width-16)),height:Math.ceil(rect?.height||20)};}
   setMetrics(previous=>previous.width===width&&previous.height===height&&JSON.stringify(previous.sizes)===JSON.stringify(sizes)?previous:{width,height,sizes});
  };
  measure();if(typeof ResizeObserver==='undefined')return;const observer=new ResizeObserver(measure);observer.observe(viewport);for(const node of bubbles.current.values())observer.observe(node);return()=>observer.disconnect();
 },[messages]);
 const layout=useMemo(()=>layoutChatBubbles(messages,metrics.sizes,metrics.width,metrics.height),[messages,metrics]);
 useLayoutEffect(()=>{if(followTail.current&&list.current)list.current.scrollTop=list.current.scrollHeight;},[layout]);
 return <FloatingPanel id="chat-spatial" label="Chat" className="hud-chat" minWidth={220} minHeight={180} initial={chatBounds} followViewport>
  <div ref={list} className="chat-messages" role="log" aria-label="Room messages" aria-live="polite" data-no-drag onScroll={()=>{const e=list.current!;followTail.current=e.scrollHeight-e.clientHeight-e.scrollTop<28;}}>
   <div className="chat-history-track" style={{height:layout.height}}>
    {messages.map((message,index)=>{const placement=layout.placements[index];return <div key={message.id} ref={node=>{if(node)bubbles.current.set(message.id,node);else bubbles.current.delete(message.id);}} className="chat-bubble" data-message-id={message.id} data-sender-x={message.position?.x} data-sender-y={message.position?.y} style={{left:placement.left,top:placement.top,zIndex:index+1,'--chat-tail':placement.tail+'px','--chat-shirt':chatShirtColour(message.appearance)} as React.CSSProperties}><ChatPortrait appearance={message.appearance}/><span className="chat-text"><strong>{message.playerName}</strong>{message.content}</span></div>;})}
   </div>
   {!messages.length&&<p className="chat-empty hud-muted">Say hello to the room.</p>}
  </div>
  <form className="chat-compose" onSubmit={event=>{event.preventDefault();if(input.trim()){onSend(input.trim());setInput('');followTail.current=true;}}}>
   <input aria-label="Type to chat" placeholder="Type to chat…" maxLength={200} value={input} onChange={event=>setInput(event.target.value)}/>
   <button type="submit" aria-label="Send message">➜</button>
  </form>
 </FloatingPanel>;
}
