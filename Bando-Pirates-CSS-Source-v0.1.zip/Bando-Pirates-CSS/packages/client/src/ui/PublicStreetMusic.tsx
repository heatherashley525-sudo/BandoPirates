import React,{useEffect,useRef,useState} from 'react';
import {YouTubePlayer} from '../game-logic/YouTubePlayer';
import {FloatingPanel} from './FloatingPanel';

const VIDEO_ID = '-n2KrXS5Lmc';
const YOUTUBE_URL = 'https://www.youtube.com/watch?v='+VIDEO_ID;
const musicBounds = (_width:number,height:number) => ({x:12,y:Math.max(0,height-340),w:236,h:278});
type Status = 'loading' | 'ready' | 'blocked' | 'unavailable';

export function PublicStreetMusic({volume,onDone}:{volume:number;onDone:()=>void}){
  const host = useRef<HTMLDivElement>(null);
  const player = useRef<YouTubePlayer|null>(null);
  const [status,setStatus] = useState<Status>('loading');
  const currentVolume = useRef(volume);
  currentVolume.current = volume;

  useEffect(()=>{
    const mount = host.current!;
    let disposed = false;
    let attempted = false;
    let visible = false;
    let resume = false;
    let observer:IntersectionObserver|undefined;
    const music = new YouTubePlayer(mount,{
      onPlaying:()=>{setStatus('ready');updatePlayback();},
      onAutoplayBlocked:()=>setStatus('blocked'),
      onError:()=>setStatus('unavailable'),
    });
    player.current = music;
    music.setOnTrackEnded(onDone);

    const updatePlayback = () => {
      if (document.hidden || (observer && !visible)) {
        if (music.isPlaying()) {
          resume = true;
          music.pause();
        }
        return;
      }
      if (!visible) return;
      if (!attempted) {
        attempted = true;
        if (!music.isPlaying()) music.loadVideo(VIDEO_ID);
      } else if (resume) {
        resume = false;
        music.play();
      }
    };
    document.addEventListener('visibilitychange',updatePlayback);
    void music.init().then(()=>{
      if (disposed) return;
      music.setVolume(currentVolume.current);
      music.cueVideo(VIDEO_ID);
      setStatus('ready');
      const iframe = mount.querySelector('iframe');
      if (!iframe || typeof IntersectionObserver==='undefined') return;
      observer = new IntersectionObserver(([entry])=>{
        visible = entry.isIntersecting && entry.intersectionRatio>.5;
        updatePlayback();
      },{threshold:[.5,.51]});
      observer.observe(iframe);
    }).catch(()=>{if(!disposed)setStatus('unavailable');});

    return ()=>{
      disposed = true;
      observer?.disconnect();
      document.removeEventListener('visibilitychange',updatePlayback);
      music.destroy();
      player.current = null;
    };
  },[onDone]);

  useEffect(()=>player.current?.setVolume(volume),[volume]);

  return <FloatingPanel id="public-street-music" label="Public Street music" initial={musicBounds} minWidth={224} minHeight={278} resizable={false} className="street-music">
    <header className="titlebar">
      <span className="window-title">Public Street music</span>
      <div className="window-controls"><button className="window-control window-close" type="button" aria-label="Dismiss Public Street music" onClick={onDone}>×</button></div>
    </header>
    <div className="street-music-body">
      <div ref={host} className="street-music-player"/>
      <div className="street-music-status" aria-live="polite">
        {status==='blocked'?<button type="button" onClick={()=>player.current?.play()}>Play music</button>:
          status==='unavailable'?<a href={YOUTUBE_URL} target="_blank" rel="noreferrer">Open on YouTube</a>:
          status==='loading'?<span>Loading music…</span>:null}
      </div>
    </div>
  </FloatingPanel>;
}
