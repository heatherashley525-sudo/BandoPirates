import React,{useLayoutEffect,useRef} from 'react';
import {ChildWindow} from '../theme/ChildWindow';
import {windowArea} from '../theme/workArea';
import type {WindowBounds} from '../theme/windowGeometry';
import './game-hud.css';
const savedBounds=new Map<string,WindowBounds>();
const customized=new Set<string>();
interface Props {id:string;label:string;initial:(width:number,height:number)=>WindowBounds;minWidth?:number;minHeight?:number;resizable?:boolean;dragButtons?:boolean;followViewport?:boolean;className?:string;onUserBoundsChange?:()=>void;children:React.ReactNode}
export function FloatingPanel({id,label,initial,minWidth=160,minHeight=100,resizable=true,dragButtons=false,followViewport=false,className='',onUserBoundsChange,children}:Props){
 const ref=useRef<HTMLElement>(null);
 useLayoutEffect(()=>{const win=ref.current!,responsive=followViewport&&!customized.has(id);const controller=new ChildWindow(win,{minWidth,minHeight,resizable,dragButtons,followViewport:responsive?initial:undefined,onUserBoundsChange:()=>{customized.add(id);onUserBoundsChange?.();},onBoundsChange:bounds=>savedBounds.set(id,bounds)});controller.open(responsive?initial(windowArea(win).width,windowArea(win).height):savedBounds.get(id)||initial(windowArea(win).width,windowArea(win).height));return()=>controller.destroy();},[id]);
 return <section ref={ref} aria-label={label} data-floating-panel={id} className={`floating-panel bevel ${className}`}>{children}</section>;
}
