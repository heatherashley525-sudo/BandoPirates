import {PUBLIC_STREET_ID,type RoomDestination,type RoomDirectoryEntry} from '@cocoworking/shared';
import {ChildWindow} from '../theme/ChildWindow';
import {windowArea} from '../theme/workArea';

export class NavigationWindow {
  private dialog = document.createElement('dialog');
  private list = document.createElement('ul');
  private status = document.createElement('p');
  private controls: ChildWindow;
  private rooms?: RoomDirectoryEntry[];
  private connected = false;

  constructor(parent: HTMLElement, private current: RoomDestination, private enter: (room: RoomDestination) => void) {
    this.dialog.className = 'window active bevel navigation-window';
    this.dialog.dataset.program = 'navigation';
    this.dialog.setAttribute('aria-label','Navigation');
    this.dialog.tabIndex = -1;

    const header = document.createElement('header');
    header.className = 'titlebar';
    const title = document.createElement('span');
    title.className = 'window-title';
    title.textContent = 'Navigation';
    const chrome = document.createElement('div');
    chrome.className = 'window-controls';
    const close = document.createElement('button');
    close.type = 'button';
    close.className = 'window-control window-close';
    close.textContent = '×';
    close.setAttribute('aria-label','Close Navigation');
    close.addEventListener('click',()=>this.close());
    chrome.append(close);
    header.append(title,chrome);

    const body = document.createElement('div');
    body.className = 'window-body navigation-body';
    this.list.className = 'navigation-rooms';
    this.list.setAttribute('aria-label','Available rooms');
    this.status.className = 'navigation-status';
    this.status.setAttribute('role','status');
    body.append(this.list,this.status);
    this.dialog.append(header,body);
    parent.append(this.dialog);

    this.controls = new ChildWindow(this.dialog,{minWidth:220,minHeight:160});
    this.dialog.addEventListener('cancel',event=>{event.preventDefault();this.close();});
    this.dialog.addEventListener('keydown',event=>{
      event.stopPropagation();
      if(event.key==='Escape'){event.preventDefault();this.close();}
    });
  }

  setRooms(rooms: RoomDirectoryEntry[]) {
    this.rooms = rooms;
    if(this.dialog.open)this.render();
  }

  setConnected(connected: boolean) {
    this.connected = connected;
    if(!connected)this.rooms=undefined;
    if(this.dialog.open)this.render();
  }

  private render() {
    this.list.replaceChildren();
    for(const room of this.rooms??[]){
      const row = document.createElement('li');
      const details = document.createElement('div');
      const name = document.createElement('strong');
      name.textContent = room.name;
      const kind = document.createElement('span');
      kind.textContent = room.destination===PUBLIC_STREET_ID?'Public room':'Player room';
      details.append(name,kind);
      const button = document.createElement('button');
      button.type = 'button';
      const current = room.destination===this.current;
      button.textContent = current?'Here now':'Enter';
      button.disabled = current||!this.connected;
      button.setAttribute('aria-label',current?'Current room: '+room.name:'Enter '+room.name);
      button.addEventListener('click',()=>this.enter(room.destination));
      row.append(details,button);
      this.list.append(row);
    }
    this.status.textContent = !this.connected?'Connect to view or enter rooms.':!this.rooms?'Finding available rooms…':'Choose a room to enter.';
  }

  open() {
    this.render();
    if(!this.dialog.open){
      if(typeof this.dialog.show==='function')this.dialog.show();
      else this.dialog.setAttribute('open','');
    }
    const area = windowArea(this.dialog);
    this.controls.open({x:16,y:Math.max(0,area.height-266),w:340,h:250});
    this.dialog.focus();
  }

  private close() {
    this.controls.close();
    if(typeof this.dialog.close==='function')this.dialog.close();
    else this.dialog.removeAttribute('open');
  }

  destroy() {
    this.controls.destroy();
    this.dialog.remove();
  }
}
