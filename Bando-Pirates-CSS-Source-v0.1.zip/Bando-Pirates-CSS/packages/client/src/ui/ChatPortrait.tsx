import React,{useEffect,useRef} from 'react';
import {defaultAppearance,habboImageUrl,type AvatarAppearance} from '@cocoworking/shared';
import {makeAvatar,disposeAvatar} from '../artwork/avatar';
import {HABBO_SHIRT_COLOURS} from './habboShirtColours';
export function chatShirtColour(appearance?:AvatarAppearance){const a=appearance||defaultAppearance(),id=a.habboFigure?.split('.').find(p=>p.startsWith('ch-'))?.split('-')[2];return id&&HABBO_SHIRT_COLOURS[id]|| (a.top==='none'?a.skin:a.topColor);}
export function ChatPortrait({appearance}:{appearance?:AvatarAppearance}){
 const ref=useRef<HTMLSpanElement>(null),a=appearance||defaultAppearance();
 useEffect(()=>{const parent=ref.current!;const head=makeAvatar('',undefined,{...a,habboFigure:undefined});head.classList.add('chat-head-avatar');parent.append(head);
  let image:HTMLImageElement|undefined;
  if(a.habboFigure){image=new Image();image.className='chat-habbo-head';image.alt='';image.draggable=false;image.referrerPolicy='no-referrer';image.hidden=true;const url=new URL(habboImageUrl(a.habboFigure,'south'));url.searchParams.set('headonly','1');url.searchParams.set('size','s');image.onload=()=>{if(image){image.hidden=false;head.hidden=true;}};image.src=url.href;parent.append(image);}
  return()=>{disposeAvatar(head);head.remove();if(image){image.onload=null;image.onerror=null;image.remove();}};
 },[appearance]);
 return <span ref={ref} className="chat-portrait" aria-hidden="true"/>;
}
