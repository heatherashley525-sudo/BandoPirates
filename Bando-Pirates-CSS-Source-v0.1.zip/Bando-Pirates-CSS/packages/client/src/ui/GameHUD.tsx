import React,{useEffect,useRef,useState} from 'react';
import {createDJState,type ChatMessage,type DJState} from '@cocoworking/shared';
import type {CoworkingScene} from '../scenes/CoworkingScene';
import type {YouTubePlayer} from '../game-logic/YouTubePlayer';
import {Chat} from './Chat';
import {CallPanel} from './CallPanel';
import {DJPanel} from './DJPanel';
import {PlayerCount} from './PlayerCount';
import {AudioControl} from './AudioControl';
import {FloatingPanel} from './FloatingPanel';
import {profileBounds} from './hudLayout';
import {createPortal} from 'react-dom';
export function GameHUD({scene,offline=false,onChangePlayer}:{scene:CoworkingScene;offline?:boolean;onChangePlayer?:()=>void}){
 const [messages,setMessages]=useState<ChatMessage[]>([]),[count,setCount]=useState(1),[dj,setDJ]=useState<DJState>(createDJState()),[socketId,setSocketId]=useState<string>();const player=useRef<YouTubePlayer|null>(null),localVolume=useRef(50);
 useEffect(()=>{scene.setChatCallback(messages=>setMessages([...messages]));scene.setPlayerCountCallback(count=>{setCount(count);setSocketId(scene.getNetwork().getSocketId());});scene.setDJCallback(state=>setDJ({...state}));const timer=setInterval(()=>{const id=scene.getNetwork().getSocketId();if(id){setSocketId(id);clearInterval(timer);}},200);return()=>{clearInterval(timer);scene.setChatCallback(()=>{});scene.setPlayerCountCallback(()=>{});scene.setDJCallback(()=>{});};},[scene]);
 useEffect(()=>{player.current?.setVolume(Math.round(localVolume.current*dj.volume/100));},[dj.volume]);
 const network=scene.getNetwork();
 return createPortal(<><PlayerCount count={count}/>{onChangePlayer&&<FloatingPanel id="profile" label="Player profile" initial={profileBounds} minWidth={120} minHeight={40} resizable={false} className="hud-compact"><button type="button" onClick={onChangePlayer}>Change player</button></FloatingPanel>}
  <CallPanel manager={network.getCalls()} localId={socketId} offline={offline}/>
  <Chat messages={messages} onSend={content=>scene.sendChat(content)}/>
  <DJPanel djState={dj} isLocalDJ={dj.djId===socketId} offline={offline} onClaim={()=>network.claimDJ()} onRelease={()=>network.releaseDJ()} onPlay={()=>network.djPlay()} onPause={()=>network.djPause()} onNext={()=>network.djNext()} onPrev={()=>network.djPrev()} onVolume={value=>network.djVolume(value)} onAddTrack={url=>network.djAddTrack(url)} onUpdateTitle={(id,title)=>network.djUpdateTitle(id,title)} onPlayerReady={value=>{player.current=value;value.setVolume(Math.round(localVolume.current*dj.volume/100));}}/>
  <AudioControl host={scene.getTaskbarVolumeHost()} onVolumeChange={volume=>{localVolume.current=volume;player.current?.setVolume(Math.round(volume*dj.volume/100));}} onMuteToggle={()=>{}}/>
 </>,scene.getOverlayParent());
}
