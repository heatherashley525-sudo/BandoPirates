import React,{useCallback,useEffect,useRef,useState} from 'react';
import {createDJState,type ChatMessage,type DJState} from '@cocoworking/shared';
import type {CoworkingScene} from '../scenes/CoworkingScene';
import type {YouTubePlayer} from '../game-logic/YouTubePlayer';
import {Chat} from './Chat';
import {CallPanel} from './CallPanel';
import {DJPanel} from './DJPanel';
import {PlayerCount} from './PlayerCount';
import {AudioControl} from './AudioControl';
import {PublicStreetMusic} from './PublicStreetMusic';
import {createPortal} from 'react-dom';
export function GameHUD({scene,offline=false,publicStreet=false}:{scene:CoworkingScene;offline?:boolean;publicStreet?:boolean}){
 const [messages,setMessages]=useState<ChatMessage[]>([]),[count,setCount]=useState(1),[dj,setDJ]=useState<DJState>(createDJState()),[socketId,setSocketId]=useState<string>();const player=useRef<YouTubePlayer|null>(null),localVolume=useRef(50);
 const [streetMusicDone,setStreetMusicDone]=useState(false),[streetVolume,setStreetVolume]=useState(8);
 const streetMusic=publicStreet&&!streetMusicDone;
 const finishStreetMusic=useCallback(()=>setStreetMusicDone(true),[]);
 useEffect(()=>{scene.setChatCallback(messages=>setMessages([...messages]));scene.setPlayerCountCallback(count=>{setCount(count);setSocketId(scene.getNetwork().getSocketId());});scene.setDJCallback(state=>setDJ({...state}));const timer=setInterval(()=>{const id=scene.getNetwork().getSocketId();if(id){setSocketId(id);clearInterval(timer);}},200);return()=>{clearInterval(timer);scene.setChatCallback(()=>{});scene.setPlayerCountCallback(()=>{});scene.setDJCallback(()=>{});};},[scene]);
 useEffect(()=>{player.current?.setVolume(Math.round(localVolume.current*dj.volume/100));},[dj.volume]);
 const network=scene.getNetwork();
 return createPortal(<><PlayerCount count={count}/>
  <CallPanel manager={network.getCalls()} localId={socketId} offline={offline}/>
  <Chat messages={messages} onSend={content=>scene.sendChat(content)}/>
  {streetMusic&&socketId&&<PublicStreetMusic volume={streetVolume} onDone={finishStreetMusic}/>}
  <DJPanel djState={dj} isLocalDJ={dj.djId===socketId} offline={offline} deferPlayback={streetMusic} onClaim={()=>network.claimDJ()} onRelease={()=>network.releaseDJ()} onPlay={()=>network.djPlay()} onPause={()=>network.djPause()} onNext={()=>network.djNext()} onPrev={()=>network.djPrev()} onVolume={value=>network.djVolume(value)} onAddTrack={url=>network.djAddTrack(url)} onUpdateTitle={(id,title)=>network.djUpdateTitle(id,title)} onPlayerReady={value=>{player.current=value;value.setVolume(Math.round(localVolume.current*dj.volume/100));}}/>
  <AudioControl host={scene.getTaskbarVolumeHost()} onVolumeChange={volume=>{localVolume.current=volume;if(publicStreet)setStreetVolume(Math.round(volume*.16));player.current?.setVolume(Math.round(volume*dj.volume/100));}} onMuteToggle={()=>{}}/>
 </>,scene.getOverlayParent());
}
