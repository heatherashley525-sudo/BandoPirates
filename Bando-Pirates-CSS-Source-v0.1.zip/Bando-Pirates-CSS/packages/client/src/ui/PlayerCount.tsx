import React from 'react';
import {FloatingPanel} from './FloatingPanel';
import {onlineBounds} from './hudLayout';
export function PlayerCount({count}:{count:number}){return <FloatingPanel id="online" label="Players online" initial={onlineBounds} minWidth={80} minHeight={40} resizable={false} className="hud-compact"><span className="hud-online">{count} online</span></FloatingPanel>;}
