import React from "react";

interface PlayerCountProps {
  count: number;
}

export function PlayerCount({ count }: PlayerCountProps) {
  return (
    <div style={styles.container}>
      <span style={styles.dot} />
      {count} online
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  container: {
    position: "absolute",
    top: 16,
    left: 16,
    background:"var(--ui-window-background)",
    borderRadius:0,
    padding: "6px 14px",
    fontFamily: "Tahoma, 'MS Sans Serif', Arial, sans-serif",
    fontSize: 12,
    color:"var(--ui-text)",
    display: "flex",
    alignItems: "center",
    gap: 8,
    border:"2px solid var(--ui-button-shadow)",
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: "50%",
    background: "#00b894",
    display: "inline-block",
  },
};
