import {habboFurnitureImageUrl,furnitureTiles,type FurnitureState} from '@cocoworking/shared';
import './habboFurniture.css';
/** Native transparent 64px furniture render, with no frame, background or display stand. */
export function makeHabboFurniture(item:FurnitureState){
 if(!item.nft)throw Error('Missing verified furniture artwork.');
 const root=document.createElement('div');root.className='css-art art-habbo-nft';root.dataset.artwork='habbo-nft';root.setAttribute('aria-busy','true');
 const image=document.createElement('img');image.alt=item.nft.asset.name;image.draggable=false;image.referrerPolicy='no-referrer';root.append(image);
 const tiles=furnitureTiles(item),w=(Math.max(...tiles.map(t=>t.x))-item.gx)/(item.scale??1)+1,h=(Math.max(...tiles.map(t=>t.y))-item.gy)/(item.scale??1)+1;
 image.onload=()=>{
  root.style.width=`${image.naturalWidth}px`;root.style.height=`${image.naturalHeight}px`;root.style.marginLeft=`${-image.naturalWidth/2}px`;root.style.marginTop=`${(w+h)*8-image.naturalHeight}px`;root.removeAttribute('aria-busy');
 };
 image.onerror=()=>{root.dataset.assetError='true';root.removeAttribute('aria-busy');image.remove();const label=document.createElement('span');label.textContent='Furniture image unavailable';root.append(label);};
 image.src=habboFurnitureImageUrl(item.nft.definition,item.rotation,item.state||0);return root;
}
