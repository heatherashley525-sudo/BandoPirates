import './base-table.css';
export const BASE_TABLE_MARKUP = `<div class="base-table" data-rotation="0" aria-label="A simple brown wooden table with a square tabletop, four straight legs and slim supporting rails.">
   <div class="shadow"></div>
   <div class="block leg back-left"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block leg back-right"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block leg front-left"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block leg front-right"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block rail back-rail"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block rail left-rail"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block rail right-rail"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block rail front-rail"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block apron"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block seat"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
  </div>`;
