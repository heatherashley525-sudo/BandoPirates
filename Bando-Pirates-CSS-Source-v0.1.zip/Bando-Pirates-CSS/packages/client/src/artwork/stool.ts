import './stool.css';
export const STOOL_MARKUP = `<div class="stool" data-rotation="0" aria-label="A low brown wooden Stool with a plain square seat, four short legs and slim supporting rails.">
   <div class="shadow"></div>
   <div class="block leg back-left"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block leg back-right"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block leg front-left"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block leg front-right"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block rail back-rail"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block rail left-rail"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block rail right-rail"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block rail front-rail"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block apron"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block seat"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
  </div>`;
