import type {WalletChallenge,WalletState} from '@cocoworking/shared';
import type {NetworkManager} from '../game-logic/NetworkManager';
export interface EthereumProvider {isMetaMask?:boolean;providers?:EthereumProvider[];request(input:{method:string;params?:unknown[]}):Promise<any>;on?(event:string,listener:(...args:any[])=>void):void;removeListener?(event:string,listener:(...args:any[])=>void):void}
export function metaMaskMobileUrl(url:string){const u=new URL(url);return u.protocol==='https:'?`https://link.metamask.io/dapp/${u.host}${u.pathname}`:null;}
export class MetaMaskConnection {
 private provider?:EthereumProvider;private announced?:EthereumProvider;private generation=0;
 private announcement=(event:Event)=>{const detail=(event as CustomEvent).detail;if(detail?.info?.rdns==='io.metamask'&&typeof detail?.provider?.request==='function')this.announced=detail.provider;};
 private changed=()=>{void this.disconnect();this.notice('Wallet account or network changed. Connect again to verify ownership.');};
 constructor(private network:Pick<NetworkManager,'walletRequest'>,private notice:(message:string)=>void){window.addEventListener('eip6963:announceProvider',this.announcement);window.dispatchEvent(new Event('eip6963:requestProvider'));}
 async connect():Promise<WalletState>{
  const generation=++this.generation,ethereum=(window as unknown as {ethereum?:EthereumProvider}).ethereum;
  const provider=this.announced||ethereum?.providers?.find(p=>p.isMetaMask)|| (ethereum?.isMetaMask?ethereum:undefined);
  if(!provider)throw Error('Open this game in the MetaMask app browser, or install the MetaMask browser extension.');
  this.detach();this.provider=provider;
  try{
   const accounts=await provider.request({method:'eth_requestAccounts'}),address=accounts?.[0],chainId=Number(BigInt(await provider.request({method:'eth_chainId'})));
   provider.on?.('accountsChanged',this.changed);provider.on?.('chainChanged',this.changed);provider.on?.('disconnect',this.changed);
   if(typeof address!=='string'||!/^0x[0-9a-f]{40}$/i.test(address))throw Error('Select a MetaMask account.');
   if(generation!==this.generation)throw Error('Wallet changed. Connect again.');
   const challenge=await this.network.walletRequest<WalletChallenge>('wallet:challenge',{address,chainId});
   if(challenge.origin!==location.origin||challenge.chainId!==chainId||challenge.address.toLowerCase()!==address.toLowerCase()||!challenge.message.toLowerCase().startsWith(`${location.host} wants you to sign in with your ethereum account:\n${address}`.toLowerCase()))throw Error('The login request does not match this website or wallet.');
   if(generation!==this.generation)throw Error('Wallet changed. Connect again.');
   const hex='0x'+Array.from(new TextEncoder().encode(challenge.message),n=>n.toString(16).padStart(2,'0')).join('');
   const signature=await provider.request({method:'personal_sign',params:[hex,address]});
   const current=await provider.request({method:'eth_accounts'});
   if(generation!==this.generation||current?.[0]?.toLowerCase()!==address.toLowerCase())throw Error('Wallet changed. Connect again.');
   return await this.network.walletRequest<WalletState>('wallet:verify',{signature});
  }catch(error){if(generation===this.generation){this.detach();await this.network.walletRequest('wallet:disconnect',{}).catch(()=>{});}if((error as {code?:number})?.code===4001)throw Error('Connection or signature cancelled.');throw error;}
 }
 async disconnect(){this.generation++;this.detach();await this.network.walletRequest('wallet:disconnect',{}).catch(()=>{});}
 private detach(){for(const event of ['accountsChanged','chainChanged','disconnect'])this.provider?.removeListener?.(event,this.changed);this.provider=undefined;}
 destroy(){this.generation++;this.detach();window.removeEventListener('eip6963:announceProvider',this.announcement);}
}
