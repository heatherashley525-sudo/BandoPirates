import {floorTiles,EMPTY_SPLITS,DEFAULT_FLOOR} from '@cocoworking/shared';
import '../theme';
/** Original HTML/CSS geometry. No third-party image assets. */
import { BASE_SOFA_MARKUP } from './baseSofa';
import { BASE_TABLE_MARKUP } from './baseTable';
import { STOOL_MARKUP } from './stool';
export const ARTWORK_KEYS = ['base-sofa','base-table','stool'] as const;
export const ARTWORK_NAMES: Record<string,string> = {'base-sofa':'Base sofa','base-table':'Base table','stool':'Stool'};

export function element(className: string, parent?: HTMLElement): HTMLDivElement {
  const el = document.createElement('div');
  el.className = className;
  parent?.append(el);
  return el;
}
export function tilePosition(x: number, y: number) {
  return { left: (x - y) * 32, top: (x + y) * 16 };
}
export function worldDepth(x:number,y:number,depth=0){return 100000+Math.round((x+y+depth)*10000);}
export function position(el: HTMLElement, x: number, y: number, offset = 0, depth = 0) {
  const p = tilePosition(x, y);
  el.style.left = `${p.left}px`; el.style.top = `${p.top + offset}px`;
  el.style.zIndex = String(worldDepth(x,y,depth));
}
export function makeTile(x: number, y: number,size=1,id?:string): HTMLElement {
  const tile = element(`floor-tile${Math.round((x+y)/size)%2 ? ' floor-alt' : ''}`);
  const p = tilePosition(x, y);
  tile.style.left = `${p.left}px`; tile.style.top = `${p.top}px`;
  Object.assign(tile.style,{width:64*size+'px',height:32*size+'px',marginLeft:-32*size+'px',marginTop:-16*size+'px'});tile.style.setProperty('--tile-scale',String(size));if(id){tile.dataset.tileId=id;tile.dataset.depth=String(Math.round(Math.log2(1/size)));}
  tile.dataset.x = String(x); tile.dataset.y = String(y);
  tile.setAttribute('aria-hidden', 'true');
  return tile;
}
export function makeFurniture(key: string, rotation = 0): HTMLElement {
  if (key !== 'base-sofa' && key !== 'base-table' && key !== 'stool') throw new Error(`Unknown CSS artwork: ${key}`);
  const root = element(`css-art art-${key}`);
  root.dataset.artwork = key;
  root.setAttribute('aria-label', ARTWORK_NAMES[key]);
  const camera = element(`${key}-camera`, root);
  // Constant original model markup, never user input.
  camera.innerHTML = key === 'base-sofa' ? BASE_SOFA_MARKUP : key === 'base-table' ? BASE_TABLE_MARKUP : STOOL_MARKUP;
  camera.querySelector<HTMLElement>(`.${key}`)!.dataset.rotation = String(rotation % 4);
  return root;
}
export {makeAvatar,applyAvatarAppearance,setAvatarDirection,setAvatarWalking,setAvatarSitting,disposeAvatar} from './avatar';
export function populateFloor(world:HTMLElement,splits:readonly string[]=EMPTY_SPLITS,bounds=DEFAULT_FLOOR){
 for(const node of world.querySelectorAll('.floor-tile'))node.remove();
 if(bounds===DEFAULT_FLOOR)for(let i=0;i<10;i++){world.append(makeTile(0,i));if(i)world.append(makeTile(i,0));}
 for(const tile of floorTiles(splits,bounds))world.append(makeTile(tile.x,tile.y,tile.size,tile.id));
}
export function populateRoom(world: HTMLElement,splits:readonly string[]=EMPTY_SPLITS,bounds=DEFAULT_FLOOR) {
  populateFloor(world,splits,bounds);
  if(bounds!==DEFAULT_FLOOR)return;
  for (const side of ['left', 'back']) for (let i = 0; i < 10; i++) {
    const wall = element(`room-wall wall-${side}`, world);
    const p = side === 'left' ? tilePosition(0, i) : tilePosition(i, 0);
    wall.style.left = `${p.left}px`; wall.style.top = `${p.top}px`;
  }
}
