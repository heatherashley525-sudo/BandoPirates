import '../theme';
/** Original HTML/CSS geometry. No third-party image assets. */
import { BASE_SOFA_MARKUP } from './baseSofa';
import { BASE_TABLE_MARKUP } from './baseTable';
import { STOOL_MARKUP } from './stool';
export const ARTWORK_KEYS = ['base-sofa','base-table','stool'] as const;
export const ARTWORK_NAMES: Record<string,string> = {'base-sofa':'Base sofa','base-table':'Base table','stool':'Stool'};

export function element(className: string, parent?: HTMLElement): HTMLDivElement {
  const el = document.createElement('div');
  el.className = className;
  parent?.append(el);
  return el;
}
export function tilePosition(x: number, y: number) {
  return { left: (x - y) * 32, top: (x + y) * 16 };
}
export function position(el: HTMLElement, x: number, y: number, offset = 0, depth = 0) {
  const p = tilePosition(x, y);
  el.style.left = `${p.left}px`; el.style.top = `${p.top + offset}px`;
  el.style.zIndex = String(100 + Math.round((x + y + depth) * 10));
}
export function makeTile(x: number, y: number): HTMLElement {
  const tile = element(`floor-tile${(x + y) % 2 ? ' floor-alt' : ''}`);
  const p = tilePosition(x, y);
  tile.style.left = `${p.left}px`; tile.style.top = `${p.top}px`;
  tile.dataset.x = String(x); tile.dataset.y = String(y);
  tile.setAttribute('aria-hidden', 'true');
  return tile;
}
export function makeFurniture(key: string, rotation = 0): HTMLElement {
  if (key !== 'base-sofa' && key !== 'base-table' && key !== 'stool') throw new Error(`Unknown CSS artwork: ${key}`);
  const root = element(`css-art art-${key}`);
  root.dataset.artwork = key;
  root.setAttribute('aria-label', ARTWORK_NAMES[key]);
  const camera = element(`${key}-camera`, root);
  // Constant original model markup, never user input.
  camera.innerHTML = key === 'base-sofa' ? BASE_SOFA_MARKUP : key === 'base-table' ? BASE_TABLE_MARKUP : STOOL_MARKUP;
  camera.querySelector<HTMLElement>(`.${key}`)!.dataset.rotation = String(rotation % 4);
  return root;
}
export {makeAvatar,applyAvatarAppearance,setAvatarDirection,setAvatarWalking,setAvatarSitting,disposeAvatar} from './avatar';
export function populateRoom(world: HTMLElement) {
  for (let x = 0; x < 10; x++) for (let y = 0; y < 10; y++) world.append(makeTile(x, y));
  for (const side of ['left', 'back']) for (let i = 0; i < 10; i++) {
    const wall = element(`room-wall wall-${side}`, world);
    const p = side === 'left' ? tilePosition(0, i) : tilePosition(i, 0);
    wall.style.left = `${p.left}px`; wall.style.top = `${p.top}px`;
  }
}
