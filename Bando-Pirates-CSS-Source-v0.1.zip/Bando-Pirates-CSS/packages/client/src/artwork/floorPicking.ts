import {tileAt,EMPTY_SPLITS} from '@cocoworking/shared';
/** Pick the floor plane, independently of the artwork currently covering it. */
export function floorAtScreen(x:number,y:number,originX:number,originY:number,scale:number,splits:readonly string[]=EMPTY_SPLITS){
 if(![x,y,originX,originY,scale].every(Number.isFinite)||scale<=0)return null;
 const px=(x-originX)/scale,py=(y-originY)/scale;
 return tileAt({x:px/64+py/32,y:py/32-px/64},splits);
}
