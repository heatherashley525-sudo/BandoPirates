import '../theme';
import {ChildWindow} from '../theme/ChildWindow';
import {blankAppearance,defaultAppearance,heatherAppearance,parseAppearance,type AvatarAppearance,type Direction,AVATAR_DIRECTIONS,parseHabboFigure} from '@cocoworking/shared';
import {makeAvatar,applyAvatarAppearance,setAvatarDirection,setAvatarWalking,disposeAvatar} from './avatar';
import './wardrobe.css';
import {HABBO_HOTELS,lookupHabboFigure} from './habboLookup';
const directions:Direction[]=[...AVATAR_DIRECTIONS];
/** A draft is separate from the saved profile; only Wear commits it. */
export class Wardrobe {
 private dialog:HTMLDialogElement;private form:HTMLElement;private stage:HTMLElement;private turn:HTMLElement;private actor:HTMLElement;
 private nameInput!:HTMLInputElement;private hotelInput!:HTMLSelectElement;private lookupButton!:HTMLButtonElement;private lookupAbort?:AbortController;private lookupTimer?:ReturnType<typeof setTimeout>;private lookupGeneration=0;
 private draft:AvatarAppearance=blankAppearance();private facing=3;private windowControls:ChildWindow;private artwork!:HTMLSelectElement;private habboFields!:HTMLElement;private figureInput!:HTMLInputElement;private externalMode=false;private message:HTMLElement;private wear:HTMLButtonElement;private focusBefore:HTMLElement|null=null;private saveTimer?:ReturnType<typeof setTimeout>;
 constructor(parent:HTMLElement,private onWear:(appearance:AvatarAppearance)=>void,private standalone=false){
  this.dialog=document.createElement('dialog');this.dialog.className='wardrobe window active bevel';this.dialog.setAttribute('aria-label','Avatar wardrobe');parent.append(this.dialog);
  const header=document.createElement('header');header.className='titlebar';this.dialog.append(header);
  const title=document.createElement('span');title.className='window-title';title.textContent='Avatar wardrobe';header.append(title);
  const controls=document.createElement('div');controls.className='window-controls';header.append(controls);const close=this.button(controls,'×',()=>this.close());close.className='window-control window-close';close.setAttribute('aria-label','Close wardrobe');
  const body=document.createElement('div');body.className='window-body';this.dialog.append(body);
  const sub=document.createElement('p');sub.className='wardrobe-intro';sub.textContent='Start with our blank skin. Add each layer when you are ready.';body.append(sub);
  const content=document.createElement('div');content.className='wardrobe-content';body.append(content);
  const preview=document.createElement('section');preview.className='wardrobe-preview sunken';content.append(preview);
  this.stage=document.createElement('div');this.stage.className='wardrobe-stage';preview.append(this.stage);this.actor=makeAvatar('Base skin',0xe995c4,this.draft);this.stage.append(this.actor);
  const turn=document.createElement('div');turn.className='wardrobe-turn';preview.append(turn);this.turn=turn;
  this.button(turn,'Turn left ↺',()=>{this.facing=(this.facing+7)%8;this.renderPose();});this.button(turn,'Turn right ↻',()=>{this.facing=(this.facing+1)%8;this.renderPose();});
  const walk=document.createElement('label');walk.className='wardrobe-walk';preview.append(walk);const checkbox=document.createElement('input');checkbox.type='checkbox';walk.append(checkbox,document.createTextNode(' Walk preview'));checkbox.addEventListener('change',()=>setAvatarWalking(this.actor,checkbox.checked));
  this.form=document.createElement('section');this.form.className='wardrobe-fields';content.append(this.form);
  this.color('Skin colour','skin');this.select('Face','face',[['blank','Blank'],['simple','Friendly face']]);
  this.breastSlider();
  this.select('Hair','hair',[['none','None'],['short','Short'],['long','Long']]);this.color('Hair colour','hairColor');
  this.select('Top','top',[['none','None'],['tee','T-shirt']]);this.color('Top colour','topColor');
  this.select('Bottoms','bottom',[['none','None'],['shorts','Shorts'],['trousers','Trousers']]);this.color('Bottom colour','bottomColor');
  this.select('Footwear','shoes',[['none','Bare feet'],['shoes','Simple shoes']]);this.color('Shoe colour','shoeColor');
  this.select('Accessory','accessory',[['none','None'],['bow','White bow']]);
  const presets=document.createElement('div');presets.className='wardrobe-presets';body.append(presets);
  this.button(presets,'Blank base',()=>{this.cancelLookup();this.externalMode=false;this.draft=blankAppearance();this.message.textContent='Preview · unsaved changes';this.render();});this.button(presets,'Heather preset',()=>{this.cancelLookup();this.externalMode=false;this.draft=heatherAppearance();this.message.textContent='Preview · unsaved changes';this.render();});
  const footer=document.createElement('footer');body.append(footer);
  this.message=document.createElement('p');this.message.className='wardrobe-message';this.message.setAttribute('aria-live','polite');footer.append(this.message);
  this.button(footer,'Export avatar JSON',()=>this.export());this.wear=this.button(footer,standalone?'Save base design':'Wear in room',()=>{this.wear.disabled=true;this.message.textContent='Saving…';clearTimeout(this.saveTimer);this.saveTimer=setTimeout(()=>this.failed('No save confirmation. Check the connection and try again.'),8000);this.onWear({...this.draft});});
  this.dialog.addEventListener('cancel',()=>this.close());
  this.dialog.addEventListener('keydown',event=>{event.stopPropagation();if(event.key==='Escape'){event.preventDefault();this.close();}});
  const artworkRow=document.createElement('label');artworkRow.className='avatar-artwork-source';artworkRow.textContent='Avatar artwork';this.artwork=document.createElement('select');this.artwork.setAttribute('aria-label','Avatar artwork');
  for(const [value,label] of [['css','Original CSS'],['heather','Heather CSS portrait'],['habbo','Habbo figure']]){const option=document.createElement('option');option.value=value;option.textContent=label;this.artwork.append(option);}artworkRow.append(this.artwork);body.insertBefore(artworkRow,content);
  this.habboFields=document.createElement('section');this.habboFields.className='habbo-figure-fields';const figureLabel=document.createElement('label');figureLabel.textContent='Habbo figure string';this.figureInput=document.createElement('input');this.figureInput.type='text';this.figureInput.maxLength=512;this.figureInput.placeholder='hd-180-1.ch-255-66.lg-285-82';this.figureInput.setAttribute('aria-label','Habbo figure string');figureLabel.append(this.figureInput);this.habboFields.append(figureLabel);
  this.button(this.habboFields,'Preview figure',()=>{this.cancelLookup();const figure=parseHabboFigure(this.figureInput.value.trim());if(!figure){this.failed('Enter a valid Habbo figure string.');return;}this.draft={...this.draft,habboFigure:figure};this.message.textContent='Preview · unsaved changes';this.render();});
  const lookup=document.createElement('div');lookup.className='habbo-name-lookup';this.habboFields.prepend(lookup);
  const hotelLabel=document.createElement('label');hotelLabel.textContent='Habbo hotel';this.hotelInput=document.createElement('select');this.hotelInput.setAttribute('aria-label','Habbo hotel');for(const h of HABBO_HOTELS){const option=document.createElement('option');option.value=h.id;option.textContent=h.label;this.hotelInput.append(option);}hotelLabel.append(this.hotelInput);lookup.append(hotelLabel);
  const nameLabel=document.createElement('label');nameLabel.textContent='Habbo name';this.nameInput=document.createElement('input');this.nameInput.type='text';this.nameInput.maxLength=32;this.nameInput.autocomplete='off';this.nameInput.setAttribute('aria-label','Habbo name');nameLabel.append(this.nameInput);lookup.append(nameLabel);
  this.lookupButton=this.button(lookup,'Look up outfit',()=>void this.loadHabboOutfit());this.nameInput.addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();void this.loadHabboOutfit();}});this.nameInput.addEventListener('input',()=>this.cancelLookup());this.hotelInput.addEventListener('change',()=>this.cancelLookup());this.figureInput.addEventListener('input',()=>this.cancelLookup());
  const help=document.createElement('p');help.textContent='Uses Habbo’s online image renderer. Original CSS clothing controls apply to the CSS avatar.';this.habboFields.append(help);content.append(this.habboFields);
  this.artwork.addEventListener('change',()=>{
   this.cancelLookup();this.externalMode=this.artwork.value==='habbo';
   if(this.artwork.value==='heather')this.draft=heatherAppearance();
   else if(this.draft.preset==='heather')this.draft=defaultAppearance();
   if(!this.externalMode)delete this.draft.habboFigure;
   this.message.textContent='Preview · unsaved changes';this.render();
  });
  this.actor.addEventListener('avatarasseterror',()=>this.failed('The figure image could not load. Check the figure or connection.'));
  this.windowControls=new ChildWindow(this.dialog,{maximizable:true});
  this.render();
 }
 private button(parent:HTMLElement,label:string,action:()=>void){const button=document.createElement('button');button.type='button';button.textContent=label;button.addEventListener('click',action);parent.append(button);return button;}
 private color(label:string,key:keyof AvatarAppearance){const row=document.createElement('label');row.textContent=label;this.form.append(row);const input=document.createElement('input');input.type='color';input.dataset.appearanceKey=key;input.setAttribute('aria-label',label);row.append(input);input.addEventListener('input',()=>this.change(key,input.value));}
 private select(label:string,key:keyof AvatarAppearance,values:string[][]){const row=document.createElement('label');row.textContent=label;this.form.append(row);const select=document.createElement('select');select.dataset.appearanceKey=key;select.setAttribute('aria-label',label);for(const [value,text] of values){const option=document.createElement('option');option.value=value;option.textContent=text;select.append(option);}row.append(select);select.addEventListener('change',()=>this.change(key,select.value));}
 private breastSlider(){const row=document.createElement('label');row.className='wardrobe-body-slider';row.textContent='Breast size';this.form.append(row);const input=document.createElement('input');input.type='range';input.min='0';input.max='100';input.step='1';input.dataset.appearanceKey='breastSize';input.setAttribute('aria-label','Breast size');const output=document.createElement('output');output.className='breast-size-value';row.append(input,output);input.addEventListener('input',()=>this.change('breastSize',Number(input.value)));}
 private change(key:keyof AvatarAppearance,value:string|number){const next=parseAppearance({...this.draft,[key]:value});if(next){this.draft=next;this.message.textContent='Preview · unsaved changes';this.render();}}
 private render(){const heather=!this.externalMode&&this.draft.preset==='heather';this.artwork.value=this.externalMode?'habbo':heather?'heather':'css';this.form.hidden=this.externalMode||heather;this.turn.hidden=heather;this.habboFields.hidden=!this.externalMode;applyAvatarAppearance(this.actor,this.draft);this.renderPose();for(const input of this.form.querySelectorAll<HTMLInputElement|HTMLSelectElement>('[data-appearance-key]'))input.value=String(this.draft[input.dataset.appearanceKey as keyof AvatarAppearance]??0);this.form.querySelector('output')!.textContent=`${this.draft.breastSize??0}%`;if(this.wear)this.wear.disabled=this.externalMode&&!this.draft.habboFigure;}
 private renderPose(){setAvatarDirection(this.actor,directions[this.facing]);this.stage.setAttribute('aria-label',this.turn.hidden?'Original Heather portrait preview':`Avatar preview facing ${directions[this.facing]}`);}
 private cancelLookup(){this.lookupGeneration++;clearTimeout(this.lookupTimer);const pending=this.lookupAbort;this.lookupAbort=undefined;pending?.abort();if(this.lookupButton)this.lookupButton.disabled=false;if(pending&&this.wear)this.wear.disabled=this.externalMode&&!this.draft.habboFigure;}
 private async loadHabboOutfit(){
  this.cancelLookup();const generation=this.lookupGeneration,controller=new AbortController();this.lookupAbort=controller;this.lookupButton.disabled=true;this.wear.disabled=true;this.message.textContent='Looking up Habbo outfit…';this.lookupTimer=setTimeout(()=>controller.abort(),12000);
  try{const figure=await lookupHabboFigure(this.nameInput.value,this.hotelInput.value,controller.signal);if(generation!==this.lookupGeneration)return;this.draft={...this.draft,habboFigure:figure};this.figureInput.value=figure;this.render();this.message.textContent='Outfit loaded · preview until you save.';}
  catch(error){if(generation!==this.lookupGeneration)return;this.message.textContent=controller.signal.aborted?'The lookup timed out. Try again.':error instanceof TypeError?'Could not reach Habbo. Check your connection and try again.':error instanceof Error?error.message:'Could not look up this outfit.';}
  finally{if(generation===this.lookupGeneration){clearTimeout(this.lookupTimer);this.lookupAbort=undefined;this.lookupButton.disabled=false;this.wear.disabled=this.externalMode&&!this.draft.habboFigure;}}
 }
 open(appearance:AvatarAppearance=blankAppearance()){
  this.cancelLookup();
  this.focusBefore=document.activeElement as HTMLElement;this.draft=parseAppearance(appearance)||blankAppearance();this.externalMode=!!appearance.habboFigure;this.figureInput.value=appearance.habboFigure||'';this.message.textContent='Preview · changes apply only when saved';this.render();
  if(typeof this.dialog.show==='function'){if(!this.dialog.open)this.dialog.show();}else this.dialog.setAttribute('open','');
  this.windowControls.open();
 }
 isOpen(){return this.dialog.open;}
 saved(){clearTimeout(this.saveTimer);this.wear.disabled=false;this.message.textContent=this.standalone?'Base design saved in this browser.':'Saved · your avatar is wearing this look.';}
 failed(message:string){clearTimeout(this.saveTimer);this.wear.disabled=false;this.message.textContent=message;}
 private export(){const blob=new Blob([JSON.stringify(this.draft,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download='Bando-Pirates-Avatar.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 close(){this.cancelLookup();this.windowControls.close();setAvatarWalking(this.actor,false);const walk=this.dialog.querySelector<HTMLInputElement>('.wardrobe-walk input');if(walk)walk.checked=false;if(typeof this.dialog.close==='function')this.dialog.close();else this.dialog.removeAttribute('open');this.focusBefore?.focus();}
 destroy(){this.cancelLookup();clearTimeout(this.saveTimer);this.windowControls.destroy();disposeAvatar(this.actor);this.dialog.remove();}
}
