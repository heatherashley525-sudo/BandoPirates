import { describe, expect, it } from 'vitest';
import { makeAvatar, makeFurniture, makeTile, ARTWORK_KEYS, tilePosition } from '../elements';
import { ROOM_LAYOUT } from '../../scenes/roomLayout';

describe('original CSS artwork', () => {
  it('has an original element for every configured furniture item', () => {
    for (const item of ROOM_LAYOUT) {
      expect(ARTWORK_KEYS).toContain(item.texture);
      const el = makeFurniture(item.texture);
      expect(el.querySelector('img,svg,canvas')).toBeNull();
      expect(el.classList.contains('css-art')).toBe(true);
    }
  });
  it('offers the three original pieces and preserves their rotation states', () => {
    expect(ARTWORK_KEYS).toEqual(['base-sofa','base-table','stool']);
    const stool=makeFurniture('base-table',2);
    expect(stool.getAttribute('aria-label')).toBe('Base table');
    expect(stool.querySelector('.base-table')?.getAttribute('data-rotation')).toBe('2');
    const sofa = makeFurniture('base-sofa', 3);
    expect(sofa.getAttribute('aria-label')).toBe('Base sofa');
    expect(sofa.querySelector('.base-sofa')?.getAttribute('data-rotation')).toBe('3');
  });
  it('keeps display names as text rather than executable markup', () => {
    const avatar = makeAvatar('<img src=x onerror=alert(1)>', 0xff9ff3);
    expect(avatar.querySelector('img')).toBeNull();
    expect(avatar.querySelector('.avatar-name')?.textContent).toContain('<img');
  });
  it('places floor centres in the shared isometric coordinate system', () => {
    expect(tilePosition(2, 3)).toEqual({ left: -32, top: 80 });
    const tile = makeTile(2, 3);
    expect(tile.style.left).toBe('-32px');
    expect(tile.style.top).toBe('80px');
  });
});
