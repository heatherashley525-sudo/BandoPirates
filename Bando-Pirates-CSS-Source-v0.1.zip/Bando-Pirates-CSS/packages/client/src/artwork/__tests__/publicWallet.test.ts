import {describe,it,expect,vi} from 'vitest';
import {CollectiblesWindow} from '../CollectiblesWindow';
import {PUBLIC_TEST_WALLET} from '@cocoworking/shared';
describe('public test wallet',()=>{
 it('prefills Heather’s address and loads it without asking for a wallet signature',async()=>{
  const host=document.createElement('div');document.body.append(host);const request=vi.fn(async(event:string)=>event==='wallet:test'?{address:PUBLIC_TEST_WALLET,mode:'test'}:event==='wallet:list'?{assets:[],nextCursor:null}:undefined),window=new CollectiblesWindow(host,{walletRequest:request} as any);try{
   expect(host.querySelector<HTMLInputElement>('[aria-label="Test wallet address"]')!.value).toBe(PUBLIC_TEST_WALLET);host.querySelector<HTMLButtonElement>("[aria-label=\"Try Heather's test wallet\"]")!.click();await vi.waitFor(()=>expect(request).toHaveBeenCalledWith('wallet:list',{collection:'genesis'}));expect(request).toHaveBeenCalledWith('wallet:test',{address:PUBLIC_TEST_WALLET});expect(request.mock.calls.some(([event])=>event==='wallet:challenge'||event==='wallet:verify')).toBe(false);expect(host.textContent).toContain('Unverified test wallet');
  }finally{window.destroy();host.remove();}
 });
 it('keeps sample testing available in a downloaded HTML and puts its limits above the controls',()=>{
  const host=document.createElement('div');document.body.append(host);const window=new CollectiblesWindow(host,{walletRequest:vi.fn(async()=>undefined)} as any,true);try{
   expect(host.querySelector<HTMLButtonElement>("[aria-label=\"Try Heather's test wallet\"]")!.disabled).toBe(false);expect(host.querySelector<HTMLInputElement>('[aria-label="Test wallet address"]')!.disabled).toBe(false);expect(host.querySelector('.wallet-local-notice')!.textContent).toContain('not a live inventory');expect(host.querySelector('.wallet-local-notice a')!.getAttribute('href')).toBe('https://bandopirates.onrender.com/');
  }finally{window.destroy();host.remove();}
 });
});
