import {describe,it,expect} from 'vitest';
import {floorAtScreen} from '../floorPicking';
describe('floor-plane picking',()=>{
 it('finds the square under a screen point at every perspective, independently of covering sprites',()=>{
  for(const scale of [.25,1,2,16,128]){const x=6,y=5,originX=300,originY=-80;expect(floorAtScreen(originX+(x-y)*32*scale,originY+(x+y)*16*scale,originX,originY,scale)?.id).toBe('6,5');}
 });
 it('resolves divided leaves and rejects off-floor or invalid points',()=>{
  expect(floorAtScreen(0,56,0,0,1,['2,2'])?.id).toBe('2,2/0');expect(floorAtScreen(0,0,0,0,1)).toBeNull();expect(floorAtScreen(0,0,0,0,0)).toBeNull();expect(floorAtScreen(NaN,20,0,0,1)).toBeNull();
 });
});
