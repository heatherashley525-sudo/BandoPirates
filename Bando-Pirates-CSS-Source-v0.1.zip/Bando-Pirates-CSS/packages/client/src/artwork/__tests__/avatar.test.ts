import {describe,it,expect,vi} from 'vitest';
import {blankAppearance,defaultAppearance,AVATAR_DIRECTIONS} from '@cocoworking/shared';
import {makeAvatar,applyAvatarAppearance,setAvatarDirection,setAvatarWalking,setAvatarSitting,disposeAvatar} from '../avatar';
import {Wardrobe} from '../Wardrobe';
describe('layered CSS avatar and wardrobe',()=>{
 it('looks up a Habbo name into a preview and saves only when Wear is pressed',async()=>{
  const figure='hr-828-31.hd-180-1.ch-220-66.lg-280-64.sh-290-80';vi.stubGlobal('fetch',vi.fn().mockResolvedValue({status:200,ok:true,json:async()=>({figureString:figure})}));
  const root=document.createElement('div'),saved:any[]=[];document.body.append(root);const wardrobe=new Wardrobe(root,a=>saved.push(a));
  try{wardrobe.open(defaultAppearance());const source=root.querySelector<HTMLSelectElement>('[aria-label="Avatar artwork"]')!;source.value='habbo';source.dispatchEvent(new Event('change'));root.querySelector<HTMLInputElement>('[aria-label="Habbo name"]')!.value='Habbo';[...root.querySelectorAll('button')].find(b=>b.textContent==='Look up outfit')!.click();
   await vi.waitFor(()=>expect(root.querySelector<HTMLInputElement>('[aria-label="Habbo figure string"]')!.value).toBe(figure));expect(saved).toHaveLength(0);[...root.querySelectorAll('button')].find(b=>b.textContent==='Wear in room')!.click();expect(saved[0].habboFigure).toBe(figure);
  }finally{wardrobe.destroy();root.remove();vi.unstubAllGlobals();}
 });
 it('discards a late name lookup after switching back to the CSS avatar',async()=>{
  let finish!:(value:unknown)=>void;vi.stubGlobal('fetch',vi.fn(()=>new Promise(resolve=>{finish=resolve;})));const root=document.createElement('div'),saved:any[]=[];document.body.append(root);const wardrobe=new Wardrobe(root,a=>saved.push(a));
  try{wardrobe.open(defaultAppearance());const source=root.querySelector<HTMLSelectElement>('[aria-label="Avatar artwork"]')!;source.value='habbo';source.dispatchEvent(new Event('change'));root.querySelector<HTMLInputElement>('[aria-label="Habbo name"]')!.value='Habbo';[...root.querySelectorAll('button')].find(b=>b.textContent==='Look up outfit')!.click();source.value='css';source.dispatchEvent(new Event('change'));finish({status:200,ok:true,json:async()=>({figureString:'hd-180-1.ch-255-66'})});await new Promise(resolve=>setTimeout(resolve,0));
   [...root.querySelectorAll('button')].find(b=>b.textContent==='Wear in room')!.click();expect(saved[0].habboFigure).toBeUndefined();
  }finally{wardrobe.destroy();root.remove();vi.unstubAllGlobals();}
 });
 it('uses the real sitting action for a Habbo figure and stops its walking frames',()=>{
  vi.useFakeTimers();const node=makeAvatar('Figure',0xe995c4,{...blankAppearance(),habboFigure:'hd-180-1.ch-255-66'});setAvatarWalking(node,true);setAvatarSitting(node,true);
  expect(node.dataset.posture).toBe('sit');expect(node.dataset.assetUrl).toContain('action=sit');expect(node.classList.contains('is-walking')).toBe(false);expect(vi.getTimerCount()).toBe(0);setAvatarSitting(node,false);expect(node.dataset.assetUrl).toContain('action=std');disposeAvatar(node);vi.useRealTimers();
 });
 it('builds a blank skin with stable base parts and independent clothing slots',()=>{
  const node=makeAvatar('Base skin',0xe995c4,blankAppearance());
  for(const slot of ['skin','hair','top','bottom','shoes','accessory'])expect(node.querySelector(`[data-avatar-slot="${slot}"]`)).not.toBeNull();
  expect(node.dataset.hair).toBe('none');expect(node.dataset.top).toBe('none');expect(node.querySelector('img,svg,canvas')).toBeNull();
 });
 it('changes layers without replacing the actor, speech or facing',()=>{
  const node=makeAvatar('Heather',0xe995c4);node.dataset.direction='north';const figure=node.querySelector('.avatar-figure');const speech=document.createElement('div');speech.className='speech-bubble';speech.textContent='Hi';node.append(speech);
  applyAvatarAppearance(node,blankAppearance());expect(node.querySelector('.avatar-figure')).toBe(figure);expect(node.dataset.direction).toBe('north');expect(node.querySelector('.speech-bubble')?.textContent).toBe('Hi');
 });
 it('previews a blank base and eight rotations, then passes an appearance draft to Save',()=>{
  const root=document.createElement('div'),saved:any[]=[];document.body.append(root);
  const wardrobe=new Wardrobe(root,appearance=>saved.push(appearance));wardrobe.open(defaultAppearance());
  const button=(text:string)=>[...root.querySelectorAll('button')].find(b=>b.textContent===text)!;
  button('Blank base').click();expect(root.querySelector<HTMLElement>('.wardrobe-stage .css-avatar')!.dataset.hair).toBe('none');
  button('Turn right ↻').click();expect(root.querySelector<HTMLElement>('.wardrobe-stage .css-avatar')!.dataset.direction).toBe('south-west');
  button('Wear in room').click();expect(saved[0]).toEqual(blankAppearance());wardrobe.destroy();root.remove();
 });
 it('keeps the draft available when a save response does not arrive',()=>{
  vi.useFakeTimers();const root=document.createElement('div');document.body.append(root);const wardrobe=new Wardrobe(root,()=>{});wardrobe.open(blankAppearance());
  const wear=[...root.querySelectorAll('button')].find(b=>b.textContent==='Wear in room')!;wear.click();expect(wear.disabled).toBe(true);
  vi.advanceTimersByTime(8000);expect(wear.disabled).toBe(false);expect(root.textContent).toContain('No save confirmation');expect(root.querySelector<HTMLElement>('.wardrobe-stage .css-avatar')!.dataset.top).toBe('none');
  wardrobe.destroy();root.remove();vi.useRealTimers();
 });
 it('previews the body slider without changing the saved appearance until Wear',()=>{
  const root=document.createElement('div'),saved:any[]=[];document.body.append(root);const original=defaultAppearance();const wardrobe=new Wardrobe(root,a=>saved.push(a));wardrobe.open(original);
  const input=root.querySelector<HTMLInputElement>('input[aria-label="Breast size"]')!;input.value='75';input.dispatchEvent(new Event('input'));
  const actor=root.querySelector<HTMLElement>('.css-avatar')!;expect(actor.dataset.breastSize).toBe('75');expect(actor.style.getPropertyValue('--breast-size')).toBe('0.75');expect(original.breastSize).toBe(0);expect(saved).toHaveLength(0);
  [...root.querySelectorAll('button')].find(b=>b.textContent==='Wear in room')!.click();expect(saved[0].breastSize).toBe(75);expect(saved[0].top).toBe(original.top);wardrobe.destroy();root.remove();
 });
 it('renders eight poses with a restored surface shadow and a two-eye face',()=>{
  const node=makeAvatar('Heather');expect(node.querySelector('.avatar-shadow')).not.toBeNull();expect(node.querySelectorAll('.avatar-eye')).toHaveLength(2);
  for(const direction of AVATAR_DIRECTIONS){setAvatarDirection(node,direction);expect(node.dataset.direction).toBe(direction);expect(Number(node.dataset.habboDirection)).toBeGreaterThanOrEqual(0);}
  disposeAvatar(node);
 });
 it('advances real Habbo walking frames and clears its animation timer on disposal',()=>{
  vi.useFakeTimers();const node=makeAvatar('Figure',0xe995c4,{...blankAppearance(),habboFigure:'hd-180-1.ch-255-66'});
  setAvatarDirection(node,'south-east');setAvatarWalking(node,true);vi.advanceTimersByTime(130);expect(node.dataset.assetUrl).toContain('action=wlk');expect(node.dataset.frame).toBe('1');
  disposeAvatar(node);expect(vi.getTimerCount()).toBe(0);vi.useRealTimers();
 });
});
