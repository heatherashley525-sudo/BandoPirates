import {afterEach,describe,it,expect,vi} from 'vitest';
import {MetaMaskConnection,metaMaskMobileUrl} from '../MetaMaskConnection';
import {makeAvatar,applyCollectibleAvatar,setAvatarDirection,setAvatarSitting,setAvatarWalking,disposeAvatar} from '../avatar';
import {defaultAppearance,HABBO_COLLECTIONS,type CollectibleAsset} from '@cocoworking/shared';
afterEach(()=>{delete (window as any).ethereum;vi.unstubAllGlobals();});
describe('MetaMask login bridge',()=>{
 it('requests accounts and a login signature without requesting transactions or approvals',async()=>{
  const address='0x0000000000000000000000000000000000000001',calls:string[]=[],listeners=new Map<string,Function>();
  const provider={isMetaMask:true,on:(e:string,fn:Function)=>listeners.set(e,fn),removeListener:(e:string)=>listeners.delete(e),request:vi.fn(async({method}:any)=>{calls.push(method);if(method==='eth_requestAccounts'||method==='eth_accounts')return [address];if(method==='eth_chainId')return '0x1';if(method==='personal_sign')return 'signed';throw Error('Unexpected wallet method');})};(window as any).ethereum=provider;
  const walletRequest=vi.fn(async(event:string)=>event==='wallet:challenge'?{address,chainId:1,origin:location.origin,expiresAt:Date.now()+300000,message:`${location.host} wants you to sign in with your Ethereum account:\n${address}\n\nConnect to Bando Pirates.`}:event==='wallet:verify'?{address}:null);
  const notice=vi.fn(),bridge=new MetaMaskConnection({walletRequest} as any,notice);
  try{expect((await bridge.connect()).address).toBe(address);expect(calls).toEqual(['eth_requestAccounts','eth_chainId','personal_sign','eth_accounts']);expect(provider.request.mock.calls.find(c=>c[0].method==='personal_sign')?.[0].params[0]).toMatch(/^0x[0-9a-f]+$/);
   listeners.get('accountsChanged')!([]);await vi.waitFor(()=>expect(walletRequest).toHaveBeenCalledWith('wallet:disconnect',{}));expect(notice).toHaveBeenCalled();
  }finally{bridge.destroy();}
 });
 it('refuses a challenge for another origin before asking for a signature',async()=>{
  const request=vi.fn(async({method}:any)=>method==='eth_requestAccounts'?['0x0000000000000000000000000000000000000001']:'0x1');(window as any).ethereum={isMetaMask:true,request};
  const walletRequest=vi.fn(async(event:string)=>event==='wallet:challenge'?{origin:'https://evil.example'}:null),bridge=new MetaMaskConnection({walletRequest} as any,()=>{});
  try{await expect(bridge.connect()).rejects.toThrow('does not match');expect(request.mock.calls.some(c=>c[0].method==='personal_sign')).toBe(false);}finally{bridge.destroy();}
 });
 it('offers a mobile link only to the HTTPS game, without payment parameters',()=>{
  expect(metaMaskMobileUrl('https://game.example/room?token=private#x')).toBe('https://link.metamask.io/dapp/game.example/room');expect(metaMaskMobileUrl('http://localhost:3000')).toBeNull();
 });
});
describe('verified collectible avatar display',()=>{
 it('wears the NFT outfit in the existing avatar rig and restores the wardrobe outfit on disconnect',()=>{
  vi.useFakeTimers();
  const c=HABBO_COLLECTIONS[0],asset:CollectibleAsset={key:'1',collection:c.id,chainId:1,contract:c.contract,tokenId:'1',name:'Test NFT',image:'https://nft-tokens.habbo.com/avatars/images/1.png',kind:'avatar',figure:'hd-600-10.he-4263.ch-3528-108-1423',test:true};
  const wardrobeFigure='hd-180-1.ch-255-66',node=makeAvatar('Player',0xe995c4,{...defaultAppearance(),habboFigure:wardrobeFigure});
  const params=()=>new URL(node.dataset.assetUrl!).searchParams;
  try{
   applyCollectibleAvatar(node,asset);
   expect(params().get('figure')).toBe(asset.figure);expect(node.dataset.nftTest).toBe('true');expect(node.querySelector('.avatar-nft')).toBeNull();
   setAvatarDirection(node,'north');setAvatarWalking(node,true);vi.advanceTimersByTime(130);
   expect(params().get('direction')).toBe('7');expect(params().get('action')).toBe('wlk');expect(params().get('frame')).toBe('1');
   setAvatarSitting(node,true);expect(params().get('action')).toBe('sit');
   applyCollectibleAvatar(node,null);expect(params().get('figure')).toBe(wardrobeFigure);expect(node.dataset.nftTest).toBeUndefined();
  }finally{disposeAvatar(node);vi.useRealTimers();}
 });
});
