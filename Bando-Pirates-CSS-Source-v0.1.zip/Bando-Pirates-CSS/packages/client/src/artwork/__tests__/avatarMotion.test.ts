import {afterEach,describe,it,expect,vi} from 'vitest';
import {AvatarMotion} from '../AvatarMotion';
afterEach(()=>{vi.restoreAllMocks();vi.unstubAllGlobals();});
describe('continuous walking render',()=>{
 it('interpolates between tiles and retargets from the visible position without snapping',()=>{
  let now=0,id=0;const frames=new Map<number,FrameRequestCallback>();vi.spyOn(performance,'now').mockImplementation(()=>now);vi.stubGlobal('requestAnimationFrame',(cb:FrameRequestCallback)=>{frames.set(++id,cb);return id;});vi.stubGlobal('cancelAnimationFrame',(id:number)=>frames.delete(id));
  const step=(time:number)=>{now=time;const pending=[...frames];frames.clear();for(const [,cb] of pending)cb(time);};
  const node=document.createElement('div');node.style.left='0px';node.style.top='160px';const motion=new AvatarMotion(node);
  motion.to({x:32,y:176,depth:210},true);expect(node.style.left).toBe('0px');step(95);expect(parseFloat(node.style.left)).toBeCloseTo(16);expect(parseFloat(node.style.top)).toBeCloseTo(168);
  motion.to({x:64,y:192,depth:220},true);expect(parseFloat(node.style.left)).toBeCloseTo(16);step(190);expect(parseFloat(node.style.left)).toBeCloseTo(40);step(285);expect(node.style.left).toBe('64px');expect(frames.size).toBe(0);
  motion.to({x:96,y:208,depth:230},true);motion.to({x:64,y:192,depth:220});expect(node.style.left).toBe('64px');expect(frames.size).toBe(0);motion.destroy();
 });
});
