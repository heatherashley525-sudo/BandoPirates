import {describe,it,expect} from 'vitest';
import {makeHabboFurniture} from '../habboFurniture';
import {collectionById,type FurnitureState} from '@cocoworking/shared';
const c=collectionById('furni')!;
describe('native furniture rendering',()=>{
 it('places transparent sprite art at room scale, without a frame or stand',()=>{
  const item:FurnitureState={id:'nft',kind:'habbo-nft',gx:3,gy:3,rotation:0,nft:{asset:{key:'k',collection:'furni',chainId:13371,contract:c.contract,tokenId:'1',name:'NFT Sofa',kind:'item',image:'https://nft-tokens.habbo.com/collectibles/furni/images/nft_club_sofa.png'},definition:{classname:'nft_club_sofa',revision:70734,width:1,depth:2,height:2,seat:true,walkable:false,stackable:false,directions:[2,4,6,0],states:[0]}}};
  const node=makeHabboFurniture(item),image=node.querySelector('img')!;expect(image.src).toContain('/imaging/furniture/nft_club_sofa.png');expect(node.className).toContain('art-habbo-nft');expect(node.querySelector('canvas,iframe')).toBeNull();
  Object.defineProperties(image,{naturalWidth:{value:115},naturalHeight:{value:87}});image.dispatchEvent(new Event('load'));expect(node.style.width).toBe('115px');expect(node.style.marginTop).toBe('-63px');expect(node.hasAttribute('aria-busy')).toBe(false);
 });
});
