import {describe,it,expect,vi} from 'vitest';
import {lookupHabboFigure} from '../habboLookup';
const figure='hr-828-31.hd-180-1.ch-220-66.lg-280-64.sh-290-80';
describe('public Habbo outfit lookup',()=>{
 it('encodes the name and uses only the validated outfit from the chosen official hotel',async()=>{
  const fetcher=vi.fn().mockResolvedValue({ok:true,status:200,json:async()=>({figureString:figure,motto:'discarded',name:'Habbo'})});const signal=new AbortController().signal;
  expect(await lookupHabboFigure(' A&B ','nl',signal,fetcher)).toBe(figure);const [url,options]=fetcher.mock.calls[0];expect(url).toBe('https://www.habbo.nl/api/public/users?name=A%26B');expect(options).toMatchObject({signal,credentials:'omit'});
 });
 it('rejects invalid hotels and names without making a request',async()=>{
  const fetcher=vi.fn();for(const [name,hotel] of [['','com'],['x'.repeat(33),'com'],['bad\nname','com'],['Habbo','evil.example']])await expect(lookupHabboFigure(name,hotel,undefined,fetcher)).rejects.toThrow();expect(fetcher).not.toHaveBeenCalled();
 });
 it('handles missing names and invalid outfit data',async()=>{
  await expect(lookupHabboFigure('missing','com',undefined,vi.fn().mockResolvedValue({status:404,ok:false}))).rejects.toThrow('not found');
  await expect(lookupHabboFigure('Habbo','com',undefined,vi.fn().mockResolvedValue({status:200,ok:true,json:async()=>({figureString:'https://bad.example/image.png'})}))).rejects.toThrow('usable outfit');
 });
});
