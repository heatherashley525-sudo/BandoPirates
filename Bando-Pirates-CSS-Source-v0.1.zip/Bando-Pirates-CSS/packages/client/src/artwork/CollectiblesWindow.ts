import '../theme';
import {ChildWindow} from '../theme/ChildWindow';
import {HABBO_COLLECTIONS,PUBLIC_TEST_WALLET,type WalletState,type CollectibleAsset,type CollectiblePage} from '@cocoworking/shared';
import type {NetworkManager} from '../game-logic/NetworkManager';
import {MetaMaskConnection,metaMaskMobileUrl} from './MetaMaskConnection';
import {SAMPLE_WALLET_NOTICE} from '../game-logic/SampleWallet';
import {parseHabboFigure} from '@cocoworking/shared';
import {makeCollectibleIcon} from './collectibleIcon';
import './collectibles.css';

export class CollectiblesWindow {
 private dialog:HTMLDialogElement;private controls:ChildWindow;private connection:MetaMaskConnection;
 private state:WalletState={address:null};private status:HTMLElement;private account:HTMLElement;private collection:HTMLSelectElement;private list:HTMLElement;private preview:HTMLElement;
 private assets:CollectibleAsset[]=[];private selected?:CollectibleAsset;private cursor:string|null=null;private busy=false;private generation=0;
 private sampleButton:HTMLButtonElement;private testAddress:HTMLInputElement;private testButton:HTMLButtonElement;private connectButton:HTMLButtonElement;private disconnectButton:HTMLButtonElement;private refresh:HTMLButtonElement;private more:HTMLButtonElement;private wear:HTMLButtonElement;private display:HTMLButtonElement;private pickup:HTMLButtonElement;private token:HTMLInputElement;
 constructor(parent:HTMLElement,private network:NetworkManager,private offline=false,private onPlace?:(asset:CollectibleAsset)=>void){
  this.dialog=document.createElement('dialog');this.dialog.className='collectibles-window window active bevel';this.dialog.setAttribute('aria-label','Wallet and collectibles');parent.append(this.dialog);
  const header=document.createElement('header');header.className='titlebar';this.dialog.append(header);const title=document.createElement('span');title.className='window-title';title.textContent='Wallet & collectibles';header.append(title);const chrome=document.createElement('div');chrome.className='window-controls';header.append(chrome);const close=this.button(chrome,'×',()=>this.close());close.className='window-control window-close';close.setAttribute('aria-label','Close wallet');
  const body=document.createElement('div');body.className='window-body';this.dialog.append(body);this.account=document.createElement('p');body.append(this.account);
  if(offline){const notice=document.createElement('p');notice.className='wallet-local-notice';notice.textContent=SAMPLE_WALLET_NOTICE+' ';const online=document.createElement('a');online.href='https://bandopirates.onrender.com/';online.target='_blank';online.rel='noopener';online.textContent='Open multiplayer game';notice.append(online);body.append(notice);}
  this.status=document.createElement('p');this.status.className='wallet-message';this.status.setAttribute('aria-live','polite');body.append(this.status);
  const connectRow=document.createElement('div');connectRow.className='wallet-actions';body.append(connectRow);this.connectButton=this.button(connectRow,'Connect MetaMask',()=>void this.run(async()=>{this.setState(await this.connection.connect());this.message('Wallet verified. Choose a collection and refresh, or find a token by ID.');}));this.disconnectButton=this.button(connectRow,'Disconnect wallet',()=>{this.setState({address:null});void this.connection.disconnect();});
  this.connectButton.hidden=offline;if(offline)this.disconnectButton.textContent='Clear sample';const mobile=offline?null:metaMaskMobileUrl(location.href);if(mobile){const link=document.createElement('a');link.href=mobile;link.textContent='Open game in MetaMask';connectRow.append(link);}
  const intro=document.createElement('p');intro.textContent=offline?'Wear an included Habbo avatar or place sample furniture. The sample loads without a wallet connection.':'Sign a login message to verify ownership. Wear supported NFT avatars as Habbo figures and place supported furniture in the room.';body.append(intro);
  const testRow=document.createElement('div');testRow.className='wallet-test-row';const testLabel=document.createElement('label');testLabel.textContent='Test wallet address (no signature)';this.testAddress=document.createElement('input');this.testAddress.type='text';this.testAddress.maxLength=42;this.testAddress.placeholder='0x…';this.testAddress.value=PUBLIC_TEST_WALLET;this.testAddress.spellcheck=false;this.testAddress.autocomplete='off';this.testAddress.setAttribute('aria-label','Test wallet address');testLabel.append(this.testAddress);testRow.append(testLabel);this.testButton=this.button(testRow,'Test wallet address',()=>void this.useTestWallet(this.testAddress.value.trim()));this.sampleButton=this.button(testRow,"Try Heather’s wallet",()=>{this.testAddress.value=PUBLIC_TEST_WALLET;void this.useTestWallet(PUBLIC_TEST_WALLET);});this.sampleButton.setAttribute('aria-label',"Try Heather's test wallet");const testHint=document.createElement('p');testHint.textContent=offline?'Choose Genesis avatars or Furniture, then try Heather’s saved sample. No connection or signature is needed.':'Anyone can try this shared wallet. No connection or signature is needed. Its demo items stay for the session; reload this wallet to refresh them. Choose Genesis/Crafted for avatars or Furniture for the Habbo TokenTrove collection.';testRow.append(testHint);body.append(testRow);
  const selectRow=document.createElement('label');selectRow.textContent='Collection';this.collection=document.createElement('select');this.collection.setAttribute('aria-label','Collectible collection');for(const c of HABBO_COLLECTIONS){const option=document.createElement('option');option.value=c.id;option.textContent=c.name;this.collection.append(option);}selectRow.append(this.collection);body.append(selectRow);
  const paging=document.createElement('div');paging.className='wallet-actions';body.append(paging);this.refresh=this.button(paging,'Load wallet collectibles',()=>void this.load(false));this.more=this.button(paging,'Load more',()=>void this.load(true));
  const manual=document.createElement('details'),summary=document.createElement('summary');summary.textContent='Find a collectible by token ID';manual.append(summary);const tokenLabel=document.createElement('label');tokenLabel.textContent='Token ID';this.token=document.createElement('input');this.token.type='text';this.token.inputMode='numeric';this.token.maxLength=78;this.token.setAttribute('aria-label','Collectible token ID');tokenLabel.append(this.token);manual.append(tokenLabel);this.button(manual,'Find token',()=>void this.run(async()=>{this.selected=await this.network.walletRequest<CollectibleAsset>('wallet:lookup',{collection:this.collection.value,tokenId:this.token.value.trim()});this.renderPreview();this.message(this.state.mode==='test'?'Token found at this address. Wallet control is unverified.':'Ownership verified for this token.');}));body.append(manual);
  this.list=document.createElement('div');this.list.className='collectible-list';this.list.setAttribute('aria-label','Owned collectibles');body.append(this.list);this.preview=document.createElement('section');this.preview.className='collectible-preview sunken';body.append(this.preview);
  const actions=document.createElement('div');actions.className='wallet-actions';body.append(actions);this.wear=this.button(actions,'Wear selected avatar',()=>void this.run(async()=>{await this.action('wallet:wear');this.message('NFT outfit equipped for this wallet session.');this.close();}));this.button(actions,'Use wardrobe avatar',()=>void this.run(async()=>{await this.network.walletRequest('wallet:unwear',{});this.message('Using your saved wardrobe avatar.');}));this.display=this.button(actions,'Place furniture…',()=>void this.run(async()=>{
   const prepared=await this.action('wallet:prepare') as CollectibleAsset;if(!prepared.furniture)throw Error('Furniture artwork is not available for this NFT.');
   if(!this.onPlace)throw Error('Open the room to place furniture.');this.selected=prepared;this.onPlace(prepared);this.close();this.message('Tap a room tile to place this furniture.');
  }));this.pickup=this.button(actions,'Pick up placed furniture',()=>void this.run(async()=>{await this.action('wallet:pickup');this.message('Furniture returned to your wallet inventory. The NFT has not moved.');}));
  this.collection.addEventListener('change',()=>{this.generation++;this.assets=[];this.cursor=null;this.selected=undefined;this.renderList();this.renderPreview();this.message('Refresh this collection to see owned tokens.');});
  this.dialog.addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Escape'){e.preventDefault();this.close();}});this.dialog.addEventListener('cancel',()=>this.close());this.controls=new ChildWindow(this.dialog);
  this.connection=new MetaMaskConnection(this.network,message=>{this.setState({address:null});this.message(message);});this.setState(this.state);
 }
 private button(parent:HTMLElement,label:string,action:()=>void){const b=document.createElement('button');b.type='button';b.textContent=label;b.addEventListener('click',action);parent.append(b);return b;}
 private message(value:string){this.status.textContent=value;}
 private async useTestWallet(address:string){await this.run(async()=>{await this.connection.disconnect();this.setState(await this.network.walletRequest<WalletState>('wallet:test',{address}));const generation=this.generation,page=await this.network.walletRequest<CollectiblePage>('wallet:list',{collection:this.collection.value});if(generation!==this.generation)return;this.assets=page.assets;this.cursor=page.nextCursor;this.selected=undefined;this.renderList();this.renderPreview();this.message(this.assets.length?`${this.assets.length} collectibles loaded · test wallet, no signature.`:'Test wallet connected. No collectibles found in this collection; try Furniture, Genesis or Crafted.');});}
 private async action(event:string){if(!this.selected)throw Error('Select a collectible first.');return this.network.walletRequest(event,{collection:this.selected.collection,tokenId:this.selected.tokenId});}
 private async run(action:()=>Promise<void>){if(this.busy)return;this.busy=true;this.updateButtons();try{this.message('Working…');await action();}catch(error){this.message(error instanceof Error?error.message:'Wallet request failed.');}finally{this.busy=false;this.updateButtons();}}
 private async load(more:boolean){const generation=this.generation;await this.run(async()=>{const page=await this.network.walletRequest<CollectiblePage>('wallet:list',{collection:this.collection.value,...(more&&this.cursor?{cursor:this.cursor}:{})});if(generation!==this.generation)return;this.assets=more?[...this.assets,...page.assets]:page.assets;this.cursor=page.nextCursor;this.selected=undefined;this.renderList();this.renderPreview();this.message(this.assets.length?`${this.assets.length} collectibles loaded${this.state.mode==='test'?' · unverified test wallet':''}.`:'No owned tokens found in this collection on this page.');});}
 private renderList(){
  this.list.replaceChildren();
  for(const asset of this.assets){
   const button=this.button(this.list,asset.name,()=>{this.selected=asset;this.renderPreview();this.updateButtons();});
   makeCollectibleIcon(asset,button);
  }
 }
 private renderPreview(){
  this.preview.replaceChildren();
  const asset=this.selected;
  if(!asset){this.preview.textContent='Select a collectible to preview it.';return;}
  const text=document.createElement('p');text.textContent=`${asset.name} · Token ${asset.tokenId}`;
  if(asset.kind==='avatar'&&!parseHabboFigure(asset.figure))text.append(document.createElement('br'),'Wearable figure unavailable');
  this.preview.append(makeCollectibleIcon(asset),text);
 }
 private updateButtons(){if(!this.connectButton)return;const active=!!this.state.address;
  for(const b of this.dialog.querySelectorAll<HTMLButtonElement>('.window-body button'))b.disabled=this.busy||!active;
  this.testButton.disabled=this.busy;this.sampleButton.disabled=this.busy;this.testAddress.disabled=this.busy;this.connectButton.disabled=this.busy||this.offline;this.disconnectButton.disabled=!active;this.collection.disabled=this.busy;this.more.disabled=this.busy||!active||!this.cursor;this.wear.disabled=this.busy||!active||this.selected?.kind!=='avatar'||!parseHabboFigure(this.selected.figure);this.display.disabled=this.pickup.disabled=this.busy||!active||this.selected?.collection!=='furni';
  this.disconnectButton.hidden=this.offline&&!active;
 }
 setState(state:WalletState){const changed=this.state.address!==state.address||this.state.mode!==state.mode;this.generation++;this.state=state;if(!state.address||changed){this.selected=undefined;this.assets=[];this.cursor=null;this.renderList();this.renderPreview();}this.account.textContent=state.address?`${this.offline?'Saved sample wallet':state.mode==='test'?'Unverified test wallet':'Verified wallet'}: ${state.address}`:this.offline?'Sample wallet not loaded':'Wallet not connected';this.message(state.message||(this.offline?'Try Heather’s saved sample wallet below. MetaMask and live address lookups require the multiplayer game.':'Connect MetaMask or paste a wallet address for testing.'));this.updateButtons();}
 open(){if(!this.dialog.open)this.dialog.show();this.controls.open();}
 close(){this.controls.close();this.dialog.close();}
 destroy(){this.generation++;this.connection.destroy();this.controls.destroy();this.dialog.remove();}
}
