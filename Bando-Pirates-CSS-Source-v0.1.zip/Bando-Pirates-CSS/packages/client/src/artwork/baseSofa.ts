import './base-sofa.css';

export const BASE_SOFA_MARKUP = `<div class="base-sofa" data-rotation="0" aria-label="An isometric two-seat natural off-white cotton base sofa with a tall tufted back, thick upholstered arms, two fitted cotton seat cushions and short dark wooden feet.">
   <div class="ground-shadow"></div>
   <div class="block foot" style="--x:8px;--y:9px"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block foot" style="--x:126px;--y:9px"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block foot" style="--x:8px;--y:57px"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block foot" style="--x:126px;--y:57px"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block base"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block backrest"><i class="face top"></i><i class="face front"><b class="tuft a"></b><b class="tuft b"></b><b class="tuft c"></b><b class="tuft d"></b></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block seat" style="--x:18px"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block seat" style="--x:73px"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block arm" style="--x:0px"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
   <div class="block arm" style="--x:126px"><i class="face top"></i><i class="face front"></i><i class="face right"></i><i class="face back"></i><i class="face left"></i></div>
  </div>`;
