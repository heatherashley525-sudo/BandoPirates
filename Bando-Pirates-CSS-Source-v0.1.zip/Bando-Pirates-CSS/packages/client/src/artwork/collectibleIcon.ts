import {habboFurnitureSpriteUrl,habboImageUrl,parseHabboFigure,safeCollectibleImage,type CollectibleAsset} from '@cocoworking/shared';

export function makeCollectibleIcon(asset:CollectibleAsset,button?:HTMLButtonElement){
 const icon=button??document.createElement('span');
 icon.classList.add('collectible-icon');
 icon.dataset.size=button?'small':'large';
 icon.dataset.finish=asset.finish??(asset.kind==='avatar'?'midnight':'violet');
 icon.setAttribute('aria-label',asset.name);
 if(button)button.replaceChildren();
 else icon.setAttribute('role','img');

 for(const name of ['colour','ornament','sparkles','brand']){
  const layer=document.createElement('span');layer.className='collectible-icon__'+name;layer.setAttribute('aria-hidden','true');icon.append(layer);
  if(name==='sparkles')for(let i=0;i<4;i++)layer.append(document.createElement('i'));
 }
 const picture=document.createElement('span');
 picture.className='collectible-icon__picture';
 picture.setAttribute('aria-hidden','true');
 icon.append(picture);
 if(button){
  const label=document.createElement('span');
  label.className='collectible-icon__label';
  label.textContent=asset.name;
  button.append(label);
 }
 const figure=asset.kind==='avatar'?parseHabboFigure(asset.figure):null;
 const furniture=asset.furniture??asset.furnitureIcon;
 const sprite=figure?habboImageUrl(figure,'south-east')
  :furniture?habboFurnitureSpriteUrl(furniture,asset.furniture?.directions[0],asset.furniture?.states[0]):null;
 // The inventory icon and collectible card art may have the orange badge baked in.
 const original=asset.collection==='furni'?null:safeCollectibleImage(asset.image);
 const source=sprite??original;
 if(!source)return icon;
 icon.dataset.art=figure?'figure':sprite?'furniture':'original';
 const art=document.createElement('img');art.className='collectible-icon__art';art.alt='';art.draggable=false;art.referrerPolicy='no-referrer';
 if(button)art.loading='lazy';
 art.onerror=()=>{
  if(sprite&&original&&icon.dataset.art!=='original'){icon.dataset.art='original';art.src=original;}
  else art.remove();
 };
 picture.append(art);art.src=source;
 return icon;
}
