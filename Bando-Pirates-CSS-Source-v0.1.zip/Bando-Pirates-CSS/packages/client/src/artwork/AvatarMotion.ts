export const WALK_STEP_MS=190;
export interface RenderPoint {x:number;y:number;depth:number}
/** Keep rendering continuous while the server continues to validate grid steps. */
export class AvatarMotion {
 private frame?:number;private current:RenderPoint;private motion?:{from:RenderPoint;to:RenderPoint;start:number;duration:number};
 constructor(private node:HTMLElement,private onPaint?:()=>void){this.current={x:parseFloat(node.style.left)||0,y:parseFloat(node.style.top)||0,depth:Number(node.style.zIndex)||0};}
 private paint(point:RenderPoint){this.current=point;this.node.style.left=`${point.x}px`;this.node.style.top=`${point.y}px`;this.node.style.zIndex=String(Math.round(point.depth));this.onPaint?.();}
 private sample(now:number){const m=this.motion;if(!m)return;const t=Math.max(0,Math.min(1,(now-m.start)/m.duration));this.paint({x:m.from.x+(m.to.x-m.from.x)*t,y:m.from.y+(m.to.y-m.from.y)*t,depth:m.from.depth+(m.to.depth-m.from.depth)*t});if(t===1)this.motion=undefined;}
 private tick=(now:number)=>{this.frame=undefined;this.sample(now);if(this.motion)this.frame=requestAnimationFrame(this.tick);};
 to(point:RenderPoint,animate=false){
  const now=performance.now();this.sample(now);if(this.frame!==undefined)cancelAnimationFrame(this.frame);this.frame=undefined;
  if(!animate){this.motion=undefined;this.paint(point);return;}
  this.paint(this.current);this.motion={from:{...this.current},to:point,start:now,duration:WALK_STEP_MS};this.frame=requestAnimationFrame(this.tick);
 }
 destroy(){if(this.frame!==undefined)cancelAnimationFrame(this.frame);this.frame=undefined;this.motion=undefined;}
}
