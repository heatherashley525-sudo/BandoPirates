import {floorTile,tileFromId,tileChildren,parentTileId,MAX_TILE_DEPTH,MAX_ROOM_LEAVES,floorTiles,EMPTY_SPLITS,type FloorTile,type RoomInfo} from '@cocoworking/shared';
import {ChildWindow} from '../theme/ChildWindow';
export class MicroverseWindow {
 private dialog:HTMLDialogElement;private controls:ChildWindow;private room:RoomInfo|null=null;private id='2,2';private picking=false;
 private root:HTMLSelectElement;private detail:HTMLElement;private children:HTMLElement;private divide:HTMLButtonElement;private pick:HTMLButtonElement;private parentButton:HTMLButtonElement;private status:HTMLElement;
 constructor(parent:HTMLElement,private canEdit:()=>boolean,private split:(id:string)=>void,private select:(tile:FloorTile|null)=>void,private focus:(tile:FloorTile|null)=>void){
  this.dialog=document.createElement('dialog');this.dialog.className='window active microverse-window bevel';this.dialog.setAttribute('aria-label','Microverse');parent.append(this.dialog);
  const header=document.createElement('header');header.className='titlebar';const title=document.createElement('span');title.className='window-title';title.textContent='Microverse';header.append(title);const chrome=document.createElement('div');chrome.className='window-controls';const close=this.button(chrome,'×','Close Microverse',()=>this.close());close.className='window-control window-close';header.append(chrome);this.dialog.append(header);
  const body=document.createElement('div');body.className='window-body';this.dialog.append(body);
  const label=document.createElement('label');label.textContent='Root tile';this.root=document.createElement('select');this.root.setAttribute('aria-label','Microverse root tile');for(let x=1;x<10;x++)for(let y=1;y<10;y++){const o=document.createElement('option');o.value=x+','+y;o.textContent=x+', '+y;this.root.append(o);}label.append(this.root);body.append(label);this.root.addEventListener('change',()=>this.choose(this.root.value));
  this.detail=document.createElement('p');body.append(this.detail);this.children=document.createElement('div');this.children.className='microverse-children';body.append(this.children);
  this.parentButton=this.button(body,'Parent tile','Select parent tile',()=>{const id=parentTileId(this.id);if(id)this.choose(id);});
  this.pick=this.button(body,'Pick tile in room','Pick Microverse tile',()=>{this.picking=!this.picking;this.render();});
  this.divide=this.button(body,'Divide into 4','Divide selected tile into four',()=>{if(this.canEdit()&&floorTile(this.id,this.room?.tileSplits))this.split(this.id);});
  const view=document.createElement('div');view.className='microverse-view';body.append(view);this.button(view,'Focus tile','Focus selected tile',()=>{const t=tileFromId(this.id);if(t)this.focus(t);});this.button(view,'View room','View whole room',()=>this.focus(null));
  this.status=document.createElement('p');this.status.className='microverse-status';body.append(this.status);
  this.controls=new ChildWindow(this.dialog,{minWidth:220,minHeight:300});
  this.dialog.addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Escape'){e.preventDefault();this.close();}});this.dialog.addEventListener('cancel',e=>{e.preventDefault();this.close();});this.render();
 }
 private button(parent:HTMLElement,text:string,label:string,action:()=>void){const b=document.createElement('button');b.type='button';b.textContent=text;b.setAttribute('aria-label',label);b.addEventListener('click',action);parent.append(b);return b;}
 private choose(id:string){this.id=id;this.picking=false;this.render();this.select(this.dialog.open?tileFromId(id):null);}
 chooseFromFloor(id:string){if(!this.dialog.open||!this.picking)return false;this.choose(id);return true;}
 update(room:RoomInfo|null,message=''){const changed=this.room?.id!==room?.id;this.room=room;if(changed)this.id='2,2';this.render(message);if(this.dialog.open)this.select(room?tileFromId(this.id):null);}
 private render(message=''){
  const tile=tileFromId(this.id)!,splits=this.room?.tileSplits||EMPTY_SPLITS,divided=splits.includes(this.id);this.root.value=this.id.split('/')[0];
  this.detail.textContent='Tile '+this.id+' · '+(tile.size===1?'full size':'1/'+Math.round(1/tile.size)+' width and length')+' · depth '+tile.depth+'/'+MAX_TILE_DEPTH;
  this.children.replaceChildren();if(divided)for(const [i,child] of tileChildren(tile).entries())this.button(this.children,['North-west','North-east','South-west','South-east'][i],'Select '+['north-west','north-east','south-west','south-east'][i]+' child',()=>this.choose(child.id));
  this.parentButton.disabled=!parentTileId(this.id);this.pick.setAttribute('aria-pressed',String(this.picking));this.pick.textContent=this.picking?'Tap a floor tile…':'Pick tile in room';
  this.divide.disabled=!this.room||!this.canEdit()||divided||tile.depth>=MAX_TILE_DEPTH||floorTiles(splits).length+3>MAX_ROOM_LEAVES;this.divide.hidden=divided;
  this.status.textContent=message||(!this.room?'Create a room first.':this.picking?'Tap the floor to select a tile.':!this.canEdit()?'The room owner can divide empty tiles.':'Clear a tile, divide it, then select a child to divide again.');
 }
 open(){if(!this.dialog.open){if(typeof this.dialog.show==='function')this.dialog.show();else this.dialog.setAttribute('open','');}this.controls.open({x:Math.max(16,window.innerWidth-266),y:Math.min(350,Math.max(0,window.innerHeight-392)),w:250,h:380});this.render();this.select(tileFromId(this.id));}
 close(){this.picking=false;this.controls.close();if(this.dialog.open){if(typeof this.dialog.close==='function')this.dialog.close();else this.dialog.removeAttribute('open');}this.select(null);}
 destroy(){this.controls.destroy();this.dialog.remove();}
}
