import original from './Heather_Animated_v37.html?raw';

let template:HTMLTemplateElement|undefined;

function originalFigure():HTMLTemplateElement {
  if(template)return template;
  const source=new DOMParser().parseFromString(original,'text/html');
  const styles=document.createElement('style');
  styles.textContent=source.querySelector('head style')!.textContent!.replace(/:root(?=\s*\{)/g,':host');

  // Crop the portrait's desktop chrome out of the room while retaining the whole figure.
  const layout=document.createElement('style');
  layout.textContent=`
    .heather-stage.canvas { width:340px; height:665px; background:none; overflow:visible; }
    .heather-stage.canvas::before,.heather-stage.canvas::after { content:none; }
    .heather-stage > .figure-wrap { left:0; bottom:0; transform:none; }
  `;
  const stage=document.createElement('div');
  stage.className='heather-stage canvas';
  stage.append(source.querySelector('.figure-wrap')!);

  template=document.createElement('template');
  template.content.append(styles,layout,stage);
  return template;
}

/** A renderer for the unmodified figure layers of the Heather CSS portrait. */
export class HeatherAvatar {
  private host:HTMLElement;

  constructor(parent:HTMLElement){
    this.host=document.createElement('div');
    this.host.className='heather-avatar';
    this.host.attachShadow({mode:'open'}).append(originalFigure().content.cloneNode(true));
    parent.append(this.host);
  }

  destroy(){this.host.remove();}
}
