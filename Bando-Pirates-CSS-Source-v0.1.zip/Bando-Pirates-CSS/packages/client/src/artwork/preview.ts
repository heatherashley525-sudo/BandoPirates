import { RoomEditor } from '../scenes/RoomEditor';
new RoomEditor(document.getElementById('app')!);
