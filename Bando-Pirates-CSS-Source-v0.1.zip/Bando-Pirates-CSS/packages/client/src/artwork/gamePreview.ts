import React from 'react';
import {createRoot} from 'react-dom/client';
import {App} from '../ui/App';
const app=document.getElementById('app')!;app.style.width='100vw';app.style.height='100dvh';document.body.style.overflow='hidden';
const root=createRoot(app);root.render(React.createElement(App,{offline:true,skipLobby:true}));
window.addEventListener('pagehide',()=>root.unmount(),{once:true});
