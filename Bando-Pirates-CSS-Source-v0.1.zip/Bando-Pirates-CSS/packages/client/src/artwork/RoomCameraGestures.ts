interface Point {
  x: number;
  y: number;
}

export interface CameraGesture {
  anchor: Point;
  dx: number;
  dy: number;
  zoom: number;
}

interface Measurement extends Point {
  distance: number;
}

/** Recognise camera gestures without stealing ordinary clicks on the floor or furniture. */
export class RoomCameraGestures {
  private pointers = new Map<number, Point>();
  private previous?: Measurement;
  private dragged = false;

  constructor(private surface: HTMLElement, private change: (gesture: CameraGesture) => void) {
    surface.addEventListener('pointerdown', this.down);
    surface.addEventListener('click', this.click, true);
    surface.addEventListener('wheel', this.wheel, {passive: false});
    surface.addEventListener('dragstart', this.preventDrag);
    surface.addEventListener('lostpointercapture', this.lostCapture);
    window.addEventListener('pointermove', this.move);
    window.addEventListener('pointerup', this.end);
    window.addEventListener('pointercancel', this.end);
    window.addEventListener('blur', this.reset);
  }

  get active() { return this.dragged && this.pointers.size > 0; }

  private measure(): Measurement {
    const [first, second] = this.pointers.values();
    if (!second) return {...first, distance: 0};
    return {
      x: (first.x + second.x) / 2,
      y: (first.y + second.y) / 2,
      distance: Math.hypot(first.x - second.x, first.y - second.y),
    };
  }

  private startDrag() {
    this.dragged = true;
    this.surface.dataset.cameraGesture = 'active';
    for (const id of this.pointers.keys()) this.surface.setPointerCapture?.(id);
  }

  private down = (event: PointerEvent) => {
    if (event.button !== 0) return;
    if (!this.pointers.size) this.dragged = false;
    this.pointers.set(event.pointerId, {x: event.clientX, y: event.clientY});
    this.previous = this.measure();
    if (this.pointers.size > 1) this.startDrag();
  };

  private move = (event: PointerEvent) => {
    if (!this.pointers.has(event.pointerId) || !this.previous) return;
    this.pointers.set(event.pointerId, {x: event.clientX, y: event.clientY});
    const next = this.measure();
    const previous = this.previous;
    const dx = next.x - previous.x;
    const dy = next.y - previous.y;
    if (!this.dragged) {
      if (Math.hypot(dx, dy) < 6) return;
      this.startDrag();
    }
    event.preventDefault();
    this.previous = next;
    const zoom = next.distance && previous.distance ? next.distance / previous.distance : 1;
    this.change({anchor: previous, dx, dy, zoom});
  };

  private end = (event: PointerEvent) => {
    if (!this.pointers.delete(event.pointerId)) return;
    this.previous = this.pointers.size ? this.measure() : undefined;
    if (!this.pointers.size) delete this.surface.dataset.cameraGesture;
  };

  private lostCapture = (event: PointerEvent) => {
    if (event.target === this.surface) this.end(event);
  };

  private click = (event: MouseEvent) => {
    if (this.dragged && event.detail > 0) {
      event.preventDefault();
      event.stopPropagation();
    }
  };

  private wheel = (event: WheelEvent) => {
    if (!event.ctrlKey) return;
    event.preventDefault();
    const delta = event.deltaY * (event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? this.surface.clientHeight : 1);
    this.change({anchor: {x: event.clientX, y: event.clientY}, dx: 0, dy: 0, zoom: Math.exp(-delta * .005)});
  };

  private preventDrag = (event: DragEvent) => event.preventDefault();

  private reset = () => {
    const ids = [...this.pointers.keys()];
    this.pointers.clear();
    this.previous = undefined;
    delete this.surface.dataset.cameraGesture;
    for (const id of ids) {
      if (this.surface.hasPointerCapture?.(id)) this.surface.releasePointerCapture(id);
    }
  };

  destroy() {
    this.reset();
    this.surface.removeEventListener('pointerdown', this.down);
    this.surface.removeEventListener('click', this.click, true);
    this.surface.removeEventListener('wheel', this.wheel);
    this.surface.removeEventListener('dragstart', this.preventDrag);
    this.surface.removeEventListener('lostpointercapture', this.lostCapture);
    window.removeEventListener('pointermove', this.move);
    window.removeEventListener('pointerup', this.end);
    window.removeEventListener('pointercancel', this.end);
    window.removeEventListener('blur', this.reset);
  }
}
