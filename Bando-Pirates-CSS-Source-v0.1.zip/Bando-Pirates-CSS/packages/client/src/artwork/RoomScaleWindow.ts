import {ChildWindow} from '../theme/ChildWindow';
import {windowArea} from '../theme/workArea';
import {chatBounds} from '../ui/hudLayout';
import '../ui/game-hud.css';
export const PERSPECTIVE_LEVELS=[1,2,3,4,5,6,7,8] as const;
/** Local view controls; the shared HeatherOS controls own the input/arrow styling. */
export class RoomScaleWindow {
 private dialog:HTMLDialogElement;private controls:ChildWindow;private slider:HTMLInputElement;private percentage:HTMLInputElement;private levels:HTMLSelectElement;private current=100;private perspective=1;
 private increment!:HTMLButtonElement;private decrement!:HTMLButtonElement;
 constructor(parent:HTMLElement,private change:(percent:number)=>number,private changePerspective:(level:number)=>void=()=>{}){
  this.dialog=document.createElement('dialog');this.dialog.className='window active room-scale-window bevel';this.dialog.setAttribute('aria-label','Room scale');parent.append(this.dialog);
  const heading=document.createElement('header');heading.className='titlebar';const title=document.createElement('span');title.className='window-title';title.textContent='Scale';heading.append(title);const chrome=document.createElement('div');chrome.className='window-controls';const close=this.button(chrome,'×','Close room scale',()=>this.close());close.className='window-control window-close';heading.append(chrome);this.dialog.append(heading);
  const body=document.createElement('div');body.className='window-body';this.dialog.append(body);
  this.slider=document.createElement('input');this.slider.type='range';this.slider.id='room-zoom';this.slider.min='25';this.slider.max='250';this.slider.step='1';this.slider.setAttribute('aria-label','Room zoom');this.slider.setAttribute('aria-orientation','vertical');
  const track=document.createElement('div');track.className='room-scale-controls';this.arrow(track,'Zoom in',1,()=>this.set(this.current+5));track.append(this.slider);this.arrow(track,'Zoom out',-1,()=>this.set(this.current-5));body.append(track);
  const row=document.createElement('div');row.className='room-scale-percentage';const number=document.createElement('span');number.className='sdk-number';this.percentage=document.createElement('input');this.percentage.type='number';this.percentage.min='25';this.percentage.max='250';this.percentage.step='1';this.percentage.inputMode='numeric';this.percentage.setAttribute('aria-label','Zoom percentage');number.append(this.percentage);
  const arrows=document.createElement('span');arrows.className='sdk-number-arrows';number.append(arrows);this.increment=this.arrow(arrows,'Increase zoom percentage',1,()=>this.stepPercentage(1));this.decrement=this.arrow(arrows,'Decrease zoom percentage',-1,()=>this.stepPercentage(-1));
  const unit=document.createElement('span');unit.textContent='%';unit.setAttribute('aria-hidden','true');row.append(number,unit);body.append(row);
  this.levels=document.createElement('select');this.levels.setAttribute('aria-label','Perspective level');this.levels.title='Microverse perspective';PERSPECTIVE_LEVELS.forEach(level=>{const option=document.createElement('option');option.value=String(level);option.textContent='Level '+level;option.dataset.level=String(level);this.levels.append(option);});body.append(this.levels);
  this.slider.addEventListener('input',()=>this.set(Number(this.slider.value)));this.levels.addEventListener('change',()=>{this.perspective=Number(this.levels.value);this.changePerspective(this.perspective);this.render(100);});
  this.percentage.addEventListener('change',this.commitPercentage);this.percentage.addEventListener('blur',this.commitPercentage);
  this.percentage.addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();this.commitPercentage();this.percentage.blur();}else if(event.key==='Escape')this.render(this.current);});
  this.dialog.addEventListener('keydown',event=>{event.stopPropagation();if(event.key==='Escape'){event.preventDefault();this.close();}});this.dialog.addEventListener('cancel',event=>{event.preventDefault();this.close();});
  this.controls=new ChildWindow(this.dialog,{minWidth:80,minHeight:220});this.render(100);
 }
 private button(parent:HTMLElement,text:string,label:string,action:()=>void){const button=document.createElement('button');button.type='button';button.textContent=text;button.setAttribute('aria-label',label);button.addEventListener('click',action);parent.append(button);return button;}
 private arrow(parent:HTMLElement,label:string,direction:1|-1,action:()=>void){const button=this.button(parent,'',label,action);button.className='sdk-number-step';button.dataset.direction=String(direction);return button;}
 private commitPercentage=()=>{const value=this.percentage.valueAsNumber;if(Number.isFinite(value))this.set(value);else this.render(this.current);};
 private stepPercentage(direction:1|-1){const value=this.percentage.valueAsNumber;this.set((Number.isFinite(value)?value:this.current)+direction);}
 private render(percent:number){this.current=percent;this.slider.value=String(percent);this.slider.setAttribute('aria-valuetext',percent+'%');this.percentage.value=String(percent);this.levels.value=String(this.perspective);this.increment.disabled=percent>=250;this.decrement.disabled=percent<=25;}
 private set(percent:number){this.render(this.change(percent));}
 setView(percent:number,level:number){this.perspective=level;this.render(percent);}
 open(percent:number,level=this.perspective){this.setView(percent,level);if(!this.dialog.open){if(typeof this.dialog.show==='function')this.dialog.show();else this.dialog.setAttribute('open','');}const area=windowArea(this.dialog);this.controls.open({x:16,y:Math.max(0,Math.min(area.height-304,chatBounds(area.width,area.height).h+64)),w:88,h:244});}
 close(){this.controls.close();if(this.dialog.open){if(typeof this.dialog.close==='function')this.dialog.close();else this.dialog.removeAttribute('open');}}
 destroy(){this.controls.destroy();this.dialog.remove();}
}
