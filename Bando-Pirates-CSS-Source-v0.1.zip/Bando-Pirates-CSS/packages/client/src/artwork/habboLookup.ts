import {parseHabboFigure} from '@cocoworking/shared';
export const HABBO_HOTELS=[{id:'com',label:'Habbo.com · International',host:'www.habbo.com'},{id:'nl',label:'Habbo.nl · Netherlands',host:'www.habbo.nl'}] as const;
/** Only the requested name and returned outfit are used; profile details are discarded. */
export async function lookupHabboFigure(name:string,hotel:string,signal?:AbortSignal,fetcher:typeof fetch=fetch):Promise<string>{
 const trimmed=name.trim(),selected=HABBO_HOTELS.find(h=>h.id===hotel);
 if(!selected)throw Error('Choose a supported Habbo hotel.');
 if(!trimmed||trimmed.length>32||/[\u0000-\u001f\u007f]/.test(trimmed))throw Error('Enter a valid Habbo name.');
 const url=new URL('/api/public/users',`https://${selected.host}`);url.searchParams.set('name',trimmed);
 const response=await fetcher(url.href,{signal,mode:'cors',credentials:'omit',referrerPolicy:'no-referrer'});
 if(response.status===404)throw Error('That Habbo name was not found in the selected hotel.');
 if(response.status===429)throw Error('Habbo is receiving too many lookups. Try again shortly.');
 if(!response.ok)throw Error('Habbo could not load this outfit. Try again.');
 const data:unknown=await response.json();const figure=parseHabboFigure(data&&typeof data==='object'?(data as {figureString?:unknown}).figureString:undefined);
 if(!figure)throw Error('This Habbo profile did not return a usable outfit.');
 return figure;
}
