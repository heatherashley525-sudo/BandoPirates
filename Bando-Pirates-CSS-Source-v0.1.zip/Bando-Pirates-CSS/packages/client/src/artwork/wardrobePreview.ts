import {blankAppearance,parseAppearance} from '@cocoworking/shared';
import {Wardrobe} from './Wardrobe';
const key='heather-hotel-base-design-v1',app=document.getElementById('app')!;
app.className='wardrobe-page';const title=document.createElement('h1');title.textContent='Bando Pirates · Avatar base';app.append(title);
const copy=document.createElement('p');copy.textContent='An original blank CSS skin, with eight directions and separate wardrobe layers.';app.append(copy);
const launch=document.createElement('button');launch.type='button';launch.textContent='Open wardrobe';app.append(launch);
let appearance=blankAppearance();try{appearance=parseAppearance(JSON.parse(localStorage.getItem(key)||'null'))||appearance;}catch{}
const wardrobe=new Wardrobe(app,draft=>{try{localStorage.setItem(key,JSON.stringify(draft));appearance=draft;wardrobe.saved();}catch{wardrobe.failed('Could not save. You can export the avatar JSON instead.');}},true);
launch.addEventListener('click',()=>wardrobe.open(appearance));wardrobe.open(appearance);
