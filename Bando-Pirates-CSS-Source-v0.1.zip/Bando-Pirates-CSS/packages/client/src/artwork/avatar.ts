import {defaultAppearance,parseAppearance,parseHabboFigure,directionForMove,toHabboDirection,habboImageUrl,type AvatarAppearance,type CollectibleAsset,type Direction} from '@cocoworking/shared';
import './avatar.css';
function part(parent:HTMLElement,className:string,slot?:string){const node=document.createElement('div');node.className=className;if(slot)node.dataset.avatarSlot=slot;parent.append(node);return node;}
interface SpriteState{appearance:AvatarAppearance;collectible?:{figure:string;name:string};direction:Direction;walking:boolean;sitting?:boolean;frame:number;image?:HTMLImageElement;cache:Map<string,HTMLImageElement>;timer?:ReturnType<typeof setInterval>}
const sprites=new WeakMap<HTMLElement,SpriteState>();
function activeFigure(state:SpriteState){return state.collectible?.figure??state.appearance.habboFigure;}
function clearFrames(root:HTMLElement,state:SpriteState){
 for(const frame of state.cache.values()){frame.onload=null;frame.onerror=null;}
 state.cache.clear();state.image?.remove();state.image=undefined;
 delete root.dataset.assetUrl;delete root.dataset.assetLoading;delete root.dataset.assetError;
}
export function applyCollectibleAvatar(root:HTMLElement,asset:CollectibleAsset|null){
 const state=sprites.get(root);if(!state)return;
 const previous=activeFigure(state);
 const figure=asset?.kind==='avatar'?parseHabboFigure(asset.figure):null;
 state.collectible=figure&&asset?{figure,name:asset.name}:undefined;
 if(figure&&asset?.test)root.dataset.nftTest='true';else delete root.dataset.nftTest;
 if(previous!==activeFigure(state)){
  clearFrames(root,state);state.frame=0;updateTimer(root);
 }
 renderSprite(root);
}
export function makeAvatar(name:string,color=0xe995c4,appearance:AvatarAppearance=defaultAppearance(color)):HTMLElement {
 const root=document.createElement('div');root.className='css-avatar';root.dataset.canvas='64x110';
 part(root,'avatar-shadow');const figure=part(root,'avatar-figure');const skin=part(figure,'avatar-skin','skin');
 for(const key of ['neck','torso','pelvis','head','ear ear-left','ear ear-right'])part(skin,`avatar-${key}`);
 const hair=part(figure,'avatar-hair-layer','hair');part(hair,'avatar-hair-back');part(hair,'avatar-hair');part(hair,'avatar-hair-cap');
 const face=part(figure,'avatar-face','face');
 for(const side of ['left','right']){part(face,`avatar-eyebrow eyebrow-${side}`);part(face,`avatar-eye eye-${side}`);}
 part(face,'avatar-nose');part(face,'avatar-mouth');
 for(const side of ['left','right']){
  const arm=part(figure,`avatar-arm arm-${side}`);part(arm,'avatar-sleeve');part(arm,'avatar-hand');
  const leg=part(figure,`avatar-leg leg-${side}`);part(leg,'avatar-trouser');part(leg,'avatar-foot');const shoes=part(leg,'avatar-shoes-layer','shoes');part(shoes,`avatar-shoe shoe-${side}`);
 }
 const top=part(figure,'avatar-top-layer','top');part(top,'avatar-shirt');const bust=part(figure,'avatar-bust-layer','body');part(bust,'avatar-breast breast-left');part(bust,'avatar-breast breast-right');const bottom=part(figure,'avatar-bottom-layer','bottom');part(bottom,'avatar-waistband');const accessory=part(figure,'avatar-accessory-layer','accessory');part(accessory,'avatar-bow');
 part(root,'avatar-name').textContent=name;sprites.set(root,{appearance,direction:'south',walking:false,frame:0,cache:new Map()});applyAvatarAppearance(root,appearance);setAvatarDirection(root,'south');return root;
}
function renderSprite(root:HTMLElement){
 const state=sprites.get(root);if(!state)return;
 const figure=activeFigure(state);root.dataset.frame=String(state.frame);root.dataset.renderer=figure?'habbo':'css';
 if(!figure)return;
 if(!state.image){const image=document.createElement('img');image.className='avatar-external';image.draggable=false;image.referrerPolicy='no-referrer';root.append(image);state.image=image;}
 state.image.alt=state.collectible?.name??'Habbo avatar';
 const url=habboImageUrl(figure,state.direction,state.walking,state.frame,state.sitting);root.dataset.assetUrl=url;
 const show=(image:HTMLImageElement)=>{if(sprites.get(root)!==state||!state.image||state.cache.get(image.src)!==image)return;if(root.dataset.assetUrl!==image.src&&state.image.naturalWidth)return;state.image.src=image.src;delete root.dataset.assetError;delete root.dataset.assetLoading;};
 const cached=state.cache.get(url);
 if(cached){if(cached.complete&&cached.naturalWidth)show(cached);return;}
 // Load each frame once before presenting it. Fast animation ticks never abort image requests.
 const preload=new Image();preload.referrerPolicy='no-referrer';state.cache.set(url,preload);if(!state.image.naturalWidth)root.dataset.assetLoading='true';
 preload.onload=()=>show(preload);preload.onerror=()=>{if(sprites.get(root)!==state||state.cache.get(url)!==preload)return;if(!state.image?.naturalWidth){root.dataset.assetError='true';delete root.dataset.assetLoading;root.dispatchEvent(new CustomEvent('avatarasseterror',{bubbles:true}));}};preload.src=url;
}
function updateTimer(root:HTMLElement){const state=sprites.get(root);if(!state)return;clearInterval(state.timer);state.timer=undefined;if(state.walking&&activeFigure(state))state.timer=setInterval(()=>{state.frame=(state.frame+1)%4;renderSprite(root);},120);}
export function applyAvatarAppearance(root:HTMLElement,value:AvatarAppearance){
 const a=parseAppearance(value),state=sprites.get(root);if(!a||!state)return;
 const previous=activeFigure(state);state.appearance=a;
 if(previous!==activeFigure(state)||root.dataset.assetError)clearFrames(root,state);
 for(const key of ['face','hair','top','bottom','shoes','accessory'] as const)root.dataset[key]=a[key];
 root.dataset.breastSize=String(a.breastSize??0);root.style.setProperty('--breast-size',String((a.breastSize??0)/100));
 for(const [name,color] of [['--skin',a.skin],['--hair',a.hairColor],['--shirt',a.topColor],['--bottom',a.bottomColor],['--shoe',a.shoeColor]])root.style.setProperty(name,color);
 delete root.dataset.assetError;updateTimer(root);renderSprite(root);
}
export function setAvatarDirection(root:HTMLElement,direction:Direction){
 const state=sprites.get(root);if(state)state.direction=direction;root.dataset.direction=direction;root.dataset.habboDirection=String(toHabboDirection(direction));
 const poses:Record<Direction,string>={'north-east':'quarter-back',east:'side','south-east':'quarter-front',south:'front','south-west':'quarter-front',west:'side','north-west':'quarter-back',north:'back'};
 root.dataset.pose=poses[direction];root.dataset.flip=String(['south-west','west','north-west'].includes(direction));renderSprite(root);
}
export function setAvatarWalking(root:HTMLElement,walking:boolean){const state=sprites.get(root);root.classList.toggle('is-walking',walking);if(!state)return;if(state.walking===walking)return;state.walking=walking;state.frame=0;updateTimer(root);renderSprite(root);}
export function setAvatarSitting(root:HTMLElement,sitting:boolean){const state=sprites.get(root);root.dataset.posture=sitting?'sit':'stand';if(!state)return;if(state.sitting===sitting)return;state.sitting=sitting;if(sitting)setAvatarWalking(root,false);renderSprite(root);}
export function disposeAvatar(root:HTMLElement){const state=sprites.get(root);if(!state)return;clearInterval(state.timer);clearFrames(root,state);sprites.delete(root);}
