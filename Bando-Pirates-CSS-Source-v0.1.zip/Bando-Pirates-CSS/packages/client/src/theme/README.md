# Shared theme

Upstream: HeatherOS current development Site, version 254.
Source commit: a630054aab2d206cda458703d2b28be045035809.

- `heatheros-controls.css`: exact bytes from `public/theme/controls.css`.
- `heatheros-modern.css`: verbatim selected base window/control rules and the entire Modern block from `public/assets/index-DTCo6ZBD.css`. Selectors and declarations are unchanged.
- `hotel-palette.css`: Heather pink, lavender and periwinkle colour overrides.
- `source.json`: source paths and SHA-256 values for the retained shared CSS.

Import this theme once for each entry point. Use the original `.window.active.bevel > .titlebar` / `.window-controls > .window-control` structure. The upstream Modern selector still uses `data-title-bar-style="xp"`; the public theme name is HeatherOS Modern. Do not add separate per-component button skins. Keep component sizing/layout in the component stylesheet and colours in the palette.

The Start menu additionally uses the compact menu rules from HeatherOS version 259 (commit dad3097b8374a41b00eebad5a557f6ac0d96db6e) in `heatheros-start-menu.css`, scoped to `.bando-start`. The Modern Start-button finish is retained; Bando branding, placement and compact mobile layout live in `ui/start-menu.css`. `ui/bandoIcon.ts` embeds the existing HeatherOS Bando Pirates desktop icon for the standalone HTML. Source provenance is in `source.json`. Every resizable child window uses only the bottom-left grip.

`heatheros-taskbar.css` retains the HeatherOS v259 taskbar, task button, tray and mixer rules, and its Modern finish with shell selectors scoped to `.bando-taskbar`. `ui/taskbar.css` supplies responsive game layout and calendar geometry; palette colours remain centralized. Start keeps HeatherOS Modern’s raised, flush-left taskbar geometry. Shared child headers are 28 pixels high with compact 21-pixel controls. Chat omits the header entirely. `workArea.ts` reserves the actual taskbar height below the room and child windows. The bar is 44 pixels with one row and grows by 37 pixels for each overflow row. It shrinks as program buttons are removed. Program icon metadata and original matching vector icons live in `ui/programIcons.ts`.
