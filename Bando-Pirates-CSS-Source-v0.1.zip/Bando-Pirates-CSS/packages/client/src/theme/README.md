# Shared theme

Upstream: HeatherOS current development Site, version 254.
Source commit: a630054aab2d206cda458703d2b28be045035809.

- `heatheros-controls.css`: exact bytes from `public/theme/controls.css`.
- `heatheros-modern.css`: verbatim selected base window/control rules and the entire Modern block from `public/assets/index-DTCo6ZBD.css`. Selectors and declarations are unchanged.
- `hotel-palette.css`: Hotel colour overrides only.
- `source.json`: source paths and SHA-256 values for the retained shared CSS.

Import this theme once for each entry point. Use the original `.window.active.bevel > .titlebar` / `.window-controls > .window-control` structure. The upstream Modern selector still uses `data-title-bar-style="xp"`; the public theme name is HeatherOS Modern. Do not add separate per-component button skins. Keep component sizing/layout in the component stylesheet and colours in the palette.
