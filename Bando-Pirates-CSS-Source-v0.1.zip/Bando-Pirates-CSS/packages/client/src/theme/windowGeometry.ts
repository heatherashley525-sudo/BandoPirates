/** Same bounded geometry used by HeatherOS window-layout.js, with TypeScript types. */
export interface WindowBounds{x:number;y:number;w:number;h:number}
export interface WindowArea{width:number;height:number}
export function fitWindowBounds(rect:WindowBounds,area:WindowArea,minimum={width:160,height:120}):WindowBounds{
 const w=Math.min(area.width,Math.max(Math.min(minimum.width,area.width),rect.w));
 const h=Math.min(area.height,Math.max(Math.min(minimum.height,area.height),rect.h));
 return {x:Math.max(0,Math.min(area.width-w,rect.x)),y:Math.max(0,Math.min(area.height-h,rect.y)),w,h};
}
export function resizeWindowBounds(rect:WindowBounds,edge:string,dx:number,dy:number,area:WindowArea,minimum={width:360,height:220}):WindowBounds{
 const start=fitWindowBounds(rect,area,minimum),minWidth=Math.min(minimum.width,area.width),minHeight=Math.min(minimum.height,area.height);
 let left=start.x,top=start.y,right=left+start.w,bottom=top+start.h;
 if(edge.includes('w'))left=Math.max(0,Math.min(right-minWidth,left+dx));
 if(edge.includes('e'))right=Math.min(area.width,Math.max(left+minWidth,right+dx));
 if(edge.includes('n'))top=Math.max(0,Math.min(bottom-minHeight,top+dy));
 if(edge.includes('s'))bottom=Math.min(area.height,Math.max(top+minHeight,bottom+dy));
 return {x:left,y:top,w:right-left,h:bottom-top};
}
