import {describe,it,expect} from 'vitest';
import {fitWindowBounds,resizeWindowBounds} from '../windowGeometry';
import {ChildWindow} from '../ChildWindow';
describe('owned child window movement and resizing',()=>{
 it('keeps a default full-width panel docked until the user adjusts its bounds',()=>{
  const win=document.createElement('div');document.body.append(win);const controller=new ChildWindow(win,{minWidth:200,minHeight:100,followViewport:(w)=>({x:0,y:0,w,h:240})});controller.open({x:0,y:0,w:500,h:240});window.dispatchEvent(new Event('resize'));expect(parseFloat(win.style.width)).toBe(window.innerWidth);win.querySelector<HTMLElement>('[data-edge="sw"]')!.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowRight',bubbles:true}));const custom=win.style.width;window.dispatchEvent(new Event('resize'));expect(win.style.width).toBe(custom);controller.destroy();win.remove();
 });
 it('clamps dragging and keeps each resize edge inside the viewport',()=>{
  const area={width:800,height:600};expect(fitWindowBounds({x:-90,y:800,w:500,h:400},area)).toEqual({x:0,y:200,w:500,h:400});
  expect(resizeWindowBounds({x:100,y:100,w:400,h:300},'nw',-50,-30,area)).toEqual({x:50,y:70,w:450,h:330});
  expect(resizeWindowBounds({x:100,y:100,w:400,h:300},'se',999,999,area)).toEqual({x:100,y:100,w:700,h:500});
 });
 it('adapts the minimum bounds to a narrow mobile viewport',()=>{
  expect(fitWindowBounds({x:0,y:0,w:760,h:650},{width:320,height:480})).toEqual({x:0,y:0,w:320,h:480});
  expect(resizeWindowBounds({x:10,y:10,w:300,h:400},'w',500,0,{width:320,height:480},{width:160,height:120}).w).toBe(160);
 });
 it('keeps ordinary child windows draggable and resizable without a maximize button or double-click action',()=>{
  const win=document.createElement('dialog');win.innerHTML='<header class="titlebar"><span>Scale</span><div class="window-controls"><button>×</button></div></header>';document.body.append(win);const controller=new ChildWindow(win);controller.open({x:10,y:20,w:320,h:260});expect(win.querySelector('.window-maximize')).toBeNull();win.querySelector('header')!.dispatchEvent(new MouseEvent('dblclick',{bubbles:true}));expect(win.dataset.maximized).toBeUndefined();expect(win.querySelectorAll('.resize-handle')).toHaveLength(1);controller.destroy();win.remove();
 });
 it('offers only the bottom-left grip, including in the maximizable wardrobe',()=>{
  const win=document.createElement('dialog');win.className='window';win.innerHTML='<header class="titlebar"><span>Wardrobe</span></header>';document.body.append(win);
  const controller=new ChildWindow(win,{maximizable:true});controller.open();expect(win.querySelectorAll('.resize-handle')).toHaveLength(1);
  const before=parseFloat(win.style.width);win.querySelector<HTMLElement>('[data-edge="sw"]')!.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowLeft',bubbles:true}));expect(parseFloat(win.style.width)).toBe(before+8);
  const grip=win.querySelector<HTMLElement>('[data-edge="sw"]')!,right=parseFloat(win.style.left)+parseFloat(win.style.width),top=win.style.top,height=parseFloat(win.style.height);
  const pointer=(type:string,x:number,y:number)=>{const event=new MouseEvent(type,{button:0,bubbles:true,clientX:x,clientY:y});Object.defineProperty(event,'pointerId',{value:7});return event;};
  grip.dispatchEvent(pointer('pointerdown',100,200));win.dispatchEvent(pointer('pointermove',84,216));win.dispatchEvent(pointer('pointerup',84,216));expect(parseFloat(win.style.width)).toBe(before+24);expect(parseFloat(win.style.height)).toBe(height+16);expect(parseFloat(win.style.left)+parseFloat(win.style.width)).toBe(right);expect(win.style.top).toBe(top);
  controller.toggleMaximize();expect(win.dataset.maximized).toBe('true');controller.toggleMaximize();expect(win.dataset.maximized).toBe('false');expect(parseFloat(win.style.width)).toBe(before+24);
  controller.destroy();expect(win.querySelectorAll('.resize-handle')).toHaveLength(0);win.remove();
 });
});
