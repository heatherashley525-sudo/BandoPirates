import {describe,it,expect} from 'vitest';
import {fitWindowBounds,resizeWindowBounds} from '../windowGeometry';
import {ChildWindow} from '../ChildWindow';
describe('owned child window movement and resizing',()=>{
 it('clamps dragging and keeps each resize edge inside the viewport',()=>{
  const area={width:800,height:600};expect(fitWindowBounds({x:-90,y:800,w:500,h:400},area)).toEqual({x:0,y:200,w:500,h:400});
  expect(resizeWindowBounds({x:100,y:100,w:400,h:300},'nw',-50,-30,area)).toEqual({x:50,y:70,w:450,h:330});
  expect(resizeWindowBounds({x:100,y:100,w:400,h:300},'se',999,999,area)).toEqual({x:100,y:100,w:700,h:500});
 });
 it('adapts the minimum bounds to a narrow mobile viewport',()=>{
  expect(fitWindowBounds({x:0,y:0,w:760,h:650},{width:320,height:480})).toEqual({x:0,y:0,w:320,h:480});
  expect(resizeWindowBounds({x:10,y:10,w:300,h:400},'w',500,0,{width:320,height:480},{width:160,height:120}).w).toBe(160);
 });
 it('provides all eight resize handles and keyboard resizing, with a working maximize/restore',()=>{
  const win=document.createElement('dialog');win.className='window';win.innerHTML='<header class="titlebar"><span>Wardrobe</span></header>';document.body.append(win);
  const controller=new ChildWindow(win);controller.open();expect(win.querySelectorAll('.resize-handle')).toHaveLength(8);
  const before=parseFloat(win.style.width);win.querySelector<HTMLElement>('[data-edge="e"]')!.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowRight',bubbles:true}));expect(parseFloat(win.style.width)).toBe(before+8);
  controller.toggleMaximize();expect(win.dataset.maximized).toBe('true');controller.toggleMaximize();expect(win.dataset.maximized).toBe('false');expect(parseFloat(win.style.width)).toBe(before+8);
  controller.destroy();expect(win.querySelectorAll('.resize-handle')).toHaveLength(0);win.remove();
 });
});
