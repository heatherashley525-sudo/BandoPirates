/** The game taskbar owns the strip below the floating-window work area. */
export function taskbarLayout(width:number,count=0,available?:number){
 const mobile=width<=767,space=available??Math.max(1,width-(mobile?192:302));
 const columns=Math.max(1,Math.min(Math.max(1,count),Math.floor((space+3)/((mobile?36:120)+3))));
 const rows=Math.max(1,Math.ceil(count/columns));return {columns,rows,height:44+(rows-1)*37};
}
export function taskbarHeight(width:number,count=0,available?:number){return taskbarLayout(width,count,available).height;}
export function windowArea(element:HTMLElement){
 const width=Math.max(1,window.visualViewport?.width||window.innerWidth),height=Math.max(1,window.visualViewport?.height||window.innerHeight);
 const host=element.closest<HTMLElement>('[data-game-taskbar=true]'),reserved=host?Number(host.dataset.taskbarHeight)||44:0;
 return {width,height:Math.max(1,height-reserved)};
}
