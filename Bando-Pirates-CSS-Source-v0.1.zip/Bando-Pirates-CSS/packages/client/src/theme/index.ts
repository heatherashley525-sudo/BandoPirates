/** One shared UI theme for the game, studio and wardrobe. */
import './heatheros-modern.css';
import './heatheros-controls.css';
import './hotel-palette.css';
document.body.id='screen';
document.body.dataset.titleBarStyle='xp'; // HeatherOS Modern retains this upstream selector.
