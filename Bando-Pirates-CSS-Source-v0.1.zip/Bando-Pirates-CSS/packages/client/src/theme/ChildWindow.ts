import {fitWindowBounds,resizeWindowBounds,type WindowBounds} from './windowGeometry';
import './child-windows.css';
const edges:Record<string,string>={n:'top edge',ne:'top-right corner',e:'right edge',se:'bottom-right corner',s:'bottom edge',sw:'bottom-left corner',w:'left edge',nw:'top-left corner'};
/** Shared pointer/touch/keyboard window behaviour for every Hotel child window. */
export class ChildWindow{
 private static nextLayer=100;
 private bounds?:WindowBounds;private restore?:WindowBounds;private maximized=false;private handles:HTMLElement[]=[];private header:HTMLElement;private maximize?:HTMLButtonElement;
 private drag?:{id:number;target:HTMLElement;edge:string;x:number;y:number;bounds:WindowBounds};
 constructor(private win:HTMLDialogElement){
  win.classList.add('hotel-child-window');this.header=win.querySelector<HTMLElement>('.titlebar')!;this.header.title='Drag to move. Double-click to maximise or restore.';
  const controls=this.header.querySelector('.window-controls');if(controls){this.maximize=document.createElement('button');this.maximize.type='button';this.maximize.className='window-control window-maximize';this.maximize.setAttribute('aria-label','Maximise window');this.maximize.addEventListener('click',this.toggleMaximize);controls.prepend(this.maximize);}
  this.header.addEventListener('pointerdown',this.onDown);this.header.addEventListener('dblclick',this.onDouble);
  for(const [edge,label] of Object.entries(edges)){
   const handle=document.createElement('div');handle.className=`resize-handle resize-${edge}`;handle.dataset.edge=edge;handle.tabIndex=0;handle.setAttribute('role','separator');handle.setAttribute('aria-label','Resize '+label);handle.addEventListener('pointerdown',this.onDown);handle.addEventListener('keydown',this.onKey);this.handles.push(handle);win.append(handle);
  }
  win.addEventListener('pointerdown',this.raise,true);win.addEventListener('focusin',this.raise);win.addEventListener('pointermove',this.onMove);win.addEventListener('pointerup',this.onEnd);win.addEventListener('pointercancel',this.onCancel);win.addEventListener('lostpointercapture',this.onCancel);window.addEventListener('resize',this.fit);window.visualViewport?.addEventListener('resize',this.fit);
 }
 private area(){return {width:Math.max(1,window.visualViewport?.width||window.innerWidth),height:Math.max(1,window.visualViewport?.height||window.innerHeight)};}
 private minimum(){return {width:Math.min(320,this.area().width),height:Math.min(220,this.area().height)};}
 private apply(bounds:WindowBounds){this.bounds=bounds;Object.assign(this.win.style,{left:`${Math.round(bounds.x)}px`,top:`${Math.round(bounds.y)}px`,width:`${Math.round(bounds.w)}px`,height:`${Math.round(bounds.h)}px`});}
 private raise=()=>{this.win.style.zIndex=String(++ChildWindow.nextLayer);};
 open(initial?:WindowBounds){const area=this.area();if(!this.bounds){const r=this.win.getBoundingClientRect(),w=r.width||Math.min(760,area.width-24),h=r.height||Math.min(650,area.height-24);this.apply(fitWindowBounds(initial||{x:(area.width-w)/2,y:(area.height-h)/2,w,h},area,this.minimum()));}else this.fit();this.raise();}
 private fit=()=>{if(!this.bounds)return;const area=this.area();this.apply(this.maximized?{x:0,y:0,w:area.width,h:area.height}:fitWindowBounds(this.bounds,area,this.minimum()));};
 toggleMaximize=()=>{if(!this.bounds)this.open();this.maximized=!this.maximized;if(this.maximized){this.restore={...this.bounds!};this.fit();}else this.apply(fitWindowBounds(this.restore||this.bounds!,this.area(),this.minimum()));this.win.dataset.maximized=String(this.maximized);this.maximize?.classList.toggle('window-restore',this.maximized);this.maximize?.setAttribute('aria-label',this.maximized?'Restore window':'Maximise window');};
 private onDouble=(event:MouseEvent)=>{if(!(event.target as HTMLElement).closest('button'))this.toggleMaximize();};
 private onDown=(event:PointerEvent)=>{
  if(event.button!==0||this.drag||(event.target as HTMLElement).closest('button,input,select')||this.maximized)return;
  const target=event.currentTarget as HTMLElement;event.preventDefault();event.stopPropagation();this.open();this.drag={id:event.pointerId,target,edge:target.dataset.edge||'',x:event.clientX,y:event.clientY,bounds:{...this.bounds!}};target.setPointerCapture?.(event.pointerId);this.win.dataset.windowGesture=this.drag.edge?'resize':'move';
 };
 private onMove=(event:PointerEvent)=>{
  if(!this.drag||this.drag.id!==event.pointerId)return;event.preventDefault();const d=this.drag,dx=event.clientX-d.x,dy=event.clientY-d.y;
  this.apply(d.edge?resizeWindowBounds(d.bounds,d.edge,dx,dy,this.area(),this.minimum()):fitWindowBounds({...d.bounds,x:d.bounds.x+dx,y:d.bounds.y+dy},this.area(),this.minimum()));
 };
 private end(cancel=false){const d=this.drag;this.drag=undefined;if(d){if(cancel)this.apply(fitWindowBounds(d.bounds,this.area(),this.minimum()));if(d.target.hasPointerCapture?.(d.id))d.target.releasePointerCapture(d.id);}delete this.win.dataset.windowGesture;}
 private onEnd=(event:PointerEvent)=>{if(event.pointerId===this.drag?.id)this.end();};private onCancel=(event:PointerEvent)=>{if(event.pointerId===this.drag?.id)this.end(true);};
 private onKey=(event:KeyboardEvent)=>{if(!event.key.startsWith('Arrow'))return;event.preventDefault();event.stopPropagation();if(this.maximized)this.toggleMaximize();this.open();const step=event.shiftKey?24:8;this.apply(resizeWindowBounds(this.bounds!,(event.currentTarget as HTMLElement).dataset.edge!,event.key==='ArrowRight'?step:event.key==='ArrowLeft'?-step:0,event.key==='ArrowDown'?step:event.key==='ArrowUp'?-step:0,this.area(),this.minimum()));};
 close(){this.end();}
 destroy(){this.end();this.header.removeEventListener('pointerdown',this.onDown);this.header.removeEventListener('dblclick',this.onDouble);this.maximize?.remove();for(const h of this.handles)h.remove();this.win.removeEventListener('pointerdown',this.raise,true);this.win.removeEventListener('focusin',this.raise);this.win.removeEventListener('pointermove',this.onMove);this.win.removeEventListener('pointerup',this.onEnd);this.win.removeEventListener('pointercancel',this.onCancel);this.win.removeEventListener('lostpointercapture',this.onCancel);window.removeEventListener('resize',this.fit);window.visualViewport?.removeEventListener('resize',this.fit);}
}
