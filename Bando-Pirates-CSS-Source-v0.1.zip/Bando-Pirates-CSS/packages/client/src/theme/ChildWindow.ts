import {fitWindowBounds,resizeWindowBounds,type WindowBounds} from './windowGeometry';
import './child-windows.css';
import {windowArea} from './workArea';
const edges:Record<string,string>={sw:'bottom-left corner'};
export interface ChildWindowOptions {minWidth?:number;minHeight?:number;resizable?:boolean;maximizable?:boolean;dragButtons?:boolean;onBoundsChange?:(bounds:WindowBounds)=>void;followViewport?:(width:number,height:number)=>WindowBounds;onUserBoundsChange?:()=>void}
/** Shared pointer/touch/keyboard window behaviour for every Hotel child window. */
export class ChildWindow{
 private static nextLayer=100;private static controllers=new WeakMap<HTMLElement,ChildWindow>();
 static forElement(element:HTMLElement){return this.controllers.get(element);}
 private opened=false;private minimized=false;
 private bounds?:WindowBounds;private restore?:WindowBounds;private maximized=false;private customBounds=false;private handles:HTMLElement[]=[];private header:HTMLElement;private maximize?:HTMLButtonElement;
 private drag?:{id:number;target:HTMLElement;edge:string;x:number;y:number;bounds:WindowBounds;button:boolean;moved:boolean};private suppressClick=false;private clickReset?:ReturnType<typeof setTimeout>;
 constructor(private win:HTMLElement,private options:ChildWindowOptions={}){
  ChildWindow.controllers.set(win,this);win.classList.add('hotel-child-window');this.header=win.querySelector<HTMLElement>('.titlebar')||win;if(this.header!==win)this.header.title=options.maximizable?'Drag to move. Double-click to maximise or restore.':'Drag to move.';
  const controls=this.header.querySelector('.window-controls');if(controls&&options.maximizable){this.maximize=document.createElement('button');this.maximize.type='button';this.maximize.className='window-control window-maximize';this.maximize.setAttribute('aria-label','Maximise window');this.maximize.addEventListener('click',this.toggleMaximize);controls.prepend(this.maximize);}
  win.addEventListener('pointerdown',this.onDown);win.addEventListener('click',this.onClick,true);if(this.header!==win)this.header.addEventListener('dblclick',this.onDouble);
  for(const [edge,label] of Object.entries(options.resizable===false?{}:edges)){
   const handle=document.createElement('div');handle.className=`resize-handle resize-${edge}`;handle.dataset.edge=edge;handle.tabIndex=0;handle.setAttribute('role','separator');handle.setAttribute('aria-label','Resize '+label);handle.addEventListener('pointerdown',this.onDown);handle.addEventListener('keydown',this.onKey);this.handles.push(handle);win.append(handle);
  }
  win.addEventListener('pointerdown',this.raise,true);win.addEventListener('focusin',this.raise);win.addEventListener('pointermove',this.onMove);win.addEventListener('pointerup',this.onEnd);win.addEventListener('pointercancel',this.onCancel);win.addEventListener('lostpointercapture',this.onCancel);window.addEventListener('resize',this.fit);window.visualViewport?.addEventListener('resize',this.fit);
 }
 private area(){return windowArea(this.win);}
 private minimum(){return {width:Math.min(this.options.minWidth??320,this.area().width),height:Math.min(this.options.minHeight??220,this.area().height)};}
 private apply(bounds:WindowBounds){this.bounds=bounds;Object.assign(this.win.style,{left:`${Math.round(bounds.x)}px`,top:`${Math.round(bounds.y)}px`,width:`${Math.round(bounds.w)}px`,height:`${Math.round(bounds.h)}px`});this.options.onBoundsChange?.({...bounds});}
 private changed(){this.win.dispatchEvent(new CustomEvent('hotel-window-change',{bubbles:true}));}
 private raise=()=>{this.win.style.zIndex=String(++ChildWindow.nextLayer);this.changed();};
 isOpen(){return this.opened;}
 isMinimized(){return this.minimized;}
 reflow(){this.fit();}
 minimize(){if(!this.opened)return;this.end();this.minimized=true;this.win.hidden=true;this.win.dataset.minimized='true';this.changed();}
 private unminimize(){if(this.minimized){this.minimized=false;this.win.hidden=false;delete this.win.dataset.minimized;}}
 activate(){this.open();if(!this.win.hasAttribute('tabindex'))this.win.tabIndex=-1;this.win.focus({preventScroll:true});}
 open(initial?:WindowBounds){this.opened=true;this.unminimize();const area=this.area();if(!this.bounds){const r=this.win.getBoundingClientRect(),w=r.width||Math.min(760,area.width-24),h=r.height||Math.min(650,area.height-24);this.apply(fitWindowBounds(initial||{x:(area.width-w)/2,y:(area.height-h)/2,w,h},area,this.minimum()));}else this.fit();this.raise();}
 private fit=()=>{if(!this.bounds)return;const area=this.area(),bounds=!this.customBounds&&this.options.followViewport?this.options.followViewport(area.width,area.height):this.bounds;this.apply(this.maximized?{x:0,y:0,w:area.width,h:area.height}:fitWindowBounds(bounds,area,this.minimum()));};
 private markCustom(){if(!this.customBounds){this.customBounds=true;this.options.onUserBoundsChange?.();}}
 toggleMaximize=()=>{if(!this.options.maximizable)return;if(!this.bounds)this.open();this.markCustom();this.maximized=!this.maximized;if(this.maximized){this.restore={...this.bounds!};this.fit();}else this.apply(fitWindowBounds(this.restore||this.bounds!,this.area(),this.minimum()));this.win.dataset.maximized=String(this.maximized);this.maximize?.classList.toggle('window-restore',this.maximized);this.maximize?.setAttribute('aria-label',this.maximized?'Restore window':'Maximise window');};
 private onDouble=(event:MouseEvent)=>{if(!(event.target as HTMLElement).closest('button'))this.toggleMaximize();};
 private onDown=(event:PointerEvent)=>{
  const source=event.target as HTMLElement,handle=source.closest<HTMLElement>('.resize-handle');
  const button=this.options.dragButtons?source.closest<HTMLButtonElement>('button'):null;
  if(event.button!==0||this.drag||!handle&&!button&&source.closest('button,input,select,textarea,a,label,summary,[contenteditable],[role=button],[data-no-drag]')||this.maximized)return;
  const target=handle||button||this.win;if(!button)event.preventDefault();event.stopPropagation();this.open();this.drag={id:event.pointerId,target,edge:handle?.dataset.edge||'',x:event.clientX,y:event.clientY,bounds:{...this.bounds!},button:!!button,moved:!button};target.setPointerCapture?.(event.pointerId);if(!button)this.win.dataset.windowGesture=this.drag.edge?'resize':'move';
 };
 private onMove=(event:PointerEvent)=>{
  if(!this.drag||this.drag.id!==event.pointerId)return;event.preventDefault();const d=this.drag,dx=event.clientX-d.x,dy=event.clientY-d.y;
  if(d.button&&!d.moved){if(Math.hypot(dx,dy)<6)return;d.moved=true;this.win.dataset.windowGesture='move';}
  if(dx||dy)this.markCustom();
  this.apply(d.edge?resizeWindowBounds(d.bounds,d.edge,dx,dy,this.area(),this.minimum()):fitWindowBounds({...d.bounds,x:d.bounds.x+dx,y:d.bounds.y+dy},this.area(),this.minimum()));
 };
 private end(cancel=false){const d=this.drag;this.drag=undefined;if(d){if(cancel)this.apply(fitWindowBounds(d.bounds,this.area(),this.minimum()));if(d.button&&d.moved&&!cancel){this.suppressClick=true;clearTimeout(this.clickReset);this.clickReset=setTimeout(()=>{this.suppressClick=false;},0);}if(d.target.hasPointerCapture?.(d.id))d.target.releasePointerCapture(d.id);}delete this.win.dataset.windowGesture;}
 private onClick=(event:MouseEvent)=>{if(this.suppressClick){event.preventDefault();event.stopPropagation();this.suppressClick=false;}};
 private onEnd=(event:PointerEvent)=>{if(event.pointerId===this.drag?.id)this.end();};private onCancel=(event:PointerEvent)=>{if(event.pointerId===this.drag?.id)this.end(true);};
 private onKey=(event:KeyboardEvent)=>{if(!event.key.startsWith('Arrow'))return;event.preventDefault();event.stopPropagation();if(this.maximized)this.toggleMaximize();this.open();this.markCustom();const step=event.shiftKey?24:8;this.apply(resizeWindowBounds(this.bounds!,(event.currentTarget as HTMLElement).dataset.edge!,event.key==='ArrowRight'?step:event.key==='ArrowLeft'?-step:0,event.key==='ArrowDown'?step:event.key==='ArrowUp'?-step:0,this.area(),this.minimum()));};
 close(){this.end();this.opened=false;this.unminimize();this.changed();}
 destroy(){this.close();ChildWindow.controllers.delete(this.win);clearTimeout(this.clickReset);this.win.removeEventListener('click',this.onClick,true);this.win.removeEventListener('pointerdown',this.onDown);this.header.removeEventListener('dblclick',this.onDouble);this.maximize?.remove();for(const h of this.handles)h.remove();this.win.removeEventListener('pointerdown',this.raise,true);this.win.removeEventListener('focusin',this.raise);this.win.removeEventListener('pointermove',this.onMove);this.win.removeEventListener('pointerup',this.onEnd);this.win.removeEventListener('pointercancel',this.onCancel);this.win.removeEventListener('lostpointercapture',this.onCancel);window.removeEventListener('resize',this.fit);window.visualViewport?.removeEventListener('resize',this.fit);}
}
