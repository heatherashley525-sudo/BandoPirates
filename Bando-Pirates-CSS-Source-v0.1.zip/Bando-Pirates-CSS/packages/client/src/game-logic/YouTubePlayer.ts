/**
 * Wrapper around the YouTube IFrame API.
 * Shares one API script between the DJ and the visible room music player.
 */

declare global {
  interface Window {
    YT: any;
    onYouTubeIframeAPIReady: (() => void) | undefined;
  }
}

let apiLoading: Promise<void> | undefined;

function loadYouTubeAPI(): Promise<void> {
  if (window.YT?.Player) return Promise.resolve();
  return apiLoading ??= new Promise((resolve, reject) => {
    const tag = document.createElement("script");
    tag.src = "https://www.youtube.com/iframe_api";
    tag.onerror = () => {
      tag.remove();
      apiLoading = undefined;
      reject(Error("YouTube could not load."));
    };
    window.onYouTubeIframeAPIReady = () => resolve();
    document.head.appendChild(tag);
  });
}

interface YouTubePlayerEvents {
  onPlaying?: () => void;
  onAutoplayBlocked?: () => void;
  onError?: () => void;
}

export class YouTubePlayer {
  private player: any = null;
  private disposed=false;
  private ready = false;
  private pendingVideoId: string | null = null;
  private onTitleLoaded?: (title: string) => void;

  constructor(private container: string | HTMLElement, private events: YouTubePlayerEvents = {}) {}

  async init(): Promise<void> {
    await loadYouTubeAPI();
    if(this.disposed)return;

    const inline = typeof this.container !== "string";
    let el: HTMLElement | null;
    if (typeof this.container === "string") {
      el = document.getElementById(this.container);
    } else {
      el = document.createElement("div");
      this.container.appendChild(el);
    }
    if (!el) {
      el = document.createElement("div");
      el.id = this.container as string;
      el.style.position = "absolute";
      el.style.top = "-9999px";
      el.style.left = "-9999px";
      el.style.width = "1px";
      el.style.height = "1px";
      el.style.overflow = "hidden";
      document.body.appendChild(el);
    }

    return new Promise((resolve) => {
      this.player = new window.YT.Player(el, {
        height: inline ? "200" : "1",
        width: inline ? "100%" : "1",
        playerVars: inline ? {
          autoplay: 0,
          controls: 1,
          playsinline: 1,
          rel: 0,
          ...(location.origin === "null" ? {} : {origin: location.origin}),
        } : {
          autoplay: 0,
          controls: 0,
          disablekb: 1,
          fs: 0,
          modestbranding: 1,
          rel: 0,
        },
        events: {
          onReady: () => {
            if(this.disposed){resolve();return;}
            this.ready = true;
            if (this.pendingVideoId) {
              this.loadVideo(this.pendingVideoId);
              this.pendingVideoId = null;
            }
            resolve();
          },
          onStateChange: (event: any) => {
            if(this.disposed)return;
            // When video starts playing, grab the title
            if (event.data === window.YT.PlayerState.PLAYING) {
              this.events.onPlaying?.();
              const data = this.player?.getVideoData?.();
              if (data?.title && this.onTitleLoaded) {
                this.onTitleLoaded(data.title);
              }
            }
            // Auto-advance when track ends
            if (event.data === window.YT.PlayerState.ENDED) {
              this.onTrackEnded?.();
            }
          },
          onAutoplayBlocked: () => { if (!this.disposed) this.events.onAutoplayBlocked?.(); },
          onError: () => { if (!this.disposed) this.events.onError?.(); },
        },
      });
    });
  }

  private onTrackEnded?: () => void;
  setOnTrackEnded(cb: () => void) { this.onTrackEnded = cb; }

  setOnTitleLoaded(cb: (title: string) => void) { this.onTitleLoaded = cb; }

  loadVideo(youtubeId: string) {
    if (!this.ready) {
      this.pendingVideoId = youtubeId;
      return;
    }
    this.player?.loadVideoById(youtubeId);
  }

  cueVideo(youtubeId: string) {
    if (this.ready) this.player?.cueVideoById(youtubeId);
  }

  isPlaying(): boolean {
    return this.ready && this.player?.getPlayerState?.() === window.YT.PlayerState.PLAYING;
  }

  play() {
    if (!this.ready) return;
    this.player?.playVideo?.();
  }

  pause() {
    if (!this.ready) return;
    this.player?.pauseVideo?.();
  }

  setVolume(volume: number) {
    if (!this.ready) return;
    this.player?.setVolume?.(volume);
  }

  getTitle(): string {
    return this.player?.getVideoData?.()?.title || "";
  }

  destroy() {
    this.disposed=true;
    this.player?.destroy();
    this.player = null;
  }
}
