import {describe,it,expect,vi} from 'vitest';
import {CallManager,type CallDevices,type CallTransport} from '../CallManager';
function stream(){const audio={readyState:'live',enabled:true,stop:vi.fn(),addEventListener:vi.fn()},video={...audio,stop:vi.fn()};return{getTracks:()=>[audio,video],getAudioTracks:()=>[audio],getVideoTracks:()=>[video]} as unknown as MediaStream;}
function setup(getMedia=vi.fn(async()=>stream())){
 const transport:CallTransport={request:vi.fn(async(event:string)=>event==='call:config'?{iceServers:[],relayAvailable:false}:undefined) as any,signal:vi.fn(),id:()=> 'self',room:()=> 'room'},devices:CallDevices={getMedia,peer:vi.fn(),stream:()=>stream()},manager=new CallManager(transport,devices);manager.connection(true);return{manager,transport,devices,getMedia};
}
describe('call capture lifecycle',()=>{
 it('does not access devices when opening the panel or receiving an invitation',()=>{
  const {manager,getMedia}=setup();manager.open();manager.invitation({callId:'call',fromId:'other',fromName:'Other',expiresAt:100});expect(getMedia).not.toHaveBeenCalled();manager.close();expect(getMedia).not.toHaveBeenCalled();
 });
 it('stops late permission results when joining is cancelled',async()=>{
  let finish!:(value:MediaStream)=>void;const media=stream(),{manager,transport}=setup(vi.fn(()=>new Promise<MediaStream>(resolve=>finish=resolve)));const joining=manager.start('room',{audio:true,video:false});await Promise.resolve();manager.leave();finish(media);await joining;for(const track of media.getTracks())expect(track.stop).toHaveBeenCalled();expect(transport.request).not.toHaveBeenCalledWith('call:join-room',expect.anything());expect(manager.getSnapshot().local).toBeUndefined();
 });
 it('reports denied device access and sends no invitation',async()=>{
  const {manager,transport}=setup(vi.fn(async()=>{throw new DOMException('Denied','NotAllowedError');}));await manager.start('private',{audio:true,video:false},'other');expect(manager.getSnapshot().error).toContain('declined');expect(transport.request).not.toHaveBeenCalledWith('call:invite',expect.anything());expect(manager.getSnapshot().pending).toBe(false);
 });
 it('stops capture and cancels a late server acceptance after disconnect',async()=>{
  const media=stream(),{manager,transport}=setup(vi.fn(async()=>media));let finish!:(value:any)=>void;(transport.request as any).mockImplementation(async(event:string)=>event==='call:config'?{iceServers:[],relayAvailable:true}:event==='call:join-room'?new Promise(resolve=>finish=resolve):undefined);
  const joining=manager.start('room',{audio:true,video:true});await Promise.resolve();await Promise.resolve();await Promise.resolve();manager.connection(false);finish({id:'late',roomId:'room',kind:'room',invited:[],members:[{id:'self',name:'Self',audio:true,video:true}]});await joining;for(const track of media.getTracks())expect(track.stop).toHaveBeenCalled();expect(transport.request).toHaveBeenCalledWith('call:leave',{callId:'late'});expect(manager.getSnapshot().call).toBeUndefined();
 });
 it('answers with the offered transceivers so both media tracks are sent back',async()=>{
  const media=stream(),transceivers:any[]=[];const sender=()=>({replaceTrack:vi.fn(async()=>{})});
  const pc:any={localDescription:null,remoteDescription:null,connectionState:'new',close:vi.fn(),addTransceiver:vi.fn((kind:string)=>{const t={receiver:{track:{kind}},sender:sender(),direction:'sendrecv'};transceivers.push(t);return t;}),getTransceivers:()=>transceivers,setRemoteDescription:vi.fn(async(description:any)=>{pc.remoteDescription=description;for(const kind of ['audio','video'])transceivers.push({receiver:{track:{kind}},sender:sender(),direction:'recvonly'});}),createAnswer:vi.fn(async()=>({type:'answer',sdp:'v=0'})),setLocalDescription:vi.fn(async(description:any)=>{pc.localDescription=description;})};
  const {manager,transport,devices}=setup(vi.fn(async()=>media));devices.peer=()=>pc;(transport.request as any).mockImplementation(async(event:string)=>event==='call:config'?{iceServers:[],relayAvailable:true}:event==='call:join-room'?{id:'call',roomId:'room',kind:'room',invited:[],members:[{id:'self',name:'Self',audio:true,video:true},{id:'a',name:'A',audio:true,video:true}]}:undefined);
  await manager.start('room',{audio:true,video:true});expect(pc.addTransceiver).not.toHaveBeenCalled();manager.signal({callId:'call',to:'self',from:'a',description:{type:'offer',sdp:'v=0'}});await vi.waitFor(()=>expect(pc.localDescription?.type).toBe('answer'));expect(transceivers).toHaveLength(2);expect(transceivers.every(t=>t.direction==='sendrecv')).toBe(true);expect(transceivers[0].sender.replaceTrack).toHaveBeenCalledWith(media.getAudioTracks()[0]);expect(transceivers[1].sender.replaceTrack).toHaveBeenCalledWith(media.getVideoTracks()[0]);manager.destroy();
 });
 it('joins a broadcast as a viewer without requesting devices or creating peers to other viewers',async()=>{
  const {manager,transport,getMedia,devices}=setup();const pcs:any[]=[];devices.peer=()=>{const pc={close:vi.fn(),connectionState:'new'};pcs.push(pc);return pc as any;};
  const broadcast={id:'broadcast',roomId:'room',kind:'broadcast',presenterId:'host',invited:[],members:[{id:'host',name:'Host',audio:true,video:true},{id:'self',name:'Self',audio:false,video:false},{id:'viewer',name:'Viewer',audio:false,video:false}]};
  manager.roster({players:[],roomCount:0,broadcast:{callId:'broadcast',presenterId:'host',presenterName:'Host',audio:true,video:true,viewers:1}});
  (transport.request as any).mockImplementation(async(event:string)=>event==='call:config'?{iceServers:[],relayAvailable:true}:event==='call:watch-broadcast'?broadcast:undefined);
  await manager.start('watch',{audio:true,video:true});expect(getMedia).not.toHaveBeenCalled();expect(manager.getSnapshot().peers.map(p=>p.id)).toEqual(['host']);expect(manager.getSnapshot().local).toBeUndefined();await manager.toggle('audio');await manager.toggle('video');expect(getMedia).not.toHaveBeenCalled();manager.destroy();
 });
 it('allows a listener to join the room with no capture and add private invitations without new device access',async()=>{
  const {manager,transport,getMedia}=setup();(transport.request as any).mockImplementation(async(event:string)=>event==='call:config'?{iceServers:[],relayAvailable:true}:event==='call:invite'?{id:'private',roomId:'room',kind:'private',invited:[{id:'other',name:'Other',expiresAt:999}],members:[{id:'self',name:'Self',audio:false,video:false}]}:undefined);
  await manager.start('private',{audio:false,video:false},'other');await manager.addInvite('third');expect(getMedia).not.toHaveBeenCalled();expect(transport.request).toHaveBeenCalledWith('call:add-invite',{roomId:'room',callId:'private',to:'third'});manager.destroy();
 });
 it('does not retain capture if joining a full group fails',async()=>{
  const media=stream(),{manager,transport}=setup(vi.fn(async()=>media));(transport.request as any).mockImplementation(async(event:string)=>{if(event==='call:config')return{iceServers:[],relayAvailable:true};throw Error('The room call is full.');});await manager.start('room',{audio:true,video:true});for(const track of media.getTracks())expect(track.stop).toHaveBeenCalled();expect(manager.getSnapshot().error).toContain('full');
 });
});

function testTrack(kind:'audio'|'video',settings:MediaTrackSettings={}){
 const track={
  kind,readyState:'live',enabled:true,getSettings:()=>settings,
  stop:vi.fn(()=>{track.readyState='ended';}),addEventListener:vi.fn(),
 };
 return track as unknown as MediaStreamTrack;
}
function testStream(...initial:MediaStreamTrack[]){
 let tracks=initial;
 return {
  getTracks:()=>tracks.slice(),
  getAudioTracks:()=>tracks.filter(track=>track.kind==='audio'),
  getVideoTracks:()=>tracks.filter(track=>track.kind==='video'),
  addTrack:(track:MediaStreamTrack)=>{tracks.push(track);},
  removeTrack:(track:MediaStreamTrack)=>{tracks=tracks.filter(item=>item!==track);},
 } as unknown as MediaStream;
}
function cameraCall(getMedia:ReturnType<typeof vi.fn<()=>Promise<MediaStream>>>,withPeer=false){
 const call=setup(getMedia);
 vi.mocked(call.transport.request).mockImplementation(async(event:string)=>(event==='call:config'
  ?{iceServers:[]}
  :event==='call:join-room'
   ?{id:'call',roomId:'room',kind:'room',invited:[],members:[
      {id:'self',name:'Self',audio:true,video:true},
      ...(withPeer?[{id:'viewer',name:'Viewer',audio:false,video:false}]:[]),
    ]}
   :undefined) as any);
 call.devices.stream=()=>testStream();
 return call;
}

describe('switching the active camera',()=>{
 it('flips both ways and replaces only the video sender',async()=>{
  const mic=testTrack('audio'),front=testTrack('video',{deviceId:'front',facingMode:'user'});
  const rear=testTrack('video',{deviceId:'rear',facingMode:'environment'}),frontAgain=testTrack('video',{deviceId:'front',facingMode:'user'});
  const local=testStream(mic,front),getMedia=vi.fn<()=>Promise<MediaStream>>()
   .mockResolvedValueOnce(local).mockResolvedValueOnce(testStream(rear)).mockResolvedValueOnce(testStream(frontAgain));
  const {manager,devices}=cameraCall(getMedia,true);
  const audio={replaceTrack:vi.fn(async()=>{})},video={replaceTrack:vi.fn(async()=>{})};
  const pc={
   addTransceiver:(kind:string)=>({sender:kind==='audio'?audio:video}),
   createOffer:async()=>({type:'offer',sdp:'v=0'}),setLocalDescription:async()=>{},
   connectionState:'new',close:vi.fn(),
  };
  devices.peer=()=>pc as unknown as RTCPeerConnection;
  try{
   await manager.start('room',{audio:true,video:true});
   await manager.switchCamera();
   expect(getMedia).toHaveBeenNthCalledWith(2,{audio:false,video:expect.objectContaining({facingMode:{exact:'environment'}})});
   expect(video.replaceTrack).toHaveBeenLastCalledWith(rear);
   expect(local.getVideoTracks()).toEqual([rear]);
   await manager.switchCamera();
   expect(getMedia).toHaveBeenNthCalledWith(3,{audio:false,video:expect.objectContaining({facingMode:{exact:'user'}})});
   expect(video.replaceTrack).toHaveBeenLastCalledWith(frontAgain);
   expect(local.getVideoTracks()).toEqual([frontAgain]);
   expect(front.stop).toHaveBeenCalledOnce();
   expect(rear.stop).toHaveBeenCalledOnce();
   expect(audio.replaceTrack).toHaveBeenCalledExactlyOnceWith(mic);
   expect(mic.stop).not.toHaveBeenCalled();
   expect(manager.getSnapshot()).toMatchObject({video:true,audio:true,switchingCamera:false});
  }finally{manager.destroy();}
 });
 it('uses a different desktop device and restores the original camera on failure',async()=>{
  const mic=testTrack('audio'),camera=testTrack('video',{deviceId:'built-in'}),restored=testTrack('video',{deviceId:'built-in'});
  const local=testStream(mic,camera),getMedia=vi.fn<()=>Promise<MediaStream>>()
   .mockResolvedValueOnce(local).mockRejectedValueOnce(new DOMException('Unavailable','NotReadableError')).mockResolvedValueOnce(testStream(restored));
  const {manager,devices}=cameraCall(getMedia);
  devices.cameraIds=async()=>['built-in','usb'];
  try{
   await manager.start('room',{audio:true,video:true});
   await manager.switchCamera();
   expect(getMedia).toHaveBeenNthCalledWith(2,{audio:false,video:expect.objectContaining({deviceId:{exact:'usb'}})});
   expect(getMedia).toHaveBeenNthCalledWith(3,{audio:false,video:expect.objectContaining({deviceId:{exact:'built-in'}})});
   expect(local.getVideoTracks()).toEqual([restored]);
   expect(mic.stop).not.toHaveBeenCalled();
   expect(manager.getSnapshot()).toMatchObject({video:true,audio:true,switchingCamera:false,error:expect.stringContaining('previous camera')});
  }finally{manager.destroy();}
 });
 it('releases a camera that opens after leaving',async()=>{
  const front=testTrack('video',{deviceId:'front',facingMode:'user'}),rear=testTrack('video',{deviceId:'rear',facingMode:'environment'});
  let finish!:(stream:MediaStream)=>void;
  const getMedia=vi.fn<()=>Promise<MediaStream>>().mockResolvedValueOnce(testStream(front))
   .mockImplementationOnce(()=>new Promise(resolve=>finish=resolve));
  const {manager}=cameraCall(getMedia);
  await manager.start('room',{audio:false,video:true});
  const switching=manager.switchCamera();
  await vi.waitFor(()=>expect(getMedia).toHaveBeenCalledTimes(2));
  manager.leave();
  finish(testStream(rear));
  await switching;
  expect(rear.stop).toHaveBeenCalledOnce();
  expect(manager.getSnapshot()).toMatchObject({video:false,switchingCamera:false});
  expect(manager.getSnapshot().local).toBeUndefined();
 });
});
