import { CoworkingScene } from '../scenes/CoworkingScene';
import type {RoomDestination} from '@cocoworking/shared';
/** Small compatibility handle for the existing React interface. */
export function createGame(parent: HTMLElement, name: string, color: number, offline = false, onLogout?: () => void, publicStreet = false, onTravel?: (room: RoomDestination) => void) {
  const room = new CoworkingScene(parent, name, color, offline, onLogout, publicStreet, onTravel);
  return { scene: { getScene: (_key: string) => room }, destroy: (_remove?: boolean) => room.destroy() };
}
