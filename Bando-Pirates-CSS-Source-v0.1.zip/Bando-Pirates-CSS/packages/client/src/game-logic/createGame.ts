import { CoworkingScene } from '../scenes/CoworkingScene';
/** Small compatibility handle for the existing React interface. */
export function createGame(parent: HTMLElement, name: string, color: number) {
  const room = new CoworkingScene(parent, name, color);
  return { scene: { getScene: (_key: string) => room }, destroy: (_remove?: boolean) => room.destroy() };
}
