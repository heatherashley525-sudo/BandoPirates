import type {CollectibleAsset} from '@cocoworking/shared';
/** Public metadata snapshot, 8 November 2026. Images are fetched intact from their providers. */
export const SAMPLE_WALLET_ASSETS:readonly CollectibleAsset[]=[
  {
    "key": "1:0x8a1bbef259b00ced668a8c69e50d92619c672176:8599",
    "collection": "genesis",
    "chainId": 1,
    "contract": "0x8a1bbef259b00ced668a8c69e50d92619c672176",
    "tokenId": "8599",
    "name": "Habbo #8599",
    "image": "https://nft-tokens.habbo.com/avatars/images/8599.png",
    "kind": "avatar",
    "test": true,
    "figure": "hd-600-10.hr-3791-1402-58.he-4263.ch-3528-108-1423.cc-3373-107-108.wa-2003.lg-3078-110-108.sh-3275-1425-1338"
  },
  {
    "key": "1:0x8a1bbef259b00ced668a8c69e50d92619c672176:6254",
    "collection": "genesis",
    "chainId": 1,
    "contract": "0x8a1bbef259b00ced668a8c69e50d92619c672176",
    "tokenId": "6254",
    "name": "Habbo #6254",
    "image": "https://nft-tokens.habbo.com/avatars/images/6254.png",
    "kind": "avatar",
    "test": true,
    "figure": "hd-4206-1362.hr-3926-1406-50.ha-3129-98-1416.he-4264.ch-3636-1416-1339.lg-4066-99-98.sh-3089-1417-1416",
    "finish": "gold"
  },
  {
    "key": "1:0x8a1bbef259b00ced668a8c69e50d92619c672176:7925",
    "collection": "genesis",
    "chainId": 1,
    "contract": "0x8a1bbef259b00ced668a8c69e50d92619c672176",
    "tokenId": "7925",
    "name": "Habbo #7925",
    "image": "https://nft-tokens.habbo.com/avatars/images/7925.png",
    "kind": "avatar",
    "test": true,
    "figure": "hd-4205-1363.hr-3829-1347-55.ha-3765-1424-1338.he-4261.ea-3388-64-110.ch-3506-108-1423.lg-4066-110-108.sh-3089-1425-1338",
    "finish": "rainbow"
  },
  {
    "key": "13371:0x33976ee1477c75171b2b34814d75ebc37413e589:263312145226714",
    "collection": "furni",
    "chainId": 13371,
    "contract": "0x33976ee1477c75171b2b34814d75ebc37413e589",
    "tokenId": "263312145226714",
    "name": "Bronze Cornucopia",
    "image": "https://nft-tokens.habbo.com/collectibles/furni/images/nft_h26_cornucopia_bronze.png",
    "kind": "item",
    "test": true,
    "furniture": {
      "classname": "nft_h26_cornucopia_bronze",
      "revision": 75561,
      "width": 1,
      "depth": 1,
      "height": 2,
      "seat": false,
      "walkable": false,
      "stackable": false,
      "directions": [
        2,
        0
      ],
      "states": [
        0
      ]
    },
    "furnitureIcon": {
      "classname": "nft_h26_cornucopia_bronze",
      "revision": 75561
    }
  },
  {
    "key": "13371:0x33976ee1477c75171b2b34814d75ebc37413e589:25164204468141",
    "collection": "furni",
    "chainId": 13371,
    "contract": "0x33976ee1477c75171b2b34814d75ebc37413e589",
    "tokenId": "25164204468141",
    "name": "Silver Cornucopia",
    "image": "https://nft-tokens.habbo.com/collectibles/furni/images/nft_h26_cornucopia_silver.png",
    "kind": "item",
    "test": true,
    "furniture": {
      "classname": "nft_h26_cornucopia_silver",
      "revision": 75561,
      "width": 1,
      "depth": 1,
      "height": 2,
      "seat": false,
      "walkable": false,
      "stackable": false,
      "directions": [
        2,
        0
      ],
      "states": [
        0
      ]
    },
    "furnitureIcon": {
      "classname": "nft_h26_cornucopia_silver",
      "revision": 75561
    }
  },
  {
    "key": "13371:0x33976ee1477c75171b2b34814d75ebc37413e589:1162112101304",
    "collection": "furni",
    "chainId": 13371,
    "contract": "0x33976ee1477c75171b2b34814d75ebc37413e589",
    "tokenId": "1162112101304",
    "name": "Birthday Cake",
    "image": "https://nft-tokens.habbo.com/collectibles/furni/images/birthday/cake1.png",
    "kind": "item",
    "test": true,
    "furniture": {
      "classname": "nft_h22_bday_cake1",
      "revision": 70305,
      "width": 1,
      "depth": 1,
      "height": 2,
      "seat": false,
      "walkable": false,
      "stackable": false,
      "directions": [
        2
      ],
      "states": [
        0
      ]
    },
    "furnitureIcon": {
      "classname": "nft_h22_bday_cake1",
      "revision": 70305
    }
  },
  {
    "key": "13371:0x33976ee1477c75171b2b34814d75ebc37413e589:1652556013119",
    "collection": "furni",
    "chainId": 13371,
    "contract": "0x33976ee1477c75171b2b34814d75ebc37413e589",
    "tokenId": "1652556013119",
    "name": "Bigger Birthday Cake",
    "image": "https://nft-tokens.habbo.com/collectibles/furni/images/birthday/cake2.png",
    "kind": "item",
    "test": true,
    "furniture": {
      "classname": "nft_h22_bday_cake2",
      "revision": 70305,
      "width": 1,
      "depth": 1,
      "height": 2,
      "seat": false,
      "walkable": false,
      "stackable": false,
      "directions": [
        2
      ],
      "states": [
        0,
        1
      ]
    },
    "furnitureIcon": {
      "classname": "nft_h22_bday_cake2",
      "revision": 70305
    }
  },
  {
    "key": "13371:0x33976ee1477c75171b2b34814d75ebc37413e589:1604672467552",
    "collection": "furni",
    "chainId": 13371,
    "contract": "0x33976ee1477c75171b2b34814d75ebc37413e589",
    "tokenId": "1604672467552",
    "name": "Confetti Bomb",
    "image": "https://nft-tokens.habbo.com/collectibles/furni/images/birthday/confetti.gif",
    "kind": "item",
    "test": true,
    "furniture": {
      "classname": "nft_h22_bday_confetti",
      "revision": 70305,
      "width": 1,
      "depth": 1,
      "height": 2,
      "seat": false,
      "walkable": false,
      "stackable": false,
      "directions": [
        2
      ],
      "states": [
        0,
        1,
        100,
        101
      ]
    },
    "furnitureIcon": {
      "classname": "nft_h22_bday_confetti",
      "revision": 70305
    }
  },
  {
    "key": "13371:0x33976ee1477c75171b2b34814d75ebc37413e589:1466325430410",
    "collection": "furni",
    "chainId": 13371,
    "contract": "0x33976ee1477c75171b2b34814d75ebc37413e589",
    "tokenId": "1466325430410",
    "name": "Birthday Cake",
    "image": "https://nft-tokens.habbo.com/collectibles/furni/images/birthday/cake1.png",
    "kind": "item",
    "test": true,
    "furniture": {
      "classname": "nft_h22_bday_cake1",
      "revision": 70305,
      "width": 1,
      "depth": 1,
      "height": 2,
      "seat": false,
      "walkable": false,
      "stackable": false,
      "directions": [
        2
      ],
      "states": [
        0
      ]
    },
    "furnitureIcon": {
      "classname": "nft_h22_bday_cake1",
      "revision": 70305
    }
  },
  {
    "key": "13371:0x33976ee1477c75171b2b34814d75ebc37413e589:1542114146150",
    "collection": "furni",
    "chainId": 13371,
    "contract": "0x33976ee1477c75171b2b34814d75ebc37413e589",
    "tokenId": "1542114146150",
    "name": "Birthday Cake",
    "image": "https://nft-tokens.habbo.com/collectibles/furni/images/birthday/cake1.png",
    "kind": "item",
    "test": true,
    "furniture": {
      "classname": "nft_h22_bday_cake1",
      "revision": 70305,
      "width": 1,
      "depth": 1,
      "height": 2,
      "seat": false,
      "walkable": false,
      "stackable": false,
      "directions": [
        2
      ],
      "states": [
        0
      ]
    },
    "furnitureIcon": {
      "classname": "nft_h22_bday_cake1",
      "revision": 70305
    }
  },
  {
    "key": "13371:0x33976ee1477c75171b2b34814d75ebc37413e589:1485211406082",
    "collection": "furni",
    "chainId": 13371,
    "contract": "0x33976ee1477c75171b2b34814d75ebc37413e589",
    "tokenId": "1485211406082",
    "name": "Birthday Cake",
    "image": "https://nft-tokens.habbo.com/collectibles/furni/images/birthday/cake1.png",
    "kind": "item",
    "test": true,
    "furniture": {
      "classname": "nft_h22_bday_cake1",
      "revision": 70305,
      "width": 1,
      "depth": 1,
      "height": 2,
      "seat": false,
      "walkable": false,
      "stackable": false,
      "directions": [
        2
      ],
      "states": [
        0
      ]
    },
    "furnitureIcon": {
      "classname": "nft_h22_bday_cake1",
      "revision": 70305
    }
  },
  {
    "key": "13371:0x33976ee1477c75171b2b34814d75ebc37413e589:1164136246359",
    "collection": "furni",
    "chainId": 13371,
    "contract": "0x33976ee1477c75171b2b34814d75ebc37413e589",
    "tokenId": "1164136246359",
    "name": "Cool Cats Portrait",
    "image": "https://nft-tokens.habbo.com/collectibles/furni/images/coolcats/nft_c22_cc_framedposter.png",
    "kind": "item",
    "test": true,
    "furnitureIcon": {
      "classname": "nft_c22_cc_framedposter",
      "revision": 70305
    }
  },
  {
    "key": "13371:0x33976ee1477c75171b2b34814d75ebc37413e589:401725664118",
    "collection": "furni",
    "chainId": 13371,
    "contract": "0x33976ee1477c75171b2b34814d75ebc37413e589",
    "tokenId": "401725664118",
    "name": "Birthday Cake",
    "image": "https://nft-tokens.habbo.com/collectibles/furni/images/birthday/cake1.png",
    "kind": "item",
    "test": true,
    "furniture": {
      "classname": "nft_h22_bday_cake1",
      "revision": 70305,
      "width": 1,
      "depth": 1,
      "height": 2,
      "seat": false,
      "walkable": false,
      "stackable": false,
      "directions": [
        2
      ],
      "states": [
        0
      ]
    },
    "furnitureIcon": {
      "classname": "nft_h22_bday_cake1",
      "revision": 70305
    }
  },
  {
    "key": "13371:0x33976ee1477c75171b2b34814d75ebc37413e589:451604309328",
    "collection": "furni",
    "chainId": 13371,
    "contract": "0x33976ee1477c75171b2b34814d75ebc37413e589",
    "tokenId": "451604309328",
    "name": "Trippy Duck",
    "image": "https://nft-tokens.habbo.com/collectibles/furni/images/rug.png",
    "kind": "item",
    "test": true,
    "furnitureIcon": {
      "classname": "nft_h22_trippyduck",
      "revision": 70305
    }
  },
  {
    "key": "13371:0x33976ee1477c75171b2b34814d75ebc37413e589:49291233922",
    "collection": "furni",
    "chainId": 13371,
    "contract": "0x33976ee1477c75171b2b34814d75ebc37413e589",
    "tokenId": "49291233922",
    "name": "Bigger Birthday Cake",
    "image": "https://nft-tokens.habbo.com/collectibles/furni/images/birthday/cake2.png",
    "kind": "item",
    "test": true,
    "furniture": {
      "classname": "nft_h22_bday_cake2",
      "revision": 70305,
      "width": 1,
      "depth": 1,
      "height": 2,
      "seat": false,
      "walkable": false,
      "stackable": false,
      "directions": [
        2
      ],
      "states": [
        0,
        1
      ]
    },
    "furnitureIcon": {
      "classname": "nft_h22_bday_cake2",
      "revision": 70305
    }
  }
];
