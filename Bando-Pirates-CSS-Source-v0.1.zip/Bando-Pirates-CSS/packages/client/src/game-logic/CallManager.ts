import {callPeerIds,callDirection,type CallState,type CallInvite,type CallRoster,type CallSignal,type CallIceConfig,type CallMedia} from '@cocoworking/shared';
export interface CallTransport {request<T>(event:string,data:unknown):Promise<T>;signal(data:CallSignal):void;id():string|undefined;room():string|undefined}
interface Peer {pc:RTCPeerConnection;stream:MediaStream;audio?:RTCRtpSender;video?:RTCRtpSender;candidates:RTCIceCandidateInit[];queue:Promise<void>;status:string;timer?:ReturnType<typeof setTimeout>}
export interface CallView {open:boolean;connected:boolean;pending:boolean;error:string;notice:string;invite?:CallInvite;call?:CallState;local?:MediaStream;audio:boolean;video:boolean;roster:CallRoster;peers:{id:string;stream:MediaStream;status:string}[]}
export interface CallDevices {getMedia(constraints:MediaStreamConstraints):Promise<MediaStream>;peer(config:RTCConfiguration):RTCPeerConnection;stream():MediaStream}
const browserDevices:CallDevices={getMedia:constraints=>{if(!navigator.mediaDevices?.getUserMedia)throw Error('Calls need HTTPS and microphone/camera access in your browser.');return navigator.mediaDevices.getUserMedia(constraints);},peer:config=>new RTCPeerConnection(config),stream:()=>new MediaStream()};
const emptyRoster=():CallRoster=>({players:[],roomCount:0,broadcast:null});
/** Device capture is started only by Start/Join/Accept or an explicit media toggle. */
export class CallManager {
 private view:CallView={open:false,connected:false,pending:false,error:'',notice:'',audio:false,video:false,roster:emptyRoster(),peers:[]};private listeners=new Set<()=>void>();private peers=new Map<string,Peer>();private config:RTCConfiguration={iceServers:[]};private generation=0;private desired=false;private destroyed=false;private busyMedia=false;
 constructor(private transport:CallTransport,private devices:CallDevices=browserDevices){}
 getSnapshot=()=>this.view;
 subscribe=(fn:()=>void)=>{this.listeners.add(fn);return()=>{this.listeners.delete(fn);};};
 private update(change:Partial<CallView>={}){this.view={...this.view,...change,peers:[...this.peers].map(([id,p])=>({id,stream:p.stream,status:p.status}))};for(const fn of this.listeners)fn();}
 open(){this.update({open:true});}
 close(){void this.decline();this.leave();this.update({open:false});}
 connection(connected:boolean){if(!connected)this.reset('Connection lost. Join the call again after reconnecting.');this.update({connected});}
 roomChanged(){this.reset(this.view.call||this.view.invite?'The room changed.':'');this.update({roster:emptyRoster()});}
 roster(roster:CallRoster){this.update({roster});}
 invitation(invite:CallInvite){if(this.view.call||this.view.pending){void this.transport.request('call:decline',{roomId:this.transport.room(),callId:invite.callId}).catch(()=>{});return;}this.update({invite,open:true,error:'',notice:''});}
 clearInvite(id:string){if(this.view.invite?.callId===id)this.update({invite:undefined});}
 ended(data:{callId:string;reason:string}){if(this.view.call?.id===data.callId)this.reset(data.reason);}
 async decline(){const invite=this.view.invite;if(!invite)return;this.update({invite:undefined});await this.transport.request('call:decline',{roomId:this.transport.room(),callId:invite.callId}).catch(()=>{});}
 async start(kind:'private'|'room'|'accept'|'broadcast'|'watch',media:CallMedia,to?:string){
  if(this.view.pending||this.view.call)return;if(!this.view.connected||!this.transport.room()){this.update({error:'Join the hosted multiplayer game to use calls.'});return;}
  if(kind==='watch')media={audio:false,video:false};
  if(kind==='broadcast'&&!media.audio&&!media.video){this.update({error:'Choose a microphone or camera to broadcast.'});return;}
  const invite=this.view.invite,roomId=this.transport.room();if(kind==='accept'&&!invite)return;
  const generation=++this.generation;this.desired=true;this.update({pending:true,error:'',notice:''});
  let stream:MediaStream|undefined;
  try{
   const config=await this.transport.request<CallIceConfig>('call:config',{roomId});if(generation!==this.generation)return;this.config={iceServers:config.iceServers};
   if(media.audio||media.video)stream=await this.devices.getMedia({audio:media.audio,video:media.video?{width:{ideal:640},height:{ideal:480},frameRate:{ideal:15,max:24},facingMode:'user'}:false});
   if(generation!==this.generation){this.stop(stream);return;}
   if(stream&&!stream.getTracks().length)throw Error('No microphone or camera was available.');
   this.update({local:stream,audio:stream?.getAudioTracks().some(t=>t.readyState==='live')||false,video:stream?.getVideoTracks().some(t=>t.readyState==='live')||false});if(stream)this.watchTracks(stream);
   const event={private:'call:invite',room:'call:join-room',accept:'call:accept',broadcast:'call:start-broadcast',watch:'call:watch-broadcast'}[kind];
   const state=await this.transport.request<CallState>(event,{roomId,to,callId:kind==='watch'?this.view.roster.broadcast?.callId:invite?.callId,media:{audio:this.view.audio,video:this.view.video}});
   if(generation!==this.generation){void this.transport.request('call:leave',{callId:state.id}).catch(()=>{});return;}
   this.receiveState(state);this.update({pending:false,invite:undefined,notice:config.relayAvailable?'':'Direct connections enabled. Some networks may need a relay.'});
  }catch(error){if(generation!==this.generation){this.stop(stream);return;}this.leave();this.update({error:this.error(error)});}
 }
 async addInvite(to:string){
  const call=this.view.call;if(!call||call.kind!=='private'||this.view.pending)return;
  const generation=this.generation;this.update({pending:true,error:''});
  try{await this.transport.request('call:add-invite',{roomId:this.transport.room(),callId:call.id,to});}
  catch(error){if(generation===this.generation)this.update({error:this.error(error)});}
  finally{if(generation===this.generation)this.update({pending:false});}
 }
 receiveState(call:CallState){
  if(!this.desired||call.roomId!==this.transport.room()||!call.members.some(m=>m.id===this.transport.id())){void this.transport.request('call:leave',{callId:call.id}).catch(()=>{});return;}
  if(this.view.call&&this.view.call.id!==call.id)return;this.update({call});
  const ids=new Set(callPeerIds(call,this.transport.id()!));for(const id of this.peers.keys())if(!ids.has(id))this.removePeer(id);
  for(const id of ids)if(!this.peers.has(id))this.addPeer(id,call.id);
  this.update();
 }
 private addPeer(id:string,callId:string){
  try{
   const pc=this.devices.peer(this.config),call=this.view.call!,direction=callDirection(call,this.transport.id()!),offerer=call.kind==='broadcast'?this.transport.id()===call.presenterId:this.transport.id()!<id;
   // The answerer must use transceivers created by the remote offer. Pre-creating them
   // on both sides can leave the answer recvonly and lose its outgoing media.
   const audio=offerer?pc.addTransceiver('audio',{direction}).sender:undefined,video=offerer?pc.addTransceiver('video',{direction,sendEncodings:[{maxBitrate:450000,maxFramerate:24}]}).sender:undefined;
   const peer:Peer={pc,audio,video,stream:this.devices.stream(),candidates:[],queue:Promise.resolve(),status:'Connecting…'};this.peers.set(id,peer);peer.timer=setTimeout(()=>{if(this.peers.get(id)===peer&&pc.connectionState!=='connected'){peer.status='Unable to connect. Leave and rejoin; a different network or relay may help.';this.update();}},20000);
   pc.onicecandidate=event=>{if(event.candidate&&this.view.call?.id===callId)this.transport.signal({callId,to:id,candidate:event.candidate.toJSON() as CallSignal['candidate']});};
   pc.ontrack=event=>{if(!peer.stream.getTracks().some(t=>t.id===event.track.id))peer.stream.addTrack(event.track);this.update();};
   pc.onconnectionstatechange=()=>{if(pc.connectionState==='connected')clearTimeout(peer.timer);peer.status=pc.connectionState==='connected'?'Connected':pc.connectionState==='failed'?'Could not connect. Leave and rejoin to retry.':pc.connectionState==='disconnected'?'Reconnecting…':'Connecting…';this.update();};
   peer.queue=Promise.all([audio?.replaceTrack(this.view.local?.getAudioTracks()[0]||null),video?.replaceTrack(this.view.local?.getVideoTracks()[0]||null)]).then(async()=>{if(offerer){await pc.setLocalDescription(await pc.createOffer());if(this.peers.get(id)===peer&&pc.localDescription)this.transport.signal({callId,to:id,description:{type:'offer',sdp:pc.localDescription.sdp}});}}).catch(()=>{peer.status='Could not connect. Leave and rejoin to retry.';this.update();});
  }catch(error){this.update({error:this.error(error)});}
 }
 signal(signal:CallSignal){
  if(!signal.from||signal.callId!==this.view.call?.id)return;const peer=this.peers.get(signal.from);if(!peer)return;
  peer.queue=peer.queue.then(async()=>{
   if(this.peers.get(signal.from!)!==peer)return;
   if(signal.description){await peer.pc.setRemoteDescription(signal.description);for(const candidate of peer.candidates.splice(0))await peer.pc.addIceCandidate(candidate);if(signal.description.type==='offer'){for(const transceiver of peer.pc.getTransceivers()){const kind=transceiver.receiver.track.kind;if(kind!=='audio'&&kind!=='video')continue;transceiver.direction=callDirection(this.view.call!,this.transport.id()!);peer[kind]=transceiver.sender;await transceiver.sender.replaceTrack((kind==='audio'?this.view.local?.getAudioTracks()[0]:this.view.local?.getVideoTracks()[0])||null);}await peer.pc.setLocalDescription(await peer.pc.createAnswer());if(peer.pc.localDescription)this.transport.signal({callId:signal.callId,to:signal.from!,description:{type:'answer',sdp:peer.pc.localDescription.sdp}});}}
   else if(signal.candidate){if(peer.pc.remoteDescription)await peer.pc.addIceCandidate(signal.candidate);else if(peer.candidates.length<256)peer.candidates.push(signal.candidate);}
  }).catch(()=>{peer.status='Could not connect. Leave and rejoin to retry.';this.update();});
 }
 async toggle(kind:'audio'|'video'){
  if(!this.view.call||this.view.call.kind==='broadcast'&&this.view.call.presenterId!==this.transport.id()||this.busyMedia)return;this.busyMedia=true;const generation=this.generation;
  try{
   const stream=this.view.local||this.devices.stream();if(!this.view.local)this.update({local:stream});let track=(kind==='audio'?stream.getAudioTracks():stream.getVideoTracks())[0];
   if(this.view[kind]){if(kind==='audio'&&track)track.enabled=false;else if(track){stream.removeTrack(track);track.stop();await Promise.allSettled([...this.peers.values()].map(p=>p.video?.replaceTrack(null)));}if(generation!==this.generation)return;this.update({[kind]:false});}
   else{
    if(!track||track.readyState!=='live'){
     const captured=await this.devices.getMedia({audio:kind==='audio',video:kind==='video'?{width:{ideal:640},height:{ideal:480},frameRate:{ideal:15,max:24},facingMode:'user'}:false});
     if(generation!==this.generation){this.stop(captured);return;}track=kind==='audio'?captured.getAudioTracks()[0]:captured.getVideoTracks()[0];if(!track){this.stop(captured);throw Error('That device was not available.');}for(const other of captured.getTracks())if(other!==track)other.stop();for(const old of (kind==='audio'?stream.getAudioTracks():stream.getVideoTracks())){stream.removeTrack(old);old.stop();}stream.addTrack(track);this.watchTracks(captured);
    }
    track.enabled=true;this.update({[kind]:true});await Promise.all([...this.peers.values()].map(p=>p[kind]?.replaceTrack(track!)));if(generation!==this.generation)return;
   }
   await this.publishMedia();
  }catch(error){if(generation===this.generation){this.update({error:this.error(error)});void this.publishMedia().catch(()=>{});}}finally{this.busyMedia=false;}
 }
 private watchTracks(stream:MediaStream){for(const track of stream.getTracks())track.addEventListener('ended',()=>{if(!this.view.local?.getTracks().includes(track))return;this.update({audio:this.view.local.getAudioTracks().some(t=>t.readyState==='live'&&t.enabled),video:this.view.local.getVideoTracks().some(t=>t.readyState==='live'&&t.enabled)});void this.publishMedia().catch(()=>{});},{once:true});}
 private publishMedia(){return this.view.call?this.transport.request('call:media',{roomId:this.transport.room(),callId:this.view.call.id,media:{audio:this.view.audio,video:this.view.video}}):Promise.resolve();}
 leave(){const callId=this.view.call?.id;this.reset('');if(callId)void this.transport.request('call:leave',{callId}).catch(()=>{});}
 private removePeer(id:string){const peer=this.peers.get(id);if(!peer)return;clearTimeout(peer.timer);peer.pc.onicecandidate=null;peer.pc.ontrack=null;peer.pc.onconnectionstatechange=null;peer.pc.close();for(const track of peer.stream.getTracks())track.stop();this.peers.delete(id);}
 private stop(stream?:MediaStream){stream?.getTracks().forEach(track=>track.stop());}
 private reset(notice:string){++this.generation;this.desired=false;for(const id of this.peers.keys())this.removePeer(id);this.stop(this.view.local);this.update({call:undefined,invite:undefined,local:undefined,audio:false,video:false,pending:false,notice});}
 private error(error:unknown){if(error&&typeof error==='object'&&'name' in error&&error.name==='NotAllowedError')return 'Device access was declined. Check your browser permissions and try again.';if(error instanceof Error){if(error.name==='NotAllowedError')return 'Device access was declined. Check your browser permissions and try again.';if(error.name==='NotFoundError')return 'No matching microphone or camera was found.';return error.message;}return 'The call could not connect. Try again.';}
 destroy(){if(this.destroyed)return;this.destroyed=true;this.leave();this.listeners.clear();}
}
