import {PUBLIC_TEST_WALLET,collectionById,parseTokenId,type CollectibleAsset,type CollectiblePage,type WalletState} from '@cocoworking/shared';
import {SAMPLE_WALLET_ASSETS} from './sampleWalletData';
export const SAMPLE_WALLET_NOTICE='Saved sample, not a live inventory · 8 November 2026. Includes 3 Genesis avatars and the first 12 furniture items. Images need internet; other addresses and live inventory require multiplayer.';
/** A labelled, unsigned sample for file/content URLs. Never grants verified access. */
export class SampleWallet {
 private address:string|null=null;private expiresAt=0;
 constructor(private now=Date.now){}
 connect(raw:unknown):WalletState{
  if(typeof raw!=='string'||!/^0x[0-9a-f]{40}$/i.test(raw))throw Error('Enter a valid 0x wallet address.');
  if(raw.toLowerCase()!==PUBLIC_TEST_WALLET)throw Error('The downloaded HTML includes Heather’s sample wallet. Open the multiplayer game to test another address.');
  this.address=PUBLIC_TEST_WALLET;this.expiresAt=this.now()+3600000;return {address:this.address,expiresAt:this.expiresAt,mode:'test',message:SAMPLE_WALLET_NOTICE};
 }
 require(){if(!this.address||this.expiresAt<=this.now())throw Error('Load Heather’s sample wallet again.');}
 list(raw:unknown):CollectiblePage{this.require();const c=collectionById(raw);if(!c)throw Error('Choose a supported collection.');return {assets:SAMPLE_WALLET_ASSETS.filter(a=>a.collection===c.id).map(a=>structuredClone(a)),nextCursor:null};}
 asset(collection:unknown,tokenId:unknown):CollectibleAsset{this.require();const id=parseTokenId(tokenId),asset=SAMPLE_WALLET_ASSETS.find(a=>a.collection===collection&&a.tokenId===id);if(!asset)throw Error('This token is not in the saved sample. Use the multiplayer game for the full live wallet.');return structuredClone(asset);}
 prepare(collection:unknown,tokenId:unknown){const asset=this.asset(collection,tokenId);if(asset.collection!=='furni'||!asset.furniture)throw Error('This item has no native floor mapping in the saved sample. Try a Cornucopia, Birthday Cake or Confetti Bomb, or use the multiplayer game.');return asset;}
 disconnect(){this.address=null;this.expiresAt=0;}
}
