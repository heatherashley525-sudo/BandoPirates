import { sitPlayer,standPlayer,movePlayer,seatPlayersUnderFurniture,type Direction,defaultAppearance,saveAppearance,type AvatarAppearance,emptyWorld,registerPlayer,validateWorld,roomFurniture,inventoryFor,applyWorldCommand,findSpawn,type WorldData,type RoomInfo,type InventoryEntry,type FurnitureState,type RoomOwner,type Position,type Player,type ChatMessage,type DJState,type PomodoroState } from '@cocoworking/shared';
import { io,Socket } from 'socket.io-client';
import { getActiveProfile,updateProfile } from './playerProfiles';
export type NetworkEvents={
 onFurnitureState?:(furniture:FurnitureState[])=>void;onRoomOwner?:(owner:RoomOwner)=>void;
 onRoomInfo?:(room:RoomInfo|null)=>void;onInventory?:(items:InventoryEntry[])=>void;onIdentity?:(identity:{id:string;name:string})=>void;
 onWorldNotice?:(message:string)=>void;onFurnitureBlocked?:(message:string)=>void;onPlayerCorrect?:(pos:Position)=>void;
 onAppearance?:(id:string,appearance:AvatarAppearance)=>void;onAvatarSaved?:(appearance:AvatarAppearance)=>void;onAvatarBlocked?:(message:string)=>void;
 onPosture?:(player:Player)=>void;onPostureBlocked?:(message:string)=>void;
 onConnection?:(connected:boolean)=>void;onRoomState:(players:Record<string,Player>)=>void;
 onPlayerJoin:(player:Player)=>void;onPlayerLeave:(id:string)=>void;onPlayerMove:(id:string,x:number,y:number,direction?:Direction)=>void;
 onChat:(message:ChatMessage)=>void;onPeerId?:(id:string,peerId:string)=>void;onDJState?:(state:DJState)=>void;
 onPomodoroUpdate?:(state:PomodoroState)=>void;onPomodoroEnd?:()=>void;
};
const OFFLINE_KEY='heather-hotel-owned-world-v1';
export class NetworkManager {
 private socket?:Socket;private offline?:{world:WorldData;player:Player};private timer?:ReturnType<typeof setTimeout>;
 private userId?:string;private roomId?:string;private profileId?:string;
 constructor(serverUrl:string,playerName:string,private events:NetworkEvents,offline=false,initialAppearance:AvatarAppearance=defaultAppearance()){
  if(offline){
   let world=emptyWorld();let notice='';
   try{const saved=localStorage.getItem(OFFLINE_KEY);if(saved)world=validateWorld(JSON.parse(saved));}catch{notice='The saved local preview could not be loaded.';}
   world=registerPlayer(world,'offline-player',playerName);this.userId='offline-player';
   this.offline={world,player:{id:'local-preview',name:playerName,position:findSpawn(roomFurniture(world)),direction:'south',appearance:world.profiles['offline-player'].appearance||initialAppearance}};
   this.timer=setTimeout(()=>{
    if(!this.offline)return;
    this.events.onIdentity?.({id:this.userId!,name:playerName});this.events.onConnection?.(true);
    this.events.onRoomState({'local-preview':this.offline.player});this.publishOffline();if(notice)this.events.onWorldNotice?.(notice);
   },0);return;
  }
  const profile=getActiveProfile();this.profileId=profile.localId;
  this.socket=io(serverUrl,{query:{name:playerName,color:initialAppearance.topColor},auth:{token:profile.token}});
  this.socket.on('connect',()=>this.events.onConnection?.(true));
  this.socket.on('disconnect',()=>this.events.onConnection?.(false));
  this.socket.on('connect_error',()=>this.events.onConnection?.(false));
  this.socket.on('identity:state',(identity:{id:string;name:string;token:string})=>{
   this.userId=identity.id;
   updateProfile(this.profileId!,{userId:identity.id,token:identity.token,name:identity.name});
   if(this.socket)this.socket.auth={token:identity.token};
   this.events.onIdentity?.({id:identity.id,name:identity.name});
  });
  this.socket.on('identity:error',(message:string)=>this.events.onFurnitureBlocked?.(message));
  this.socket.on('room:info',(room:RoomInfo|null)=>{this.roomId=room?.id;this.events.onRoomInfo?.(room);});
  this.socket.on('room:owner',(owner:RoomOwner)=>this.events.onRoomOwner?.(owner));
  this.socket.on('inventory:state',(items:InventoryEntry[])=>this.events.onInventory?.(items));
  this.socket.on('furniture:state',(items:FurnitureState[])=>this.events.onFurnitureState?.(items));
  this.socket.on('furniture:blocked',(message:string)=>this.events.onFurnitureBlocked?.(message));
  this.socket.on('world:notice',(message:string)=>this.events.onWorldNotice?.(message));
  this.socket.on('player:correct',(pos:Position)=>this.events.onPlayerCorrect?.(pos));
  this.socket.on('player:posture',(player:Player)=>this.events.onPosture?.(player));this.socket.on('player:posture-blocked',(message:string)=>this.events.onPostureBlocked?.(message));
  this.socket.on('room:state',(players:Record<string,Player>)=>this.events.onRoomState(players));
  this.socket.on('player:join',(player:Player)=>this.events.onPlayerJoin(player));
  this.socket.on('player:leave',(id:string)=>this.events.onPlayerLeave(id));
  this.socket.on('player:move',(data:{id:string;x:number;y:number;direction?:Direction})=>{if(data.id!==this.socket?.id)this.events.onPlayerMove(data.id,data.x,data.y,data.direction);});
  this.socket.on('player:appearance',(data:{id:string;appearance:AvatarAppearance})=>this.events.onAppearance?.(data.id,data.appearance));
  this.socket.on('avatar:saved',(appearance:AvatarAppearance)=>this.events.onAvatarSaved?.(appearance));
  this.socket.on('avatar:blocked',(message:string)=>this.events.onAvatarBlocked?.(message));
  this.socket.on('chat:message',(message:ChatMessage)=>this.events.onChat(message));
  this.socket.on('peer:id',(data:{playerId:string;peerId:string})=>this.events.onPeerId?.(data.playerId,data.peerId));
  this.socket.on('dj:state',(state:DJState)=>this.events.onDJState?.(state));
  this.socket.on('pomodoro:update',(state:PomodoroState)=>this.events.onPomodoroUpdate?.(state));
  this.socket.on('pomodoro:end',()=>this.events.onPomodoroEnd?.());
 }
 private publishOffline(){
  if(!this.offline)return;const world=this.offline.world;this.roomId=world.room?.id;
  this.events.onRoomInfo?.(world.room);this.events.onRoomOwner?.(world.room?{id:world.room.ownerId,name:world.room.ownerName}:{id:null,name:null});
  this.events.onFurnitureState?.(roomFurniture(world));this.events.onInventory?.(inventoryFor(world,this.userId!));
 }
 private emit(event:string,data?:any){
  if(!this.offline){this.socket?.emit(event,data);return;}
  const state=this.offline;
  const actions:Record<string,string>={'furniture:rotate':'rotate','furniture:move':'move','furniture:place':'place','furniture:pickup':'pickup','room:delete':'delete-room','room:create':'create-room'};
  if(event==='player:sit'||event==='player:stand'){
   if(!state.world.room||data?.roomId!==state.world.room.id){this.events.onPostureBlocked?.('This room is no longer open.');return;}
   const result=event==='player:sit'?sitPlayer(state.player,data.id,data.index,roomFurniture(state.world),[state.player]):standPlayer(state.player,roomFurniture(state.world));
   if(!result.ok){this.events.onPostureBlocked?.(result.error);return;}state.player=result.player;this.events.onPosture?.(result.player);
  }else if(event==='avatar:save'){
   const result=saveAppearance(state.world,this.userId!,data);
   if(!result.ok){this.events.onAvatarBlocked?.(result.error);return;}
   try{localStorage.setItem(OFFLINE_KEY,JSON.stringify(result.world));}catch{this.events.onAvatarBlocked?.('Could not save this look. Your previous avatar is unchanged.');return;}
   state.world=result.world;state.player.appearance=result.appearance;this.events.onAppearance?.(state.player.id,result.appearance);this.events.onAvatarSaved?.(result.appearance);
  }else if(actions[event]){
   const type=actions[event],request={...data,type,...(type==='create-room'?{newRoomId:crypto.randomUUID()}: {})};
   const result=applyWorldCommand(state.world,this.userId!,request,[state.player.position]);
   if(!result.ok){this.events.onFurnitureBlocked?.(result.error);return;}
   try{localStorage.setItem(OFFLINE_KEY,JSON.stringify(result.world));}catch{this.events.onFurnitureBlocked?.('Could not save this change. Nothing was changed.');return;}
   state.world=result.world;if(type==='create-room'||type==='delete-room'){state.player.position=findSpawn(roomFurniture(state.world));delete state.player.seat;this.events.onRoomState({[state.player.id]:state.player});}this.publishOffline();
   if(type==='move'||type==='place'||type==='rotate'){const player=seatPlayersUnderFurniture([state.player],roomFurniture(state.world))[0];if(player!==state.player){state.player=player;this.events.onPosture?.(player);}}
   if(type==='delete-room')this.events.onWorldNotice?.('Room deleted. All furniture has been returned to its owners’ inventories.');
   else if(type==='pickup')this.events.onWorldNotice?.('Furniture returned to its owner’s inventory.');
  }else if(event==='player:move'){
   if(!state.world.room)return;const result=movePlayer(state.player,{x:data.x,y:data.y},roomFurniture(state.world),[state.player]);
   if(!result.ok){this.events.onPlayerCorrect?.(state.player.position);this.events.onPosture?.(state.player);return;}
   state.player=result.player;if(result.player.seat)this.events.onPosture?.(result.player);
  }else if(event==='chat:send'&&state.world.room)this.events.onChat({id:`local-${Date.now()}`,playerId:state.player.id,playerName:state.player.name,content:data.content,timestamp:Date.now()});
 }
 saveAvatar(appearance:AvatarAppearance){this.emit('avatar:save',appearance);}
 sit(id:string,index:number){this.emit('player:sit',{id,index,roomId:this.roomId});}stand(){this.emit('player:stand',{roomId:this.roomId});}
 rotateFurniture(id:string){this.emit('furniture:rotate',{id,roomId:this.roomId});}
 moveFurniture(id:string,gx:number,gy:number){this.emit('furniture:move',{id,gx,gy,roomId:this.roomId});}
 placeFurniture(id:string,gx:number,gy:number){this.emit('furniture:place',{id,gx,gy,roomId:this.roomId});}
 pickUpFurniture(id:string){this.emit('furniture:pickup',{id,roomId:this.roomId});}
 deleteRoom(){this.emit('room:delete',{roomId:this.roomId});}
 createRoom(){this.emit('room:create');}
 sendMove(x:number,y:number,direction?:string){this.emit('player:move',{x,y,direction});}
 sendChat(content:string){this.emit('chat:send',{content});}
 sendPeerId(peerId:string){this.emit('peer:id',{peerId});}
 claimDJ(){this.emit('dj:claim');}releaseDJ(){this.emit('dj:release');}djPlay(){this.emit('dj:play');}djPause(){this.emit('dj:pause');}
 djNext(){this.emit('dj:next');}djPrev(){this.emit('dj:prev');}djVolume(volume:number){this.emit('dj:volume',{volume});}
 djAddTrack(url:string){this.emit('dj:addtrack',{url});}djUpdateTitle(youtubeId:string,title:string){this.emit('dj:updatetitle',{youtubeId,title});}
 startPomodoro(preset:'default'|'long'='default'){this.emit('pomodoro:start',{preset});}stopPomodoro(){this.emit('pomodoro:stop');}
 getSocketId(){return this.offline?this.offline.player.id:this.socket?.id;}getUserId(){return this.userId;}
 disconnect(){clearTimeout(this.timer);this.offline=undefined;this.socket?.disconnect();}
}
