import {CallManager} from './CallManager';
import { sitPlayer,standPlayer,movePlayer,seatPlayersUnderFurniture,type Direction,defaultAppearance,saveAppearance,type AvatarAppearance,emptyWorld,registerPlayer,validateWorld,roomFurniture,inventoryFor,applyWorldCommand,findSpawn,type WorldData,type RoomInfo,type InventoryEntry,type FurnitureState,type RoomOwner,type Position,type Player,type ChatMessage,type DJState } from '@cocoworking/shared';
import { io,Socket } from 'socket.io-client';
import { getActiveProfile,updateProfile } from './playerProfiles';
import type {CollectibleAsset,WalletState,WalletReply} from '@cocoworking/shared';
import {editFurniture,floorTile,furnitureTiles,placementError,resolvePlacement,supportEditError,tileOverlaps} from '@cocoworking/shared';
import {SampleWallet} from './SampleWallet';
import {parseHabboFigure} from '@cocoworking/shared';
import {PUBLIC_STREET,PUBLIC_STREET_FLOOR,PUBLIC_STREET_SPAWN,listAvailableRooms,type RoomDirectoryEntry} from '@cocoworking/shared';
export type NetworkEvents={
 onWalletState?:(state:WalletState)=>void;onCollectibleAvatar?:(id:string,asset:CollectibleAsset|null)=>void;
 onFurnitureState?:(furniture:FurnitureState[])=>void;onRoomOwner?:(owner:RoomOwner)=>void;
 onRoomInfo?:(room:RoomInfo|null)=>void;onInventory?:(items:InventoryEntry[])=>void;onIdentity?:(identity:{id:string;name:string})=>void;
 onRoomDirectory?:(rooms:RoomDirectoryEntry[])=>void;
 onWorldNotice?:(message:string)=>void;onFurnitureBlocked?:(message:string)=>void;onPlayerCorrect?:(pos:Position)=>void;
 onAppearance?:(id:string,appearance:AvatarAppearance)=>void;onAvatarSaved?:(appearance:AvatarAppearance)=>void;onAvatarBlocked?:(message:string)=>void;
 onPosture?:(player:Player)=>void;onPostureBlocked?:(message:string)=>void;
 onConnection?:(connected:boolean)=>void;onRoomState:(players:Record<string,Player>)=>void;
 onPlayerJoin:(player:Player)=>void;onPlayerLeave:(id:string)=>void;onPlayerMove:(id:string,x:number,y:number,direction?:Direction)=>void;
 onChat:(message:ChatMessage)=>void;onDJState?:(state:DJState)=>void;
};
const OFFLINE_KEY='heather-hotel-owned-world-v1';
let offlineWorldWithoutStorage:WorldData|undefined;
export class NetworkManager {
 private socket?:Socket;private offline?:{world:WorldData;player:Player};private timer?:ReturnType<typeof setTimeout>;
 private calls:CallManager;
 private sampleWallet=new SampleWallet();private sampleFurniture:FurnitureState[]=[];private sampleExpiry?:ReturnType<typeof setTimeout>;
 private chatSequence=0;private userId?:string;private roomId?:string;private profileId?:string;
 constructor(serverUrl:string,playerName:string,private events:NetworkEvents,offline=false,initialAppearance:AvatarAppearance=defaultAppearance(),private publicStreet=false){
  this.calls=new CallManager({request:<T>(event:string,data:unknown)=>new Promise<T>((resolve,reject)=>{if(!this.socket?.connected){reject(Error('Join the hosted multiplayer game to use calls.'));return;}this.socket.timeout(12000).emit(event,data,(error:Error|null,reply:any)=>{if(error||!reply?.ok)reject(Error(reply?.error||'The call request timed out. Try again.'));else resolve(reply.value);});}),signal:data=>this.socket?.emit('call:signal',data),id:()=>this.getSocketId(),room:()=>this.roomId});
  if(offline){
   let world=offlineWorldWithoutStorage??emptyWorld();let notice='';
   if(!offlineWorldWithoutStorage)try{const saved=localStorage.getItem(OFFLINE_KEY);if(saved)world=validateWorld(JSON.parse(saved));}catch{notice='The saved local preview could not be loaded.';}
   world=registerPlayer(world,'offline-player',playerName,!publicStreet);this.userId='offline-player';
   try{localStorage.setItem(OFFLINE_KEY,JSON.stringify(world));offlineWorldWithoutStorage=undefined;}catch{offlineWorldWithoutStorage=world;}
   const position=publicStreet?{...PUBLIC_STREET_SPAWN}:findSpawn(roomFurniture(world),world.room?.tileSplits);
   this.offline={world,player:{id:'local-preview',name:playerName,position,direction:'south',appearance:world.profiles['offline-player'].appearance||initialAppearance}};
   this.timer=setTimeout(()=>{
    if(!this.offline)return;
    this.events.onIdentity?.({id:this.userId!,name:playerName});this.events.onConnection?.(true);
    this.events.onRoomState({'local-preview':this.offline.player});this.publishOffline();if(notice)this.events.onWorldNotice?.(notice);
   },0);return;
  }
  const profile=getActiveProfile();this.profileId=profile.localId;
  const endpoint=publicStreet?new URL('/'+PUBLIC_STREET.id,serverUrl).href:serverUrl;
  this.socket=io(endpoint,{query:{name:playerName,color:initialAppearance.topColor},auth:{token:profile.token}});
  this.socket.on('connect',()=>{this.calls.connection(true);this.events.onConnection?.(true);});
  this.socket.on('disconnect',()=>{this.calls.connection(false);this.events.onWalletState?.({address:null,message:'Disconnected. Reconnect your wallet after joining again.'});this.events.onConnection?.(false);});
  this.socket.on('connect_error',()=>this.events.onConnection?.(false));
  this.socket.on('identity:state',(identity:{id:string;name:string;token:string})=>{
   this.userId=identity.id;
   updateProfile(this.profileId!,{userId:identity.id,token:identity.token,name:identity.name});
   if(this.socket)this.socket.auth={token:identity.token};
   this.events.onIdentity?.({id:identity.id,name:identity.name});
  });
  this.socket.on('identity:error',(message:string)=>this.events.onFurnitureBlocked?.(message));
  this.socket.on('room:info',(room:RoomInfo|null)=>{if(this.roomId!==room?.id)this.calls.roomChanged();this.roomId=room?.id;this.events.onRoomInfo?.(room);});
  this.socket.on('room:directory',(rooms:RoomDirectoryEntry[])=>this.events.onRoomDirectory?.(rooms));
  this.socket.on('room:owner',(owner:RoomOwner)=>this.events.onRoomOwner?.(owner));
  this.socket.on('inventory:state',(items:InventoryEntry[])=>this.events.onInventory?.(items));
  this.socket.on('furniture:state',(items:FurnitureState[])=>this.events.onFurnitureState?.(items));
  this.socket.on('furniture:blocked',(message:string)=>this.events.onFurnitureBlocked?.(message));
  this.socket.on('world:notice',(message:string)=>this.events.onWorldNotice?.(message));
  this.socket.on('player:correct',(pos:Position)=>this.events.onPlayerCorrect?.(pos));
  this.socket.on('player:posture',(player:Player)=>this.events.onPosture?.(player));this.socket.on('player:posture-blocked',(message:string)=>this.events.onPostureBlocked?.(message));
  this.socket.on('room:state',(players:Record<string,Player>)=>this.events.onRoomState(players));
  this.socket.on('player:join',(player:Player)=>this.events.onPlayerJoin(player));
  this.socket.on('player:leave',(id:string)=>this.events.onPlayerLeave(id));
  this.socket.on('player:move',(data:{id:string;x:number;y:number;direction?:Direction})=>{if(data.id!==this.socket?.id)this.events.onPlayerMove(data.id,data.x,data.y,data.direction);});
  this.socket.on('player:appearance',(data:{id:string;appearance:AvatarAppearance})=>this.events.onAppearance?.(data.id,data.appearance));
  this.socket.on('wallet:state',(state:WalletState)=>this.events.onWalletState?.(state));
  this.socket.on('player:collectible-avatar',(data:{id:string;asset:CollectibleAsset|null})=>this.events.onCollectibleAvatar?.(data.id,data.asset));
  this.socket.on('avatar:saved',(appearance:AvatarAppearance)=>this.events.onAvatarSaved?.(appearance));
  this.socket.on('avatar:blocked',(message:string)=>this.events.onAvatarBlocked?.(message));
  this.socket.on('chat:message',(message:ChatMessage)=>this.events.onChat(message));
  this.socket.on('call:roster',data=>this.calls.roster(data));
  this.socket.on('call:state',data=>this.calls.receiveState(data));
  this.socket.on('call:invite',data=>this.calls.invitation(data));
  this.socket.on('call:invite-clear',id=>this.calls.clearInvite(id));
  this.socket.on('call:ended',data=>this.calls.ended(data));
  this.socket.on('call:signal',data=>this.calls.signal(data));
  this.socket.on('dj:state',(state:DJState)=>this.events.onDJState?.(state));
 }
 private get offlineRoom(){return this.publicStreet?PUBLIC_STREET:this.offline?.world.room??null;}
 private publishOffline(){
  if(!this.offline)return;const world=this.offline.world,room=this.offlineRoom;this.roomId=room?.id;
  this.events.onRoomInfo?.(room);this.events.onRoomOwner?.(room?.ownerId?{id:room.ownerId,name:room.ownerName}:{id:null,name:null});
  this.events.onRoomDirectory?.(listAvailableRooms(world.room));
  this.events.onFurnitureState?.(this.offlineFurniture());this.events.onInventory?.(inventoryFor(world,this.userId!));
 }
 private offlineFurniture(){return this.offline&&!this.publicStreet?[...roomFurniture(this.offline.world),...this.sampleFurniture]:[];}
 private clearSampleUsage(){
  const state=this.offline;if(!state)return;const ids=new Set(this.sampleFurniture.map(i=>i.id));this.sampleFurniture=[];delete state.player.collectibleAvatar;this.events.onCollectibleAvatar?.(state.player.id,null);
  if(state.player.seat&&ids.has(state.player.seat.furnitureId)){delete state.player.seat;state.player.position=findSpawn(this.offlineFurniture(),state.world.room?.tileSplits);this.events.onPosture?.(state.player);}this.publishOffline();
 }
 private editSampleFurniture(event:string,data:any){
  const state=this.offline!,item=this.sampleFurniture.find(i=>i.id===data?.id);if(!item)throw Error('Choose a placed sample item.');
  if(event==='furniture:pickup'){
   const error=supportEditError(item,this.offlineFurniture(),[state.player.position]);if(error)throw Error(error);this.sampleFurniture=this.sampleFurniture.filter(i=>i.id!==item.id);
  }else if(event==='furniture:state-change'){
   const states=item.nft!.definition.states,itemIndex=states.indexOf(item.state??states[0]);this.sampleFurniture=this.sampleFurniture.map(i=>i.id===item.id?{...i,state:states[(itemIndex+1)%states.length]}:i);
  }else if(event==='furniture:move'||event==='furniture:rotate'){
   const request=event==='furniture:rotate'?{action:'rotate' as const,id:item.id}:{action:'move' as const,id:item.id,gx:data.gx,gy:data.gy};
   const result=editFurniture(this.offlineFurniture(),request,this.userId!,state.world.room?.ownerId||null,[state.player.position],state.world.room?.tileSplits);if(!result.ok)throw Error(result.error);this.sampleFurniture=result.furniture.filter(i=>!!i.nft);
  }else throw Error('Choose a valid sample furniture action.');this.publishOffline();
 }
 private offlineWalletRequest(event:string,data:any):unknown{
  const state=this.offline!;
  if(event==='wallet:disconnect'){clearTimeout(this.sampleExpiry);this.sampleWallet.disconnect();this.clearSampleUsage();this.events.onWalletState?.({address:null});return null;}
  if(event==='wallet:test'){
   const wallet=this.sampleWallet.connect(data?.address);clearTimeout(this.sampleExpiry);this.clearSampleUsage();this.sampleExpiry=setTimeout(()=>{this.sampleWallet.disconnect();this.clearSampleUsage();this.events.onWalletState?.({address:null,message:'Sample session expired. Load Heather’s wallet again.'});},3600000);this.events.onWalletState?.(wallet);return wallet;
  }
  if(event==='wallet:list')return this.sampleWallet.list(data?.collection);
  if(event==='wallet:lookup')return this.sampleWallet.asset(data?.collection,data?.tokenId);
  if(event==='wallet:unwear'){this.sampleWallet.require();delete state.player.collectibleAvatar;this.events.onCollectibleAvatar?.(state.player.id,null);return null;}
  if(event==='wallet:wear'){
   const asset=this.sampleWallet.asset(data?.collection,data?.tokenId);
   if(asset.kind!=='avatar'||!parseHabboFigure(asset.figure))throw Error('Select a collectible with a wearable Habbo figure.');
   state.player.collectibleAvatar=asset;this.events.onCollectibleAvatar?.(state.player.id,asset);return asset;
  }
  if(event==='wallet:prepare')return this.sampleWallet.prepare(data?.collection,data?.tokenId);
  if(event==='wallet:place'){
   if(this.publicStreet)throw Error('Furniture placement is available in the player room.');
   const asset=this.sampleWallet.prepare(data?.collection,data?.tokenId),room=state.world.room;if(!room)throw Error('Create a room first.');
   if(!Number.isFinite(data?.gx)||!Number.isFinite(data?.gy))throw Error('Choose a floor tile.');const id='sample:'+asset.key;if(this.sampleFurniture.some(i=>i.id===id))throw Error('This sample item is already placed. Move or pick it up.');
   const layout=this.offlineFurniture(),item=resolvePlacement({id,kind:'habbo-nft',ownerId:this.userId!,ownerName:state.player.name,gx:data.gx,gy:data.gy,rotation:0,nft:{asset,definition:asset.furniture!},state:asset.furniture!.states[0]},data.gx,data.gy,layout,room.tileSplits);
   const error=placementError(item,layout,[state.player.position],room.tileSplits);if(error)throw Error(error);this.sampleFurniture.push(item);this.publishOffline();const player=seatPlayersUnderFurniture([state.player],this.offlineFurniture(),room.tileSplits)[0];if(player!==state.player){state.player=player;this.events.onPosture?.(player);}return item;
  }
  if(event==='wallet:pickup'){this.sampleWallet.require();const asset=this.sampleWallet.asset(data?.collection,data?.tokenId);this.editSampleFurniture('furniture:pickup',{id:'sample:'+asset.key});return null;}
  throw Error('MetaMask verification requires the multiplayer game. The local HTML supports the unsigned sample wallet.');
 }
 private emit(event:string,data?:any){
  if(!this.offline){this.socket?.emit(event,data);return;}
  const state=this.offline;
  if(event.startsWith('furniture:')&&this.sampleFurniture.some(i=>i.id===data?.id)){try{this.editSampleFurniture(event,data);}catch(error){this.events.onFurnitureBlocked?.((error as Error).message);}return;}
  const actions:Record<string,string>={'furniture:rotate':'rotate','furniture:move':'move','furniture:place':'place','furniture:pickup':'pickup','room:delete':'delete-room','room:create':'create-room','room:split-tile':'split-tile'};
  if(event==='player:sit'||event==='player:stand'){
   const room=this.offlineRoom;
   if(!room||data?.roomId!==room.id){this.events.onPostureBlocked?.('This room is no longer open.');return;}
   const result=event==='player:sit'?sitPlayer(state.player,data.id,data.index,this.offlineFurniture(),[state.player],room.tileSplits):standPlayer(state.player,this.offlineFurniture(),room.tileSplits,data?.to);
   if(!result.ok){this.events.onPostureBlocked?.(result.error);return;}state.player=result.player;this.events.onPosture?.(result.player);
  }else if(event==='avatar:save'){
   const result=saveAppearance(state.world,this.userId!,data);
   if(!result.ok){this.events.onAvatarBlocked?.(result.error);return;}
   try{localStorage.setItem(OFFLINE_KEY,JSON.stringify(result.world));offlineWorldWithoutStorage=undefined;}
   catch{
    if(!offlineWorldWithoutStorage){this.events.onAvatarBlocked?.('Could not save this look. Your previous avatar is unchanged.');return;}
    offlineWorldWithoutStorage=result.world;
   }
   state.world=result.world;state.player.appearance=result.appearance;this.events.onAppearance?.(state.player.id,result.appearance);
   if(state.player.collectibleAvatar){delete state.player.collectibleAvatar;this.events.onCollectibleAvatar?.(state.player.id,null);}
   this.events.onAvatarSaved?.(result.appearance);
  }else if(actions[event]){
   if(this.publicStreet){this.events.onFurnitureBlocked?.('Public Street has a shared, fixed layout.');return;}
   const type=actions[event],request={...data,type,...(type==='create-room'?{newRoomId:crypto.randomUUID()}: {})};
   if(type==='split-tile'){const tile=floorTile(data.tileId,state.world.room?.tileSplits);if(tile&&this.sampleFurniture.some(item=>furnitureTiles(item).some(p=>tileOverlaps(tile,tile.size,p,item.scale??1)))){this.events.onFurnitureBlocked?.('Clear the furniture from this tile before dividing it.');return;}}
   if(['move','rotate','pickup'].includes(type)){const item=this.offlineFurniture().find(i=>i.id===data.id),error=item&&supportEditError(item,this.offlineFurniture(),[state.player.position]);if(error){this.events.onFurnitureBlocked?.(error);return;}}
   const result=applyWorldCommand(state.world,this.userId!,request,[state.player.position]);
   if(!result.ok){this.events.onFurnitureBlocked?.(result.error);return;}
   if(['move','rotate','place'].includes(type)){const layout=[...roomFurniture(result.world),...this.sampleFurniture],item=layout.find(i=>i.id===data.id),error=item&&placementError(item,layout,[state.player.position],result.world.room?.tileSplits);if(error){this.events.onFurnitureBlocked?.(error);return;}}
   try{localStorage.setItem(OFFLINE_KEY,JSON.stringify(result.world));}catch{this.events.onFurnitureBlocked?.('Could not save this change. Nothing was changed.');return;}
   state.world=result.world;if(type==='create-room'||type==='delete-room'){this.sampleFurniture=[];state.player.position=findSpawn(this.offlineFurniture(),state.world.room?.tileSplits);delete state.player.seat;this.events.onRoomState({[state.player.id]:state.player});}this.publishOffline();
   if(type==='move'||type==='place'||type==='rotate'){const player=seatPlayersUnderFurniture([state.player],this.offlineFurniture(),state.world.room?.tileSplits)[0];if(player!==state.player){state.player=player;this.events.onPosture?.(player);}}
   if(type==='delete-room')this.events.onWorldNotice?.('Room deleted. All furniture has been returned to its owners’ inventories.');
   else if(type==='split-tile')this.events.onWorldNotice?.('Tile divided into four smaller tiles.');
   else if(type==='pickup')this.events.onWorldNotice?.('Furniture returned to its owner’s inventory.');
  }else if(event==='player:move'){
   const room=this.offlineRoom;if(!room)return;
   const result=movePlayer(state.player,{x:data.x,y:data.y},this.offlineFurniture(),[state.player],room.tileSplits,this.publicStreet?PUBLIC_STREET_FLOOR:undefined);
   if(!result.ok){this.events.onPlayerCorrect?.(state.player.position);this.events.onPosture?.(state.player);return;}
   state.player=result.player;if(result.player.seat)this.events.onPosture?.(result.player);
  }else if(event==='chat:send'&&this.offlineRoom)this.events.onChat({id:`local-${++this.chatSequence}`,playerId:state.player.id,playerName:state.player.name,content:data.content,timestamp:Date.now(),position:{...state.player.position},sequence:this.chatSequence,appearance:state.player.appearance?{...state.player.appearance}:undefined});
 }
 saveAvatar(appearance:AvatarAppearance){this.emit('avatar:save',appearance);}
 walletRequest<T=unknown>(event:string,data:unknown):Promise<T>{
  if(this.offline){try{return Promise.resolve(this.offlineWalletRequest(event,data) as T);}catch(error){return Promise.reject(error);}}
  if(!this.socket?.connected)return Promise.reject(Error('Join the hosted multiplayer game to connect a wallet.'));
  const payload=(event==='wallet:place'||event==='wallet:pickup')?{...(data as object),roomId:this.roomId}:data;
  return new Promise((resolve,reject)=>this.socket!.timeout(60000).emit(event,payload,(error:Error|null,reply:WalletReply<T>)=>{
   if(error){reject(Error('The wallet service timed out. Refresh or reconnect to check the result.'));return;}
   if(!reply?.ok){reject(Error(reply&&!reply.ok?reply.error:'Invalid wallet response.'));return;}resolve(reply.value);
  }));
 }
 sit(id:string,index:number){this.emit('player:sit',{id,index,roomId:this.roomId});}stand(to?:Position){this.emit('player:stand',{roomId:this.roomId,...(to?{to}:{})});}
 interactFurniture(id:string){this.emit('furniture:state-change',{id,roomId:this.roomId});}
 rotateFurniture(id:string){this.emit('furniture:rotate',{id,roomId:this.roomId});}
 moveFurniture(id:string,gx:number,gy:number){this.emit('furniture:move',{id,gx,gy,roomId:this.roomId});}
 placeFurniture(id:string,gx:number,gy:number){this.emit('furniture:place',{id,gx,gy,roomId:this.roomId});}
 pickUpFurniture(id:string){this.emit('furniture:pickup',{id,roomId:this.roomId});}
 deleteRoom(){this.emit('room:delete',{roomId:this.roomId});}
 splitTile(tileId:string){this.emit('room:split-tile',{tileId,roomId:this.roomId});}
 createRoom(){this.emit('room:create');}
 sendMove(x:number,y:number,direction?:string){this.emit('player:move',{x,y,direction});}
 sendChat(content:string){this.emit('chat:send',{content});}
 claimDJ(){this.emit('dj:claim');}releaseDJ(){this.emit('dj:release');}djPlay(){this.emit('dj:play');}djPause(){this.emit('dj:pause');}
 djNext(){this.emit('dj:next');}djPrev(){this.emit('dj:prev');}djVolume(volume:number){this.emit('dj:volume',{volume});}
 djAddTrack(url:string){this.emit('dj:addtrack',{url});}djUpdateTitle(youtubeId:string,title:string){this.emit('dj:updatetitle',{youtubeId,title});}
 getSocketId(){return this.offline?this.offline.player.id:this.socket?.id;}getUserId(){return this.userId;}
 getCalls(){return this.calls;}
 disconnect(){this.calls.destroy();clearTimeout(this.timer);clearTimeout(this.sampleExpiry);this.sampleWallet.disconnect();this.offline=undefined;this.sampleFurniture=[];this.socket?.disconnect();}
}
