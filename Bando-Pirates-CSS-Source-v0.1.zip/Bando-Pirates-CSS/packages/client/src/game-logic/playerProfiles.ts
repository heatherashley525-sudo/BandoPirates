export interface LocalProfile {localId:string;name:string;color:number;token?:string;userId?:string}
const KEY='heather-hotel-player-profiles-v1',ACTIVE='heather-hotel-active-profile';
let memory:LocalProfile[]=[];let activeMemory='';
export function listProfiles():LocalProfile[]{
 try{const parsed=JSON.parse(localStorage.getItem(KEY)||'null');if(Array.isArray(parsed))memory=parsed.filter(p=>p&&typeof p.localId==='string'&&typeof p.name==='string'&&typeof p.color==='number');}catch{}
 return memory.map(p=>({...p}));
}
function write(profiles:LocalProfile[]){memory=profiles;try{localStorage.setItem(KEY,JSON.stringify(profiles));}catch{}}
export function activateProfile(id:string){activeMemory=id;try{sessionStorage.setItem(ACTIVE,id);localStorage.setItem(ACTIVE,id);}catch{}}
export function createLocalProfile():LocalProfile {
 const profile={localId:crypto.randomUUID(),name:'',color:0xff9ff3};write([...listProfiles(),profile]);activateProfile(profile.localId);return profile;
}
export function getActiveProfile():LocalProfile {
 const profiles=listProfiles();let id=activeMemory;
 try{id=sessionStorage.getItem(ACTIVE)||localStorage.getItem(ACTIVE)||id;}catch{}
 const existing=profiles.find(p=>p.localId===id)||profiles[0];if(existing){activeMemory=existing.localId;return existing;}
 const profile=createLocalProfile();try{const old=JSON.parse(localStorage.getItem('cocoworking-profile')||'null');if(old&&typeof old.name==='string')return updateProfile(profile.localId,{name:old.name,color:typeof old.color==='number'?old.color:profile.color});}catch{}
 return profile;
}
export function updateProfile(id:string,patch:Partial<LocalProfile>):LocalProfile {
 const profiles=listProfiles();const profile=profiles.find(p=>p.localId===id);if(!profile)throw Error('Player profile not found.');
 Object.assign(profile,patch,{localId:id});write(profiles);return {...profile};
}
