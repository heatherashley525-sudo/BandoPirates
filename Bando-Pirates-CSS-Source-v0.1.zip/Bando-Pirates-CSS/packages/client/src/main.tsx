import './theme';
import React from "react";
import { createRoot } from "react-dom/client";
import { App } from "./ui/App";
import { RoomEditor } from "./scenes/RoomEditor";
const host = document.getElementById("app")!;
if (new URLSearchParams(location.search).has("editor")) {
  document.body.style.overflow = "auto";
  new RoomEditor(host);
} else if(new URLSearchParams(location.search).has('wardrobe')){
  void import('./artwork/wardrobePreview');
} else createRoot(host).render(<App />);
