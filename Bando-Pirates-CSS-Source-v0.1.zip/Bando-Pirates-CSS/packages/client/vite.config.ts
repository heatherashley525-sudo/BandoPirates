import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    fs: { deny: [".env", ".env.*", "*.{crt,pem}", "**/.git/**", "**/packages/server/data/**"] },
    port: 3000,
    proxy: {
      "/socket.io": {
        target: "http://localhost:2567",
        ws: true,
      },
    },
  },
});
