import {describe,it,expect} from 'vitest';
import {collectionById,habboFurnitureImageUrl,parseHabboFurnitureDefinition,type HabboFurnitureDefinition,type CollectibleAsset} from '../collectibles';
import {furnitureTiles,furnitureTop,resolvePlacement,placementError,BASE_TABLE,STOOL,editFurniture,type FurnitureState} from '../furniture';
import {sofaSeats,movePlayer,seatPlayersUnderFurniture} from '../seating';
import {canStep} from '../walking';
import {defaultAppearance} from '../avatar';
const definition:HabboFurnitureDefinition={classname:'nft_club_sofa',revision:70734,width:1,depth:2,height:2,seat:true,walkable:false,stackable:false,directions:[2,4,6,0],states:[0]};
const c=collectionById('furni')!,asset:CollectibleAsset={key:'test',collection:'furni',chainId:13371,contract:c.contract,tokenId:'1',name:'NFT Sofa',kind:'item',image:'https://nft-tokens.habbo.com/collectibles/furni/images/nft_club_sofa.png'};
const sofa:FurnitureState={id:'nft-sofa',kind:'habbo-nft',ownerId:'guest',gx:3,gy:3,rotation:0,nft:{asset,definition}};
describe('native NFT furniture geometry',()=>{
 it('uses a transparent native render with pinned revision and four real directions',()=>{
  expect(parseHabboFurnitureDefinition(definition)).toEqual(definition);
  for(let r=0;r<4;r++){const u=new URL(habboFurnitureImageUrl(definition,r));expect(u.pathname).toContain('nft_club_sofa.png');expect(u.searchParams.get('direction')).toBe(String([2,4,6,0][r]));expect(u.searchParams.get('revision')).toBe('70734');}
  expect(parseHabboFurnitureDefinition({...definition,classname:'../../evil'})).toBeNull();expect(parseHabboFurnitureDefinition({...definition,width:100})).toBeNull();
 });
 it('swaps the footprint with native direction, rejects overlap and gives real sofa seats',()=>{
  expect(furnitureTiles(sofa)).toEqual([{x:3,y:3},{x:3,y:4}]);expect(furnitureTiles({...sofa,rotation:1})).toEqual([{x:3,y:3},{x:4,y:3}]);
  expect(placementError({...sofa,gx:9,rotation:1},[],[])).toContain('inside');expect(placementError({...sofa,id:'other'},[sofa],[])).toContain('occupies');
  const seats=sofaSeats(sofa);expect(seats).toHaveLength(2);const player={id:'p',name:'P',position:seats[0].approach,direction:'south' as const,appearance:defaultAppearance()};
  const seated=movePlayer(player,seats[0].tile,[sofa],[]);expect(seated.ok&&seated.player.seat).toEqual({furnitureId:sofa.id,index:0});
  expect(seatPlayersUnderFurniture([{...player,position:seats[1].tile}],[sofa])[0].seat?.index).toBe(1);
 });
 it('uses the NFT height for stepping and supports NFT-on-table stacking',()=>{
  const table={...sofa,id:'nft-table',nft:{asset,definition:{...definition,width:1,depth:1,height:1.6,seat:false,stackable:true}},gx:6,gy:3};
  expect(furnitureTop(table)).toBe(1.6);expect(canStep({x:5,y:3},{x:6,y:3},[table])).toBe(false);expect(canStep({x:6,y:4},{x:6,y:3},[table,STOOL])).toBe(true);
  const stacked=resolvePlacement({...sofa,gx:6,gy:3},6,3,[BASE_TABLE]);expect(stacked.z).toBe(2);expect(placementError(stacked,[BASE_TABLE],[])).toBeNull();
  const permanent=resolvePlacement({...STOOL,id:'permanent'},6,3,[table]);expect(placementError(permanent,[table],[])).toContain('permanent');
 });
 it('keeps room-owner editing and prevents editing occupied seats',()=>{
  expect(editFurniture([sofa],{action:'rotate',id:sofa.id},'guest','owner',[]).ok).toBe(false);
  expect(editFurniture([sofa],{action:'rotate',id:sofa.id},'owner','owner',[]).ok).toBe(true);
  expect(editFurniture([sofa],{action:'move',id:sofa.id,gx:7,gy:7},'owner','owner',[{x:3,y:3}]).ok).toBe(false);
 });
});
