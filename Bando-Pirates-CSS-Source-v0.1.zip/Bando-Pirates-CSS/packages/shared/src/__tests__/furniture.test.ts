import { describe, expect, it } from 'vitest';
import { BASE_SOFA, BASE_TABLE, createRoomFurniture, furnitureTiles, furnitureObstacles, editFurniture, findSpawn, type FurnitureEdit } from '../furniture';
const edit = (request: FurnitureEdit, players = [] as {x:number;y:number}[]) => editFurniture(createRoomFurniture(),request,'owner','owner',players);
describe('room furniture editing', () => {
  it('contains Base sofa, Base table and low Stool', () => {
    expect(createRoomFurniture().map(i=>i.kind)).toEqual(['base-sofa','base-table','stool']);
  });
  it.each(['base-sofa','base-table','stool'])('cycles %s through four rotations', id => {
    let items=createRoomFurniture();
    for(let i=1;i<=4;i++) {
      const result=editFurniture(items,{action:'rotate',id},'owner','owner',[]);
      expect(result.ok).toBe(true);
      if(result.ok) { items=result.furniture; expect(items.find(x=>x.id===id)?.rotation).toBe(i%4); }
    }
  });
  it('gives the sofa two tiles and the stool one in every rotation', () => {
    for(const rotation of [0,1,2,3] as const) {
      expect(furnitureTiles({...BASE_SOFA,rotation})).toHaveLength(2);
      expect(furnitureTiles({...BASE_TABLE,rotation})).toEqual([{x:6,y:3}]);
    }
    expect(furnitureTiles({...BASE_SOFA,rotation:1})).toEqual([{x:3,y:3},{x:4,y:3}]);
  });
  it('enforces ownership for both movement and rotation', () => {
    const items=createRoomFurniture();
    for(const request of [{action:'rotate',id:'base-table'},{action:'move',id:'base-sofa',gx:7,gy:7}] as const) {
      expect(editFurniture(items,request,'guest','owner',[])).toMatchObject({ok:false});
    }
    expect(items).toEqual(createRoomFurniture());
  });
  it('moves only the selected piece and frees its old collision tiles', () => {
    const result=edit({action:'move',id:'base-sofa',gx:7,gy:7}); expect(result.ok).toBe(true);
    if(result.ok) {
      expect(result.furniture.find(i=>i.id==='base-table')).toEqual(BASE_TABLE);
      const blocked=furnitureObstacles(result.furniture);
      expect(blocked.has('3,3')).toBe(false);expect(blocked.has('7,7')).toBe(true);expect(blocked.has('7,8')).toBe(true);
    }
  });
  it('rejects overlaps with other furniture', () => {
    expect(edit({action:'move',id:'base-table',gx:3,gy:4})).toMatchObject({ok:false});
    expect(edit({action:'move',id:'base-sofa',gx:6,gy:3})).toMatchObject({ok:true});
  });
  it('keeps non-seats solid while permitting a sofa cushion beneath one standing avatar', () => {
    expect(edit({action:'move',id:'base-table',gx:4,gy:5},[{x:4,y:5}])).toMatchObject({ok:false});
    expect(edit({action:'rotate',id:'base-sofa'},[{x:4,y:3}])).toMatchObject({ok:true});
  });
  it.each([{gx:0,gy:4},{gx:9,gy:9},{gx:2.5,gy:3},{gx:NaN,gy:3}])('rejects illegal placement %j', ({gx,gy}) => {
    expect(edit({action:'move',id:'base-sofa',gx,gy})).toMatchObject({ok:false});
  });
  it('rejects malformed requests and unknown pieces', () => {
    for(const request of [null,{action:'delete',id:'base-sofa'},{action:'rotate',id:'missing'},{action:'move',id:'base-sofa'}]) {
      expect(editFurniture(createRoomFurniture(),request,'owner','owner',[])).toMatchObject({ok:false});
    }
  });
  it('does not spawn new visitors inside furniture', () => {
    const items=createRoomFurniture();items[1]={...items[1],gx:5,gy:5};
    const spawn=findSpawn(items);expect(spawn).not.toEqual({x:5,y:5});expect(furnitureObstacles(items).has(`${spawn.x},${spawn.y}`)).toBe(false);
  });
});
