import { describe,expect,it } from 'vitest';
import { emptyWorld,registerPlayer,applyWorldCommand,inventoryFor,roomFurniture,validateWorld,type WorldData,type WorldCommand } from '../ownedWorld';
function initial(){let w=emptyWorld();for(const [id,name] of [['owner','Heather'],['alice','Alice'],['bob','Bob']])w=registerPlayer(w,id,name);return w;}
function run(world:WorldData,user:string,command:Omit<WorldCommand,'roomId'>):WorldData {
 const result=applyWorldCommand(world,user,{...command,roomId:world.room?.id},[]);expect(result.ok).toBe(true);if(!result.ok)throw Error(result.error);return result.world;
}
describe('owned furniture and inventory',()=>{
 it('gives each player four uniquely owned starter pieces only once',()=>{
  const world=initial();expect(inventoryFor(world,'alice')).toHaveLength(4);expect(roomFurniture(world).every(i=>i.ownerId==='owner')).toBe(true);
  const again=registerPlayer(world,'alice','Alice renamed');expect(Object.keys(again.furniture)).toHaveLength(12);
 });
 it('places inventory items exactly once without changing their owner',()=>{
  const world=initial(),item=inventoryFor(world,'alice').find(i=>i.kind==='base-table')!;
  const placed=run(world,'alice',{type:'place',id:item.id,gx:7,gy:7});expect(inventoryFor(placed,'alice')).toHaveLength(3);
  expect(placed.furniture[item.id].ownerId).toBe('alice');
  expect(applyWorldCommand(placed,'alice',{type:'place',id:item.id,gx:8,gy:7,roomId:placed.room!.id},[]).ok).toBe(false);
 });
 it('rejects placing another player’s inventory item',()=>{
  const world=initial(),id=inventoryFor(world,'alice')[0].id;
  expect(applyWorldCommand(world,'bob',{type:'place',id,gx:7,gy:7,roomId:world.room!.id},[]).ok).toBe(false);
 });
 it('returns a picked-up guest item to that guest, not the room owner',()=>{
  let world=initial();const item=inventoryFor(world,'alice')[1];world=run(world,'alice',{type:'place',id:item.id,gx:7,gy:7});
  const picked=run(world,'owner',{type:'pickup',id:item.id});expect(inventoryFor(picked,'alice')).toHaveLength(4);expect(inventoryFor(picked,'owner')).toHaveLength(1);
  expect(picked.furniture[item.id].ownerId).toBe('alice');
 });
 it('lets a visitor collect their own piece but rejects collecting someone else’s',()=>{
  let world=initial();const own=inventoryFor(world,'alice')[1];world=run(world,'alice',{type:'place',id:own.id,gx:7,gy:7});
  expect(applyWorldCommand(world,'bob',{type:'pickup',id:own.id,roomId:world.room!.id},[]).ok).toBe(false);
  expect(inventoryFor(run(world,'alice',{type:'pickup',id:own.id}),'alice')).toHaveLength(4);
 });
 it('deletes the room and returns all items to the correct inventories, including offline owners',()=>{
  let world=initial();const a=inventoryFor(world,'alice')[1],b=inventoryFor(world,'bob')[0];
  world=run(world,'alice',{type:'place',id:a.id,gx:7,gy:7});world=run(world,'bob',{type:'place',id:b.id,gx:1,gy:6});
  const ids=Object.keys(world.furniture).sort(),roomId=world.room!.id;
  const deleted=run(world,'owner',{type:'delete-room'});expect(deleted.room).toBeNull();expect(roomFurniture(deleted)).toEqual([]);
  for(const user of ['owner','alice','bob'])expect(inventoryFor(deleted,user)).toHaveLength(4);
  expect(Object.keys(deleted.furniture).sort()).toEqual(ids);
  expect(applyWorldCommand(deleted,'owner',{type:'delete-room',roomId},[]).ok).toBe(false);
  expect(Object.keys(deleted.furniture)).toHaveLength(12);
 });
 it('rejects deleting a room as a guest and preserves every item',()=>{
  const world=initial(),before=JSON.stringify(world);expect(applyWorldCommand(world,'alice',{type:'delete-room',roomId:world.room!.id},[]).ok).toBe(false);expect(JSON.stringify(world)).toBe(before);
 });
 it('creates an empty replacement room and preserves inventory without reissuing starters',()=>{
  let world=run(initial(),'owner',{type:'delete-room'});world=run(world,'alice',{type:'create-room',newRoomId:'replacement'});
  expect(world.room?.ownerId).toBe('alice');expect(roomFurniture(world)).toHaveLength(0);expect(Object.keys(world.furniture)).toHaveLength(12);
  expect(inventoryFor(world,'owner')).toHaveLength(4);
 });
 it('rejects stale delete requests after a new room was created',()=>{
  const world=initial(),oldId=world.room!.id;let next=run(world,'owner',{type:'delete-room'});next=run(next,'owner',{type:'create-room',newRoomId:'new'});
  expect(applyWorldCommand(next,'owner',{type:'delete-room',roomId:oldId},[]).ok).toBe(false);
 });
 it('keeps item ownership when the room owner moves or rotates it',()=>{
  let world=initial();const item=inventoryFor(world,'alice')[1];world=run(world,'alice',{type:'place',id:item.id,gx:7,gy:7});
  world=run(world,'owner',{type:'move',id:item.id,gx:8,gy:7});world=run(world,'owner',{type:'rotate',id:item.id});expect(world.furniture[item.id].ownerId).toBe('alice');
 });
 it('migrates the old stool name without changing item identity or ownership',()=>{
  const world=initial(),item=Object.values(world.furniture).find(i=>i.kind==='base-table')!;
  (item as {kind:string}).kind='base-stool';const migrated=validateWorld(world);
  expect(migrated.furniture[item.id].kind).toBe('base-table');expect(migrated.furniture[item.id].ownerId).toBe(item.ownerId);expect(Object.keys(migrated.furniture)).toHaveLength(12);
 });
 it('rejects corrupt saved furniture positions rather than resetting inventories',()=>{
  const world=initial(),before=Object.keys(world.furniture).length;Object.values(world.furniture)[0].placement!.gx=99;
  expect(()=>validateWorld(world)).toThrow('Invalid saved furniture placement');expect(Object.keys(world.furniture)).toHaveLength(before);
 });
 it('validates inventory placement against players, walls and other furniture',()=>{
  const world=initial(),item=inventoryFor(world,'alice')[1];
  for(const p of [{gx:0,gy:3},{gx:3,gy:3},{gx:5,gy:5}])expect(applyWorldCommand(world,'alice',{type:'place',id:item.id,...p,roomId:world.room!.id},[{x:5,y:5}]).ok).toBe(false);
 });
});

describe('owned stacks and upgrade grants',()=>{
 it('upgrades an existing profile once without duplicating furniture',()=>{
  let old=registerPlayer(emptyWorld(),'owner','Heather');
  delete old.furniture['owner:stool'];delete old.furniture['owner:base-table:extra'];delete old.profiles.owner.grants;
  const upgraded=registerPlayer(old,'owner','Heather');
  expect(inventoryFor(upgraded,'owner').map(i=>i.kind).sort()).toEqual(['base-table','stool']);
  expect(registerPlayer(upgraded,'owner','Heather')).toEqual(upgraded);
 });
 it('saves support height, rejects removing supports, and returns a mixed-owner stack on deletion',()=>{
  let world=initial();const tableId='owner:base-table',guestTable='alice:base-table',sofa='bob:base-sofa';
  world=run(world,'alice',{type:'place',id:guestTable,gx:6,gy:3});
  world=run(world,'bob',{type:'place',id:sofa,gx:6,gy:3});
  expect(world.furniture[guestTable].placement).toMatchObject({z:2,supportId:tableId});
  expect(world.furniture[sofa].placement).toMatchObject({z:4,supportId:guestTable});
  expect(validateWorld(JSON.parse(JSON.stringify(world)))).toEqual(world);
  for(const type of ['pickup','move','rotate'] as const)expect(applyWorldCommand(world,'owner',{type,id:tableId,gx:8,gy:8,roomId:world.room!.id},[]).ok).toBe(false);
  const deleted=run(world,'owner',{type:'delete-room'});
  for(const id of ['owner','alice','bob'])expect(inventoryFor(deleted,id)).toHaveLength(4);
  expect(Object.keys(deleted.furniture)).toHaveLength(12);
 });
});
