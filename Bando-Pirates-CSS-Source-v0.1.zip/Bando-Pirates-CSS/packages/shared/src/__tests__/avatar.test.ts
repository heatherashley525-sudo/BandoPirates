import {describe,it,expect} from 'vitest';
import {blankAppearance,defaultAppearance,heatherAppearance,parseAppearance,saveAppearance} from '../avatar';
import {emptyWorld,registerPlayer,validateWorld} from '../ownedWorld';
describe('original avatar appearance',()=>{
 it('has a hairless, clothing-free neutral base with independently selectable layers',()=>{
  expect(blankAppearance()).toMatchObject({version:1,hair:'none',top:'none',bottom:'none',shoes:'none',accessory:'none'});
  const edited={...blankAppearance(),skin:'#8c5e46',top:'tee',topColor:'#f5c2df'};expect(parseAppearance(edited)).toEqual(edited);
 });
 it('rejects malformed styles, injected CSS and unknown fields',()=>{
  const base=blankAppearance();
  for(const value of [null,{}, {...base,hair:'unknown'}, {...base,skin:'red; background:url(x)'}, {...base,version:2}, {...base,token:'claim'}, {...base,puzzlePirates:{image:'removed'}}])expect(parseAppearance(value)).toBeNull();
 });
 it('keeps the familiar dressed default distinct from the blank base',()=>{
  expect(defaultAppearance(0x48dbfb)).toMatchObject({hair:'long',top:'tee',topColor:'#48dbfb',bottom:'trousers',shoes:'shoes',accessory:'bow'});
 });
 it('round-trips the built-in Heather design and rejects other preset IDs',()=>{
  const look=heatherAppearance();
  expect(parseAppearance(look)).toEqual(look);
  expect(parseAppearance({...look,preset:'unknown'})).toBeNull();
  const result=saveAppearance(registerPlayer(emptyWorld(),'a','Heather'),'a',look);
  expect(result.ok&&validateWorld(JSON.parse(JSON.stringify(result.world))).profiles.a.appearance).toEqual(look);
 });
 it('accepts bounded breast sizes, keeps legacy saves flat and rejects malformed body values',()=>{
  const base=blankAppearance();const {breastSize,...legacy}=base;expect(parseAppearance(legacy)?.breastSize).toBe(0);
  for(const size of [0,35,100])expect(parseAppearance({...base,breastSize:size})?.breastSize).toBe(size);
  for(const size of [-1,101,1.5,'50',null,NaN,Infinity])expect(parseAppearance({...base,breastSize:size})).toBeNull();
  const world=registerPlayer(emptyWorld(),'a','Heather');const saved=saveAppearance(world,'a',{...base,breastSize:70});expect(saved.ok&&saved.world.profiles.a.appearance?.breastSize).toBe(70);
 });
 it('saves only the authenticated profile and preserves furniture and other appearances',()=>{
  let w=registerPlayer(registerPlayer(emptyWorld(),'a','Heather'),'b','Guest');const original=structuredClone(w);
  const result=saveAppearance(w,'a',blankAppearance());expect(result.ok).toBe(true);if(!result.ok)return;
  expect(result.world.profiles.a.appearance).toEqual(blankAppearance());expect(result.world.profiles.b).toEqual(original.profiles.b);expect(result.world.furniture).toEqual(original.furniture);
  expect(w).toEqual(original);expect(saveAppearance(w,'missing',blankAppearance()).ok).toBe(false);expect(saveAppearance(w,'a',{}).ok).toBe(false);
 });
});
