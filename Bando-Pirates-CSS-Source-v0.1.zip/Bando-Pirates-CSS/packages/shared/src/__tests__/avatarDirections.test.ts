import {describe,it,expect} from 'vitest';
import {AVATAR_DIRECTIONS,toHabboDirection,fromHabboDirection,directionForMove,parseHabboFigure,habboImageUrl} from '../avatarDirections';
import {parseAppearance,blankAppearance} from '../avatar';
import {canStep} from '../walking';
import {BASE_SOFA,BASE_TABLE,STOOL} from '../furniture';
describe('eight avatar directions and Habbo figure adapter',()=>{
 it('round-trips the eight native direction codes',()=>{
  expect(AVATAR_DIRECTIONS).toHaveLength(8);
  for(let i=0;i<8;i++)expect(toHabboDirection(fromHabboDirection(i))).toBe(i);
  expect(toHabboDirection('south-east')).toBe(2);expect(toHabboDirection('north')).toBe(7);
 });
 it('derives every facing from movement on the isometric grid',()=>{
  const from={x:5,y:5};expect(new Set([[0,-1],[1,-1],[1,0],[1,1],[0,1],[-1,1],[-1,0],[-1,-1]].map(([dx,dy])=>directionForMove(from,{x:5+dx,y:5+dy})))).toHaveLength(8);
  expect(directionForMove(from,{x:6,y:5})).toBe('south-east');
 });
 it('accepts bounded figure strings, rejects URLs/injection, and stores them without changing CSS slot data',()=>{
  const figure='hd-180-1.ch-255-66.lg-285-82.sh-290-91.hr-100-61';expect(parseHabboFigure(figure)).toBe(figure);
  for(const bad of ['https://example.com/a.png','hd-180-1&x=y','hd-1','x'.repeat(600)])expect(parseHabboFigure(bad)).toBeNull();
  expect(parseAppearance({...blankAppearance(),habboFigure:figure})?.habboFigure).toBe(figure);
  const url=new URL(habboImageUrl(figure,'south-east',true,1));expect(url.hostname).toBe('www.habbo.com');expect(url.searchParams.get('direction')).toBe('2');expect(url.searchParams.get('action')).toBe('wlk');expect(url.searchParams.get('frame')).toBe('1');
 });
 it('allows diagonal walking without cutting furniture corners or bypassing height limits',()=>{
  expect(canStep({x:5,y:5},{x:6,y:6},[])).toBe(true);
  expect(canStep({x:5,y:5},{x:6,y:6},[{...BASE_SOFA,gx:6,gy:5}])).toBe(false);
  expect(canStep({x:5,y:5},{x:6,y:6},[{...BASE_TABLE,gx:6,gy:6}])).toBe(false);
  expect(canStep({x:5,y:5},{x:6,y:6},[{...STOOL,gx:6,gy:6}])).toBe(true);
 });
});
