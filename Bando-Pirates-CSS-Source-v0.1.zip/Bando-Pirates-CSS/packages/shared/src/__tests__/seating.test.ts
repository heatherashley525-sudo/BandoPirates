import {describe,it,expect} from 'vitest';
import {sofaSeats,sitPlayer,standPlayer,seatApproachable,movePlayer,findPlayerPath,seatPlayersUnderFurniture,seatExits} from '../seating';
import {BASE_SOFA,BASE_TABLE,STOOL,supportEditError,placementError,type FurnitureRotation} from '../furniture';
import type {Player} from '../types';
const player:Player={id:'a',name:'A',position:{x:4,y:3},direction:'south'};
describe('two-seat sofas',()=>{
 it('sits automatically from any adjacent approach and routes to the cushion as the final tile',()=>{
  const result=movePlayer(player,{x:3,y:3},[BASE_SOFA],[]);expect(result.ok&&result.player.seat).toEqual({furnitureId:BASE_SOFA.id,index:0});
  expect(findPlayerPath({x:5,y:5},{x:3,y:3},[BASE_SOFA],[])?.slice(-2)).toEqual([{x:4,y:4},{x:3,y:3}]);
  expect(movePlayer({...player,position:{x:2,y:3}},{x:3,y:3},[BASE_SOFA],[]).ok).toBe(true);
  expect(result.ok&&movePlayer({...player,id:'b'},{x:3,y:3},[BASE_SOFA],[result.player]).ok).toBe(false);
  expect(movePlayer(player,{x:3,y:3},[BASE_SOFA,{...STOOL,gx:4,gy:3}],[]).ok).toBe(true);
 });
 it('permits placing a sofa under two distinct standing avatars and seats each on its own cushion',()=>{
  const players=[{...player,position:{x:3,y:3}},{...player,id:'b',position:{x:3,y:4}}];expect(placementError(BASE_SOFA,[],players.map(p=>p.position))).toBeNull();
  expect(seatPlayersUnderFurniture(players,[BASE_SOFA]).map(p=>p.seat?.index)).toEqual([0,1]);
  expect(placementError(BASE_SOFA,[],[players[0].position,players[0].position])).toContain('one avatar');
 });
 it('requires a matching support height and safe exit when placing beneath an avatar',()=>{
  const table={...BASE_TABLE,gx:3,gy:3},sofa={...BASE_SOFA,z:2,supportId:table.id};
  expect(placementError(sofa,[table],[{x:3,y:3}])).toBeNull();expect(placementError(sofa,[table],[{x:3,y:4}])).toContain('floor level');
  expect(placementError({...BASE_SOFA,gx:9,gy:5},[],[{x:9,y:5}])).toBeNull();
  expect(placementError(BASE_SOFA,[{...BASE_TABLE,gx:4,gy:3}],[{x:3,y:3}])).toBeNull();
 });
 it('has two front approaches and the correct facing in all four rotations',()=>{
  const facings=['south-east','south-west','north-west','north-east'];
  for(let r=0;r<4;r++){const sofa={...BASE_SOFA,rotation:r as FurnitureRotation};const seats=sofaSeats(sofa);expect(seats).toHaveLength(2);expect(seats[0].direction).toBe(facings[r]);expect(seats[0].tile).not.toEqual(seats[1].tile);for(const seat of seats)expect(sitPlayer({...player,position:seat.approach},sofa.id,seat.index,[sofa],[]).ok).toBe(true);}
 });
 it('rejects remote sitting, occupied seats and invalid indices, but allows the second seat',()=>{
  const seated=sitPlayer(player,BASE_SOFA.id,0,[BASE_SOFA],[]);expect(seated.ok).toBe(true);if(!seated.ok)return;
  expect(sitPlayer({...player,id:'b'},BASE_SOFA.id,0,[BASE_SOFA],[seated.player]).ok).toBe(false);
  expect(sitPlayer({...player,id:'b',position:{x:4,y:4}},BASE_SOFA.id,1,[BASE_SOFA],[seated.player]).ok).toBe(true);
  expect(sitPlayer({...player,position:{x:8,y:8}},BASE_SOFA.id,0,[BASE_SOFA],[]).ok).toBe(false);expect(sitPlayer(player,BASE_SOFA.id,2,[BASE_SOFA],[]).ok).toBe(false);
  expect(supportEditError(BASE_SOFA,[BASE_SOFA],[seated.player.position])).toBeTruthy();
 });
 it('requires a reachable support level for elevated sofas and preserves stacking on stand',()=>{
  const sofa={...BASE_SOFA,z:2,supportId:BASE_TABLE.id},seat=sofaSeats(sofa)[0];expect(seatApproachable(sofa,seat,[sofa,BASE_TABLE])).toBe(false);
  const step={...BASE_TABLE,gx:seat.approach.x,gy:seat.approach.y};const result=sitPlayer(player,sofa.id,0,[sofa,step],[]);expect(result.ok).toBe(true);if(!result.ok)return;
  const stood=standPlayer(result.player,[sofa,step]);expect(stood.ok&&stood.player.seat).toBeUndefined();expect(stood.ok&&stood.player.position).toEqual(seat.approach);
 });
 it('uses another safe side when the front is blocked and rejects a fully enclosed seat',()=>{
  const seated=sitPlayer(player,BASE_SOFA.id,0,[BASE_SOFA],[]);if(!seated.ok)throw Error('seat');
  const blockedFront=[BASE_SOFA,{...BASE_SOFA,id:'block',gx:4,gy:3}];const stood=standPlayer(seated.player,blockedFront);expect(stood.ok).toBe(true);expect(stood.ok&&stood.player.position).not.toEqual({x:4,y:3});const blocks=seatExits(BASE_SOFA,sofaSeats(BASE_SOFA)[0],[BASE_SOFA]).map((p,i)=>({...BASE_TABLE,id:'wall-'+i,gx:p.x,gy:p.y}));expect(standPlayer(seated.player,[BASE_SOFA,...blocks]).ok).toBe(false);expect(placementError(BASE_SOFA,blocks,[{x:3,y:3}])).toContain('adjacent exit');
 });
 it('enters and exits every clear neighboring direction in all sofa rotations',()=>{
  for(let rotation=0;rotation<4;rotation++){const sofa={...BASE_SOFA,rotation:rotation as FurnitureRotation},seat=sofaSeats(sofa)[0],exits=seatExits(sofa,seat,[sofa]);expect(exits.length).toBeGreaterThanOrEqual(6);for(const p of exits){const result=sitPlayer({...player,position:p},sofa.id,seat.index,[sofa],[]);expect(result.ok).toBe(true);if(!result.ok)continue;const stood=standPlayer(result.player,[sofa],[],p);expect(stood.ok&&stood.player.position).toEqual(p);expect(findPlayerPath(p,seat.tile,[sofa],[])).toEqual([seat.tile]);}}
 });
 it('never jumps to a remote exit or ignores an occupied seat',()=>{
  const sat=sitPlayer(player,BASE_SOFA.id,0,[BASE_SOFA],[]);if(!sat.ok)throw Error('seat');const stood=standPlayer(sat.player,[BASE_SOFA],[],{x:9,y:9});expect(stood.ok).toBe(true);expect(stood.ok&&Math.abs(stood.player.position.x-3)).toBeLessThanOrEqual(1);expect(standPlayer(sat.player,[BASE_SOFA],[],{x:999,y:999}).ok).toBe(false);expect(sitPlayer({...player,id:'b',position:{x:2,y:3}},BASE_SOFA.id,0,[BASE_SOFA],[sat.player]).ok).toBe(false);
 });

});
