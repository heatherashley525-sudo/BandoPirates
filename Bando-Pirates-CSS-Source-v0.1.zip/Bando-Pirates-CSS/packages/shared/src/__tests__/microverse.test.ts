import {describe,it,expect} from 'vitest';
import {floorTiles,tileFromId,tileForPosition,tileAt,nextFloorTile,validateTileSplits,splitTileError,MAX_TILE_DEPTH,applyWorldCommand,emptyWorld,registerPlayer,validateWorld,roomFurniture,inventoryFor,findWalkPath,canStep,resolvePlacement,placementError,furnitureTop,furnitureTiles,sitPlayer,standPlayer,sofaSeats,type WorldData,type Player,type FurnitureState} from '../index';
const divided=['2,2','2,2/0'];
function world(){return registerPlayer(registerPlayer(emptyWorld(),'owner','Owner'),'guest','Guest');}
function command(w:WorldData,type:string,data:object={},actor='owner',players:{x:number;y:number}[]=[]){return applyWorldCommand(w,actor,{type,roomId:w.room!.id,...data},players);}
describe('recursive usable floor tiles',()=>{
 it('keeps the same floor area while replacing each chosen leaf with exactly four smaller leaves',()=>{
  const tiles=floorTiles(divided);expect(tiles).toHaveLength(87);expect(tiles.reduce((n,t)=>n+t.size*t.size,0)).toBe(81);expect(new Set(tiles.map(t=>t.id)).size).toBe(87);expect(tileForPosition({x:2,y:2},divided)).toBeNull();expect(tileFromId('2,2/00')).toMatchObject({x:1.625,y:1.625,size:.25,depth:2});expect(tileAt({x:1.63,y:1.63},divided)?.id).toBe('2,2/00');
 });
 it('routes across unequal-size neighbors and never accepts arbitrary fractional coordinates or teleports',()=>{
  const from={x:5,y:5},goal=tileFromId('2,2/00')!,path=findWalkPath(from,goal,[],divided)!;expect(path.at(-1)).toEqual({x:goal.x,y:goal.y});for(let i=0;i<path.length;i++)expect(canStep(i?path[i-1]:from,path[i],[],divided)).toBe(true);
  expect(canStep(from,goal,[],divided)).toBe(false);expect(canStep({x:3,y:2},{x:2.123,y:2.25},[],divided)).toBe(false);expect(canStep({x:3,y:2},{x:2,y:2},[],divided)).toBe(false);expect(nextFloorTile({x:3,y:2},{dx:-1,dy:0},divided)).toEqual({x:2.25,y:2.25});
 });
 it('rejects malformed trees, duplicate divisions and divisions deeper than the current limit',()=>{
  for(const invalid of [['2,2/0'],['2,2','2,2'],['0,2'],['2,2/999'],[{},'2,2']])expect(()=>validateTileSplits(invalid)).toThrow();
  const chain=Array.from({length:MAX_TILE_DEPTH},(_,i)=>'2,2'+(i?'/'+ '0'.repeat(i):''));expect(validateTileSplits(chain)).toHaveLength(8);expect(splitTileError('2,2/'+ '0'.repeat(8),chain)).toContain('depth');expect(splitTileError('2,2',chain)).toContain('undivided');
 });
 it('bounds the room leaf budget without accepting an oversized saved tree',()=>{
  const splits:string[]=[],queue=[...floorTiles()];while(splits.length<1338){const t=queue.shift()!;if(t.depth>=8)continue;splits.push(t.id);for(let i=0;i<4;i++)queue.push(tileFromId(t.id+(t.depth?'':'/')+i)!);}
  expect(validateTileSplits(splits)).toHaveLength(1338);expect(floorTiles(splits)).toHaveLength(4095);expect(splitTileError(floorTiles(splits)[0].id,splits)).toContain('limit');expect(()=>validateTileSplits([...splits,floorTiles(splits)[0].id])).toThrow();
 });
 it('allows only the room owner to split clear leaves and rejects stale room IDs, avatars and furniture',()=>{
  const w=world();expect(command(w,'split-tile',{tileId:'2,2'},'guest').ok).toBe(false);expect(command(w,'split-tile',{tileId:'2,2'},'owner',[{x:2,y:2}]).ok).toBe(false);expect(command(w,'split-tile',{tileId:'3,3'}).ok).toBe(false);expect(command(w,'split-tile',{tileId:'2,2',roomId:'old'}).ok).toBe(false);
  const first=command(w,'split-tile',{tileId:'2,2'});expect(first.ok).toBe(true);if(!first.ok)return;expect(first.world.room!.tileSplits).toEqual(['2,2']);const next=command(first.world,'split-tile',{tileId:'2,2/0'});expect(next.ok).toBe(true);expect(command(first.world,'split-tile',{tileId:'2,2'}).ok).toBe(false);expect(w.room!.tileSplits).toBeUndefined();
 });
 it('saves divided furniture at its tile scale, restores it and returns it to inventory on room deletion',()=>{
  let w=world();for(const tileId of divided){const r=command(w,'split-tile',{tileId});if(!r.ok)throw Error(r.error);w=r.world;}
  const item=inventoryFor(w,'guest').find(i=>i.kind==='base-table')!,tile=tileFromId('2,2/00')!,placed=command(w,'place',{id:item.id,gx:tile.x,gy:tile.y},'guest');expect(placed.ok).toBe(true);if(!placed.ok)return;
  w=validateWorld(JSON.parse(JSON.stringify(placed.world)));expect(w.room!.tileSplits).toEqual(divided);const table=roomFurniture(w).find(i=>i.id===item.id)!;expect(table.scale).toBe(.25);expect(furnitureTop(table)).toBe(.5);expect(command(w,'split-tile',{tileId:tile.id}).ok).toBe(false);
  const deleted=command(w,'delete-room');expect(deleted.ok).toBe(true);if(deleted.ok){expect(deleted.world.room).toBeNull();expect(inventoryFor(deleted.world,'guest').some(i=>i.id===item.id)).toBe(true);}
 });
 it('keeps scaled table climbs, Stool steps and stacking physically consistent',()=>{
  const splits=['2,2'],table=resolvePlacement({id:'table',kind:'base-table',gx:1.75,gy:1.75,rotation:0},1.75,1.75,[],splits),stool=resolvePlacement({id:'stool',kind:'stool',gx:2.25,gy:1.75,rotation:0},2.25,1.75,[table],splits);
  expect(placementError(table,[table,stool],[],splits)).toBeNull();expect(canStep({x:2,y:1},{x:1.75,y:1.75},[table,stool],splits)).toBe(false);expect(canStep({x:3,y:2},{x:2.25,y:1.75},[table,stool],splits)).toBe(true);expect(canStep({x:2.25,y:1.75},{x:1.75,y:1.75},[table,stool],splits)).toBe(true);
  const upper=resolvePlacement({...table,id:'upper'},table.gx,table.gy,[table,stool],splits);expect(upper.z).toBe(1);expect(furnitureTop(upper)).toBe(2);expect(placementError(upper,[table,stool],[],splits)).toBeNull();
 });
 it('keeps both micro-sofa seats usable and scales a two-cell footprint',()=>{
  const splits=['2,2'],sofa=resolvePlacement({id:'sofa',kind:'base-sofa',gx:1.75,gy:1.75,rotation:0},1.75,1.75,[],splits);expect(furnitureTiles(sofa)).toEqual([{x:1.75,y:1.75},{x:1.75,y:2.25}]);expect(placementError(sofa,[],[],splits)).toBeNull();
  const seat=sofaSeats(sofa,splits)[0],p:Player={id:'p',name:'P',position:seat.approach,direction:'south'},sat=sitPlayer(p,sofa.id,0,[sofa],[p],splits);expect(sat.ok).toBe(true);if(sat.ok){expect(sat.player.position).toEqual(seat.tile);const standing=standPlayer(sat.player,[sofa],splits);expect(standing.ok&&standing.player.position).toEqual(seat.approach);}
  const bad:FurnitureState={...sofa,gx:2.25};expect(placementError({...bad,rotation:1},[],[],splits)).not.toBeNull();
 });
});
