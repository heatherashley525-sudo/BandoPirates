import {describe,expect,it} from 'vitest';
import {BASE_SOFA,BASE_TABLE,STOOL,resolvePlacement,placementError,editFurniture,type FurnitureState} from '../furniture';
import {surfaceAt,canStep,findWalkPath} from '../walking';
const table=(id:string,gx:number,gy:number,z=0,supportId?:string):FurnitureState=>({...BASE_TABLE,id,gx,gy,z,supportId});
const stool=(id:string,gx:number,gy:number,z=0,supportId?:string):FurnitureState=>({...STOOL,id,gx,gy,z,supportId});
describe('stacked furniture',()=>{
 it('places tables on table tops with persistent support links',()=>{
  const bottom=table('bottom',4,4),top=resolvePlacement(table('top',1,1),4,4,[bottom]);
  expect(top).toMatchObject({z:2,supportId:'bottom'});expect(placementError(top,[bottom],[])).toBeNull();
  const third=resolvePlacement(table('third',1,1),4,4,[bottom,top]);expect(third).toMatchObject({z:4,supportId:'top'});
 });
 it('allows a two-tile sofa to overhang a single supporting table',()=>{
  const bottom=table('bottom',4,4),sofa=resolvePlacement({...BASE_SOFA,id:'sofa'},4,4,[bottom]);
  expect(sofa.z).toBe(2);expect(sofa.supportId).toBe('bottom');expect(placementError(sofa,[bottom],[])).toBeNull();
 });
 it('rejects a sofa whose overhang intersects a taller stack',()=>{
  const a=table('a',4,4),b=table('b',4,5),c=table('c',4,5,2,'b');
  const sofa=resolvePlacement({...BASE_SOFA,id:'sofa'},4,4,[a,b,c]);expect(placementError(sofa,[a,b,c],[])).not.toBeNull();
 });
 it('rejects unsupported and overlapping saved placements',()=>{
  expect(placementError(table('floating',4,4,2),[],[])).not.toBeNull();
  const a=table('a',4,4);expect(placementError(table('b',4,4),[a],[])).not.toBeNull();
 });
 it('does not remove or move support from under a stack or a player',()=>{
  const bottom=table('bottom',4,4),top=table('top',4,4,2,'bottom');
  expect(editFurniture([bottom,top],{action:'move',id:'bottom',gx:6,gy:6},'owner','owner',[]).ok).toBe(false);
  expect(editFurniture([bottom],{action:'rotate',id:'bottom'},'owner','owner',[{x:4,y:4}]).ok).toBe(false);
 });
});
describe('height-aware walking',()=>{
 it('allows floor to Stool, but not floor directly to table',()=>{
  const items=[stool('step',4,5),table('table',4,4)];
  expect(canStep({x:5,y:5},{x:4,y:5},items)).toBe(true);
  expect(canStep({x:5,y:4},{x:4,y:4},items)).toBe(false);
  expect(canStep({x:4,y:5},{x:4,y:4},items)).toBe(true);
 });
 it('finds a route onto a table via a lower Stool',()=>{
  const items=[stool('step',4,5),table('table',4,4)],path=findWalkPath({x:5,y:5},{x:4,y:4},items)!;
  expect(path).toEqual([{x:4,y:5},{x:4,y:4}]);
 });
 it('does not teleport or climb an isolated table',()=>{
  const items=[table('table',4,4)];expect(canStep({x:1,y:1},{x:4,y:4},items)).toBe(false);expect(findWalkPath({x:5,y:5},{x:4,y:4},items)).toBeNull();
 });
 it('uses the top of a table stack and requires intermediate steps',()=>{
  const items=[table('a',4,4),table('b',4,4,2,'a'),table('c',4,5),stool('d',4,5,2,'c')];
  expect(surfaceAt({x:4,y:4},items).height).toBe(4);expect(canStep({x:5,y:4},{x:4,y:4},items)).toBe(false);expect(canStep({x:4,y:5},{x:4,y:4},items)).toBe(true);
 });
 it('allows stepping down and prevents walking through a sofa',()=>{
  const tableItem=table('table',4,4);expect(canStep({x:4,y:4},{x:5,y:4},[tableItem])).toBe(true);
  const sofa=resolvePlacement({...BASE_SOFA,id:'sofa'},4,4,[tableItem]);expect(surfaceAt({x:4,y:4},[tableItem,sofa]).walkable).toBe(false);
 });
});
