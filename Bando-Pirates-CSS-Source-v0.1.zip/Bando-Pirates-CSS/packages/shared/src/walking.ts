import {coversTile,isSurface,furnitureTop,type FurnitureState} from './furniture';
import {EMPTY_SPLITS,tileForPosition,tileAt,tilesAdjacent,tileNeighbors,type FloorTile} from './microverse';
import type {Position} from './types';
export interface WalkSurface {height:number;walkable:boolean;supportId?:string}
export function surfaceAt(pos:Position,items:readonly FurnitureState[]):WalkSurface{
 const covering=items.filter(i=>coversTile(i,pos));
 if(covering.some(i=>!isSurface(i)))return{height:0,walkable:false};
 const top=covering.sort((a,b)=>furnitureTop(b)-furnitureTop(a))[0];return top?{height:furnitureTop(top),walkable:true,supportId:top.id}:{height:0,walkable:true};
}
function axisStep(from:Position,to:Position,items:readonly FurnitureState[],splits:readonly string[]):boolean{const a=surfaceAt(from,items),b=surfaceAt(to,items),s=Math.min(tileAt(from,splits)?.size||1,tileAt(to,splits)?.size||1);return a.walkable&&b.walkable&&b.height-a.height<=s+1e-9;}
export function canStep(from:Position,to:Position,items:readonly FurnitureState[],splits:readonly string[]=EMPTY_SPLITS):boolean{
 const a=tileForPosition(from,splits),b=tileForPosition(to,splits);if(!a||!b||!tilesAdjacent(a,b)||!axisStep(from,to,items,splits))return false;
 const half=(a.size+b.size)/2;
 if(Math.abs(Math.abs(to.x-from.x)-half)<1e-9&&Math.abs(Math.abs(to.y-from.y)-half)<1e-9){
  const c=tileAt({x:to.x,y:from.y},splits),d=tileAt({x:from.x,y:to.y},splits);return !!c&&!!d&&axisStep(from,c,items,splits)&&axisStep(c,to,items,splits)&&axisStep(from,d,items,splits)&&axisStep(d,to,items,splits);
 }return true;
}
function heading(a:Position,b:Position){
 let x=Math.round((b.x-a.x)*512),y=Math.round((b.y-a.y)*512),u=Math.abs(x),v=Math.abs(y);
 while(v){const r=u%v;u=v;v=r;}return `${x/(u||1)},${y/(u||1)}`;
}
/** Keep the shortest safe route, then prefer fewer turns and less deviation. */
export function findWalkPath(from:Position,to:Position,items:readonly FurnitureState[],splits:readonly string[]=EMPTY_SPLITS):Position[]|null{
 if(from.x===to.x&&from.y===to.y)return[];
 const start=tileForPosition(from,splits),goal=tileForPosition(to,splits);if(!start||!goal||!surfaceAt(to,items).walkable)return null;
 // Reverse edges deliberately: stepping down and climbing have different limits.
 const queue=[goal],distance=new Map<string,number>([[goal.id,0]]);
 for(let i=0;i<queue.length;i++){
  const tile=queue[i];if(tile.id===start.id)break;
  for(const next of tileNeighbors(tile,splits))if(!distance.has(next.id)&&canStep(next,tile,items,splits)){distance.set(next.id,distance.get(tile.id)!+1);queue.push(next);}
 }
 const length=distance.get(start.id);if(length===undefined)return null;
 type Choice={turns:number;deviation:number;next?:FloorTile};const choices=new Map<string,Choice>();
 const dx=to.x-from.x,dy=to.y-from.y,lineLength=Math.hypot(dx,dy)||1;
 // Distances strictly decrease, so this is an iterative DAG pass, not recursion.
 for(const tile of queue){
  const d=distance.get(tile.id)!;if(d>length)break;
  const neighbors=tileNeighbors(tile,splits),incoming=new Set(['',...neighbors.map(n=>heading(n,tile))]);
  const onward=neighbors.filter(n=>distance.get(n.id)===d-1&&canStep(tile,n,items,splits));
  for(const previous of incoming){
   if(d===0){choices.set(tile.id+'|'+previous,{turns:0,deviation:0});continue;}
   let best:Choice|undefined;
   for(const next of onward){const direction=heading(tile,next),tail=choices.get(next.id+'|'+direction);if(!tail)continue;
    const turns=tail.turns+Number(!!previous&&direction!==previous),deviation=tail.deviation+Math.abs(dx*(next.y-from.y)-dy*(next.x-from.x))/lineLength;
    if(!best||turns<best.turns||turns===best.turns&&deviation<best.deviation-1e-9)best={turns,deviation,next};
   }if(best)choices.set(tile.id+'|'+previous,best);
  }
 }
 const path:Position[]=[];let current=start,previous='';while(current.id!==goal.id){const next=choices.get(current.id+'|'+previous)?.next;if(!next)return null;path.push({x:next.x,y:next.y});previous=heading(current,next);current=next;}return path;
}
