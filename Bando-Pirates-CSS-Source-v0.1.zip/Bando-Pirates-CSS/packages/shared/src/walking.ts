import {coversTile,isSurface,furnitureTop,type FurnitureState} from './furniture';
import type {Position} from './types';
export interface WalkSurface {height:number;walkable:boolean;supportId?:string}
export function surfaceAt(pos:Position,items:readonly FurnitureState[]):WalkSurface{
 const covering=items.filter(i=>coversTile(i,pos));
 if(covering.some(i=>!isSurface(i)))return{height:0,walkable:false};
 const top=covering.sort((a,b)=>furnitureTop(b)-furnitureTop(a))[0];return top?{height:furnitureTop(top),walkable:true,supportId:top.id}:{height:0,walkable:true};
}
function axisStep(from:Position,to:Position,items:readonly FurnitureState[]):boolean{const a=surfaceAt(from,items),b=surfaceAt(to,items);return a.walkable&&b.walkable&&b.height-a.height<=1;}
export function canStep(from:Position,to:Position,items:readonly FurnitureState[]):boolean{
 const dx=Math.abs(to.x-from.x),dy=Math.abs(to.y-from.y);
 if(!Number.isInteger(to.x)||!Number.isInteger(to.y)||to.x<1||to.y<1||to.x>=10||to.y>=10||dx>1||dy>1||dx+dy===0||!axisStep(from,to,items))return false;
 if(dx&&dy){const a={x:to.x,y:from.y},b={x:from.x,y:to.y};return axisStep(from,a,items)&&axisStep(a,to,items)&&axisStep(from,b,items)&&axisStep(b,to,items);}
 return true;
}
/** Shortest adjacent-tile route; only one level of upward movement per step. */
export function findWalkPath(from:Position,to:Position,items:readonly FurnitureState[]):Position[]|null{
 if(from.x===to.x&&from.y===to.y)return[];
 if(!surfaceAt(to,items).walkable)return null;
 const key=(p:Position)=>`${p.x},${p.y}`,queue=[from],previous=new Map<string,Position|null>([[key(from),null]]);
 for(let i=0;i<queue.length;i++){
  const current=queue[i];for(const [dx,dy] of [[0,-1],[1,0],[0,1],[-1,0],[1,-1],[1,1],[-1,1],[-1,-1]]){
   const next={x:current.x+dx,y:current.y+dy},id=key(next);if(previous.has(id)||!canStep(current,next,items))continue;
   previous.set(id,current);
   if(next.x===to.x&&next.y===to.y){const path:Position[]=[];let p:Position|null=next;while(p&&key(p)!==key(from)){path.unshift(p);p=previous.get(key(p))!;}return path;}
   queue.push(next);
  }
 }return null;
}
