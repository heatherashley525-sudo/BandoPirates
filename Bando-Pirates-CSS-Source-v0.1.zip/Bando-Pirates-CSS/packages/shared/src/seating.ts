import {DEFAULT_FLOOR,EMPTY_SPLITS,nextFloorTile,tileForPosition,tileNeighbors} from './microverse';
import {furnitureTiles,furnitureCenter,furnitureSeatTiles,furnitureFront,isSeat,HEIGHT_PIXELS,type FurnitureState} from './furniture';
import {surfaceAt,canStep,findWalkPath} from './walking';
import {directionForMove} from './avatarDirections';
import type {Player,Position,Direction,SofaSeatState} from './types';
export interface SofaSeat {index:number;tile:Position;approach:Position;direction:Direction}
const fronts=[{x:1,y:0},{x:0,y:1},{x:-1,y:0},{x:0,y:-1}];
export function sofaSeats(item:FurnitureState,splits:readonly string[]=EMPTY_SPLITS):SofaSeat[]{
 if(!isSeat(item))return [];const front=furnitureFront(item);
 return furnitureSeatTiles(item).map((tile,index)=>({index,tile,approach:nextFloorTile(tile,{dx:front.x,dy:front.y},splits),direction:directionForMove(tile,{x:tile.x+front.x,y:tile.y+front.y})}));
}
/** Every adjacent leaf can be an entrance/exit, including diagonal and micro tiles. */
export function seatExits(item:FurnitureState,seat:SofaSeat,items:readonly FurnitureState[],splits:readonly string[]=EMPTY_SPLITS,entering=false):Position[]{
 const tile=tileForPosition(seat.tile,splits);if(!tile)return [];const base=item.z??0,scale=item.scale??1;
 return tileNeighbors(tile,splits).filter(p=>{const surface=surfaceAt(p,items);return surface.walkable&&surface.height<=base+Math.min(scale,p.size)+1e-9&&(!entering||surface.height>=base-1e-9);}).sort((a,b)=>Number(b.x===seat.approach.x&&b.y===seat.approach.y)-Number(a.x===seat.approach.x&&a.y===seat.approach.y)).map(p=>({x:p.x,y:p.y}));
}
export function seatApproachable(item:FurnitureState,seat:SofaSeat,items:readonly FurnitureState[],splits:readonly string[]=EMPTY_SPLITS){return seatExits(item,seat,items,splits,true).length>0;}
export function seatOccupied(id:string,index:number,players:readonly Player[],exceptId?:string){return players.some(p=>p.id!==exceptId&&p.seat?.furnitureId===id&&p.seat.index===index);}
export type PostureResult={ok:true;player:Player}|{ok:false;error:string};
export function sitPlayer(player:Player,id:unknown,index:unknown,items:readonly FurnitureState[],players:readonly Player[],splits:readonly string[]=EMPTY_SPLITS):PostureResult{
 const item=items.find(i=>i.id===id&&isSeat(i));if(!item||!Number.isInteger(index)||typeof index!=='number'||index<0||index>=sofaSeats(item,splits).length)return{ok:false,error:'Choose a sofa seat.'};
 if(player.seat){if(player.seat.furnitureId===id&&player.seat.index===index)return{ok:true,player};return{ok:false,error:'Stand up before changing seats.'};}
 const seat=sofaSeats(item,splits)[index];if(!seatExits(item,seat,items,splits,true).some(p=>p.x===player.position.x&&p.y===player.position.y))return{ok:false,error:'Reach a safe adjacent space at the seat’s level first.'};
 if(seatOccupied(item.id,index,players,player.id))return{ok:false,error:'That sofa seat is occupied.'};
 return{ok:true,player:{...player,position:{...seat.tile},direction:seat.direction,seat:{furnitureId:item.id,index}}};
}
export function standPlayer(player:Player,items:readonly FurnitureState[],splits:readonly string[]=EMPTY_SPLITS,towards?:Position):PostureResult{
 if(!player.seat)return{ok:true,player};const item=items.find(i=>i.id===player.seat!.furnitureId),seat=item&&sofaSeats(item,splits)[player.seat.index];
 if(!item||!seat)return{ok:false,error:'That seat is no longer available.'};
 if(towards&&!tileForPosition(towards,splits))return{ok:false,error:'Choose a valid floor tile.'};
 const exits=seatExits(item,seat,items,splits);if(towards){const costs=new Map(exits.map(p=>{const route=findWalkPath(p,towards,items,splits);return [p,route?route.length:10000+Math.hypot(p.x-towards.x,p.y-towards.y)] as const;}));exits.sort((a,b)=>costs.get(a)!-costs.get(b)!);}
 const p=exits[0];if(!p)return{ok:false,error:'Clear an adjacent space before standing up.'};
 const {seat:oldSeat,...standing}=player;return{ok:true,player:{...standing,position:{...p},direction:directionForMove(seat.tile,p)}};
}
/** A seat is a movement destination, never a tile that a route walks through. */
export function movePlayer(player:Player,to:Position,items:readonly FurnitureState[],players:readonly Player[],splits:readonly string[]=EMPTY_SPLITS,bounds=DEFAULT_FLOOR):PostureResult{
 if(player.seat)return{ok:false,error:'Stand up before walking.'};
 const sofa=items.find(i=>isSeat(i)&&sofaSeats(i,splits).some(s=>s.tile.x===to.x&&s.tile.y===to.y));
 if(sofa){const seat=sofaSeats(sofa,splits).find(s=>s.tile.x===to.x&&s.tile.y===to.y)!;return sitPlayer(player,sofa.id,seat.index,items,players,splits);}
 if(!canStep(player.position,to,items,splits,bounds))return{ok:false,error:'There is no safe step there.'};
 return{ok:true,player:{...player,position:{...to},direction:directionForMove(player.position,to)}};
}
export function findPlayerPath(from:Position,to:Position,items:readonly FurnitureState[],players:readonly Player[],splits:readonly string[]=EMPTY_SPLITS,bounds=DEFAULT_FLOOR):Position[]|null{
 const sofa=items.find(i=>isSeat(i)&&sofaSeats(i,splits).some(s=>s.tile.x===to.x&&s.tile.y===to.y));
 if(!sofa)return findWalkPath(from,to,items,splits,bounds);
 const seat=sofaSeats(sofa,splits).find(s=>s.tile.x===to.x&&s.tile.y===to.y)!;
 if(seatOccupied(sofa.id,seat.index,players))return null;
 const paths=seatExits(sofa,seat,items,splits,true).map(approach=>findWalkPath(from,approach,items,splits,bounds)).filter((path):path is Position[]=>path!==null).sort((a,b)=>a.length-b.length);
 return paths.length?[...paths[0],seat.tile]:null;
}
/** Placement validation has already checked the standing level and one avatar per cushion. */
export function seatPlayersUnderFurniture(players:readonly Player[],items:readonly FurnitureState[],splits:readonly string[]=EMPTY_SPLITS):Player[]{
 return players.map(player=>{
  if(player.seat)return player;
  for(const item of items){const seat=sofaSeats(item,splits).find(s=>s.tile.x===player.position.x&&s.tile.y===player.position.y);if(seat&&!seatOccupied(item.id,seat.index,players,player.id))return{...player,direction:seat.direction,seat:{furnitureId:item.id,index:seat.index}};}
  return player;
 });
}
/** Project the actual CSS cushion centre, rather than the sofa's taller backrest. */
export function sofaSeatAnchor(item:FurnitureState,seat:SofaSeatState,splits:readonly string[]=EMPTY_SPLITS){
 if(item.nft){const tile=sofaSeats(item,splits)[seat.index]?.tile||furnitureCenter(item);return{center:tile,x:0,y:(-item.nft.definition.height*HEIGHT_PIXELS-8)*(item.scale??1)};}
 const theta=(-45+item.rotation*90)*Math.PI/180,sign=(item.rotation===0||item.rotation===3)?1:-1;
 const x=(seat.index===0?sign:-sign)*27.5,y=4.5,scale=.62853936;
 return{center:furnitureCenter(item),x:(item.scale??1)*scale*(Math.cos(theta)*x-Math.sin(theta)*y),y:(item.scale??1)*scale*(.5*(Math.sin(theta)*x+Math.cos(theta)*y)-Math.sin(Math.PI/3)*40)};
}
