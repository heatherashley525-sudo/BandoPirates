import {furnitureTiles,furnitureCenter,type FurnitureState} from './furniture';
import {surfaceAt,canStep,findWalkPath} from './walking';
import {directionForMove} from './avatarDirections';
import type {Player,Position,Direction,SofaSeatState} from './types';
export interface SofaSeat {index:0|1;tile:Position;approach:Position;direction:Direction}
const fronts=[{x:1,y:0},{x:0,y:1},{x:-1,y:0},{x:0,y:-1}];
export function sofaSeats(item:FurnitureState):SofaSeat[]{
 if(item.kind!=='base-sofa')return [];const front=fronts[item.rotation];
 return furnitureTiles(item).map((tile,index)=>({index:index as 0|1,tile,approach:{x:tile.x+front.x,y:tile.y+front.y},direction:directionForMove(tile,{x:tile.x+front.x,y:tile.y+front.y})}));
}
export function seatApproachable(item:FurnitureState,seat:SofaSeat,items:readonly FurnitureState[]){const p=seat.approach,s=surfaceAt(p,items),base=item.z??0;return p.x>=1&&p.y>=1&&p.x<10&&p.y<10&&s.walkable&&s.height>=base&&s.height<=base+1;}
export function seatOccupied(id:string,index:number,players:readonly Player[],exceptId?:string){return players.some(p=>p.id!==exceptId&&p.seat?.furnitureId===id&&p.seat.index===index);}
export type PostureResult={ok:true;player:Player}|{ok:false;error:string};
export function sitPlayer(player:Player,id:unknown,index:unknown,items:readonly FurnitureState[],players:readonly Player[]):PostureResult{
 const item=items.find(i=>i.id===id&&i.kind==='base-sofa');if(!item||!Number.isInteger(index)||(index!==0&&index!==1))return{ok:false,error:'Choose a sofa seat.'};
 if(player.seat){if(player.seat.furnitureId===id&&player.seat.index===index)return{ok:true,player};return{ok:false,error:'Stand up before changing seats.'};}
 const seat=sofaSeats(item)[index];if(!seatApproachable(item,seat,items)||player.position.x!==seat.approach.x||player.position.y!==seat.approach.y)return{ok:false,error:'Reach a safe space at the front of the sofa first.'};
 if(seatOccupied(item.id,index,players,player.id))return{ok:false,error:'That sofa seat is occupied.'};
 return{ok:true,player:{...player,position:{...seat.tile},direction:seat.direction,seat:{furnitureId:item.id,index}}};
}
export function standPlayer(player:Player,items:readonly FurnitureState[]):PostureResult{
 if(!player.seat)return{ok:true,player};const item=items.find(i=>i.id===player.seat!.furnitureId),seat=item&&sofaSeats(item)[player.seat.index];
 if(!item||!seat)return{ok:false,error:'That sofa is no longer available.'};
 const p=seat.approach,s=surfaceAt(p,items);if(p.x<1||p.y<1||p.x>=10||p.y>=10||!s.walkable||s.height-(item.z??0)>1)return{ok:false,error:'Clear the space in front of this seat before standing up.'};
 const {seat:oldSeat,...standing}=player;return{ok:true,player:{...standing,position:{...p},direction:seat.direction}};
}
/** A seat is a movement destination, never a tile that a route walks through. */
export function movePlayer(player:Player,to:Position,items:readonly FurnitureState[],players:readonly Player[]):PostureResult{
 if(player.seat)return{ok:false,error:'Stand up before walking.'};
 const sofa=items.find(i=>i.kind==='base-sofa'&&sofaSeats(i).some(s=>s.tile.x===to.x&&s.tile.y===to.y));
 if(sofa){const seat=sofaSeats(sofa).find(s=>s.tile.x===to.x&&s.tile.y===to.y)!;return sitPlayer(player,sofa.id,seat.index,items,players);}
 if(!canStep(player.position,to,items))return{ok:false,error:'There is no safe step there.'};
 return{ok:true,player:{...player,position:{...to},direction:directionForMove(player.position,to)}};
}
export function findPlayerPath(from:Position,to:Position,items:readonly FurnitureState[],players:readonly Player[]):Position[]|null{
 const sofa=items.find(i=>i.kind==='base-sofa'&&sofaSeats(i).some(s=>s.tile.x===to.x&&s.tile.y===to.y));
 if(!sofa)return findWalkPath(from,to,items);
 const seat=sofaSeats(sofa).find(s=>s.tile.x===to.x&&s.tile.y===to.y)!;
 if(!seatApproachable(sofa,seat,items)||seatOccupied(sofa.id,seat.index,players))return null;
 const path=findWalkPath(from,seat.approach,items);return path&&[...path,seat.tile];
}
/** Placement validation has already checked the standing level and one avatar per cushion. */
export function seatPlayersUnderFurniture(players:readonly Player[],items:readonly FurnitureState[]):Player[]{
 return players.map(player=>{
  if(player.seat)return player;
  for(const item of items){const seat=sofaSeats(item).find(s=>s.tile.x===player.position.x&&s.tile.y===player.position.y);if(seat&&!seatOccupied(item.id,seat.index,players,player.id))return{...player,direction:seat.direction,seat:{furnitureId:item.id,index:seat.index}};}
  return player;
 });
}
/** Project the actual CSS cushion centre, rather than the sofa's taller backrest. */
export function sofaSeatAnchor(item:FurnitureState,seat:SofaSeatState){
 const theta=(-45+item.rotation*90)*Math.PI/180,sign=(item.rotation===0||item.rotation===3)?1:-1;
 const x=(seat.index===0?sign:-sign)*27.5,y=4.5,scale=.62853936;
 return{center:furnitureCenter(item),x:scale*(Math.cos(theta)*x-Math.sin(theta)*y),y:scale*(.5*(Math.sin(theta)*x+Math.cos(theta)*y)-Math.sin(Math.PI/3)*40)};
}
