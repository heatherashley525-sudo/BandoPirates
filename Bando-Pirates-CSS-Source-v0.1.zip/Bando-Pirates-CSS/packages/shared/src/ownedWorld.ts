import {validateTileSplits,splitTileError,floorTile,tileContains,tileOverlaps,EMPTY_SPLITS} from './microverse';
import {furnitureTiles} from './furniture';
import {parseAppearance,type AvatarAppearance} from './avatar';
import { editFurniture,placementError,resolvePlacement,supportEditError,type FurnitureKind,type FurnitureRotation,type FurnitureState } from './furniture';
import type { Position } from './types';
export interface SavedPlayer {id:string;name:string;grants?:string[];appearance?:AvatarAppearance}
export interface ItemPlacement {roomId:string;gx:number;gy:number;rotation:FurnitureRotation;scale?:number;z?:number;supportId?:string|null}
export interface OwnedItem {id:string;kind:FurnitureKind;ownerId:string;placement:ItemPlacement|null}
export interface RoomInfo {id:string;name:string;ownerId:string;ownerName:string;tileSplits?:string[]}
export interface WorldData {version:1;welcomeInitialized:boolean;profiles:Record<string,SavedPlayer>;furniture:Record<string,OwnedItem>;room:RoomInfo|null}
export interface InventoryEntry {id:string;kind:FurnitureKind;ownerId:string}
export interface WorldCommand {type:'move'|'rotate'|'place'|'pickup'|'delete-room'|'create-room'|'split-tile';tileId?:string;roomId?:string;id?:string;gx?:number;gy?:number;newRoomId?:string}
export type WorldResult={ok:true;world:WorldData}|{ok:false;error:string};
export function emptyWorld():WorldData{return {version:1,welcomeInitialized:false,profiles:{},furniture:{},room:null};}
export function inventoryFor(world:WorldData,userId:string):InventoryEntry[]{return Object.values(world.furniture).filter(i=>i.ownerId===userId&&!i.placement).map(({id,kind,ownerId})=>({id,kind,ownerId}));}
export function roomFurniture(world:WorldData):FurnitureState[]{
 if(!world.room)return [];
 return Object.values(world.furniture).filter(i=>i.placement?.roomId===world.room!.id).map(i=>({id:i.id,kind:i.kind,ownerId:i.ownerId,ownerName:world.profiles[i.ownerId]?.name||'Unknown player',gx:i.placement!.gx,gy:i.placement!.gy,rotation:i.placement!.rotation,scale:i.placement!.scale??1,z:i.placement!.z??0,supportId:i.placement!.supportId??null}));
}
export function registerPlayer(world:WorldData,id:string,name:string):WorldData {
 const next=structuredClone(world);const existing=next.profiles[id];next.profiles[id]={...existing,id,name};
 if(next.room?.ownerId===id)next.room.ownerName=name;
 if(!existing)for(const kind of ['base-sofa','base-table'] as const){const itemId=`${id}:${kind}`;next.furniture[itemId]={id:itemId,kind,ownerId:id,placement:null};}
 // A permanent grant marker keeps upgrades idempotent across reconnects and deletions.
 const grants=next.profiles[id].grants||[];
 if(!grants.includes('stacking-kit-v1')){
  for(const [suffix,kind] of [['stool','stool'],['base-table:extra','base-table']] as const){const itemId=`${id}:${suffix}`;if(!next.furniture[itemId])next.furniture[itemId]={id:itemId,kind,ownerId:id,placement:null};}
  next.profiles[id].grants=[...grants,'stacking-kit-v1'];
 }
 if(!next.welcomeInitialized){
  const roomId=`welcome-${id}`;next.room={id:roomId,name:`${name}'s room`,ownerId:id,ownerName:name};next.welcomeInitialized=true;
  next.furniture[`${id}:base-sofa`].placement={roomId,gx:3,gy:3,rotation:0};next.furniture[`${id}:base-table`].placement={roomId,gx:6,gy:3,rotation:0};next.furniture[`${id}:stool`].placement={roomId,gx:6,gy:4,rotation:0};
 }
 return next;
}
export function applyWorldCommand(world:WorldData,actorId:string,raw:unknown,players:readonly Position[]):WorldResult {
 const fail=(error:string):WorldResult=>({ok:false,error});
 if(!world.profiles[actorId])return fail('Player profile not found.');
 if(!raw||typeof raw!=='object')return fail('Invalid request.');
 const cmd=raw as WorldCommand;
 if(cmd.type==='create-room'){
  if(world.room)return fail('A room is already open.');
  if(typeof cmd.newRoomId!=='string'||!cmd.newRoomId)return fail('Invalid room.');
  const next=structuredClone(world),name=next.profiles[actorId].name;next.room={id:cmd.newRoomId,name:`${name}'s room`,ownerId:actorId,ownerName:name};return {ok:true,world:next};
 }
 if(!world.room||cmd.roomId!==world.room.id)return fail('This room is no longer open.');
 if(cmd.type==='delete-room'){
  if(world.room.ownerId!==actorId)return fail('Only the room owner can delete this room.');
  const next=structuredClone(world);for(const item of Object.values(next.furniture))if(item.placement?.roomId===world.room.id)item.placement=null;
  next.room=null;return {ok:true,world:next};
 }
 if(cmd.type==='split-tile'){
  if(world.room.ownerId!==actorId)return fail('Only the room owner can divide floor tiles.');
  const splits=world.room.tileSplits||EMPTY_SPLITS,error=splitTileError(cmd.tileId,splits);if(error)return fail(error);
  const tile=floorTile(cmd.tileId!,splits)!;
  if(players.some(p=>tileContains(tile,p)))return fail('Move the avatar off this tile before dividing it.');
  if(roomFurniture(world).some(item=>furnitureTiles(item).some(p=>tileOverlaps(tile,tile.size,p,item.scale??1))))return fail('Clear the furniture from this tile before dividing it.');
  const next=structuredClone(world);next.room!.tileSplits=[...splits,cmd.tileId!].sort();return{ok:true,world:next};
 }
 const item=typeof cmd.id==='string'?world.furniture[cmd.id]:null;if(!item)return fail('Choose a piece of furniture.');
 const next=structuredClone(world),record=next.furniture[item.id];
 if(cmd.type==='place'){
  if(item.ownerId!==actorId)return fail('You can only place furniture from your own inventory.');
  if(item.placement)return fail('That item is already placed.');
  if(typeof cmd.gx!=='number'||typeof cmd.gy!=='number')return fail('Choose a floor tile.');
  const candidate=resolvePlacement({id:item.id,kind:item.kind,gx:cmd.gx,gy:cmd.gy,rotation:0},cmd.gx,cmd.gy,roomFurniture(world),world.room.tileSplits);
  const error=placementError(candidate,roomFurniture(world),players,world.room.tileSplits);if(error)return fail(error);
  record.placement={roomId:world.room.id,gx:cmd.gx,gy:cmd.gy,rotation:0,scale:candidate.scale,z:candidate.z,supportId:candidate.supportId};return {ok:true,world:next};
 }
 if(item.placement?.roomId!==world.room.id)return fail('That item is not in this room.');
 if(cmd.type==='pickup'){
  if(item.ownerId!==actorId&&world.room.ownerId!==actorId)return fail('Only its owner or the room owner can pick up that item.');
  const blocked=supportEditError(roomFurniture(world).find(i=>i.id===item.id)!,roomFurniture(world),players);if(blocked)return fail(blocked);
  record.placement=null;return {ok:true,world:next};
 }
 if(cmd.type==='move'||cmd.type==='rotate'){
  const result=editFurniture(roomFurniture(world),{action:cmd.type,id:item.id,gx:cmd.gx,gy:cmd.gy},actorId,world.room.ownerId,players,world.room.tileSplits);
  if(!result.ok)return fail(result.error);const updated=result.furniture.find(i=>i.id===item.id)!;
  record.placement={roomId:world.room.id,gx:updated.gx,gy:updated.gy,rotation:updated.rotation,scale:updated.scale,z:updated.z,supportId:updated.supportId};return {ok:true,world:next};
 }
 return fail('Invalid furniture action.');
}
export function validateWorld(value:unknown):WorldData {
 const world=value as WorldData;
 if(!world||world.version!==1||typeof world.welcomeInitialized!=='boolean'||!world.profiles||Array.isArray(world.profiles)||!world.furniture||Array.isArray(world.furniture)||!('room' in world))throw Error('Invalid saved world.');
 for(const [id,profile] of Object.entries(world.profiles))if(profile.id!==id||typeof profile.name!=='string'||(profile.grants!==undefined&&(!Array.isArray(profile.grants)||profile.grants.some(g=>typeof g!=='string')))||(profile.appearance!==undefined&&!parseAppearance(profile.appearance)))throw Error('Invalid saved player.');
 for(const [id,item] of Object.entries(world.furniture)){
  if((item.kind as string)==='base-stool')item.kind='base-table';
  if(item.id!==id||!world.profiles[item.ownerId]||!['base-sofa','base-table','stool'].includes(item.kind))throw Error('Invalid saved furniture.');
  if(item.placement&&(!world.room||item.placement.roomId!==world.room.id||![0,1,2,3].includes(item.placement.rotation)))throw Error('Invalid furniture placement.');
 }
 if(world.room){
  if(world.room.tileSplits!==undefined)world.room.tileSplits=validateTileSplits(world.room.tileSplits);
  if(typeof world.room.id!=='string'||typeof world.room.name!=='string'||!world.profiles[world.room.ownerId])throw Error('Invalid room owner.');
  const placed=roomFurniture(world);
  for(const item of placed)if(placementError(item,placed,[],world.room.tileSplits))throw Error('Invalid saved furniture placement.');
 }
 return world;
}
