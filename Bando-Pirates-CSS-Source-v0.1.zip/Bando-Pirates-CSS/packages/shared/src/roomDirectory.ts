import type {RoomInfo} from './ownedWorld';
import {PUBLIC_STREET,PUBLIC_STREET_ID} from './publicStreet';

export type RoomDestination = 'player-room' | typeof PUBLIC_STREET_ID;
export interface RoomDirectoryEntry {
  name: string;
  destination: RoomDestination;
}

export function listAvailableRooms(playerRoom: RoomInfo | null): RoomDirectoryEntry[] {
  const rooms: RoomDirectoryEntry[] = [{name: PUBLIC_STREET.name,destination: PUBLIC_STREET_ID}];
  if (playerRoom) rooms.push({name: playerRoom.name,destination: 'player-room'});
  return rooms;
}
