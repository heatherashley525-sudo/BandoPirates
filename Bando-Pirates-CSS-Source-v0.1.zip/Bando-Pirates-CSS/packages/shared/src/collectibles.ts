export const PUBLIC_TEST_WALLET='0x71a780c3a25dd7a22901781764f1200fa24e8e15';
/** Published contract addresses from collectibles.habbo.com/traits/editor/ runtimeConfig (2026-11-08). */
export const HABBO_COLLECTIONS=[
 {id:'genesis',name:'Genesis avatars',chainId:1,contract:'0x8a1bbef259b00ced668a8c69e50d92619c672176',kind:'avatar',metadata:'avatars'},
 {id:'crafted',name:'Crafted avatars',chainId:1,contract:'0x852ab534c93bb308553bc5e960ea8916a89a9955',kind:'avatar',metadata:'crafted-avatars'},
 {id:'furni',name:'Furniture',chainId:13371,contract:'0x33976ee1477c75171b2b34814d75ebc37413e589',kind:'item',metadata:'collectibles/furni'},
 {id:'clothes',name:'Clothing',chainId:13371,contract:'0xdbf185750d135ea5581f9853db9f9657fb843a62',kind:'item',metadata:'collectibles/clothes'},
 {id:'pets',name:'Pets',chainId:13371,contract:'0xb7727da90019d072a5f8fdd58ff4522f796a20c5',kind:'item',metadata:'collectibles/pets'},
 {id:'addons',name:'Add-ons',chainId:13371,contract:'0x2da5094f8c6cd42f5b3b24803f998a28b40a398f',kind:'item',metadata:'collectibles/addons'},
 {id:'tokens',name:'Collectible tokens',chainId:13371,contract:'0xe06f06a4128373ecc5444881a6a26fc18723487a',kind:'item',metadata:'collectibles/tokens'},
] as const;
export type CollectionId=typeof HABBO_COLLECTIONS[number]['id'];
export interface HabboFurnitureDefinition {classname:string;revision:number;width:number;depth:number;height:number;seat:boolean;walkable:boolean;stackable:boolean;directions:number[];states:number[]}
export type CollectibleFinish='gold'|'diamond'|'rainbow'|'trippy';
export interface HabboFurnitureIcon {classname:string;revision:number}
export interface CollectibleAsset {key:string;collection:CollectionId;chainId:number;contract:string;tokenId:string;name:string;image:string;kind:'avatar'|'item';figure?:string;finish?:CollectibleFinish;furniture?:HabboFurnitureDefinition;furnitureIcon?:HabboFurnitureIcon;test?:boolean}
function validFurnitureArtwork(icon:HabboFurnitureIcon):boolean{
 return typeof icon.classname==='string'&&/^nft_[a-zA-Z0-9_]{1,95}$/.test(icon.classname)&&Number.isSafeInteger(icon.revision)&&icon.revision>=1;
}
export function habboFurnitureIconUrl(icon:HabboFurnitureIcon):string|null{
 if(!validFurnitureArtwork(icon))return null;
 return `https://images.habbo.com/dcr/hof_furni/${icon.revision}/${icon.classname}_icon.png`;
}
export function habboFurnitureSpriteUrl(icon:HabboFurnitureIcon,direction=2,state=0):string|null{
 if(!validFurnitureArtwork(icon))return null;
 const url=new URL(`https://www.habboassets.com/imaging/furniture/${icon.classname}.png`);
 url.search=new URLSearchParams({revision:String(icon.revision),direction:String(direction),state:String(state),size:'64'}).toString();
 return url.href;
}
export function parseHabboFurnitureDefinition(value:unknown):HabboFurnitureDefinition|null{
 if(!value||typeof value!=='object')return null;const d=value as HabboFurnitureDefinition;
 if(typeof d.classname!=='string'||!/^nft_[a-zA-Z0-9_]{1,95}$/.test(d.classname)||!Number.isSafeInteger(d.revision)||d.revision<1)return null;
 if(![d.width,d.depth].every(n=>Number.isInteger(n)&&n>=1&&n<=9)||!Number.isFinite(d.height)||d.height<0||d.height>32)return null;
 if(![d.seat,d.walkable,d.stackable].every(n=>typeof n==='boolean')||!Array.isArray(d.directions)||!d.directions.length||d.directions.length>4||d.directions.some(n=>![0,2,4,6].includes(n))||new Set(d.directions).size!==d.directions.length)return null;
 if(!Array.isArray(d.states)||!d.states.length||d.states.length>32||d.states.some(n=>!Number.isInteger(n)||n<0||n>255))return null;
 return {classname:d.classname,revision:d.revision,width:d.width,depth:d.depth,height:d.height,seat:d.seat,walkable:d.walkable,stackable:d.stackable,directions:[...d.directions],states:[...new Set(d.states)]};
}
export function habboFurnitureImageUrl(definition:HabboFurnitureDefinition,rotation=0,state=0){
 const d=parseHabboFurnitureDefinition(definition);if(!d)throw Error('Unsupported furniture definition.');
 const direction=d.directions[((Math.trunc(rotation)%d.directions.length)+d.directions.length)%d.directions.length];
 return habboFurnitureSpriteUrl(d,direction,d.states.includes(state)?state:d.states[0])!;
}
export interface WalletState {address:string|null;expiresAt?:number;message?:string;mode?:'verified'|'test'}
export interface CollectiblePage {assets:CollectibleAsset[];nextCursor:string|null}
export interface WalletChallenge {message:string;address:string;chainId:number;expiresAt:number;origin:string}
export type WalletReply<T>={ok:true;value:T}|{ok:false;error:string};
export function collectionById(id:unknown){return HABBO_COLLECTIONS.find(c=>c.id===id);}
export function parseTokenId(value:unknown):string|null{
 if(typeof value!=='string'||! /^(0|[1-9][0-9]{0,77})$/.test(value))return null;
 try{return BigInt(value)<2n**256n?value:null;}catch{return null;}
}
export function safeCollectibleImage(value:unknown):string|null{
 if(typeof value!=='string'||value.length>512)return null;
 try{const u=new URL(value);return u.origin==='https://nft-tokens.habbo.com'&&!u.username&&!u.password&&!u.search&&!u.hash&&/^\/(avatars|crafted-avatars|collectibles\/(furni|clothes|pets|addons|tokens))\/images\/[a-zA-Z0-9_/-]+\.(png|gif)$/.test(u.pathname)?u.href:null;}catch{return null;}
}
