import {EMPTY_SPLITS,nextFloorTile,tileForPosition,tileNeighbors,floorTiles,tileOverlaps,type FloorTile} from './microverse';
import type {Position} from './types';
import type {CollectibleAsset,HabboFurnitureDefinition} from './collectibles';
export type FurnitureRotation=0|1|2|3;
export type FurnitureKind='base-sofa'|'base-table'|'stool'|'habbo-nft';
export interface FurnitureState {ownerId?:string;ownerName?:string;id:string;kind:FurnitureKind;gx:number;gy:number;rotation:FurnitureRotation;scale?:number;z?:number;supportId?:string|null;nft?:{asset:CollectibleAsset;definition:HabboFurnitureDefinition};state?:number}
export interface RoomOwner {id:string|null;name:string|null}
export type FurnitureEdit={action:'rotate';id:string}|{action:'move';id:string;gx:number;gy:number};
export type FurnitureEditResult={ok:true;furniture:FurnitureState[]}|{ok:false;error:string};
export const BASE_SOFA:FurnitureState={id:'base-sofa',kind:'base-sofa',gx:3,gy:3,rotation:0};
export const BASE_TABLE:FurnitureState={id:'base-table',kind:'base-table',gx:6,gy:3,rotation:0};
export const STOOL:FurnitureState={id:'stool',kind:'stool',gx:6,gy:4,rotation:0};
export const FURNITURE_NAMES:Record<FurnitureKind,string>={'base-sofa':'Base sofa','base-table':'Base table','stool':'Stool','habbo-nft':'NFT furniture'};
export const FURNITURE_HEIGHT:Record<FurnitureKind,number>={'base-sofa':3,'base-table':2,'stool':1,'habbo-nft':1};
export const HEIGHT_PIXELS=16;
export function createRoomFurniture():FurnitureState[]{return [{...BASE_SOFA},{...BASE_TABLE},{...STOOL}];}
export function furnitureDirection(item:FurnitureState){return item.nft?item.nft.definition.directions[item.rotation%item.nft.definition.directions.length]:[2,4,6,0][item.rotation];}
export function furnitureRotationCount(item:FurnitureState){return item.nft?.definition.directions.length||4;}
export function furnitureName(item:FurnitureState){return (item.nft?.asset.name||FURNITURE_NAMES[item.kind])+(item.nft?.asset.test?' (test wallet)':'');}
export function furnitureFront(item:FurnitureState){return ({2:{x:1,y:0},4:{x:0,y:1},6:{x:-1,y:0},0:{x:0,y:-1}} as Record<number,Position>)[furnitureDirection(item)];}
export function isSeat(item:FurnitureState){return item.kind==='base-sofa'||item.kind==='habbo-nft'&&!!item.nft?.definition.seat;}
export function furnitureTiles(item:FurnitureState):Position[]{
 const origin={x:item.gx,y:item.gy},s=item.scale??1;
 if(item.kind==='habbo-nft'&&item.nft){const d=item.nft.definition,swap=furnitureDirection(item)%4===0,w=swap?d.depth:d.width,h=swap?d.width:d.depth;return Array.from({length:w*h},(_,i)=>({x:item.gx+(i%w)*s,y:item.gy+Math.floor(i/w)*s}));}
 if(item.kind!=='base-sofa')return [origin];return [origin,item.rotation%2===0?{x:item.gx,y:item.gy+s}:{x:item.gx+s,y:item.gy}];
}
export function furnitureSeatTiles(item:FurnitureState):Position[]{if(!isSeat(item))return [];const tiles=furnitureTiles(item);if(!item.nft)return tiles;const f=furnitureFront(item),axis=f.x?'x':'y',values=tiles.map(t=>t[axis]),edge=(f.x+f.y)>0?Math.max(...values):Math.min(...values);return tiles.filter(t=>t[axis]===edge);}
export function furnitureCenter(item:FurnitureState):Position{const tiles=furnitureTiles(item);return{x:tiles.reduce((n,t)=>n+t.x,0)/tiles.length,y:tiles.reduce((n,t)=>n+t.y,0)/tiles.length};}
export function furnitureObstacles(items:readonly FurnitureState[]):Set<string>{return new Set(items.flatMap(furnitureTiles).map(p=>`${p.x},${p.y}`));}
export function furnitureTop(item:FurnitureState){return (item.z??0)+(item.nft?.definition.height??FURNITURE_HEIGHT[item.kind])*(item.scale??1);}
export function isSurface(item:FurnitureState){return item.kind==='base-table'||item.kind==='stool'||!!item.nft&&!isSeat(item)&&(item.nft.definition.walkable||item.nft.definition.stackable);}
export function canSupportFurniture(item:FurnitureState){return item.nft?item.nft.definition.stackable:isSurface(item);}
export function coversTile(item:FurnitureState,pos:Position){return furnitureTiles(item).some(p=>Math.abs(p.x-pos.x)<(item.scale??1)/2-1e-9&&Math.abs(p.y-pos.y)<(item.scale??1)/2-1e-9);}
export function resolvePlacement(item:FurnitureState,gx:number,gy:number,items:readonly FurnitureState[],splits:readonly string[]=EMPTY_SPLITS):FurnitureState{
 const supports=items.filter(i=>i.id!==item.id&&canSupportFurniture(i)&&coversTile(i,{x:gx,y:gy})&&furnitureTop(i)>0).sort((a,b)=>furnitureTop(b)-furnitureTop(a));
 const support=supports[0];return {...item,gx,gy,scale:tileForPosition({x:gx,y:gy},splits)?.size??item.scale??1,z:support?furnitureTop(support):0,supportId:support?.id||null};
}
export function placementError(candidate:FurnitureState,items:readonly FurnitureState[],players:readonly Position[],splits:readonly string[]=EMPTY_SPLITS):string|null{
 const tiles=furnitureTiles(candidate),z=candidate.z??0;
 const scale=candidate.scale??1;
 if(!Number.isFinite(scale)||scale<=0||tiles.some(p=>{const tile=tileForPosition(p,splits);return !tile||Math.abs(tile.size-scale)>1e-9;}))return 'Keep the furniture inside matching floor tiles.';
 if(!Number.isFinite(z)||z<0)return 'Invalid stacking height.';
 if(z>0){const support=items.find(i=>i.id===candidate.supportId);if(!support||!canSupportFurniture(support)||!coversTile(support,{x:candidate.gx,y:candidate.gy})||Math.abs(furnitureTop(support)-z)>1e-8)return 'Elevated furniture needs a supporting table or Stool.';if(!candidate.nft&&support.nft)return 'Place saved inventory furniture on a permanent table or Stool.';}
 else if(candidate.supportId)return 'Invalid floor support.';
 for(const other of items){
  if(other.id===candidate.id)continue;
  const overlap=tiles.some(p=>furnitureTiles(other).some(q=>tileOverlaps(p,scale,q,other.scale??1)));
  if(overlap&&z<furnitureTop(other)&&(other.z??0)<furnitureTop(candidate))return 'Another piece of furniture occupies that height.';
 }
 for(const tile of tiles){
  const standing=players.filter(p=>Math.abs(p.x-tile.x)<scale/2-1e-9&&Math.abs(p.y-tile.y)<scale/2-1e-9);if(!standing.length)continue;
  if(!isSeat(candidate)||!furnitureSeatTiles(candidate).some(p=>p.x===tile.x&&p.y===tile.y))return 'A player is standing in that space.';
  if(standing.length>1)return 'Only one avatar can occupy each sofa seat.';
  const beneath=items.filter(i=>i.id!==candidate.id&&coversTile(i,tile));
  if(beneath.some(i=>!isSurface(i))||Math.max(0,...beneath.map(furnitureTop))!==z)return 'Place the seat at the avatar’s current floor level.';
  const floor=tileForPosition(tile,splits),clear=floor&&tileNeighbors(floor,splits).some(exit=>{if(coversTile(candidate,exit))return false;const covering=items.filter(i=>i.id!==candidate.id&&coversTile(i,exit));return !covering.some(i=>!isSurface(i))&&Math.max(0,...covering.map(furnitureTop))-z<=Math.min(scale,exit.size)+1e-9;});
  if(!clear)return 'Leave a clear adjacent exit before placing a seat beneath an avatar.';
 }
 return null;
}
export function supportEditError(item:FurnitureState,items:readonly FurnitureState[],players:readonly Position[]):string|null{
 if(items.some(i=>i.supportId===item.id))return 'Remove the items on top first.';
 if(players.some(p=>coversTile(item,p)))return 'A player is standing on that furniture.';
 return null;
}
export function editFurniture(items:readonly FurnitureState[],request:unknown,actorId:string,ownerId:string|null,players:readonly Position[],splits:readonly string[]=EMPTY_SPLITS):FurnitureEditResult{
 if(!ownerId||actorId!==ownerId)return{ok:false,error:'Only the room owner can move or rotate furniture.'};
 if(!request||typeof request!=='object')return{ok:false,error:'Invalid furniture request.'};
 const edit=request as Partial<FurnitureEdit>&{gx?:number;gy?:number},item=items.find(i=>i.id===edit.id);
 if(!item)return{ok:false,error:'Choose a piece of furniture.'};
 const blocked=supportEditError(item,items,players);if(blocked)return{ok:false,error:blocked};
 let next:FurnitureState;
 if(edit.action==='rotate')next={...item,rotation:((item.rotation+1)%furnitureRotationCount(item)) as FurnitureRotation};
 else if(edit.action==='move'&&typeof edit.gx==='number'&&typeof edit.gy==='number')next=resolvePlacement(item,edit.gx,edit.gy,items,splits);
 else return{ok:false,error:'Invalid furniture request.'};
 const error=placementError(next,items,players,splits);if(error)return{ok:false,error};
 return{ok:true,furniture:items.map(i=>i.id===item.id?next:{...i})};
}
export function findSpawn(items:readonly FurnitureState[],splits:readonly string[]=EMPTY_SPLITS):Position{
 if(!splits.length){if(!items.some(i=>coversTile(i,{x:5,y:5})))return{x:5,y:5};for(let x=1;x<10;x++)for(let y=1;y<10;y++)if(!items.some(i=>coversTile(i,{x,y})))return{x,y};return{x:5,y:5};}
 const leaves=[...floorTiles(splits)].sort((a,b)=>Math.hypot(a.x-5,a.y-5)-Math.hypot(b.x-5,b.y-5));const tile=leaves.find(p=>!items.some(i=>coversTile(i,p)));return tile?{x:tile.x,y:tile.y}:{x:5,y:5};
}
