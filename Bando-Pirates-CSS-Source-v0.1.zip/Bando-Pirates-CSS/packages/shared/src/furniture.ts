import type {Position} from './types';
export type FurnitureRotation=0|1|2|3;
export type FurnitureKind='base-sofa'|'base-table'|'stool';
export interface FurnitureState {ownerId?:string;ownerName?:string;id:string;kind:FurnitureKind;gx:number;gy:number;rotation:FurnitureRotation;z?:number;supportId?:string|null}
export interface RoomOwner {id:string|null;name:string|null}
export type FurnitureEdit={action:'rotate';id:string}|{action:'move';id:string;gx:number;gy:number};
export type FurnitureEditResult={ok:true;furniture:FurnitureState[]}|{ok:false;error:string};
export const BASE_SOFA:FurnitureState={id:'base-sofa',kind:'base-sofa',gx:3,gy:3,rotation:0};
export const BASE_TABLE:FurnitureState={id:'base-table',kind:'base-table',gx:6,gy:3,rotation:0};
export const STOOL:FurnitureState={id:'stool',kind:'stool',gx:6,gy:4,rotation:0};
export const FURNITURE_NAMES:Record<FurnitureKind,string>={'base-sofa':'Base sofa','base-table':'Base table','stool':'Stool'};
export const FURNITURE_HEIGHT:Record<FurnitureKind,number>={'base-sofa':3,'base-table':2,'stool':1};
export const HEIGHT_PIXELS=16;
export function createRoomFurniture():FurnitureState[]{return [{...BASE_SOFA},{...BASE_TABLE},{...STOOL}];}
export function furnitureTiles(item:FurnitureState):Position[]{const origin={x:item.gx,y:item.gy};if(item.kind!=='base-sofa')return [origin];return [origin,item.rotation%2===0?{x:item.gx,y:item.gy+1}:{x:item.gx+1,y:item.gy}];}
export function furnitureCenter(item:FurnitureState):Position{const tiles=furnitureTiles(item);return{x:tiles.reduce((n,t)=>n+t.x,0)/tiles.length,y:tiles.reduce((n,t)=>n+t.y,0)/tiles.length};}
export function furnitureObstacles(items:readonly FurnitureState[]):Set<string>{return new Set(items.flatMap(furnitureTiles).map(p=>`${p.x},${p.y}`));}
export function furnitureTop(item:FurnitureState){return (item.z??0)+FURNITURE_HEIGHT[item.kind];}
export function isSurface(item:FurnitureState){return item.kind==='base-table'||item.kind==='stool';}
export function coversTile(item:FurnitureState,pos:Position){return furnitureTiles(item).some(p=>p.x===pos.x&&p.y===pos.y);}
export function resolvePlacement(item:FurnitureState,gx:number,gy:number,items:readonly FurnitureState[]):FurnitureState{
 const supports=items.filter(i=>i.id!==item.id&&isSurface(i)&&coversTile(i,{x:gx,y:gy})).sort((a,b)=>furnitureTop(b)-furnitureTop(a));
 const support=supports[0];return {...item,gx,gy,z:support?furnitureTop(support):0,supportId:support?.id||null};
}
export function placementError(candidate:FurnitureState,items:readonly FurnitureState[],players:readonly Position[]):string|null{
 const tiles=furnitureTiles(candidate),z=candidate.z??0;
 if(tiles.some(p=>!Number.isInteger(p.x)||!Number.isInteger(p.y)||p.x<1||p.y<1||p.x>=10||p.y>=10))return 'Keep the furniture inside the room.';
 if(!Number.isSafeInteger(z)||z<0)return 'Invalid stacking height.';
 if(z>0){const support=items.find(i=>i.id===candidate.supportId);if(!support||!isSurface(support)||!coversTile(support,{x:candidate.gx,y:candidate.gy})||furnitureTop(support)!==z)return 'Elevated furniture needs a supporting table or Stool.';}
 else if(candidate.supportId)return 'Invalid floor support.';
 for(const other of items){
  if(other.id===candidate.id)continue;
  const overlap=tiles.some(p=>coversTile(other,p));
  if(overlap&&z<furnitureTop(other)&&(other.z??0)<furnitureTop(candidate))return 'Another piece of furniture occupies that height.';
 }
 for(const tile of tiles){
  const standing=players.filter(p=>p.x===tile.x&&p.y===tile.y);if(!standing.length)continue;
  if(candidate.kind!=='base-sofa')return 'A player is standing in that space.';
  if(standing.length>1)return 'Only one avatar can occupy each sofa seat.';
  const beneath=items.filter(i=>i.id!==candidate.id&&coversTile(i,tile));
  if(beneath.some(i=>!isSurface(i))||Math.max(0,...beneath.map(furnitureTop))!==z)return 'Place the seat at the avatar’s current floor level.';
  const front=[{x:1,y:0},{x:0,y:1},{x:-1,y:0},{x:0,y:-1}][candidate.rotation],exit={x:tile.x+front.x,y:tile.y+front.y};
  const atExit=items.filter(i=>i.id!==candidate.id&&coversTile(i,exit));
  if(exit.x<1||exit.y<1||exit.x>=10||exit.y>=10||atExit.some(i=>!isSurface(i))||Math.max(0,...atExit.map(furnitureTop))-z>1)return 'Leave a clear front exit before placing a seat beneath an avatar.';
 }
 return null;
}
export function supportEditError(item:FurnitureState,items:readonly FurnitureState[],players:readonly Position[]):string|null{
 if(items.some(i=>i.supportId===item.id))return 'Remove the items on top first.';
 if(players.some(p=>coversTile(item,p)))return 'A player is standing on that furniture.';
 return null;
}
export function editFurniture(items:readonly FurnitureState[],request:unknown,actorId:string,ownerId:string|null,players:readonly Position[]):FurnitureEditResult{
 if(!ownerId||actorId!==ownerId)return{ok:false,error:'Only the room owner can move or rotate furniture.'};
 if(!request||typeof request!=='object')return{ok:false,error:'Invalid furniture request.'};
 const edit=request as Partial<FurnitureEdit>&{gx?:number;gy?:number},item=items.find(i=>i.id===edit.id);
 if(!item)return{ok:false,error:'Choose a piece of furniture.'};
 const blocked=supportEditError(item,items,players);if(blocked)return{ok:false,error:blocked};
 let next:FurnitureState;
 if(edit.action==='rotate')next={...item,rotation:((item.rotation+1)%4) as FurnitureRotation};
 else if(edit.action==='move'&&typeof edit.gx==='number'&&typeof edit.gy==='number')next=resolvePlacement(item,edit.gx,edit.gy,items);
 else return{ok:false,error:'Invalid furniture request.'};
 const error=placementError(next,items,players);if(error)return{ok:false,error};
 return{ok:true,furniture:items.map(i=>i.id===item.id?next:{...i})};
}
export function findSpawn(items:readonly FurnitureState[]):Position{const blocked=furnitureObstacles(items);if(!blocked.has('5,5'))return{x:5,y:5};for(let x=1;x<10;x++)for(let y=1;y<10;y++)if(!blocked.has(`${x},${y}`))return{x,y};return{x:5,y:5};}
