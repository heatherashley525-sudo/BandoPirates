import type {AvatarAppearance} from './avatar';
export interface Position {
  x: number;
  y: number;
}

export interface ScreenPosition {
  screenX: number;
  screenY: number;
}

export interface Player {
  id: string;
  name: string;
  position: Position;
  direction: Direction;
  appearance?:AvatarAppearance;
  seat?:SofaSeatState;
}
export interface SofaSeatState {furnitureId:string;index:0|1}

export type Direction = "north" | "north-east" | "east" | "south-east" | "south" | "south-west" | "west" | "north-west";

export interface Room {
  id: string;
  name: string;
  ownerId: string;
  players: Map<string, Player>;
  width: number;
  height: number;
}

export interface ChatMessage {
  id: string;
  playerId: string;
  playerName: string;
  content: string;
  timestamp: number;
}
