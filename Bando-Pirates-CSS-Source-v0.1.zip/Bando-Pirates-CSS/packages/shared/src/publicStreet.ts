import {tileChildren,tileFromId,type FloorBounds} from './microverse';
import type {RoomInfo} from './ownedWorld';

export const PUBLIC_STREET_ID = 'public-street';
export const PUBLIC_STREET_FLOOR: Readonly<FloorBounds> = Object.freeze({minX:4,maxX:6,minY:2,maxY:7});
export const PUBLIC_STREET_ENTRANCE = '5,7';
export const PUBLIC_STREET_SPAWN = Object.freeze({x:5,y:6});

const entrance = tileFromId(PUBLIC_STREET_ENTRANCE)!;
const quarters = tileChildren(entrance);
export const PUBLIC_STREET = {
  id: PUBLIC_STREET_ID,
  name: 'Public Street',
  ownerId: '',
  ownerName: '',
  tileSplits: [entrance,...quarters,...quarters.flatMap(tileChildren)].map(tile=>tile.id),
} satisfies RoomInfo;
