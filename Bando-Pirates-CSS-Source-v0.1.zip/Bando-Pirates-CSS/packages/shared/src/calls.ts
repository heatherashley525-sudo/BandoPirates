/** Signaling metadata only. Audio/video travels over WebRTC. */
export interface CallMedia {audio:boolean;video:boolean}
export interface CallMember extends CallMedia {id:string;name:string}
export interface PendingCallInvite {id:string;name:string;expiresAt:number}
export interface CallState {id:string;roomId:string;kind:'private'|'room'|'broadcast';members:CallMember[];invited:PendingCallInvite[];presenterId?:string}
export interface CallInvite {callId:string;fromId:string;fromName:string;expiresAt:number}
export interface CallRosterEntry {id:string;name:string;busy:boolean}
export interface RoomBroadcast extends CallMedia {callId:string;presenterId:string;presenterName:string;viewers:number}
export interface CallRoster {players:CallRosterEntry[];roomCount:number;broadcast:RoomBroadcast|null}
export interface CallSignal {callId:string;to:string;from?:string;description?:{type:'offer'|'answer';sdp:string};candidate?:{candidate:string;sdpMid:string|null;sdpMLineIndex:number|null;usernameFragment?:string|null}}
export interface CallIceConfig {iceServers:{urls:string|string[];username?:string;credential?:string}[];relayAvailable:boolean}
export type CallReply<T=undefined>={ok:true;value:T}|{ok:false;error:string};
/** Broadcasts form a presenter-to-viewer star; private/room calls form a mesh. */
export function callPeerIds(call:CallState,self:string){return call.members.filter(m=>m.id!==self&&(call.kind!=='broadcast'||self===call.presenterId||m.id===call.presenterId)).map(m=>m.id);}
export function callDirection(call:CallState,self:string):RTCDirection {return call.kind==='broadcast'?(self===call.presenterId?'sendonly':'recvonly'):'sendrecv';}
type RTCDirection='sendrecv'|'sendonly'|'recvonly';
