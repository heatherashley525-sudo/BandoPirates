import {parseHabboFigure} from './avatarDirections';
import type {WorldData} from './ownedWorld';
export interface AvatarAppearance {
 version:1;preset?:'heather';habboFigure?:string;breastSize?:number;skin:string;face:'blank'|'simple';hair:'none'|'short'|'long';hairColor:string;
 top:'none'|'tee';topColor:string;bottom:'none'|'shorts'|'trousers';bottomColor:string;
 shoes:'none'|'shoes';shoeColor:string;accessory:'none'|'bow';
}
export function blankAppearance():AvatarAppearance{return {version:1,breastSize:0,skin:'#f0c29f',face:'blank',hair:'none',hairColor:'#eac26d',top:'none',topColor:'#e995c4',bottom:'none',bottomColor:'#62566e',shoes:'none',shoeColor:'#e4d9e7',accessory:'none'};}
export function defaultAppearance(color=0xe995c4):AvatarAppearance{return {...blankAppearance(),face:'simple',hair:'long',top:'tee',topColor:`#${(color>>>0&0xffffff).toString(16).padStart(6,'0')}`,bottom:'trousers',shoes:'shoes',accessory:'bow'};}
export function heatherAppearance():AvatarAppearance{
 return {...blankAppearance(),preset:'heather',skin:'#e9aa8c',hairColor:'#e8c178',face:'simple',hair:'long'};
}
const choices:Record<string,readonly unknown[]>={version:[1],face:['blank','simple'],hair:['none','short','long'],top:['none','tee'],bottom:['none','shorts','trousers'],shoes:['none','shoes'],accessory:['none','bow']};
const colors=['skin','hairColor','topColor','bottomColor','shoeColor'];
/** Accept only known slots and literal hex colours; never remote HTML, URLs or CSS. */
export function parseAppearance(value:unknown):AvatarAppearance|null {
 if(!value||typeof value!=='object'||Array.isArray(value))return null;
 const raw=value as Record<string,unknown>,keys=[...Object.keys(choices),...colors];
 const optional=['habboFigure','breastSize','preset'];
 if(Object.keys(raw).length!==keys.length+optional.filter(k=>Object.hasOwn(raw,k)).length||Object.keys(raw).some(k=>!keys.includes(k)&&!optional.includes(k)))return null;
 if(raw.preset!==undefined&&raw.preset!=='heather')return null;
 if(raw.habboFigure!==undefined&&!parseHabboFigure(raw.habboFigure))return null;
 if(raw.breastSize!==undefined&&(typeof raw.breastSize!=='number'||!Number.isInteger(raw.breastSize)||raw.breastSize<0||raw.breastSize>100))return null;
 for(const [key,values] of Object.entries(choices))if(!values.includes(raw[key]))return null;
 for(const key of colors)if(typeof raw[key]!=='string'||!/^#[0-9a-fA-F]{6}$/.test(raw[key] as string))return null;
 return {...raw,breastSize:raw.breastSize??0} as unknown as AvatarAppearance;
}
export function saveAppearance(world:WorldData,userId:string,value:unknown):{ok:true;world:WorldData;appearance:AvatarAppearance}|{ok:false;error:string}{
 const appearance=parseAppearance(value);if(!appearance)return {ok:false,error:'Choose valid avatar layers and colours.'};
 if(!world.profiles[userId])return {ok:false,error:'Player profile not found.'};
 const next=structuredClone(world);next.profiles[userId].appearance=appearance;return {ok:true,world:next,appearance};
}
