import type {Position} from './types';
export const MAX_TILE_DEPTH=8,MAX_ROOM_LEAVES=4096;
export interface FloorTile extends Position {id:string;size:number;depth:number}
export const EMPTY_SPLITS:readonly string[]=Object.freeze([]);
const EPS=1e-9;
export function tileFromId(id:unknown):FloorTile|null {
 if(typeof id!=='string'||!/^[1-9],[1-9](\/[0-3]{1,8})?$/.test(id))return null;
 const [root,path='']=id.split('/');let [x,y]=root.split(',').map(Number),size=1;
 for(const digit of path){const n=Number(digit);x+=(n%2?1:-1)*size/4;y+=(n>=2?1:-1)*size/4;size/=2;}
 return{id,x,y,size,depth:path.length};
}
export function tileChildren(tile:FloorTile):FloorTile[]{return Array.from({length:4},(_,i)=>tileFromId(tile.id+(tile.depth?'':'/')+i)!).filter(Boolean);}
export function parentTileId(id:string){const [root,path='']=id.split('/');return path.length>1?root+'/'+path.slice(0,-1):path?root:null;}
export function validateTileSplits(raw:unknown):string[]{
 if(raw===undefined)return[];
 if(!Array.isArray(raw)||raw.length>(MAX_ROOM_LEAVES-81)/3||raw.some(id=>typeof id!=='string')||new Set(raw).size!==raw.length)throw Error('Invalid divided floor.');
 const ids=new Set<string>(raw);
 for(const id of ids){const tile=tileFromId(id),parent=tile&&parentTileId(id);if(!tile||tile.depth>=MAX_TILE_DEPTH||parent&&!ids.has(parent))throw Error('Invalid divided floor.');}
 return [...ids].sort();
}
interface FloorIndex {leaves:FloorTile[];byId:Map<string,FloorTile>;splits:Set<string>;neighbors?:Map<string,FloorTile[]>}
const cache=new WeakMap<readonly string[],FloorIndex>();
function floorIndex(splits:readonly string[]=EMPTY_SPLITS):FloorIndex {
 const cached=cache.get(splits);if(cached)return cached;
 const set=new Set(splits),leaves:FloorTile[]=[];const visit=(tile:FloorTile)=>{if(set.has(tile.id)&&tile.depth<MAX_TILE_DEPTH)tileChildren(tile).forEach(visit);else leaves.push(tile);};
 for(let x=1;x<10;x++)for(let y=1;y<10;y++)visit({id:x+','+y,x,y,size:1,depth:0});
 const index={leaves,byId:new Map(leaves.map(t=>[t.id,t])),splits:set};cache.set(splits,index);return index;
}
export function floorTiles(splits:readonly string[]=EMPTY_SPLITS):readonly FloorTile[]{return floorIndex(splits).leaves;}
export function floorTile(id:string,splits:readonly string[]=EMPTY_SPLITS){return floorIndex(splits).byId.get(id)||null;}
export function tileAt(pos:Position,splits:readonly string[]=EMPTY_SPLITS):FloorTile|null {
 if(!Number.isFinite(pos.x)||!Number.isFinite(pos.y)||pos.x<.5||pos.x>=9.5||pos.y<.5||pos.y>=9.5)return null;
 let tile=tileFromId(Math.floor(pos.x+.5)+','+Math.floor(pos.y+.5))!,set=floorIndex(splits).splits;
 while(set.has(tile.id)&&tile.depth<MAX_TILE_DEPTH){const child=(pos.x>=tile.x?1:0)+(pos.y>=tile.y?2:0);tile=tileChildren(tile)[child];}return tile;
}
export function tileForPosition(pos:Position,splits:readonly string[]=EMPTY_SPLITS){const t=tileAt(pos,splits);return t&&Math.abs(t.x-pos.x)<EPS&&Math.abs(t.y-pos.y)<EPS?t:null;}
export function tilesAdjacent(a:FloorTile,b:FloorTile){const dx=Math.abs(a.x-b.x),dy=Math.abs(a.y-b.y),half=(a.size+b.size)/2;return a.id!==b.id&&dx<=half+EPS&&dy<=half+EPS&&(Math.abs(dx-half)<EPS||Math.abs(dy-half)<EPS);}
export function tileNeighbors(tile:FloorTile,splits:readonly string[]=EMPTY_SPLITS):readonly FloorTile[]{
 const index=floorIndex(splits);if(!index.neighbors){const neighbors=new Map(index.leaves.map(t=>[t.id,[] as FloorTile[]]));for(let i=0;i<index.leaves.length;i++)for(let j=i+1;j<index.leaves.length;j++){const a=index.leaves[i],b=index.leaves[j];if(tilesAdjacent(a,b)){neighbors.get(a.id)!.push(b);neighbors.get(b.id)!.push(a);}}index.neighbors=neighbors;}return index.neighbors.get(tile.id)||[];
}
export function nextFloorTile(from:Position,delta:{dx:number;dy:number},splits:readonly string[]=EMPTY_SPLITS):Position {
 const tile=tileForPosition(from,splits);if(!tile||!delta.dx&&!delta.dy)return from;
 const offset=tile.size/2+1/1024,to=tileAt({x:tile.x+Math.sign(delta.dx)*offset,y:tile.y+Math.sign(delta.dy)*offset},splits);
 return to?{x:to.x,y:to.y}:from;
}
export function tileContains(tile:FloorTile,pos:Position){return pos.x>=tile.x-tile.size/2-EPS&&pos.x<tile.x+tile.size/2-EPS&&pos.y>=tile.y-tile.size/2-EPS&&pos.y<tile.y+tile.size/2-EPS;}
export function tileOverlaps(a:Position,sizeA:number,b:Position,sizeB:number){return Math.abs(a.x-b.x)<(sizeA+sizeB)/2-EPS&&Math.abs(a.y-b.y)<(sizeA+sizeB)/2-EPS;}
export function splitTileError(id:unknown,splits:readonly string[]=EMPTY_SPLITS){
 const tile=typeof id==='string'?floorTile(id,splits):null;if(!tile)return 'Choose an undivided floor tile.';
 if(tile.depth>=MAX_TILE_DEPTH)return 'This tile has reached the current eight-level depth limit.';
 if(floorTiles(splits).length+3>MAX_ROOM_LEAVES)return 'This room has reached its divided-tile limit.';
 return null;
}
