import type {Direction,Position} from './types';
/** Native Habbo direction order, 0..7. Screen compass names are explicit at the boundary. */
export const AVATAR_DIRECTIONS:readonly Direction[]=['north-east','east','south-east','south','south-west','west','north-west','north'];
export function toHabboDirection(direction:Direction){return AVATAR_DIRECTIONS.indexOf(direction);}
export function fromHabboDirection(value:number):Direction{return AVATAR_DIRECTIONS[((Math.trunc(value)%8)+8)%8];}
export function isAvatarDirection(value:unknown):value is Direction{return typeof value==='string'&&AVATAR_DIRECTIONS.includes(value as Direction);}
export function directionForMove(from:Position,to:Position):Direction{
 const dx=Math.sign(to.x-from.x),dy=Math.sign(to.y-from.y);
 if(!dx&&!dy)return 'south';
 const table:Record<string,Direction>={'0,-1':'north-east','1,-1':'east','1,0':'south-east','1,1':'south','0,1':'south-west','-1,1':'west','-1,0':'north-west','-1,-1':'north'};return table[`${dx},${dy}`];
}
export function parseHabboFigure(value:unknown):string|null{
 if(typeof value!=='string'||value.length>512)return null;
 return /^[a-z]{2}-\d{1,9}(?:-\d{1,9}){1,3}(?:\.[a-z]{2}-\d{1,9}(?:-\d{1,9}){1,3})*$/.test(value)?value:null;
}
/** Official image renderer; no arbitrary remote URLs or executable asset files. */
export function habboImageUrl(figure:string,direction:Direction,walking=false,frame=0,sitting=false):string{
 if(!parseHabboFigure(figure))throw Error('Invalid Habbo figure.');
 const url=new URL('https://www.habbo.com/habbo-imaging/avatarimage');url.search=new URLSearchParams({figure,direction:String(toHabboDirection(direction)),head_direction:String(toHabboDirection(direction)),size:'n',gesture:'sml',action:sitting?'sit':walking?'wlk':'std',frame:String(Math.abs(Math.trunc(frame))%4)}).toString();return url.href;
}
