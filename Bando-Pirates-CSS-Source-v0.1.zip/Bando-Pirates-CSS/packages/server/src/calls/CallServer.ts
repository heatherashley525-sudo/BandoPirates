import {randomUUID,createHmac} from 'node:crypto';
import type {Socket} from 'socket.io';
import {callPeerIds,type Player,type CallState,type CallMedia,type CallSignal,type CallIceConfig} from '@cocoworking/shared';
interface Session {socket:Socket;inviteTimes:number[];signalTimes:number[]}
interface Invitation {from:string;expiresAt:number;timer:ReturnType<typeof setTimeout>}
interface ActiveCall {state:CallState;invitations:Map<string,Invitation>}
export function callIceConfig(id:string,env:NodeJS.ProcessEnv=process.env,now=Date.now()):CallIceConfig {
 const urls=(env.BANDO_TURN_URLS||'').split(',').map(s=>s.trim()).filter(s=>/^turns?:[^\s]+$/.test(s));
 const config:CallIceConfig={iceServers:[{urls:'stun:stun.l.google.com:19302'}],relayAvailable:false};
 if(urls.length&&env.BANDO_TURN_SECRET){const username=`${Math.floor(now/1000)+3600}:${id}`;config.iceServers.push({urls,username,credential:createHmac('sha1',env.BANDO_TURN_SECRET).update(username).digest('base64')});config.relayAvailable=true;}
 return config;
}
/** Invitations are private; public calls require an explicit join. Viewers cannot transmit media. */
export class CallServer {
 private sessions=new Map<string,Session>();private calls=new Map<string,ActiveCall>();private membership=new Map<string,string>();
 constructor(private players:Map<string,Player>,private roomId:()=>string|undefined){}
 connect(socket:Socket){
  this.sessions.set(socket.id,{socket,inviteTimes:[],signalTimes:[]});
  const rpc=(event:string,action:(data:any)=>unknown)=>socket.on(event,(data,ack)=>{if(typeof ack!=='function')return;try{if(!this.sessions.has(socket.id)||!this.players.has(socket.id)||!this.roomId()||data?.roomId!==this.roomId())throw Error('This room is no longer open.');ack({ok:true,value:action(data)});}catch(e){ack({ok:false,error:e instanceof Error?e.message:'The call could not be updated.'});}});
  rpc('call:config',()=>callIceConfig(socket.id));
  rpc('call:invite',data=>{
   this.free(socket.id);this.checkInvite(socket.id,data.to);
   const call=this.create('private',[this.member(socket.id,data.media)]);this.membership.set(socket.id,call.state.id);this.invite(call,socket.id,data.to);this.publish(call);return call.state;
  });
  rpc('call:add-invite',data=>{
   const call=this.own(socket.id,data.callId);if(call.state.kind!=='private')throw Error('Invitations are available in private calls.');
   this.checkInvite(socket.id,data.to);this.invite(call,socket.id,data.to);this.publish(call);return call.state;
  });
  rpc('call:accept',data=>{
   this.free(socket.id);const call=this.calls.get(data.callId),invite=call?.invitations.get(socket.id);
   if(!call||!invite||invite.expiresAt<=Date.now()||!call.state.members.some(m=>m.id===invite.from))throw Error('This invitation has ended.');
   call.state.members.push(this.member(socket.id,data.media));this.clearInvite(call,socket.id);this.membership.set(socket.id,call.state.id);this.publish(call);return call.state;
  });
  rpc('call:decline',data=>{const call=this.calls.get(data.callId);if(call?.invitations.has(socket.id)){this.clearInvite(call,socket.id);this.prunePrivate(call,'Invitation declined.');}});
  rpc('call:join-room',data=>{
   this.free(socket.id);const member=this.member(socket.id,data.media);let call=this.publicCall('room');
   if(!call)call=this.create('room',[]);call.state.members.push(member);this.membership.set(socket.id,call.state.id);this.publish(call);return call.state;
  });
  rpc('call:start-broadcast',data=>{
   this.free(socket.id);if(this.publicCall('broadcast'))throw Error('Someone is already broadcasting. Join their broadcast or wait for it to end.');
   const member=this.member(socket.id,data.media);if(!member.audio&&!member.video)throw Error('Choose a microphone or camera to broadcast.');
   const call=this.create('broadcast',[member]);call.state.presenterId=socket.id;this.membership.set(socket.id,call.state.id);this.publish(call);return call.state;
  });
  rpc('call:watch-broadcast',data=>{
   this.free(socket.id);const call=this.publicCall('broadcast');if(!call||call.state.id!==data.callId)throw Error('This broadcast has ended.');
   call.state.members.push(this.member(socket.id,{audio:false,video:false}));this.membership.set(socket.id,call.state.id);this.publish(call);return call.state;
  });
  rpc('call:media',data=>{
   const call=this.own(socket.id,data.callId),member=call.state.members.find(m=>m.id===socket.id)!,media=this.media(data.media);
   if(call.state.kind==='broadcast'&&socket.id!==call.state.presenterId&&(media.audio||media.video))throw Error('Broadcast viewers cannot share devices.');
   Object.assign(member,media);this.publish(call);
  });
  socket.on('call:leave',(data,ack)=>{if(data?.callId===this.membership.get(socket.id))this.leave(socket.id);if(typeof ack==='function')ack({ok:true,value:undefined});});
  socket.on('call:signal',data=>{try{
   const call=this.own(socket.id,data?.callId);this.rate(socket.id,'signalTimes',Math.max(300,call.state.members.length*60),10_000);
   if(!callPeerIds(call.state,socket.id).includes(data?.to)||this.membership.get(data.to)!==call.state.id)return;
   const signal=this.signal(data);if(signal)this.sessions.get(data.to)?.socket.emit('call:signal',{...signal,from:socket.id});
  }catch{/* Drop invalid or excessive signaling. */}});
  this.roster();
 }
 private media(value:any):CallMedia {if(!value||typeof value.audio!=='boolean'||typeof value.video!=='boolean')throw Error('Choose microphone and camera settings.');return{audio:value.audio,video:value.video};}
 private member(id:string,value:any){return{id,name:this.players.get(id)!.name,...this.media(value)};}
 private create(kind:CallState['kind'],members:CallState['members']){const call:ActiveCall={state:{id:randomUUID(),roomId:this.roomId()!,kind,members,invited:[]},invitations:new Map()};this.calls.set(call.state.id,call);return call;}
 private publicCall(kind:'room'|'broadcast'){return [...this.calls.values()].find(c=>c.state.kind===kind&&c.state.roomId===this.roomId());}
 private free(id:string){if(this.membership.has(id))throw Error('That player is already in a call.');}
 private own(id:string,callId:string){const c=this.calls.get(callId);if(!c||this.membership.get(id)!==callId||c.state.roomId!==this.roomId())throw Error('This call has ended.');return c;}
 private checkInvite(from:string,to:unknown){
  this.rate(from,'inviteTimes',8,60_000);if(typeof to!=='string'||to===from||!this.sessions.has(to)||!this.players.has(to))throw Error('Choose a player who is still in this room.');this.free(to);
  if([...this.calls.values()].some(c=>c.invitations.has(to)))throw Error('That player already has an invitation.');
 }
 private invite(call:ActiveCall,from:string,to:string){
  const expiresAt=Date.now()+45_000,timer=setTimeout(()=>{if(this.calls.has(call.state.id)){this.clearInvite(call,to);this.prunePrivate(call,'Invitation expired.');}},45_000);timer.unref?.();
  call.invitations.set(to,{from,expiresAt,timer});this.sessions.get(to)!.socket.emit('call:invite',{callId:call.state.id,fromId:from,fromName:this.players.get(from)!.name,expiresAt});
 }
 private clearInvite(call:ActiveCall,to:string){const invite=call.invitations.get(to);if(!invite)return;clearTimeout(invite.timer);call.invitations.delete(to);this.sessions.get(to)?.socket.emit('call:invite-clear',call.state.id);}
 private prunePrivate(call:ActiveCall,reason:string){if(call.state.kind==='private'&&call.state.members.length<2&&!call.invitations.size)this.end(call.state.id,reason);else this.publish(call);}
 private rate(id:string,key:'inviteTimes'|'signalTimes',limit:number,period:number){const s=this.sessions.get(id);if(!s)throw Error('Disconnected.');s[key]=s[key].filter(t=>t>Date.now()-period);if(s[key].length>=limit)throw Error('Please wait before trying again.');s[key].push(Date.now());}
 private signal(data:any):CallSignal|null {
  if(typeof data.callId!=='string'||typeof data.to!=='string')return null;const clean:CallSignal={callId:data.callId,to:data.to};
  if(data.description){const d=data.description;if(!['offer','answer'].includes(d.type)||typeof d.sdp!=='string'||d.sdp.length>65536)return null;clean.description={type:d.type,sdp:d.sdp};}
  else if(data.candidate){const c=data.candidate;if(typeof c.candidate!=='string'||c.candidate.length>2048||!(c.sdpMid===null||typeof c.sdpMid==='string'&&c.sdpMid.length<64)||!(c.sdpMLineIndex===null||Number.isInteger(c.sdpMLineIndex)&&c.sdpMLineIndex>=0&&c.sdpMLineIndex<10))return null;clean.candidate={candidate:c.candidate,sdpMid:c.sdpMid,sdpMLineIndex:c.sdpMLineIndex};if(typeof c.usernameFragment==='string'&&c.usernameFragment.length<256)clean.candidate.usernameFragment=c.usernameFragment;}
  else return null;return clean;
 }
 private publish(call:ActiveCall){call.state.invited=[...call.invitations].map(([id,i])=>({id,name:this.players.get(id)?.name||'Player',expiresAt:i.expiresAt}));for(const member of call.state.members)this.sessions.get(member.id)?.socket.emit('call:state',call.state);this.roster();}
 private roster(){
  const players=[...this.players.values()].filter(p=>this.sessions.has(p.id)).map(p=>({id:p.id,name:p.name,busy:this.membership.has(p.id)})),roomCount=this.publicCall('room')?.state.members.length||0,broadcastCall=this.publicCall('broadcast')?.state,presenter=broadcastCall?.members.find(m=>m.id===broadcastCall.presenterId),broadcast=broadcastCall&&presenter?{callId:broadcastCall.id,presenterId:presenter.id,presenterName:presenter.name,viewers:broadcastCall.members.length-1,audio:presenter.audio,video:presenter.video}:null;
  for(const s of this.sessions.values())s.socket.emit('call:roster',{players,roomCount,broadcast});
 }
 private end(id:string,reason:string){const call=this.calls.get(id);if(!call)return;this.calls.delete(id);for(const to of [...call.invitations.keys()])this.clearInvite(call,to);for(const member of call.state.members){this.membership.delete(member.id);this.sessions.get(member.id)?.socket.emit('call:ended',{callId:id,reason});}this.roster();}
 private leave(id:string){
  const call=this.calls.get(this.membership.get(id)||'');if(!call)return;
  if(call.state.kind==='broadcast'&&call.state.presenterId===id){this.end(call.state.id,'The presenter ended the broadcast.');return;}
  this.membership.delete(id);call.state.members=call.state.members.filter(m=>m.id!==id);this.sessions.get(id)?.socket.emit('call:ended',{callId:call.state.id,reason:'You left the call.'});
  for(const [to,invite] of [...call.invitations])if(invite.from===id)this.clearInvite(call,to);
  if(!call.state.members.length)this.end(call.state.id,'The call ended.');else if(call.state.kind==='private')this.prunePrivate(call,'The other player left the call.');else this.publish(call);
 }
 disconnect(id:string){this.leave(id);for(const call of [...this.calls.values()])if(call.invitations.has(id)){this.clearInvite(call,id);this.prunePrivate(call,'That player disconnected.');}this.sessions.delete(id);this.roster();}
 clearRoom(){for(const id of [...this.calls.keys()])this.end(id,'The room closed.');}
 stop(){this.clearRoom();this.sessions.clear();}
}
