import {afterEach,describe,it,expect,vi} from 'vitest';
import {CallServer,callIceConfig} from './CallServer';
import type {Player} from '@cocoworking/shared';
const media={audio:true,video:false};
function setup(n=3){
 const players=new Map<string,Player>(),sockets:any[]=[];let room:string|undefined='room';
 const server=new CallServer(players,()=>room);
 for(let i=0;i<n;i++){const id='p'+i,handlers:Record<string,Function>={},messages:{event:string;data:any}[]=[];players.set(id,{id,name:'Player '+i,position:{x:5,y:5},direction:'south'});const socket={id,on:(event:string,fn:Function)=>handlers[event]=fn,emit:(event:string,data:any)=>messages.push({event,data:structuredClone(data)})};server.connect(socket as any);sockets.push({id,handlers,messages,send:(event:string,data:any={})=>{let reply:any;handlers[event]({roomId:room,...data},(v:any)=>reply=v);return reply;},last:(event:string)=>messages.filter(m=>m.event===event).at(-1)?.data});}
 return{server,sockets,room:(value:string|undefined)=>room=value};
}
afterEach(()=>vi.useRealTimers());
describe('consensual room call signaling',()=>{
 it('requires acceptance before relaying media signaling and rejects outsiders and spoofed sender IDs',()=>{
  const {server,sockets:[a,b,c]}=setup(),call=a.send('call:invite',{to:b.id,media}).value;
  expect(b.last('call:invite')).toMatchObject({callId:call.id,fromId:a.id});
  const signal={callId:call.id,to:b.id,from:c.id,description:{type:'offer',sdp:'v=0'}};
  a.send('call:signal',signal);expect(b.last('call:signal')).toBeUndefined();
  expect(c.send('call:accept',{callId:call.id,media}).ok).toBe(false);
  expect(b.send('call:accept',{callId:call.id,media}).ok).toBe(true);
  c.send('call:signal',signal);expect(b.last('call:signal')).toBeUndefined();
  a.send('call:signal',signal);expect(b.last('call:signal')).toMatchObject({from:a.id,to:b.id,callId:call.id});
  a.send('call:signal',{...signal,description:{type:'offer',sdp:'x'.repeat(65537)}});expect(b.messages.filter((m:any)=>m.event==='call:signal')).toHaveLength(1);server.stop();
 });
 it('allows every room player past the former six-person limit, including receive-only participants',()=>{
  const {server,sockets}=setup(10);const room=sockets[0].send('call:join-room',{media}).value;
  for(const s of sockets.slice(1))expect(s.send('call:join-room',{media:{audio:false,video:false}}).value.id).toBe(room.id);
  expect(sockets[0].last('call:state').members).toHaveLength(10);expect(sockets[0].last('call:roster').roomCount).toBe(10);
  expect(sockets[1].send('call:invite',{to:sockets[6].id,media}).ok).toBe(false);
  sockets[1].send('call:leave',{callId:room.id});expect(sockets[0].last('call:state').members).toHaveLength(9);server.stop();
 });
 it('expires or declines invitations and clears reservations',()=>{
  vi.useFakeTimers();const {server,sockets:[a,b]}=setup();const first=a.send('call:invite',{to:b.id,media}).value;vi.advanceTimersByTime(45001);expect(a.last('call:ended').reason).toContain('expired');expect(b.last('call:invite-clear')).toBe(first.id);
  const second=a.send('call:invite',{to:b.id,media}).value;expect(b.send('call:decline',{callId:second.id}).ok).toBe(true);expect(a.last('call:ended').reason).toContain('declined');expect(a.send('call:join-room',{media}).ok).toBe(true);server.stop();
 });
 it('cleans disconnects, room deletion and stale room requests without moving users into calls',()=>{
  const {server,sockets:[a,b,c],room}=setup();const call=a.send('call:invite',{to:b.id,media}).value;server.disconnect(b.id);expect(a.last('call:ended').reason).toContain('disconnected');
  const group=a.send('call:join-room',{media}).value;c.send('call:join-room',{media});room(undefined);server.clearRoom();expect(a.last('call:ended').callId).toBe(group.id);expect(c.last('call:ended').callId).toBe(group.id);expect(a.send('call:accept',{callId:call.id,media}).ok).toBe(false);server.stop();
 });
 it('validates media flags, prevents private invitation spam and preserves a newer call on late leave',()=>{
  const {server,sockets:[a,b]}=setup();expect(a.send('call:start-broadcast',{media:{audio:false,video:false}}).ok).toBe(false);
  const first=a.send('call:invite',{to:b.id,media}).value;a.send('call:leave',{callId:first.id});const next=a.send('call:join-room',{media}).value;a.send('call:leave',{callId:first.id});expect(a.last('call:state').id).toBe(next.id);a.send('call:media',{callId:next.id,media:{audio:false,video:true}});expect(a.last('call:state').members[0]).toMatchObject({audio:false,video:true});server.stop();
 });
 it('expands a private call by invitation without exposing its membership to the room',()=>{
  const {server,sockets:[a,b,c,d]}=setup(4),call=a.send('call:invite',{to:b.id,media}).value;
  b.send('call:accept',{callId:call.id,media});expect(b.send('call:add-invite',{callId:call.id,to:c.id}).ok).toBe(true);
  expect(c.last('call:invite').fromId).toBe(b.id);expect(d.last('call:state')).toBeUndefined();
  expect(d.send('call:accept',{callId:call.id,media}).ok).toBe(false);expect(c.send('call:accept',{callId:call.id,media}).ok).toBe(true);expect(a.last('call:state').members).toHaveLength(3);
  a.send('call:leave',{callId:call.id});expect(b.last('call:state').members).toHaveLength(2);expect(b.last('call:ended')).toBeUndefined();server.stop();
 });
 it('expires an added invitation without ending an established private group and clears inviter departures',()=>{
  vi.useFakeTimers();const {server,sockets:[a,b,c,d]}=setup(4),call=a.send('call:invite',{to:b.id,media}).value;b.send('call:accept',{callId:call.id,media});
  a.send('call:add-invite',{callId:call.id,to:c.id});vi.advanceTimersByTime(45001);expect(c.last('call:invite-clear')).toBe(call.id);expect(a.last('call:ended')).toBeUndefined();
  b.send('call:add-invite',{callId:call.id,to:c.id});c.send('call:accept',{callId:call.id,media});b.send('call:add-invite',{callId:call.id,to:d.id});b.send('call:leave',{callId:call.id});expect(d.last('call:invite-clear')).toBe(call.id);expect(a.last('call:state').members.map((m:any)=>m.id)).toEqual([a.id,c.id]);server.stop();
 });
 it('broadcasts from one presenter, forces viewers to receive only and rejects viewer-to-viewer signaling',()=>{
  const {server,sockets:[a,b,c,d]}=setup(4);const call=a.send('call:start-broadcast',{media:{audio:true,video:true}}).value;
  expect(b.last('call:roster').broadcast).toMatchObject({presenterId:a.id,presenterName:'Player 0',video:true,viewers:0});
  expect(d.send('call:start-broadcast',{media}).ok).toBe(false);
  for(const s of [b,c])expect(s.send('call:watch-broadcast',{callId:call.id,media:{audio:true,video:true}}).ok).toBe(true);
  expect(a.last('call:state').members.slice(1).every((m:any)=>!m.audio&&!m.video)).toBe(true);
  expect(b.send('call:media',{callId:call.id,media}).ok).toBe(false);
  b.send('call:signal',{callId:call.id,to:c.id,description:{type:'offer',sdp:'v=0'}});expect(c.last('call:signal')).toBeUndefined();
  a.send('call:signal',{callId:call.id,to:c.id,description:{type:'offer',sdp:'v=0'}});expect(c.last('call:signal').from).toBe(a.id);
  c.send('call:signal',{callId:call.id,to:a.id,description:{type:'answer',sdp:'v=0'}});expect(a.last('call:signal').from).toBe(c.id);
  b.send('call:leave',{callId:call.id});expect(a.last('call:state').members).toHaveLength(2);expect(c.last('call:ended')).toBeUndefined();
  server.disconnect(a.id);expect(c.last('call:ended').reason).toContain('presenter');expect(d.last('call:roster').broadcast).toBeNull();server.stop();
 });
 it('keeps public room and broadcast sessions independent and removes both when the room closes',()=>{
  const {server,sockets:[a,b,c,d]}=setup(4);const room=a.send('call:join-room',{media}).value;b.send('call:join-room',{media});const broadcast=c.send('call:start-broadcast',{media}).value;d.send('call:watch-broadcast',{callId:broadcast.id});
  expect(a.last('call:roster')).toMatchObject({roomCount:2,broadcast:{presenterId:c.id,viewers:1}});expect(a.send('call:add-invite',{callId:room.id,to:d.id}).ok).toBe(false);
  server.clearRoom();for(const s of [a,b,c,d])expect(s.last('call:ended').reason).toContain('room');server.stop();
 });
 it('issues short-lived TURN credentials without exposing the shared secret',()=>{
  const config=callIceConfig('player',{BANDO_TURN_URLS:'turn:relay.example:3478,turns:relay.example:5349',BANDO_TURN_SECRET:'test-secret'},0);expect(config.relayAvailable).toBe(true);expect(config.iceServers[1].username).toBe('3600:player');expect(config.iceServers[1].credential).toMatch(/^[A-Za-z0-9+/]+=*$/);expect(JSON.stringify(config)).not.toContain('test-secret');expect(callIceConfig('player',{}).relayAvailable).toBe(false);
 });
});
