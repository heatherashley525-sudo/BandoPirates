import {createServer} from 'node:http';
import {io as connect,type Socket} from 'socket.io-client';
import {describe,expect,it} from 'vitest';
import {
  floorTiles,findWalkPath,PUBLIC_STREET,PUBLIC_STREET_ENTRANCE,PUBLIC_STREET_FLOOR,PUBLIC_STREET_SPAWN,
  type Player,type RoomDirectoryEntry,type RoomInfo,
} from '@cocoworking/shared';
import {createSocketServer} from '../../rooms/CoworkingServer';
import {WorldStore,type PlayerIdentity} from '../../state/WorldStore';

function receive<T>(socket: Socket,event: string): Promise<T> {
  return new Promise(resolve=>socket.once(event,resolve));
}

describe('Public Street',()=>{
  it('has a single shared corridor and 64 walkable entrance tiles',async()=>{
    const roots=floorTiles(undefined,PUBLIC_STREET_FLOOR);
    const leaves=floorTiles(PUBLIC_STREET.tileSplits,PUBLIC_STREET_FLOOR);
    expect(roots).toHaveLength(18);
    const microtiles=leaves.filter(tile=>tile.id.startsWith(PUBLIC_STREET_ENTRANCE+'/'));
    expect(leaves).toHaveLength(81);
    expect(microtiles).toHaveLength(64);
    for(const tile of microtiles)expect(findWalkPath(PUBLIC_STREET_SPAWN,tile,[],PUBLIC_STREET.tileSplits,PUBLIC_STREET_FLOOR)).not.toBeNull();

    const store=new WorldStore();
    const server=createServer();
    const io=createSocketServer(server,{store});
    await new Promise<void>(resolve=>server.listen(0,'127.0.0.1',resolve));
    const address=server.address();
    if(!address||typeof address==='string')throw Error('Server did not start.');
    const url='http://127.0.0.1:'+address.port;
    const sockets:Socket[]=[];
    const join=async(name:string,street:boolean,token?:string)=>{
      const socket=connect(url+(street?'/'+PUBLIC_STREET.id:''),{autoConnect:false,forceNew:true,query:{name},auth:{token}});
      sockets.push(socket);
      const identity=receive<PlayerIdentity>(socket,'identity:state');
      const players=receive<Record<string,Player>>(socket,'room:state');
      const room=receive<RoomInfo>(socket,'room:info');
      const directory=receive<RoomDirectoryEntry[]>(socket,'room:directory');
      socket.connect();
      return {socket,identity:await identity,players:await players,room:await room,directory:await directory};
    };
    try{
      const a=await join('First',true);
      const b=await join('Second',true);
      expect(a.room).toEqual(PUBLIC_STREET);
      expect(b.room).toEqual(a.room);
      expect(a.directory).toEqual([{name:'Public Street',destination:'public-street'}]);
      expect(b.players[a.socket.id!].position).toEqual(PUBLIC_STREET_SPAWN);
      expect(store.state.room).toBeNull();

      const opened=receive<RoomDirectoryEntry[]>(b.socket,'room:directory');
      const playerRoom=await join('First',false,a.identity.token);
      expect(playerRoom.identity.id).toBe(a.identity.id);
      expect(Object.keys(playerRoom.players)).toEqual([playerRoom.socket.id]);
      expect(playerRoom.room.id).not.toBe(a.room.id);
      expect(await opened).toEqual([...a.directory,{name:playerRoom.room.name,destination:'player-room'}]);
      expect(playerRoom.directory).toHaveLength(2);

      const moved=receive<Player['position']>(b.socket,'player:move');
      a.socket.emit('player:move',{x:6,y:6});
      expect(await moved).toMatchObject({x:6,y:6});
      const corrected=receive<Player['position']>(a.socket,'player:correct');
      a.socket.emit('player:move',{x:7,y:6});
      expect(await corrected).toEqual({x:6,y:6});

      const blocked=receive<string>(a.socket,'furniture:blocked');
      a.socket.emit('room:delete',{roomId:playerRoom.room.id});
      expect(await blocked).toMatch(/fixed layout/);
      expect(store.state.room?.id).toBe(playerRoom.room.id);

      const closed=receive<RoomDirectoryEntry[]>(b.socket,'room:directory');
      playerRoom.socket.emit('room:delete',{roomId:playerRoom.room.id});
      expect(await closed).toEqual(a.directory);
    }finally{
      for(const socket of sockets)socket.disconnect();
      await io.close();
    }
  });
});
