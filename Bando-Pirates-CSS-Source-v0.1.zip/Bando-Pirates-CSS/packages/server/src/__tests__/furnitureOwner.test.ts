import {beforeEach,describe,expect,it,vi} from 'vitest';
import type {Server as HttpServer} from 'http';
import {blankAppearance} from '@cocoworking/shared';
import {WorldStore} from '../state/WorldStore';
const harness=vi.hoisted(()=>({connect:null as null|((socket:any)=>void),emitted:[] as {event:string;data:any}[]}));
vi.mock('socket.io',()=>({Server:class{on(event:string,cb:(socket:any)=>void){if(event==='connection')harness.connect=cb;}emit(event:string,data:any){harness.emitted.push({event,data});}}}));
import {createSocketServer} from '../rooms/CoworkingServer';
function connect(id:string,name:string,token?:string){
 const handlers:Record<string,(data?:any)=>void>={},emitted:{event:string;data:any}[]=[];
 const socket={id,handshake:{query:{name},auth:{token}},on:(event:string,cb:(data?:any)=>void)=>{handlers[event]=cb;},emit:(event:string,data:any)=>emitted.push({event,data}),broadcast:{emit:vi.fn()},disconnect:vi.fn()};
 harness.connect!(socket);return {handlers,emitted,socket};
}
const last=(socket:ReturnType<typeof connect>,event:string)=>socket.emitted.filter(e=>e.event===event).at(-1)?.data;
const broadcast=(event:string)=>harness.emitted.filter(e=>e.event===event).at(-1)?.data;
beforeEach(()=>{harness.emitted=[];createSocketServer({} as HttpServer);});
describe('owned room and inventory protocol',()=>{
 it('automatically seats movement onto a sofa and preserves the other occupied cushion',()=>{
  const a=connect('a','Heather'),b=connect('b','Guest');for(const client of [a,b]){client.handlers['player:move']({x:4,y:4});client.handlers['player:move']({x:4,y:3});}
  a.handlers['player:move']({x:3,y:3});expect(broadcast('player:posture')).toMatchObject({id:'a',seat:{index:0}});
  b.handlers['player:move']({x:3,y:3});expect(last(b,'player:correct')).toEqual({x:4,y:3});b.handlers['player:move']({x:4,y:4});b.handlers['player:move']({x:3,y:4});expect(broadcast('player:posture')).toMatchObject({id:'b',seat:{index:1}});
 });
 it('seats two standing players when a sofa is moved underneath and exposes the result to late joiners',()=>{
  const a=connect('a','Heather'),b=connect('b','Guest'),roomId=last(a,'room:info').id,sofa=last(a,'furniture:state').find((i:any)=>i.kind==='base-sofa');
  b.handlers['player:move']({x:5,y:6});a.handlers['furniture:move']({id:sofa.id,gx:5,gy:5,roomId});
  const late=connect('late','Visitor'),players=last(late,'room:state');expect(players.a.seat).toEqual({furnitureId:sofa.id,index:0});expect(players.b.seat).toEqual({furnitureId:sofa.id,index:1});expect(last(late,'furniture:state').find((i:any)=>i.id===sofa.id).ownerId).toBe(last(a,'identity:state').id);
 });
 it('does not change player posture when saving a sofa move underneath fails',()=>{
  const store=new WorldStore();harness.emitted=[];createSocketServer({} as HttpServer,{store});const a=connect('a','Heather'),roomId=last(a,'room:info').id,sofa=last(a,'furniture:state').find((i:any)=>i.kind==='base-sofa');vi.spyOn(store,'commit').mockImplementation(()=>{throw Error('Disk failure');});
  a.handlers['furniture:move']({id:sofa.id,gx:5,gy:5,roomId});expect(broadcast('player:posture')).toBeUndefined();expect(last(a,'furniture:blocked')).toContain('Nothing was changed');
 });
 it('synchronizes two occupied sofa seats, rejects remote sitting and releases seats on standing or departure',()=>{
  const a=connect('a','Heather'),b=connect('b','Guest'),roomId=last(a,'room:info').id,sofa=last(a,'furniture:state').find((i:any)=>i.kind==='base-sofa');
  a.handlers['player:sit']({id:sofa.id,index:0,roomId});expect(last(a,'player:posture-blocked')).toContain('front');
  for(const client of [a,b]){client.handlers['player:move']({x:4,y:4});client.handlers['player:move']({x:4,y:3});}
  a.handlers['player:sit']({id:sofa.id,index:0,roomId});expect(broadcast('player:posture')).toMatchObject({id:'a',position:{x:3,y:3},seat:{furnitureId:sofa.id,index:0},direction:'south-east'});
  b.handlers['player:sit']({id:sofa.id,index:0,roomId});expect(last(b,'player:posture-blocked')).toContain('occupied');
  b.handlers['player:move']({x:4,y:4});b.handlers['player:sit']({id:sofa.id,index:1,roomId});expect(broadcast('player:posture').seat.index).toBe(1);
  const c=connect('c','Late visitor');expect(last(c,'room:state').a.seat.index).toBe(0);expect(last(c,'room:state').b.seat.index).toBe(1);
  a.handlers['player:move']({x:4,y:3});expect(last(a,'player:correct')).toEqual({x:3,y:3});
  a.handlers['furniture:pickup']({id:sofa.id,roomId});expect(last(a,'furniture:blocked')).toContain('player');
  a.handlers['player:stand']({roomId});expect(broadcast('player:posture')).toMatchObject({id:'a',position:{x:4,y:3}});expect(broadcast('player:posture').seat).toBeUndefined();
  b.handlers.disconnect();a.handlers['furniture:pickup']({id:sofa.id,roomId});expect(last(a,'inventory:state').some((i:any)=>i.id===sofa.id)).toBe(true);
 });
 it('clears seated posture when the room is deleted without changing furniture returns',()=>{
  const a=connect('a','Heather'),roomId=last(a,'room:info').id,sofa=last(a,'furniture:state').find((i:any)=>i.kind==='base-sofa');
  a.handlers['player:move']({x:4,y:4});a.handlers['player:move']({x:4,y:3});a.handlers['player:sit']({id:sofa.id,index:0,roomId});a.handlers['room:delete']({roomId});expect(broadcast('room:state').a.seat).toBeUndefined();expect(last(a,'inventory:state')).toHaveLength(4);
 });
 it('uses persistent player identity for ownership, not a username or socket ID',()=>{
  const owner=connect('first','Heather'),guest=connect('guest','Heather');const identity=last(owner,'identity:state');
  expect(last(guest,'room:info').ownerId).toBe(identity.id);expect(last(guest,'identity:state').id).not.toBe(identity.id);
  owner.handlers.disconnect();const visitor=connect('later','Visitor');expect(last(visitor,'room:info').ownerId).toBe(identity.id);
 });
 it('rejects guest moves, rotations and room deletion',()=>{
  const owner=connect('first','Heather'),guest=connect('guest','Guest'),roomId=last(guest,'room:info').id,item=last(owner,'furniture:state')[0];
  guest.handlers['furniture:move']({id:item.id,gx:7,gy:7,roomId});guest.handlers['furniture:rotate']({id:item.id,roomId});guest.handlers['room:delete']({roomId});
  expect(guest.emitted.filter(e=>e.event==='furniture:blocked')).toHaveLength(3);expect(broadcast('room:info')).toBeUndefined();
 });
 it('broadcasts movement without changing the item owner and restores it for late visitors',()=>{
  const owner=connect('first','Heather'),roomId=last(owner,'room:info').id,item=last(owner,'furniture:state').find((i:any)=>i.kind==='base-table');
  owner.handlers['furniture:move']({id:item.id,gx:7,gy:7,roomId});expect(broadcast('furniture:state').find((i:any)=>i.id===item.id)).toMatchObject({gx:7,gy:7,ownerId:last(owner,'identity:state').id});
  const late=connect('later','Visitor');expect(last(late,'furniture:state')).toEqual(broadcast('furniture:state'));
 });
 it('returns a guest item to the guest when collected by the room owner',()=>{
  const owner=connect('first','Heather'),guest=connect('guest','Guest'),roomId=last(guest,'room:info').id,item=last(guest,'inventory:state').find((i:any)=>i.kind==='base-table');
  guest.handlers['furniture:place']({id:item.id,gx:7,gy:7,roomId});expect(last(guest,'inventory:state')).toHaveLength(3);
  owner.handlers['furniture:pickup']({id:item.id,roomId});expect(last(guest,'inventory:state')).toHaveLength(4);expect(last(owner,'inventory:state')).toHaveLength(1);
 });
 it('returns offline owners’ items on deletion and restores their inventory on reconnect',()=>{
  const owner=connect('first','Heather'),guest=connect('guest','Guest'),identity=last(guest,'identity:state'),roomId=last(guest,'room:info').id,item=last(guest,'inventory:state')[1];
  guest.handlers['furniture:place']({id:item.id,gx:7,gy:7,roomId});guest.handlers.disconnect();owner.handlers['room:delete']({roomId});
  expect(broadcast('room:info')).toBeNull();expect(last(owner,'inventory:state')).toHaveLength(4);
  const returned=connect('reconnected','Guest',identity.token);expect(last(returned,'identity:state').id).toBe(identity.id);expect(last(returned,'inventory:state')).toHaveLength(4);
  owner.handlers['room:delete']({roomId});expect(last(owner,'inventory:state')).toHaveLength(4);
 });
 it('corrects attempts to walk through placed furniture',()=>{
  const owner=connect('first','Heather');owner.handlers['player:move']({x:6,y:3});expect(last(owner,'player:correct')).toEqual({x:5,y:5});
 });
 it('enforces adjacent height-aware walking on the server',()=>{
  const owner=connect('first','Heather');
  owner.handlers['player:move']({x:6,y:3});expect(last(owner,'player:correct')).toEqual({x:5,y:5});
  owner.handlers['player:move']({x:5,y:4});owner.handlers['player:move']({x:5,y:3});
  owner.handlers['player:move']({x:6,y:3});expect(last(owner,'player:correct')).toEqual({x:5,y:3});
  owner.handlers['player:move']({x:5,y:4});owner.handlers['player:move']({x:6,y:4});owner.handlers['player:move']({x:6,y:3});
  expect(broadcast('player:move')).toMatchObject({x:6,y:3});
 });
 it('saves authenticated appearance, broadcasts it and restores it on reconnect',()=>{
  const a=connect('a','Heather'),b=connect('b','Guest'),identity=last(a,'identity:state');
  a.handlers['avatar:save']({...blankAppearance(),skin:'#8c5e46',userId:last(b,'identity:state').id});
  expect(last(a,'avatar:blocked')).toBeTypeOf('string');
  a.handlers['avatar:save'](blankAppearance());expect(broadcast('player:appearance')).toMatchObject({id:'a',appearance:blankAppearance()});
  a.handlers.disconnect();const returned=connect('again','Heather',identity.token);expect(last(returned,'room:state').again.appearance).toEqual(blankAppearance());
  expect(last(returned,'room:state').b.appearance).not.toEqual(blankAppearance());
 });
 it('accepts safe diagonal steps and computes the facing instead of trusting client directions',()=>{
  const owner=connect('first','Heather');owner.handlers['player:move']({x:6,y:6,direction:'invalid'});expect(broadcast('player:move')).toMatchObject({x:6,y:6,direction:'south'});
  owner.handlers['player:move']({x:5,y:5,direction:'east'});expect(broadcast('player:move')).toMatchObject({x:5,y:5,direction:'north'});
 });
 it('rejects an invalid saved identity rather than exposing someone else’s inventory',()=>{
  connect('owner','Heather');const invalid=connect('spoof','Heather','invalid-token');expect(last(invalid,'identity:error')).toBeTypeOf('string');expect(last(invalid,'inventory:state')).toBeUndefined();expect(invalid.socket.disconnect).toHaveBeenCalledWith(true);
 });
 it('keeps the room and furniture unchanged if durable saving fails',()=>{
  const store=new WorldStore();harness.emitted=[];createSocketServer({} as HttpServer,{store});const owner=connect('owner','Heather'),roomId=last(owner,'room:info').id;
  vi.spyOn(store,'commit').mockImplementation(()=>{throw Error('Disk failure');});owner.handlers['room:delete']({roomId});
  expect(store.state.room?.id).toBe(roomId);expect(last(owner,'furniture:blocked')).toContain('Nothing was changed');expect(broadcast('room:info')).toBeUndefined();
 });
});
