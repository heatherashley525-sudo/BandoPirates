import {describe,it,expect,vi} from 'vitest';
import {HabboFurniture} from '../HabboFurniture';
import {collectionById,type CollectibleAsset} from '@cocoworking/shared';
const c=collectionById('furni')!,asset:CollectibleAsset={key:'one',collection:'furni',chainId:13371,contract:c.contract,tokenId:'1',name:'Diamond HC Sofa',kind:'item',image:'https://nft-tokens.habbo.com/collectibles/furni/images/nft_club_sofa.png'};
describe('native Habbo furniture mapping',()=>{
 it('matches the official floor classname and binds dimensions, flags and a pinned renderer revision',async()=>{
  const fetcher=vi.fn(async(url:any)=>new Response(JSON.stringify(String(url).includes('furnidata_json')?{roomitemtypes:{furnitype:[{classname:'nft_club_sofa',revision:70734,xdim:2,ydim:1,height:1,cansiton:true,canstandon:false,canputstuffon:false}]}}:{classname:'nft_club_sofa',revisions:[70734],directions:[2,6,4,0],states:[]})));
  const service=new HabboFurniture(fetcher as typeof fetch),d=await service.resolve(asset);
  expect(d).toEqual({classname:'nft_club_sofa',revision:70734,width:1,depth:2,height:2,seat:true,walkable:false,stackable:false,directions:[2,4,6,0],states:[0]});
  expect(await service.resolve(asset)).toEqual(d);expect(fetcher).toHaveBeenCalledTimes(2);
 });
 it('does not turn unknown collectibles, avatar images or unmatched revisions into substitute furniture',async()=>{
  const fetcher=vi.fn(async(url:any)=>new Response(JSON.stringify(String(url).includes('furnidata_json')?{roomitemtypes:{furnitype:[]}}:{}))),service=new HabboFurniture(fetcher as typeof fetch);
  await expect(service.resolve({...asset,collection:'genesis'})).rejects.toThrow('Only furniture');
  await expect(service.resolve({...asset,image:'https://nft-tokens.habbo.com/collectibles/furni/images/not_matched.png'})).rejects.toThrow('mapping');
  await expect(service.resolve(asset)).rejects.toThrow('not matched');
 });
 it('maps legacy official image names only when their official NFT floor name is unique',async()=>{
  const fetcher=vi.fn(async(url:any)=>new Response(JSON.stringify(String(url).includes('furnidata_json')?{roomitemtypes:{furnitype:[{classname:'nft_birthday_cake',name:'Birthday Cake',revision:42,xdim:1,ydim:1,height:.5,cansiton:false,canstandon:false,canputstuffon:false}]}}:{classname:'nft_birthday_cake',revisions:[42],directions:[2],states:[0]})));const service=new HabboFurniture(fetcher as typeof fetch);expect((await service.resolve({...asset,name:'Birthday Cake',image:'https://nft-tokens.habbo.com/collectibles/furni/images/birthday/cake1.png'})).classname).toBe('nft_birthday_cake');
 });
 it('rejects ambiguous name matches instead of choosing a substitute',async()=>{
  const fetcher=vi.fn(async()=>new Response(JSON.stringify({roomitemtypes:{furnitype:[{classname:'nft_a',name:'Birthday Cake'},{classname:'nft_b',name:'Birthday Cake'}]}})));await expect(new HabboFurniture(fetcher as typeof fetch).resolve({...asset,name:'Birthday Cake',image:'https://nft-tokens.habbo.com/collectibles/furni/images/birthday/cake1.png'})).rejects.toThrow('unambiguous');
 });

 it('does not replace an explicit unknown NFT classname with a different same-name item',async()=>{
  const fetcher=vi.fn(async()=>new Response(JSON.stringify({roomitemtypes:{furnitype:[{classname:'nft_old_cake',name:'Birthday Cake'}]}})));await expect(new HabboFurniture(fetcher as typeof fetch).resolve({...asset,name:'Birthday Cake',image:'https://nft-tokens.habbo.com/collectibles/furni/images/nft_new_cake.png'})).rejects.toThrow('mapping');
 });

});
