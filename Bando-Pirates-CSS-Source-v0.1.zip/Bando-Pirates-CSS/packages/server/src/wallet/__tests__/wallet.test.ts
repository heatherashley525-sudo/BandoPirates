import {describe,it,expect,vi} from 'vitest';
import {Wallet,Interface} from 'ethers';
import {WalletSession,walletOrigin} from '../WalletSession';
import {HabboGateway,type AssetGateway} from '../HabboGateway';
import {CollectiblesServer} from '../CollectiblesServer';
import {collectionById,defaultAppearance,safeCollectibleImage,parseTokenId,movePlayer,type HabboFurnitureDefinition,type CollectibleAsset,type Player} from '@cocoworking/shared';
const collection=collectionById('genesis')!;
const asset:CollectibleAsset={key:`1:${collection.contract}:1`,collection:'genesis',chainId:1,contract:collection.contract,tokenId:'1',name:'Test collectible',image:'https://nft-tokens.habbo.com/avatars/images/1.png',kind:'avatar',figure:'hd-600-10.lg-5332'};
const definition:HabboFurnitureDefinition={classname:'nft_club_sofa',revision:70734,width:1,depth:2,height:2,seat:true,walkable:false,stackable:false,directions:[2,4,6,0],states:[0]};
const furniCollection=collectionById('furni')!;
const furni:CollectibleAsset={...asset,key:`13371:${furniCollection.contract}:1`,collection:'furni',chainId:13371,contract:furniCollection.contract,kind:'item',name:'NFT Sofa',image:'https://nft-tokens.habbo.com/collectibles/furni/images/nft_club_sofa.png'};
function gateway():AssetGateway{return {owned:vi.fn(async()=>true),asset:vi.fn(async(_address,c)=>c==='furni'?furni:asset),furniture:vi.fn(async()=>definition),list:vi.fn(async()=>({assets:[asset],nextCursor:null}))};}

describe('wallet ownership proof',()=>{
 it('labels pasted addresses as unverified test sessions and can upgrade only after a signature',async()=>{
  const owner=Wallet.createRandom(),s=new WalletSession('test','https://game.example',gateway());
  for(const address of ['not an address','alice.eth','0x123',7])expect(()=>s.testAddress(address)).toThrow();
  expect(s.testAddress(owner.address)).toMatchObject({address:owner.address,mode:'test'});expect((await s.asset('genesis','1')).test).toBe(true);expect(()=>s.verify('0x')).toThrow();
  const challenge=s.challenge(owner.address,1);expect(s.verify(await owner.signMessage(challenge.message)).mode).toBe('verified');expect((await s.asset('genesis','1')).test).toBeUndefined();
 });
 it('expires test snapshots and never reuses them after upgrading to a signed wallet',async()=>{
  const owner=Wallet.createRandom(),g=gateway();let now=1000;const session=new WalletSession('a','https://game.example',g,()=>now);session.testAddress(owner.address);session.rememberTestAssets([asset]);await session.asset('genesis','1');expect(g.asset).not.toHaveBeenCalled();now+=3600001;await expect(session.asset('genesis','1')).rejects.toThrow();session.testAddress(owner.address);session.rememberTestAssets([asset]);const challenge=session.challenge(owner.address,1);session.verify(await owner.signMessage(challenge.message));await session.asset('genesis','1');expect(g.asset).toHaveBeenCalledOnce();
 });
 it('requires a configured production origin and supports localhost development',()=>{
  expect(walletOrigin('https://game.example','https://game.example/')).toBe('https://game.example');
  expect(()=>walletOrigin('https://wrong.example','https://game.example')).toThrow();
  expect(()=>walletOrigin('https://game.example','')).toThrow();expect(walletOrigin('http://127.0.0.1:4173','')).toContain('4173');
  expect(walletOrigin(undefined,'https://game.example','https://game.example/game?room=1')).toBe('https://game.example');expect(()=>walletOrigin(undefined,'https://game.example','https://wrong.example/')).toThrow();
 });
 it('accepts a real EIP-191 signature once, bound to session, address and expiration',async()=>{
  const owner=Wallet.createRandom(),other=Wallet.createRandom();let now=1000;const one=new WalletSession('socket:profile','https://game.example',gateway(),()=>now);
  const proof=one.challenge(owner.address,1),signature=await owner.signMessage(proof.message);expect(proof.message).toContain('Request ID: socket:profile');expect(proof.message).toContain('URI: https://game.example');
  expect(one.verify(signature).address).toBe(owner.address);expect(()=>one.verify(signature)).toThrow();
  const two=new WalletSession('another:profile','https://game.example',gateway(),()=>now);two.challenge(owner.address,1);expect(()=>two.verify(signature)).toThrow();
  now+=3000;const bad=one.challenge(owner.address,1);expect(()=>one.verify(other.signMessageSync(bad.message))).toThrow();
  now+=3000;const expired=one.challenge(owner.address,1);now+=300001;expect(()=>one.verify(owner.signMessageSync(expired.message))).toThrow();
 });
 it('rejects stale asynchronous ownership results after disconnect',async()=>{
  const owner=Wallet.createRandom(),g=gateway();let finish!:(asset:CollectibleAsset)=>void;g.asset=vi.fn(()=>new Promise<CollectibleAsset>(r=>finish=r));const s=new WalletSession('a','https://game.example',g);
  const proof=s.challenge(owner.address,1);s.verify(await owner.signMessage(proof.message));const pending=s.asset('genesis','1');s.disconnect();finish(asset);await expect(pending).rejects.toThrow();
 });
 it('only accepts bounded token IDs and official raster images',()=>{
  for(const input of ['-1','01','1/../2','1e3',(2n**256n).toString()])expect(parseTokenId(input)).toBeNull();
  expect(parseTokenId('0')).toBe('0');expect(safeCollectibleImage(asset.image)).toBe(asset.image);expect(safeCollectibleImage('https://nft-tokens.habbo.com/collectibles/furni/images/birthday/confetti.gif')).toBe('https://nft-tokens.habbo.com/collectibles/furni/images/birthday/confetti.gif');
  for(const url of ['javascript:alert(1)','https://evil.example/a.png','https://nft-tokens.habbo.com/avatars/images/a.svg','https://nft-tokens.habbo.com/avatars/images/1.png?redirect=evil','https://nft-tokens.habbo.com.evil.example/avatars/images/1.png'])expect(safeCollectibleImage(url)).toBeNull();
 });
});

describe('on-chain reads and metadata',()=>{
 const abi=new Interface(['function ownerOf(uint256) view returns (address)']);
 it('checks the chain and owner before fetching metadata from the fixed official endpoint',async()=>{
  const owner=Wallet.createRandom(),urls:string[]=[],methods:string[]=[];
  const fetcher=vi.fn(async(url:any,init?:RequestInit)=>{
   urls.push(String(url));if(init?.body){const request=JSON.parse(String(init.body));methods.push(request.method);return new Response(JSON.stringify({result:request.method==='eth_chainId'?'0x1':abi.encodeFunctionResult('ownerOf',[owner.address])}));}
   const attributes=Object.entries({Gender:'Female',Face:'Default',Complexion:'Vanilla',Legs:'White Suspender Pants',Effect:'Golden H'}).map(([trait_type,value])=>({trait_type,value}));
   return new Response(JSON.stringify({name:'Owned avatar',image:asset.image,attributes}));
  });
  const g=new HabboGateway(fetcher as typeof fetch,{1:'https://rpc.example'});expect(await g.asset(owner.address,'genesis','1')).toMatchObject({name:'Owned avatar',figure:asset.figure,finish:'gold'});
  expect(methods).toEqual(['eth_chainId','eth_call','eth_call']);expect(urls).toContain('https://nft-tokens.habbo.com/avatars/metadata/1.json');
 });
 it('uses Immutable metadata for individual furniture token IDs and rejects burned tokens',async()=>{
  const owner=Wallet.createRandom(),c=collectionById('furni')!,calls:string[]=[];
  const fetcher=vi.fn(async(url:any,init?:RequestInit)=>{calls.push(String(url));if(init?.body){const r=JSON.parse(String(init.body));return new Response(JSON.stringify({result:r.method==='eth_chainId'?'0x343b':abi.encodeFunctionResult('ownerOf',[owner.address])}));}return new Response(JSON.stringify({result:{contract_address:c.contract,token_id:'123',name:'Furniture',image:'https://nft-tokens.habbo.com/collectibles/furni/images/example.png'}}));});
  const result=await new HabboGateway(fetcher as typeof fetch,{13371:'https://rpc.example'}).asset(owner.address,'furni','123');expect(result.kind).toBe('item');expect(calls).toContain(`https://api.immutable.com/v1/chains/imtbl-zkevm-mainnet/collections/${c.contract}/nfts/123`);
  const burned=vi.fn(async(_url:any,init?:RequestInit)=>{const r=JSON.parse(String(init?.body));return new Response(JSON.stringify(r.method==='eth_chainId'?{result:'0x1'}:{error:{code:3,message:'execution reverted: invalid token ID'}}));});
  await expect(new HabboGateway(burned as typeof fetch,{1:'https://rpc.example'}).asset(owner.address,'genesis','1')).rejects.toThrow('does not currently own');
 });
 it('rejects wrong ownership and a wrong RPC chain before granting any assets',async()=>{
  const owner=Wallet.createRandom(),other=Wallet.createRandom();
  const wrongChain=new HabboGateway(vi.fn(async()=>new Response(JSON.stringify({result:'0x2'}))) as typeof fetch,{1:'https://rpc.example'});await expect(wrongChain.asset(owner.address,'genesis','1')).rejects.toThrow('network');
  const fetcher=vi.fn(async(_url:any,init?:RequestInit)=>{const r=JSON.parse(String(init?.body));return new Response(JSON.stringify({result:r.method==='eth_chainId'?'0x1':abi.encodeFunctionResult('ownerOf',[other.address])}));});
  await expect(new HabboGateway(fetcher as typeof fetch,{1:'https://rpc.example'}).asset(owner.address,'genesis','1')).rejects.toThrow('does not currently own');expect(fetcher).toHaveBeenCalledTimes(2);
 });
});

function harness(){
 const players=new Map<string,Player>(),emitted:{event:string;data:any}[]=[],g=gateway();
 const io={emit:(event:string,data:any)=>emitted.push({event,data})};const service=new CollectiblesServer(io as any,players,()=>({id:'room',name:'Room',ownerId:'profile',ownerName:'Player'}),g,'https://game.example');
 function connect(id:string){const handlers:Record<string,Function>={},messages:{event:string;data:any}[]=[];const socket={id,handshake:{headers:{origin:'https://game.example'}},on:(event:string,fn:Function)=>handlers[event]=fn,emit:(event:string,data:any)=>messages.push({event,data})};players.set(id,{id,name:'Player',position:{x:5,y:5},direction:'south',appearance:defaultAppearance()});service.connect(socket,id+'-profile');
  const send=async(event:string,data:any={})=>{let reply:any;await handlers[event](data,(r:any)=>reply=r);return reply;};
  const login=async(owner:Wallet|ReturnType<typeof Wallet.createRandom>)=>{const challenge=await send('wallet:challenge',{address:owner.address,chainId:1});expect(challenge.ok).toBe(true);return send('wallet:verify',{signature:await owner.signMessage(challenge.value.message)});};
  return {send,login,messages};}
 return {players,emitted,g,service,connect};
}
describe('multiplayer collectible lifecycle',()=>{
 it('permits address-only furniture tests without evicting the verified wallet owner',async()=>{
  const h=harness(),a=h.connect('a'),b=h.connect('b'),owner=Wallet.createRandom();try{
   await a.login(owner);expect((await b.send('wallet:test',{address:owner.address})).value.mode).toBe('test');expect((await a.send('wallet:list',{collection:'genesis'})).ok).toBe(true);
   const page=await b.send('wallet:list',{collection:'genesis'});expect(page.value.assets[0].test).toBe(true);const placed=await b.send('wallet:place',{collection:'furni',tokenId:'1',roomId:'room',gx:3,gy:3});expect(placed.ok).toBe(true);expect(placed.value.nft.asset.test).toBe(true);
   await b.send('wallet:test',{address:Wallet.createRandom().address});expect(h.service.furniture()).toEqual([]);expect((await a.send('wallet:list',{collection:'genesis'})).ok).toBe(true);
  }finally{h.service.stop();}
 });
 it('keeps labelled test copies usable without background ownership proof and clears them on disconnect',async()=>{
  const h=harness(),a=h.connect('a'),owner=Wallet.createRandom();try{
   await a.send('wallet:test',{address:owner.address});await a.send('wallet:list',{collection:'genesis'});h.g.asset=vi.fn(async(_address,c)=>c==='furni'?furni:asset);expect((await a.send('wallet:wear',{collection:'genesis',tokenId:'1'})).ok).toBe(true);expect(h.g.asset).not.toHaveBeenCalled();expect((await a.send('wallet:prepare',{collection:'furni',tokenId:'1'})).ok).toBe(true);h.g.asset=vi.fn(async()=>{throw Error('upstream unavailable');});h.g.owned=vi.fn(async()=>{throw Error('RPC outage');});expect((await a.send('wallet:place',{collection:'furni',tokenId:'1',roomId:'room',gx:3,gy:3})).ok).toBe(true);await h.service.recheck();expect(h.service.furniture()).toHaveLength(1);expect(h.players.get('a')?.collectibleAvatar?.test).toBe(true);expect(h.g.owned).not.toHaveBeenCalled();expect(h.g.asset).not.toHaveBeenCalled();await a.send('wallet:disconnect');expect(h.service.furniture()).toHaveLength(0);expect(h.players.get('a')?.collectibleAvatar).toBeUndefined();
  }finally{h.service.stop();}
 });
 it('releases an occupied NFT seat when the wallet loses ownership',async()=>{
  const h=harness(),a=h.connect('a');try{
   await a.login(Wallet.createRandom());const placed=await a.send('wallet:place',{collection:'furni',tokenId:'1',roomId:'room',gx:3,gy:3});expect(placed.ok).toBe(true);
   const player=h.players.get('a')!;player.position={x:4,y:3};const result=movePlayer(player,{x:3,y:3},h.service.furniture(),[]);expect(result.ok).toBe(true);if(result.ok)h.players.set('a',result.player);
   h.g.owned=vi.fn(async()=>false);await h.service.recheck();expect(h.service.furniture()).toEqual([]);expect(h.players.get('a')?.seat).toBeUndefined();expect(h.players.get('a')?.position).toEqual({x:5,y:5});
   expect(h.emitted.some(e=>e.event==='player:posture'&&e.data.id==='a'&&!e.data.seat)).toBe(true);
  }finally{h.service.stop();}
 });
 it('removes dependent NFT stacks when a support owner leaves, while keeping permanent inventory separate',async()=>{
  const h=harness(),a=h.connect('a'),b=h.connect('b');try{
   await a.login(Wallet.createRandom());await b.login(Wallet.createRandom());
   h.g.furniture=vi.fn(async()=>({...definition,width:1,depth:1,height:1.6,seat:false,stackable:true}));
   const table=await a.send('wallet:place',{collection:'furni',tokenId:'1',roomId:'room',gx:3,gy:3});expect(table.ok).toBe(true);
   h.g.furniture=vi.fn(async()=>definition);
   const sofa=await b.send('wallet:place',{collection:'furni',tokenId:'1',roomId:'room',gx:3,gy:3});expect(sofa.ok).toBe(true);expect(sofa.value).toMatchObject({z:1.6,supportId:table.value.id});
   await a.send('wallet:disconnect');expect(h.service.furniture()).toEqual([]);
   const returned=await b.send('wallet:place',{collection:'furni',tokenId:'1',roomId:'room',gx:3,gy:3});expect(returned.ok).toBe(true);expect(returned.value.z).toBe(0);
   expect((await b.send('wallet:pickup',{collection:'furni',tokenId:'1',roomId:'room'})).ok).toBe(true);expect(h.service.furniture()).toEqual([]);
  }finally{h.service.stop();}
 });
 it('requires a proof, equips an owned avatar, places native furniture and revokes on transfer',async()=>{
  const h=harness(),a=h.connect('a');try{
   expect((await a.send('wallet:wear',{collection:'genesis',tokenId:'1'})).ok).toBe(false);
   expect((await a.login(Wallet.createRandom())).ok).toBe(true);expect((await a.send('wallet:wear',{collection:'genesis',tokenId:'1'})).ok).toBe(true);expect(h.players.get('a')?.collectibleAvatar).toEqual(asset);
   expect((await a.send('wallet:place',{collection:'furni',tokenId:'1',roomId:'room',gx:3,gy:3})).ok).toBe(true);expect([...h.emitted].reverse().find(e=>e.event==='furniture:state')?.data).toHaveLength(1);
   const late=h.connect('late');expect(late.messages.find(e=>e.event==='furniture:state')?.data).toHaveLength(1);
   h.g.owned=vi.fn(async()=>false);await h.service.recheck();expect(h.players.get('a')?.collectibleAvatar).toBeUndefined();expect([...h.emitted].reverse().find(e=>e.event==='furniture:state')?.data).toEqual([]);expect(a.messages.at(-1)?.data.address).toBeNull();
  }finally{h.service.stop();}
 });
 it('clears furniture on room deletion and prevents a disconnected pending request from equipping',async()=>{
  const h=harness(),a=h.connect('a');try{
   await a.login(Wallet.createRandom());await a.send('wallet:place',{collection:'furni',tokenId:'1',roomId:'room',gx:3,gy:3});h.service.clearRoom();expect([...h.emitted].reverse().find(e=>e.event==='furniture:state')?.data).toEqual([]);
   let finish!:(asset:CollectibleAsset)=>void;h.g.asset=vi.fn(()=>new Promise<CollectibleAsset>(resolve=>finish=resolve));const pending=a.send('wallet:wear',{collection:'genesis',tokenId:'1'});await a.send('wallet:disconnect');finish(asset);expect((await pending).ok).toBe(false);expect(h.players.get('a')?.collectibleAvatar).toBeUndefined();
  }finally{h.service.stop();}
 });
 it('allows one session per wallet and fails closed if ownership reads fail',async()=>{
  const h=harness(),owner=Wallet.createRandom(),a=h.connect('a'),b=h.connect('b');try{
   await a.login(owner);await a.send('wallet:wear',{collection:'genesis',tokenId:'1'});await b.login(owner);expect(h.players.get('a')?.collectibleAvatar).toBeUndefined();expect((await a.send('wallet:list',{collection:'genesis'})).ok).toBe(false);
   await b.send('wallet:wear',{collection:'genesis',tokenId:'1'});h.g.owned=vi.fn(async()=>{throw Error('RPC outage');});await h.service.recheck();expect(h.players.get('b')?.collectibleAvatar).toBeUndefined();
  }finally{h.service.stop();}
 });
});
