import {parseHabboFigure, type CollectibleFinish} from '@cocoworking/shared';
import traitIds from './habboAvatarTraits.json';

// Set and palette IDs published by Habbo's Avatar Editor on 9 November 2026.
// https://collectibles.habbo.com/traits/editor/
type SetId = string | {m?: string; f?: string};
const {Hues, Complexion, 'Hair Color': hairColours, ...figureSets} = traitIds;
const sets: Record<string, Record<string, SetId>> = figureSets;
const huePalettes: Record<string, Record<string, string>> = Hues;
const slots = ['Face','Hair','Hat','Head Accessory','Eyewear','Mask','Shirt','Jacket','Jewelry','Belt','Legs','Shoes'];

function lookup<T>(entries: Record<string, T> | undefined, name: string | undefined) {
  return entries && name && Object.hasOwn(entries, name) ? entries[name] : undefined;
}

export function collectibleAvatarStyle(metadata: {figureString?: unknown; attributes?: unknown}): {figure?: string; finish?: CollectibleFinish} {
  const traits = new Map<string, string>();
  if (Array.isArray(metadata.attributes)) {
    for (const trait of metadata.attributes) {
      if (typeof trait?.trait_type === 'string' && typeof trait.value === 'string') traits.set(trait.trait_type, trait.value);
    }
  }
  const effect = traits.get('Effect');
  const finish = effect === 'Golden H' ? 'gold' : effect === 'Diamond H' ? 'diamond' : effect === 'Rainbow H' ? 'rainbow' : effect === 'Trippy H' || effect === 'Ultra Trippy H' ? 'trippy' : undefined;
  const publishedFigure = parseHabboFigure(metadata.figureString);
  if (publishedFigure) return {figure: publishedFigure, finish};

  const gender = traits.get('Gender');
  if ((gender !== 'Male' && gender !== 'Female') || !traits.has('Face')) return {finish};
  const palettes = lookup(huePalettes, traits.get('Hues'));
  const figure: string[] = [];
  for (const slot of slots) {
    // The Avatar Editor supplies white suspenders for legacy tokens with no Legs trait.
    const value = traits.get(slot) ?? (slot === 'Legs' ? 'White Suspender Pants' : undefined);
    if (!value || value === 'None') continue;
    const set = lookup(sets[slot], value);
    if (!set) return {finish};
    const template = typeof set === 'string' ? set : gender === 'Male' ? set.m ?? set.f : set.f ?? set.m;
    if (!template) return {finish};
    if (!template.includes('{0}')) {
      figure.push(template);
      continue;
    }
    const palette = slot === 'Face' ? lookup(Complexion, traits.get('Complexion'))
      : slot === 'Hair' ? lookup(hairColours, traits.get('Hair Color'))
      : lookup(palettes, slot);
    if (!palette) return {finish};
    figure.push(template.replaceAll('{0}', palette));
  }
  return {figure: parseHabboFigure(figure.join('.')) ?? undefined, finish};
}
