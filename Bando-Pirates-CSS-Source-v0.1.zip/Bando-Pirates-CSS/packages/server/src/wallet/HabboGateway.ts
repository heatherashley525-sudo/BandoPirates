import {Interface} from 'ethers';
import {HabboFurniture} from './HabboFurniture';
import {collectibleAvatarStyle} from './HabboAvatarFigure';
import type {HabboFurnitureDefinition} from '@cocoworking/shared';
import {collectionById,parseTokenId,safeCollectibleImage,type CollectionId,type CollectibleAsset,type CollectiblePage} from '@cocoworking/shared';
const abi=new Interface(['function ownerOf(uint256) view returns (address)','function tokensOfOwner(address) view returns (uint256[])','function balanceOf(address) view returns (uint256)','function tokenOfOwnerByIndex(address,uint256) view returns (uint256)']);
export interface AssetGateway {
 owned(address:string,collection:CollectionId,tokenId:string):Promise<boolean>;
 asset(address:string,collection:CollectionId,tokenId:string):Promise<CollectibleAsset>;
 list(address:string,collection:CollectionId,cursor?:string):Promise<CollectiblePage>;
 furniture?(asset:CollectibleAsset):Promise<HabboFurnitureDefinition>;
}
/** All RPC and metadata destinations are server controlled. No user-supplied URLs. */
export class HabboGateway implements AssetGateway {
 private verified=new Map<number,number>();private rpcId=0;private furnitureAssets:HabboFurniture;
 constructor(private fetcher:typeof fetch=fetch,private rpc:Record<number,string>={1:process.env.ETHEREUM_RPC_URL||'https://ethereum-rpc.publicnode.com',13371:process.env.IMMUTABLE_RPC_URL||'https://rpc.immutable.com'}){this.furnitureAssets=new HabboFurniture(fetcher);}
 furniture(asset:CollectibleAsset){return this.furnitureAssets.resolve(asset);}
 private async json(url:string,init:RequestInit={}){
  const response=await this.fetcher(url,{...init,redirect:'error',signal:AbortSignal.timeout(12000)});
  if(!response.ok)throw Error(`Collectible service unavailable (${response.status}). Try again later.`);
  const reader=response.body?.getReader();let text='';
  if(reader){const decoder=new TextDecoder();let size=0;try{while(true){const {value,done}=await reader.read();if(done)break;size+=value.length;if(size>1024*1024)throw Error('Collectible response too large.');text+=decoder.decode(value,{stream:true});}}finally{await reader.cancel();}}else text=await response.text();
  if(text.length>1024*1024)throw Error('Collectible response too large.');return JSON.parse(text);
 }
 private async rpcCall(chain:number,method:string,params:unknown[]){
  const url=this.rpc[chain];if(!url)throw Error('This blockchain is not configured.');
  const data=await this.json(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:++this.rpcId,method,params})});
  if(data.error||typeof data.result!=='string'){const error=Error('Blockchain read failed. Try again later.');error.name=data.error?.code===3?'ContractReverted':'RpcReadFailed';throw error;}return data.result as string;
 }
 private async read(collection:CollectionId,method:string,args:unknown[]){
  const c=collectionById(collection);if(!c)throw Error('Unsupported collection.');
  if((this.verified.get(c.chainId)||0)<Date.now()){
   if(Number(BigInt(await this.rpcCall(c.chainId,'eth_chainId',[])))!==c.chainId)throw Error('RPC network does not match this collection.');
   this.verified.set(c.chainId,Date.now()+300000);
  }
  const data=await this.rpcCall(c.chainId,'eth_call',[{to:c.contract,data:abi.encodeFunctionData(method,args)},'latest']);return abi.decodeFunctionResult(method,data);
 }
 async owned(address:string,collection:CollectionId,tokenId:string){
  if(!parseTokenId(tokenId))throw Error('Invalid token ID.');
  try{return String((await this.read(collection,'ownerOf',[tokenId]))[0]).toLowerCase()===address.toLowerCase();}catch(error){if(error instanceof Error&&error.name==='ContractReverted')return false;throw error;}
 }
 async asset(address:string,collection:CollectionId,tokenId:string,includeInventoryIcon=true):Promise<CollectibleAsset>{
  const c=collectionById(collection);if(!c||!parseTokenId(tokenId))throw Error('Choose a supported collection and token ID.');
  if(!await this.owned(address,collection,tokenId))throw Error('This wallet does not currently own that collectible.');
  // zkEVM token IDs identify individual instances; their metadata is indexed by Immutable.
  const raw=await this.json(c.chainId===1?`https://nft-tokens.habbo.com/${c.metadata}/metadata/${tokenId}.json`:`https://api.immutable.com/v1/chains/imtbl-zkevm-mainnet/collections/${c.contract}/nfts/${tokenId}`,c.chainId===13371&&process.env.IMMUTABLE_API_KEY?{headers:{'x-immutable-api-key':process.env.IMMUTABLE_API_KEY}}:{});
  const metadata=c.chainId===1?raw:raw.result;
  if(!metadata||c.chainId===13371&&(metadata.contract_address?.toLowerCase()!==c.contract||String(metadata.token_id)!==tokenId))throw Error('Collectible metadata does not match the token.');
  const image=safeCollectibleImage(metadata.image);
  if(!image)throw Error('This collectible has no supported official preview image.');
  if(!await this.owned(address,collection,tokenId))throw Error('This wallet does not currently own that collectible.');
  const style=c.kind==='avatar'?collectibleAvatarStyle(metadata):{};
  const asset:CollectibleAsset={key:`${c.chainId}:${c.contract}:${tokenId}`,collection,chainId:c.chainId,contract:c.contract,tokenId,name:typeof metadata.name==='string'?metadata.name.slice(0,120):`${c.name} #${tokenId}`,image,kind:c.kind,...style};
  if(includeInventoryIcon&&collection==='furni')asset.furnitureIcon=await this.furnitureAssets.icon(asset).catch(()=>undefined);
  return asset;
 }
 async list(address:string,collection:CollectionId,cursor=''):Promise<CollectiblePage>{
  const c=collectionById(collection);if(!c)throw Error('Unsupported collection.');let ids:string[]=[],nextCursor:string|null=null;
  if(c.chainId===1){
   if(cursor&&!/^\d{1,6}$/.test(cursor))throw Error('Invalid page.');const offset=Number(cursor)||0;
   // Genesis supports enumeration; crafted contracts may expose tokensOfOwner instead.
   try{
    const count=BigInt((await this.read(collection,'balanceOf',[address]))[0]);const end=Math.min(offset+12,Number(count));
    for(let i=offset;i<end;i+=4)ids.push(...await Promise.all(Array.from({length:Math.min(4,end-i)},(_,n)=>this.read(collection,'tokenOfOwnerByIndex',[address,i+n]).then(r=>String(r[0])))));
    nextCursor=end<Number(count)?String(end):null;
   }catch{
    const all=(await this.read(collection,'tokensOfOwner',[address]))[0] as bigint[];ids=all.slice(offset,offset+12).map(String);nextCursor=offset+12<all.length?String(offset+12):null;
   }
  }else{
   if(cursor.length>2048)throw Error('Invalid page.');
   const url=new URL(`https://api.immutable.com/v1/chains/imtbl-zkevm-mainnet/accounts/${address}/nfts`);url.searchParams.set('contract_address',c.contract);url.searchParams.set('page_size','12');if(cursor)url.searchParams.set('page_cursor',cursor);
   const data=await this.json(url.href,process.env.IMMUTABLE_API_KEY?{headers:{'x-immutable-api-key':process.env.IMMUTABLE_API_KEY}}:{});
   if(!Array.isArray(data.result))throw Error('Could not read the collectible inventory.');
   ids=data.result.filter((n:any)=>typeof n.contract_address==='string'&&n.contract_address.toLowerCase()===c.contract&&parseTokenId(n.token_id)).slice(0,12).map((n:any)=>n.token_id);
   nextCursor=typeof data.page?.next_cursor==='string'&&data.page.next_cursor.length<=2048?data.page.next_cursor:null;
  }
  const assets:CollectibleAsset[]=[];
  // Verify every listed token on-chain; stale indexer entries never grant access.
  for(let i=0;i<ids.length;i+=4){const batch=await Promise.all(ids.slice(i,i+4).map(async id=>{try{return await this.asset(address,collection,id,false);}catch(error){if(error instanceof Error&&error.message.includes('does not currently own'))return null;throw error;}}));for(const asset of batch)if(asset)assets.push(asset);}
  if(collection==='furni')await Promise.all(assets.map(async asset=>{
   asset.furnitureIcon=await this.furnitureAssets.icon(asset).catch(()=>undefined);
  }));
  return {assets,nextCursor};
 }
}
