import {randomBytes} from 'node:crypto';
import {getAddress,verifyMessage} from 'ethers';
import type {WalletChallenge,WalletState,CollectibleAsset,CollectionId} from '@cocoworking/shared';
import type {AssetGateway} from './HabboGateway';

export function walletOrigin(requestOrigin:unknown,configured=process.env.BANDO_PUBLIC_URL||process.env.RENDER_EXTERNAL_URL,referer?:unknown):string{
 if(typeof requestOrigin!=='string'&&typeof referer==='string'){try{requestOrigin=new URL(referer).origin;}catch{throw Error('Invalid wallet website reference.');}}
 if(typeof requestOrigin!=='string')throw Error('Open the game on its HTTPS website to connect a wallet.');
 const u=new URL(requestOrigin);if(u.origin!==requestOrigin)throw Error('Invalid website origin.');
 if(configured){if(new URL(configured).origin!==u.origin)throw Error('Wallet website does not match BANDO_PUBLIC_URL.');}
 else if(!['localhost','127.0.0.1','[::1]'].includes(u.hostname))throw Error('Wallet login needs BANDO_PUBLIC_URL configured on the server.');
 if(u.protocol!=='https:'&&!(u.protocol==='http:'&&['localhost','127.0.0.1','[::1]'].includes(u.hostname)))throw Error('Wallet connections require HTTPS.');return u.origin;
}
export class WalletSession {
 address:string|null=null;expiresAt=0;generation=0;mode:'verified'|'test'='verified';private pending?:WalletChallenge;private nextChallenge=0;private testAssets=new Map<string,CollectibleAsset>();
 constructor(private binding:string,private origin:string,readonly gateway:AssetGateway,private now=Date.now){}
 state(message?:string):WalletState{return {address:this.address,expiresAt:this.expiresAt||undefined,message,mode:this.mode};}
 testAddress(rawAddress:unknown):WalletState{
  if(typeof rawAddress!=='string'||!/^0x[0-9a-f]{40}$/i.test(rawAddress))throw Error('Enter a valid 0x wallet address.');
  const address=getAddress(rawAddress);this.testAssets.clear();this.pending=undefined;this.address=address;this.mode='test';this.expiresAt=this.now()+3600000;this.generation++;return this.state('Unverified test wallet. Loaded collectibles are demo copies for this session.');
 }
 challenge(rawAddress:unknown,chainId:unknown):WalletChallenge{
  if(this.now()<this.nextChallenge)throw Error('Wait a moment before requesting another signature.');this.nextChallenge=this.now()+2000;
  if(typeof rawAddress!=='string'||![1,13371].includes(chainId as number))throw Error('Select Ethereum or Immutable zkEVM in MetaMask.');
  const address=getAddress(rawAddress),issued=this.now(),expiresAt=issued+300000,nonce=randomBytes(16).toString('hex');
  const message=`${new URL(this.origin).host} wants you to sign in with your Ethereum account:\n${address}\n\nConnect your wallet to Bando Pirates to verify collectible ownership. This does not transfer tokens or grant spending permissions.\n\nURI: ${this.origin}\nVersion: 1\nChain ID: ${chainId}\nNonce: ${nonce}\nIssued At: ${new Date(issued).toISOString()}\nExpiration Time: ${new Date(expiresAt).toISOString()}\nRequest ID: ${this.binding}`;
  return this.pending={message,address,chainId:chainId as number,expiresAt,origin:this.origin};
 }
 verify(signature:unknown):WalletState{
  const challenge=this.pending;this.pending=undefined;
  if(!challenge||challenge.expiresAt<=this.now()||typeof signature!=='string'||signature.length>132)throw Error('Signature request expired or was already used. Connect again.');
  if(verifyMessage(challenge.message,signature).toLowerCase()!==challenge.address.toLowerCase())throw Error('The signature does not match the selected wallet.');
  this.testAssets.clear();this.address=challenge.address;this.mode='verified';this.expiresAt=this.now()+3600000;this.generation++;return this.state();
 }
 require(){if(!this.address||this.expiresAt<=this.now())throw Error('Connect and verify your wallet again.');return this.address;}
 /** Only server-fetched inventory is retained, scoped to this unsigned session. */
 rememberTestAssets(assets:readonly CollectibleAsset[]){if(this.mode!=='test')return;for(const asset of assets){const key=asset.collection+':'+asset.tokenId;this.testAssets.delete(key);this.testAssets.set(key,{...asset,test:true});}while(this.testAssets.size>512)this.testAssets.delete(this.testAssets.keys().next().value!);}
 async asset(collection:CollectionId,tokenId:string){const generation=this.generation,address=this.require(),cached=this.mode==='test'?this.testAssets.get(collection+':'+tokenId):undefined;if(cached)return {...cached,test:true};const asset=await this.gateway.asset(address,collection,tokenId);if(generation!==this.generation||this.require()!==address)throw Error('Wallet changed. Try again.');if(this.mode==='test'){this.rememberTestAssets([asset]);return {...asset,test:true};}return asset;}
 async owns(asset:CollectibleAsset){const address=this.require();return this.mode==='test'?this.testAssets.has(asset.collection+':'+asset.tokenId):this.gateway.owned(address,asset.collection,asset.tokenId);}
 disconnect(){this.testAssets.clear();this.address=null;this.mode='verified';this.expiresAt=0;this.pending=undefined;this.generation++;}
}
