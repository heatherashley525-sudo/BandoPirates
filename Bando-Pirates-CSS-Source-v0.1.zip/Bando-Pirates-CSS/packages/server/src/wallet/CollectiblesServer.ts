import type {Server} from 'socket.io';
import {collectionById,parseTokenId,resolvePlacement,placementError,supportEditError,editFurniture,seatPlayersUnderFurniture,findSpawn,type FurnitureState,type FurnitureRotation,type Player,type RoomInfo,type CollectibleAsset,type CollectionId,type CollectiblePage} from '@cocoworking/shared';
import {HabboGateway,type AssetGateway} from './HabboGateway';
import {WalletSession,walletOrigin} from './WalletSession';
import {parseHabboFigure} from '@cocoworking/shared';

export class CollectiblesServer {
 private sessions=new Map<string,{wallet:WalletSession;socket:any;userId:string}>();private placed=new Map<string,{socketId:string;item:FurnitureState}>();
 private timer:ReturnType<typeof setInterval>;private checking=false;
 constructor(private io:Server,private players:Map<string,Player>,private room:()=>RoomInfo|null,private gateway:AssetGateway=new HabboGateway(),private publicUrl?:string,private nativeFurniture:()=>FurnitureState[]=()=>[],private onFurnitureChange?:()=>void){
  this.timer=setInterval(()=>void this.recheck(),60000);this.timer.unref?.();
 }
 stop(){clearInterval(this.timer);}
 furniture(){return [...this.placed.values()].map(p=>p.item);}
 layout(){return [...this.nativeFurniture(),...this.furniture()];}
 has(id:unknown){return typeof id==='string'&&this.placed.has(id);}
 private publish(){
  const items=this.layout();
  for(const player of this.players.values())if(player.seat&&!items.some(i=>i.id===player.seat!.furnitureId)){
   delete player.seat;player.position=findSpawn(items,this.room()?.tileSplits);this.io.emit('player:posture',player);
  }
  for(const player of seatPlayersUnderFurniture([...this.players.values()],items,this.room()?.tileSplits))if(player!==this.players.get(player.id)){this.players.set(player.id,player);this.io.emit('player:posture',player);}
  if(this.onFurnitureChange)this.onFurnitureChange();else this.io.emit('furniture:state',items);
 }
 private remove(ids:Set<string>){
  let expanded=true;while(expanded){expanded=false;for(const [id,p] of this.placed)if(p.item.supportId&&ids.has(p.item.supportId)&&!ids.has(id)){ids.add(id);expanded=true;}}
  let changed=false;for(const id of ids)if(this.placed.delete(id))changed=true;if(changed)this.publish();
 }
 private clearAvatar(id:string){const player=this.players.get(id);if(player?.collectibleAvatar){delete player.collectibleAvatar;this.io.emit('player:collectible-avatar',{id,asset:null});}}
 private clearUsage(id:string){this.clearAvatar(id);this.remove(new Set([...this.placed].filter(([,p])=>p.socketId===id).map(([key])=>key)));}
 ordinaryAvatar(userId:string){for(const [id,s] of this.sessions)if(s.userId===userId)this.clearAvatar(id);}
 clearRoom(){this.placed.clear();this.publish();}
 disconnect(id:string){const session=this.sessions.get(id);session?.wallet.disconnect();this.clearUsage(id);this.sessions.delete(id);}
 async edit(socketId:string,userId:string,type:'move'|'rotate'|'pickup'|'state',data:any){
  const entry=this.placed.get(data?.id),room=this.room();if(!entry||!room||data?.roomId!==room.id)throw Error('This furniture is no longer in the room.');
  const item=entry.item;if(userId!==room.ownerId&&(type!=='pickup'||userId!==item.ownerId))throw Error('Only the room owner can move or rotate furniture.');
  const players=[...this.players.values()].map(p=>p.position);
  const blocked=supportEditError(item,this.layout(),players);if(blocked)throw Error(blocked);
  if(type==='pickup'){this.remove(new Set([item.id]));return;}
  const owner=this.sessions.get(entry.socketId);if(!owner)throw Error('The furniture owner is no longer connected.');
  const generation=owner.wallet.generation;if(!await owner.wallet.owns(item.nft!.asset)){this.remove(new Set([item.id]));throw Error('The NFT is no longer owned by its connected wallet.');}
  if(this.placed.get(item.id)!==entry||this.sessions.get(entry.socketId)!==owner||owner.wallet.generation!==generation||this.room()?.id!==room.id||!this.players.has(socketId))throw Error('Furniture or wallet changed. Try again.');
  const layout=this.layout(),currentPlayers=[...this.players.values()].map(p=>p.position);
  if(type==='state'){
   const unavailable=supportEditError(item,layout,currentPlayers);if(unavailable)throw Error(unavailable);
   const states=item.nft!.definition.states,next=states[(states.indexOf(item.state??0)+1)%states.length];this.placed.set(item.id,{...entry,item:{...item,state:next}});
  }else{
   const result=editFurniture(layout,{action:type,id:item.id,gx:data?.gx,gy:data?.gy},userId,room.ownerId,currentPlayers,this.room()?.tileSplits);if(!result.ok)throw Error(result.error);
   this.placed.set(item.id,{...entry,item:result.furniture.find(i=>i.id===item.id)!});
  }
  this.publish();
 }
 connect(socket:any,userId:string){
  socket.emit('furniture:state',this.layout());
  let busy=false;let requests:number[]=[];
  const session=()=>{
   let current=this.sessions.get(socket.id);if(current)return current;
   const origin=walletOrigin(socket.handshake.headers?.origin,this.publicUrl,socket.handshake.headers?.referer);
   current={wallet:new WalletSession(socket.id+':'+userId,origin,this.gateway),socket,userId};this.sessions.set(socket.id,current);return current;
  };
  const on=(name:string,action:(input:any,wallet:WalletSession)=>unknown|Promise<unknown>)=>socket.on(name,async(input:unknown,ack:unknown)=>{
   if(typeof ack!=='function')return;
   requests=requests.filter(t=>t>Date.now()-10000);
   if(busy||requests.length>=20){ack({ok:false,error:'A wallet request is already running. Wait a moment.'});return;}
   busy=true;requests.push(Date.now());
   try{const s=session(),result=await action(input,s.wallet);if(this.sessions.get(socket.id)!==s)throw Error('Wallet disconnected. Connect again.');ack({ok:true,value:result});}
   catch(error){ack({ok:false,error:error instanceof Error?error.message:'Wallet request failed.'});}
   finally{busy=false;}
  });
  on('wallet:challenge',(v,w)=>w.challenge(v?.address,v?.chainId));
  on('wallet:test',(v,w)=>{
   const result=w.testAddress(v?.address);this.clearUsage(socket.id);socket.emit('wallet:state',result);return result;
  });
  on('wallet:verify',(v,w)=>{
   const result=w.verify(v?.signature);this.clearUsage(socket.id);
   // A wallet has one active game session, preventing duplicate NFT representations in tabs.
   for(const [id,s] of this.sessions)if(id!==socket.id&&s.wallet.mode==='verified'&&s.wallet.address?.toLowerCase()===w.address?.toLowerCase()){
    this.clearUsage(id);s.wallet.disconnect();s.socket.emit('wallet:state',s.wallet.state('Wallet connected in another game session.'));
   }
   socket.emit('wallet:state',result);return result;
  });
  on('wallet:list',async(v,w):Promise<CollectiblePage>=>{
   const collection=collectionById(v?.collection);if(!collection||v?.cursor!==undefined&&typeof v.cursor!=='string')throw Error('Choose a supported collection.');
   const generation=w.generation,address=w.require(),page=await w.gateway.list(address,collection.id,v?.cursor);
   if(generation!==w.generation||w.require()!==address)throw Error('Wallet changed. Refresh the inventory.');w.rememberTestAssets(page.assets);return w.mode==='test'?{...page,assets:page.assets.map(asset=>({...asset,test:true}))}:page;
  });
  const selected=async(v:any,w:WalletSession)=>{const c=collectionById(v?.collection),tokenId=parseTokenId(v?.tokenId);if(!c||!tokenId)throw Error('Choose a supported collection and token ID.');return w.asset(c.id,tokenId);};
  const active=(w:WalletSession)=>{if(this.sessions.get(socket.id)?.wallet!==w)throw Error('Wallet disconnected.');w.require();};
  on('wallet:lookup',selected);
  on('wallet:wear',async(v,w)=>{
   const asset=await selected(v,w);active(w);if(asset.kind!=='avatar')throw Error('Only an avatar collection can be worn.');
   if(!parseHabboFigure(asset.figure))throw Error('Habbo does not provide a wearable figure for this collectible.');
   const player=this.players.get(socket.id);if(!player)throw Error('Reconnect to the room.');player.collectibleAvatar=asset;this.io.emit('player:collectible-avatar',{id:socket.id,asset});return asset;
  });
  on('wallet:unwear',(_v,w)=>{w.require();const player=this.players.get(socket.id);if(player)delete player.collectibleAvatar;this.io.emit('player:collectible-avatar',{id:socket.id,asset:null});return null;});
  const prepare=async(v:any,w:WalletSession)=>{
   const asset=await selected(v,w);active(w);if(asset.collection!=='furni'||!w.gateway.furniture)throw Error('Select a supported furniture NFT.');
   const generation=w.generation,definition=await w.gateway.furniture(asset);active(w);if(!await w.owns(asset))throw Error('This wallet no longer owns that furniture.');active(w);if(w.generation!==generation)throw Error('Wallet changed.');
   return {...asset,furniture:definition};
  };
  on('wallet:prepare',prepare);
  on('wallet:place',async(v,w)=>{
   const asset=await prepare(v,w);active(w);const room=this.room();if(!room||v?.roomId!==room.id)throw Error('Enter the current room first.');
   if(!Number.isFinite(v?.gx)||!Number.isFinite(v?.gy))throw Error('Choose a floor tile.');
   const id='nft:'+socket.id+':'+asset.key;if(this.placed.has(id))throw Error('This NFT is already placed. Move or pick up its furniture.');
   if([...this.placed.values()].filter(p=>p.socketId===socket.id).length>=32)throw Error('Place up to 32 collectible items per wallet session.');
   const layout=this.layout(),item=resolvePlacement({id,kind:'habbo-nft',ownerId:userId,ownerName:this.players.get(socket.id)?.name,gx:v.gx,gy:v.gy,rotation:0,nft:{asset,definition:asset.furniture!},state:asset.furniture!.states[0]},v.gx,v.gy,layout,room.tileSplits);
   const error=placementError(item,layout,[...this.players.values()].map(p=>p.position),room.tileSplits);if(error)throw Error(error);
   this.placed.set(id,{socketId:socket.id,item});this.publish();return item;
  });
  on('wallet:pickup',async(v,w)=>{
   w.require();const c=collectionById(v?.collection),tokenId=parseTokenId(v?.tokenId);if(c?.id!=='furni'||!tokenId)throw Error('Select placed NFT furniture.');
   await this.edit(socket.id,userId,'pickup',{id:`nft:${socket.id}:${c.chainId}:${c.contract}:${tokenId}`,roomId:v?.roomId});return null;
  });
  // Always allow disconnect, including while an upstream request is pending.
  socket.on('wallet:disconnect',(_v:unknown,ack:unknown)=>{const s=this.sessions.get(socket.id);s?.wallet.disconnect();this.clearUsage(socket.id);this.sessions.delete(socket.id);socket.emit('wallet:state',{address:null});if(typeof ack==='function')ack({ok:true,value:null});});
 }
 async recheck(){
  if(this.checking)return;this.checking=true;
  try{for(const [id,s] of this.sessions){const generation=s.wallet.generation;
   try{
    s.wallet.require();const used=new Map<string,CollectibleAsset>();const avatar=this.players.get(id)?.collectibleAvatar;if(avatar)used.set(avatar.key,avatar);
    for(const p of this.placed.values())if(p.socketId===id)used.set(p.item.nft!.asset.key,p.item.nft!.asset);
    for(const asset of used.values())if(!await s.wallet.owns(asset))throw Error('Collectible ownership changed.');
    if(generation!==s.wallet.generation)continue;
   }catch{
    if(this.sessions.get(id)!==s||generation!==s.wallet.generation)continue;
    const test=s.wallet.mode==='test';this.clearUsage(id);s.wallet.disconnect();s.socket.emit('wallet:state',s.wallet.state(test?'Reload the test wallet to refresh its demo items.':'Ownership could not be confirmed. Reconnect to verify again.'));
   }
  }}finally{this.checking=false;}
 }
}
