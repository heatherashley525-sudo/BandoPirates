import {habboFurnitureIconUrl,parseHabboFurnitureDefinition,type CollectibleAsset,type HabboFurnitureDefinition,type HabboFurnitureIcon} from '@cocoworking/shared';
/** Bind an owned NFT's official classname to live Habbo floor-furniture data and pinned renders. */
export class HabboFurniture {
 private catalog?:Promise<{floor:Map<string,any>;all:Map<string,any>}>;private catalogUntil=0;private definitions=new Map<string,Promise<HabboFurnitureDefinition>>();
 constructor(private fetcher:typeof fetch=fetch){}
 private async json(url:string,maxBytes:number){
  const response=await this.fetcher(url,{signal:AbortSignal.timeout(20000),redirect:'follow'});if(!response.ok)throw Error('Furniture asset service is unavailable. Try again later.');
  const finalUrl=new URL(response.url||url);if(!['www.habbo.com','images.habbo.com','www.habboassets.com'].includes(finalUrl.hostname)||finalUrl.protocol!=='https:')throw Error('Unexpected furniture asset source.');
  const reader=response.body?.getReader();let text='',size=0;if(reader){const decoder=new TextDecoder();try{while(true){const r=await reader.read();if(r.done)break;size+=r.value.length;if(size>maxBytes)throw Error('Furniture data is too large.');text+=decoder.decode(r.value,{stream:true});}}finally{await reader.cancel();}}else text=await response.text();
  if(text.length>maxBytes)throw Error('Furniture data is too large.');return JSON.parse(text);
 }
 private async furnitureData(){
  if(!this.catalog||Date.now()>this.catalogUntil){this.catalogUntil=Date.now()+21600000;this.catalog=this.json('https://www.habbo.com/gamedata/furnidata_json/1',16*1024*1024).then(data=>{
   if(!Array.isArray(data.roomitemtypes?.furnitype))throw Error('Invalid Habbo furniture data.');
   const nftEntries=(rows:any[])=>rows.filter(f=>typeof f?.classname==='string'&&/^nft_[a-zA-Z0-9_]{1,95}$/.test(f.classname)).map(f=>[f.classname,f] as const);
   const floor=nftEntries(data.roomitemtypes.furnitype);
   const wall=nftEntries(Array.isArray(data.wallitemtypes?.furnitype)?data.wallitemtypes.furnitype:[]);
   return {floor:new Map(floor),all:new Map([...wall,...floor])};
  }).catch(error=>{this.catalog=undefined;throw error;});}return this.catalog;
 }
 private match(asset:CollectibleAsset,catalog:Map<string,any>){
  const filename=new URL(asset.image).pathname.split('/').pop()?.replace(/\.(png|gif)$/,'');
  if(filename?.startsWith('nft_'))return catalog.get(filename);
  const normalize=(name:string)=>name.trim().toLowerCase().replace(/[^a-z0-9]+/g,' ');
  const matches=[...catalog.values()].filter(item=>typeof item.name==='string'&&normalize(item.name)===normalize(asset.name));
  return matches.length===1?matches[0]:undefined;
 }
 async icon(asset:CollectibleAsset):Promise<HabboFurnitureIcon|undefined>{
  const data=this.match(asset,(await this.furnitureData()).all);
  if(!data)return undefined;
  const icon={classname:data.classname,revision:data.revision};
  return habboFurnitureIconUrl(icon)?icon:undefined;
 }
 async resolve(asset:CollectibleAsset):Promise<HabboFurnitureDefinition>{
  if(asset.collection!=='furni')throw Error('Only furniture collectibles can be placed in the room.');
  const data=this.match(asset,(await this.furnitureData()).floor);
  if(!data)throw Error('This NFT is not matched to an unambiguous native furniture mapping.');
  const classname=data.classname;
  const key=classname+':'+data.revision;let pending=this.definitions.get(key);
  if(!pending){pending=this.json(`https://www.habboassets.com/imaging/info/furniture/${classname}`,128*1024).then(info=>{
   if(info.classname!==classname||!Array.isArray(info.revisions)||!info.revisions.includes(data.revision))throw Error('This furniture revision is not available from the sprite renderer.');
   const directions=[2,4,6,0].filter(n=>Array.isArray(info.directions)&&info.directions.includes(n));
   const definition=parseHabboFurnitureDefinition({classname,revision:data.revision,width:data.ydim,depth:data.xdim,height:Number(data.height)*2,seat:data.cansiton===true,walkable:data.canstandon===true,stackable:data.canputstuffon===true,directions,states:Array.isArray(info.states)&&info.states.length?info.states:[0]});
   if(!definition)throw Error('This furniture has unsupported dimensions, heights or sprite states.');return definition;
  }).catch(error=>{this.definitions.delete(key);throw error;});this.definitions.set(key,pending);}
  return pending;
 }
}
