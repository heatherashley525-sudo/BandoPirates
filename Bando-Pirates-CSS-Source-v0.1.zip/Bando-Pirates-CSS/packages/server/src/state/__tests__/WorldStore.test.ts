import { afterEach,describe,expect,it } from 'vitest';
import { mkdtempSync,readFileSync,rmSync,writeFileSync,mkdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { WorldStore } from '../WorldStore';
import { applyWorldCommand,inventoryFor,roomFurniture,saveAppearance,blankAppearance } from '@cocoworking/shared';
const dirs:string[]=[];function file(){const d=mkdtempSync(join(tmpdir(),'heather-world-'));dirs.push(d);return join(d,'world.json');}
afterEach(()=>{for(const d of dirs.splice(0))rmSync(d,{recursive:true,force:true});});
describe('durable furniture inventory',()=>{
 it('restores the same identity and inventory after a server restart',()=>{
  const path=file(),store=new WorldStore(path),identity=store.authenticate(undefined,'Heather')!;
  const restarted=new WorldStore(path),again=restarted.authenticate(identity.token,'Heather')!;
  expect(again.id).toBe(identity.id);expect(Object.keys(restarted.state.furniture)).toHaveLength(4);
  expect(roomFurniture(restarted.state).every(i=>i.ownerId===identity.id)).toBe(true);
 });
 it('persists deletion returns for an offline owner, without duplicate starters on reconnect',()=>{
  const path=file(),store=new WorldStore(path),owner=store.authenticate(undefined,'Heather')!,guest=store.authenticate(undefined,'Guest')!;
  const item=inventoryFor(store.state,guest.id)[1],roomId=store.state.room!.id;
  const placed=applyWorldCommand(store.state,guest.id,{type:'place',id:item.id,gx:7,gy:7,roomId},[]);if(!placed.ok)throw Error(placed.error);store.commit(placed.world);
  const deleted=applyWorldCommand(store.state,owner.id,{type:'delete-room',roomId},[]);if(!deleted.ok)throw Error(deleted.error);store.commit(deleted.world);
  const restarted=new WorldStore(path);restarted.authenticate(guest.token,'Guest');
  expect(inventoryFor(restarted.state,guest.id)).toHaveLength(4);expect(inventoryFor(restarted.state,owner.id)).toHaveLength(4);expect(Object.keys(restarted.state.furniture)).toHaveLength(8);
 });
 it('restores stacked heights and support links after restart',()=>{
  const path=file(),store=new WorldStore(path),owner=store.authenticate(undefined,'Heather')!;
  const roomId=store.state.room!.id,item=inventoryFor(store.state,owner.id).find(i=>i.kind==='base-table')!;
  const placed=applyWorldCommand(store.state,owner.id,{type:'place',roomId,id:item.id,gx:6,gy:3},[]);if(!placed.ok)throw Error(placed.error);store.commit(placed.world);
  const restarted=new WorldStore(path);restarted.authenticate(owner.token,'Heather');
  expect(roomFurniture(restarted.state).find(i=>i.id===item.id)).toMatchObject({z:2,supportId:`${owner.id}:base-table`,ownerId:owner.id});
  expect(Object.keys(restarted.state.furniture)).toHaveLength(4);
 });
 it('persists the saved avatar skin independently of room and inventory changes',()=>{
  const path=file(),store=new WorldStore(path),identity=store.authenticate(undefined,'Heather')!;
  const result=saveAppearance(store.state,identity.id,{...blankAppearance(),skin:'#8c5e46'});if(!result.ok)throw Error(result.error);store.commit(result.world);
  const restarted=new WorldStore(path);restarted.authenticate(identity.token,'Heather');
  expect(restarted.state.profiles[identity.id].appearance).toEqual(result.appearance);expect(Object.keys(restarted.state.furniture)).toHaveLength(4);
 });
 it('rejects unknown saved credentials instead of issuing replacement inventory',()=>{
  const store=new WorldStore(),one=store.authenticate(undefined,'Heather')!;
  expect(store.authenticate('not-a-valid-token','Heather')).toBeNull();expect(Object.keys(store.state.profiles)).toHaveLength(1);
  expect(store.authenticate(undefined,'Heather')!.id).not.toBe(one.id);
 });
 it('stores credential hashes without writing plaintext tokens to disk',()=>{
  const path=file(),store=new WorldStore(path),identity=store.authenticate(undefined,'Heather')!;
  expect(readFileSync(path,'utf8')).not.toContain(identity.token);
 });
 it('does not change the in-memory world if saving fails',()=>{
  const path=file(),store=new WorldStore(path),identity=store.authenticate(undefined,'Heather')!,before=store.state;
  rmSync(path);mkdirSync(path);
  const result=applyWorldCommand(before,identity.id,{type:'delete-room',roomId:before.room!.id},[]);if(!result.ok)throw Error(result.error);
  expect(()=>store.commit(result.world)).toThrow();expect(store.state).toBe(before);
 });
 it('refuses to overwrite an unreadable save with an empty world',()=>{
  const path=file();writeFileSync(path,'broken save');expect(()=>new WorldStore(path)).toThrow();expect(readFileSync(path,'utf8')).toBe('broken save');
 });
});
