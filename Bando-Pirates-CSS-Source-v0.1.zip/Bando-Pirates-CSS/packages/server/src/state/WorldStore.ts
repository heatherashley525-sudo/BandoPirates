import { createHash,randomBytes,randomUUID } from 'node:crypto';
import { existsSync,readFileSync,mkdirSync,openSync,writeFileSync,fsyncSync,closeSync,renameSync,unlinkSync } from 'node:fs';
import { dirname } from 'node:path';
import { emptyWorld,registerPlayer,validateWorld,type WorldData } from '@cocoworking/shared';
export interface PlayerIdentity {id:string;name:string;token:string}
interface SavedData {world:WorldData;credentials:Record<string,string>}
export class WorldStore {
 private data:SavedData;
 constructor(private file?:string){
  if(file&&existsSync(file)){
   const parsed=JSON.parse(readFileSync(file,'utf8')) as SavedData;
   if(!parsed.credentials||typeof parsed.credentials!=='object'||Array.isArray(parsed.credentials))throw Error('Invalid saved credentials.');
   this.data={world:validateWorld(parsed.world),credentials:parsed.credentials};
  }else this.data={world:emptyWorld(),credentials:{}};
 }
 get state(){return this.data.world;}
 authenticate(token:unknown,name:unknown):PlayerIdentity|null {
  const safeName=typeof name==='string'?name.trim().slice(0,20)||'Guest':'Guest';
  let id:string,credential:string;
  if(typeof token==='string'&&token){
   id=this.data.credentials[this.hash(token)];if(!id||!this.data.world.profiles[id])return null;credential=token;
  }else if(token===undefined||token===null||token===''){id=randomUUID();credential=randomBytes(32).toString('base64url');}
  else return null;
  const world=registerPlayer(this.data.world,id,safeName),credentials={...this.data.credentials,[this.hash(credential)]:id};
  this.save({world,credentials});return {id,name:safeName,token:credential};
 }
 commit(world:WorldData){this.save({world:validateWorld(world),credentials:this.data.credentials});}
 private hash(token:string){return createHash('sha256').update(token).digest('hex');}
 private save(next:SavedData){
  if(this.file){
   mkdirSync(dirname(this.file),{recursive:true,mode:0o700});const temp=`${this.file}.${randomUUID()}.tmp`;
   try{const fd=openSync(temp,'w',0o600);try{writeFileSync(fd,JSON.stringify(next));fsyncSync(fd);}finally{closeSync(fd);}renameSync(temp,this.file);}
   finally{if(existsSync(temp))unlinkSync(temp);}
  }
  this.data=next;
 }
}
