import {CallServer} from "../calls/CallServer";
import { randomUUID } from "node:crypto";
import { WorldStore } from "../state/WorldStore";
import {CollectiblesServer} from '../wallet/CollectiblesServer';
import type {AssetGateway} from '../wallet/HabboGateway';
import { Server as SocketServer, type Namespace } from "socket.io";
import type { Server as HttpServer } from "http";
import {
  tileFromId,tileOverlaps,furnitureTiles,roomFurniture, inventoryFor, placementError, supportEditError, resolvePlacement, applyWorldCommand, findSpawn,saveAppearance, defaultAppearance,sitPlayer,standPlayer,movePlayer,seatPlayersUnderFurniture,
  type Player,
  type ChatMessage,
  type DJState,
  type AvatarAppearance,
  DEFAULT_FLOOR,
  PUBLIC_STREET,
  PUBLIC_STREET_FLOOR,
  PUBLIC_STREET_SPAWN,
  listAvailableRooms,
  createDJState,
  claimDJ,
  releaseDJ,
  playTrack,
  pauseTrack,
  nextTrack,
  prevTrack,
  setVolume,
  isDJ,
  addTrackFromUrl,
  updateTrackTitle,
  DEFAULT_PLAYLIST,
} from "@cocoworking/shared";

interface ServerState {

  players: Map<string, Player>;
  dj: DJState;
}

interface ServerOptions {store?:WorldStore;assetGateway?:AssetGateway;publicUrl?:string}
type AppearanceSync = (userId: string, appearance: AvatarAppearance) => void;

export function createSocketServer(httpServer: HttpServer, options: ServerOptions = {}): SocketServer {
  const store=options.store||new WorldStore();
  const io = new SocketServer(httpServer, {
    cors: { origin: "*" },
  });
  const syncAppearance: AppearanceSync = (userId, appearance) => {
    syncPlayerRoom(userId,appearance);
    syncPublicStreet(userId,appearance);
  };
  const playerRoom=io.of('/');
  const publicStreet=io.of('/'+PUBLIC_STREET.id);
  const publishDirectory=()=>{
    const rooms=listAvailableRooms(store.state.room);
    playerRoom.emit('room:directory',rooms);
    publicStreet.emit('room:directory',rooms);
  };
  const syncPlayerRoom=hostRoom(playerRoom,httpServer,store,options,false,syncAppearance,publishDirectory);
  const syncPublicStreet=hostRoom(publicStreet,httpServer,store,options,true,syncAppearance,publishDirectory);
  return io;
}

function hostRoom(io:Namespace,httpServer:HttpServer,store:WorldStore,options:ServerOptions,publicStreet:boolean,onAppearance:AppearanceSync,onDirectoryChange:()=>void): AppearanceSync {
  const sessions=new Map<string,{socket:any;userId:string}>();
  let chatSequence=0;
  const currentRoom=()=>publicStreet?PUBLIC_STREET:store.state.room;
  const floor=publicStreet?PUBLIC_STREET_FLOOR:DEFAULT_FLOOR;
  const state: ServerState = {

    players: new Map(),
    dj: { ...createDJState(), playlist: DEFAULT_PLAYLIST },
  };
  const collectibles=new CollectiblesServer(io,state.players,currentRoom,options.assetGateway,options.publicUrl,()=>publicStreet?[]:roomFurniture(store.state),()=>publishWorld());
  const calls=new CallServer(state.players,()=>currentRoom()?.id);
  const currentFurniture=()=>collectibles.layout();
  httpServer.on?.('close',()=>{collectibles.stop();calls.stop();});

  function publishWorld(target?:any) {
    const output=target||io,world=store.state,room=currentRoom();
    output.emit('room:info',room);
    output.emit('room:owner',room?.ownerId?{id:room.ownerId,name:room.ownerName}:{id:null,name:null});
    output.emit('furniture:state',currentFurniture());
    if(target){const session=sessions.get(target.id);if(session)target.emit('inventory:state',inventoryFor(world,session.userId));}
    else for(const session of sessions.values())session.socket.emit('inventory:state',inventoryFor(world,session.userId));
  }

  io.on("connection", (socket) => {
    const previousRoomId=store.state.room?.id;
    let identity;
    try { identity=store.authenticate(socket.handshake.auth?.token,socket.handshake.query.name,!publicStreet); }
    catch { socket.emit('identity:error','Could not open the saved player profile.');socket.disconnect(true);return; }
    if(!identity){socket.emit('identity:error','This saved profile could not be opened. Return to the lobby and choose New player.');socket.disconnect(true);return;}
    const userId=identity.id,name=identity.name;
    sessions.set(socket.id,{socket,userId});
    socket.emit('identity:state',identity);

    const player: Player = {
      id: socket.id,
      name,
      position: publicStreet?{...PUBLIC_STREET_SPAWN}:findSpawn(currentFurniture(),store.state.room?.tileSplits),
      direction: "south",
      appearance:store.state.profiles[userId].appearance||defaultAppearance(typeof socket.handshake.query.color==='string'&&/^#[0-9a-f]{6}$/i.test(socket.handshake.query.color)?parseInt(socket.handshake.query.color.slice(1),16):undefined),
    };
    state.players.set(socket.id, player);

    // Send full state
    socket.emit("room:state", Object.fromEntries(state.players));
    publishWorld(socket);
    if(previousRoomId!==store.state.room?.id)onDirectoryChange();
    else socket.emit('room:directory',listAvailableRooms(store.state.room));
    socket.emit("dj:state", state.dj);

    socket.broadcast.emit("player:join", player);
    collectibles.connect(socket,userId);
    calls.connect(socket);

    socket.on('avatar:save',(value:unknown)=>{
      const result=saveAppearance(store.state,userId,value);
      if(!result.ok){socket.emit('avatar:blocked',result.error);return;}
      try{store.commit(result.world);}catch{socket.emit('avatar:blocked','Could not save this look. Your previous avatar is unchanged.');return;}
      onAppearance(userId,result.appearance);
    });

    // ─── Movement ─────────────────────────────────
    socket.on("player:move", (data: { x: number; y: number; direction?: string }) => {
      const room=currentRoom();
      if (!room || !data || !isValidPosition(data.x, data.y)) return;
      const currentPlayer=state.players.get(socket.id);
      if(!currentPlayer)return;const result=movePlayer(currentPlayer,{x:data.x,y:data.y},currentFurniture(),[...state.players.values()],room.tileSplits,floor);
      if(!result.ok){socket.emit('player:correct',currentPlayer.position);socket.emit('player:posture',currentPlayer);return;}
      const p=result.player;state.players.set(socket.id,p);
      if(p.seat)io.emit('player:posture',p);else io.emit('player:move',{id:p.id,x:p.position.x,y:p.position.y,direction:p.direction});
    });

    function changePosture(sitting:boolean,data:any){
      const player=state.players.get(socket.id);if(!player)return;
      const room=currentRoom();
      if(!room||data?.roomId!==room.id){socket.emit('player:posture-blocked','This room is no longer open.');return;}
      const result=sitting?sitPlayer(player,data.id,data.index,currentFurniture(),[...state.players.values()],room.tileSplits):standPlayer(player,currentFurniture(),room.tileSplits,data?.to);
      if(!result.ok){socket.emit('player:posture-blocked',result.error);return;}
      state.players.set(socket.id,result.player);io.emit('player:posture',result.player);
    }
    socket.on('player:sit',data=>changePosture(true,data));socket.on('player:stand',data=>changePosture(false,data));

    function changeWorld(type:'move'|'rotate'|'place'|'pickup'|'delete-room'|'create-room'|'split-tile',data:unknown) {
      if(!sessions.has(socket.id))return;
      if(publicStreet){socket.emit('furniture:blocked','Public Street has a shared, fixed layout.');return;}
      const raw=data as {id?:string;roomId?:string;gx?:number;gy?:number;tileId?:string}|null;
      if(collectibles.has(raw?.id)){
        if(type==='move'||type==='rotate'||type==='pickup')void collectibles.edit(socket.id,userId,type,raw).catch(error=>socket.emit('furniture:blocked',error instanceof Error?error.message:'Could not edit NFT furniture.'));
        return;
      }
      const existing=currentFurniture().find(i=>i.id===raw?.id);
      if(existing&&(type==='move'||type==='rotate'||type==='pickup')){const blocked=supportEditError(existing,currentFurniture(),[...state.players.values()].map(p=>p.position));if(blocked){socket.emit('furniture:blocked',blocked);return;}}
      const request={...(data&&typeof data==='object'?data:{}),type,...(type==='create-room'?{newRoomId:randomUUID()}: {})};
      const result=applyWorldCommand(store.state,userId,request,[...state.players.values()].map(p=>p.position));
      if(!result.ok){socket.emit('furniture:blocked',result.error);return;}
      if(type==='split-tile'){
        const tile=tileFromId(raw?.tileId)!;
        if(currentFurniture().some(item=>furnitureTiles(item).some(p=>tileOverlaps(tile,tile.size,p,item.scale??1)))){socket.emit('furniture:blocked','Clear the furniture from this tile before dividing it.');return;}
      }
      if(type==='place'||type==='move'||type==='rotate'){
        const changed=roomFurniture(result.world).find(i=>i.id===raw?.id);
        if(changed){const full=[...roomFurniture(result.world),...collectibles.furniture()];const expected=resolvePlacement(changed,changed.gx,changed.gy,full,result.world.room?.tileSplits);const error=expected.supportId&&full.find(i=>i.id===expected.supportId)?.nft?'Place saved inventory furniture on a permanent table or Stool.':placementError(changed,full,[...state.players.values()].map(p=>p.position),result.world.room?.tileSplits);if(error){socket.emit('furniture:blocked',error);return;}}
      }
      try{store.commit(result.world);}catch{socket.emit('furniture:blocked','Could not save this change. Nothing was changed.');return;}
      if(type==='create-room'||type==='delete-room'){
        for(const player of state.players.values()){player.position=findSpawn(currentFurniture(),store.state.room?.tileSplits);delete player.seat;}
        io.emit('room:state',Object.fromEntries(state.players));
      }
      if(type==='delete-room'){
        collectibles.clearRoom();calls.clearRoom();
        state.dj={...createDJState(),playlist:DEFAULT_PLAYLIST};io.emit('dj:state',state.dj);
      }
      publishWorld();
      if(type==='create-room'||type==='delete-room')onDirectoryChange();
      if(type==='move'||type==='place'||type==='rotate')for(const player of seatPlayersUnderFurniture([...state.players.values()],currentFurniture(),store.state.room?.tileSplits)){
        if(player!==state.players.get(player.id)){state.players.set(player.id,player);io.emit('player:posture',player);}
      }
      if(type==='delete-room')io.emit('world:notice','Room deleted. All furniture has been returned to its owners’ inventories.');
      else if(type==='split-tile')socket.emit('world:notice','Tile divided into four smaller tiles.');
      else if(type==='pickup')socket.emit('world:notice','Furniture returned to its owner’s inventory.');
    }
    socket.on('furniture:rotate',data=>changeWorld('rotate',data));
    socket.on('furniture:move',data=>changeWorld('move',data));
    socket.on('furniture:place',data=>changeWorld('place',data));
    socket.on('furniture:pickup',data=>changeWorld('pickup',data));
    socket.on('furniture:state-change',data=>{if(collectibles.has(data?.id))void collectibles.edit(socket.id,userId,'state',data).catch(error=>socket.emit('furniture:blocked',error instanceof Error?error.message:'Could not change furniture state.'));});
    socket.on('room:split-tile',data=>changeWorld('split-tile',data));
    socket.on('room:delete',data=>changeWorld('delete-room',data));
    socket.on('room:create',data=>changeWorld('create-room',data));

    // ─── Chat ─────────────────────────────────────
    socket.on("chat:send", (data: { content: string }) => {
      if (!currentRoom() || !data || typeof data.content!=="string" || !data.content || data.content.length > 200) return;
      const player=state.players.get(socket.id);if(!player||!data.content.trim())return;
      const msg: ChatMessage = {
        id: randomUUID(),
        playerId: socket.id,
        playerName: player.name,
        content: data.content,
        timestamp: Date.now(),
        position:{...player.position},
        sequence:++chatSequence,
        appearance:player.appearance?{...player.appearance}:undefined,
      };
      io.emit("chat:message", msg);
    });

    // ─── DJ ───────────────────────────────────────
    socket.on("dj:claim", () => {
      state.dj = claimDJ(state.dj, socket.id, name);
      io.emit("dj:state", state.dj);
    });

    socket.on("dj:release", () => {
      state.dj = releaseDJ(state.dj, socket.id);
      io.emit("dj:state", state.dj);
    });

    socket.on("dj:play", () => {
      if (!isDJ(state.dj, socket.id)) return;
      state.dj = playTrack(state.dj, Date.now());
      io.emit("dj:state", state.dj);
    });

    socket.on("dj:pause", () => {
      if (!isDJ(state.dj, socket.id)) return;
      state.dj = pauseTrack(state.dj);
      io.emit("dj:state", state.dj);
    });

    socket.on("dj:next", () => {
      if (!isDJ(state.dj, socket.id)) return;
      state.dj = nextTrack(state.dj, Date.now());
      io.emit("dj:state", state.dj);
    });

    socket.on("dj:prev", () => {
      if (!isDJ(state.dj, socket.id)) return;
      state.dj = prevTrack(state.dj, Date.now());
      io.emit("dj:state", state.dj);
    });

    socket.on("dj:volume", (data: { volume: number }) => {
      if (!isDJ(state.dj, socket.id)) return;
      state.dj = setVolume(state.dj, data.volume);
      io.emit("dj:state", state.dj);
    });

    socket.on("dj:addtrack", (data: { url: string }) => {
      if (!isDJ(state.dj, socket.id)) return;
      if (!data.url || typeof data.url !== "string") return;
      state.dj = addTrackFromUrl(state.dj, data.url);
      io.emit("dj:state", state.dj);
    });

    socket.on("dj:updatetitle", (data: { youtubeId: string; title: string }) => {
      // Anyone can send title updates (fetched from YouTube API client-side)
      state.dj = updateTrackTitle(state.dj, data.youtubeId, data.title);
      io.emit("dj:state", state.dj);
    });

    // ─── Disconnect ───────────────────────────────
    socket.on("disconnect", () => {
      calls.disconnect(socket.id);
      collectibles.disconnect(socket.id);
      state.players.delete(socket.id);
      sessions.delete(socket.id);
      io.emit("player:leave", socket.id);

      // Release DJ if the DJ disconnects
      if (isDJ(state.dj, socket.id)) {
        state.dj = releaseDJ(state.dj, socket.id);
        io.emit("dj:state", state.dj);
      }

    });
  });

  return (userId,appearance)=>{
    collectibles.ordinaryAvatar(userId);
    for(const [id,session] of sessions)if(session.userId===userId){
      const player=state.players.get(id);if(player)player.appearance={...appearance};
      io.emit('player:appearance',{id,appearance});
      session.socket.emit('avatar:saved',appearance);
    }
  };
}

function isValidPosition(x:number,y:number){return Number.isFinite(x)&&Number.isFinite(y)&&x>=.5&&y>=.5&&x<9.5&&y<9.5;}
