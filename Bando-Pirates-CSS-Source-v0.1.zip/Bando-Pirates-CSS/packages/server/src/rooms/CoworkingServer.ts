import { randomUUID } from "node:crypto";
import { WorldStore } from "../state/WorldStore";
import { Server as SocketServer } from "socket.io";
import type { Server as HttpServer } from "http";
import {
  roomFurniture, inventoryFor, applyWorldCommand, findSpawn,saveAppearance, defaultAppearance,sitPlayer,standPlayer,movePlayer,seatPlayersUnderFurniture,
  type Player,
  type ChatMessage,
  type DJState,
  type PomodoroState,
  type PomodoroConfig,
  createDJState,
  claimDJ,
  releaseDJ,
  playTrack,
  pauseTrack,
  nextTrack,
  prevTrack,
  setVolume,
  isDJ,
  addTrackFromUrl,
  updateTrackTitle,
  DEFAULT_PLAYLIST,
  createPomodoroState,
  isPhaseOver,
  nextPhase,
  DEFAULT_CONFIG,
  LONG_CONFIG,
} from "@cocoworking/shared";

interface ServerState {

  players: Map<string, Player>;
  dj: DJState;
  pomodoro: PomodoroState | null;
}

export function createSocketServer(httpServer: HttpServer, options: {store?:WorldStore} = {}): SocketServer {
  const store=options.store||new WorldStore();
  const sessions=new Map<string,{socket:any;userId:string}>();
  const io = new SocketServer(httpServer, {
    cors: { origin: "*" },
  });

  const state: ServerState = {

    players: new Map(),
    dj: { ...createDJState(), playlist: DEFAULT_PLAYLIST },
    pomodoro: null,
  };

  // Pomodoro timer check
  let pomodoroInterval: ReturnType<typeof setInterval> | null = null;

  function startPomodoroTimer() {
    if (pomodoroInterval) return;
    pomodoroInterval = setInterval(() => {
      if (!state.pomodoro) { stopPomodoroTimer(); return; }
      const now = Date.now();
      if (isPhaseOver(state.pomodoro, now)) {
        const next = nextPhase(state.pomodoro, now);
        if (next) {
          state.pomodoro = next;
          io.emit("pomodoro:update", state.pomodoro);
        } else {
          state.pomodoro = null;
          io.emit("pomodoro:end");
          stopPomodoroTimer();
        }
      }
    }, 1000);
  }

  function stopPomodoroTimer() {
    if (pomodoroInterval) { clearInterval(pomodoroInterval); pomodoroInterval = null; }
  }

  function publishWorld(target?:any) {
    const output=target||io,world=store.state;
    output.emit('room:info',world.room);
    output.emit('room:owner',world.room?{id:world.room.ownerId,name:world.room.ownerName}:{id:null,name:null});
    output.emit('furniture:state',roomFurniture(world));
    if(target){const session=sessions.get(target.id);if(session)target.emit('inventory:state',inventoryFor(world,session.userId));}
    else for(const session of sessions.values())session.socket.emit('inventory:state',inventoryFor(world,session.userId));
  }

  io.on("connection", (socket) => {
    let identity;
    try { identity=store.authenticate(socket.handshake.auth?.token,socket.handshake.query.name); }
    catch { socket.emit('identity:error','Could not open the saved player profile.');socket.disconnect(true);return; }
    if(!identity){socket.emit('identity:error','This saved profile could not be opened. Return to the lobby and choose New player.');socket.disconnect(true);return;}
    const userId=identity.id,name=identity.name;
    sessions.set(socket.id,{socket,userId});
    socket.emit('identity:state',identity);

    const player: Player = {
      id: socket.id,
      name,
      position: findSpawn(roomFurniture(store.state)),
      direction: "south",
      appearance:store.state.profiles[userId].appearance||defaultAppearance(typeof socket.handshake.query.color==='string'&&/^#[0-9a-f]{6}$/i.test(socket.handshake.query.color)?parseInt(socket.handshake.query.color.slice(1),16):undefined),
    };
    state.players.set(socket.id, player);

    // Send full state
    socket.emit("room:state", Object.fromEntries(state.players));
    publishWorld(socket);
    socket.emit("dj:state", state.dj);
    if (state.pomodoro) socket.emit("pomodoro:update", state.pomodoro);

    socket.broadcast.emit("player:join", player);

    socket.on('avatar:save',(value:unknown)=>{
      const result=saveAppearance(store.state,userId,value);
      if(!result.ok){socket.emit('avatar:blocked',result.error);return;}
      try{store.commit(result.world);}catch{socket.emit('avatar:blocked','Could not save this look. Your previous avatar is unchanged.');return;}
      // All active sessions for the same saved profile wear the same appearance.
      for(const [id,session] of sessions)if(session.userId===userId){
        const player=state.players.get(id);if(player)player.appearance={...result.appearance};
        io.emit('player:appearance',{id,appearance:result.appearance});
        session.socket.emit('avatar:saved',result.appearance);
      }
    });

    // ─── Movement ─────────────────────────────────
    socket.on("player:move", (data: { x: number; y: number; direction?: string }) => {
      if (!store.state.room || !data || !isValidPosition(data.x, data.y)) return;
      const currentPlayer=state.players.get(socket.id);
      if(!currentPlayer)return;const result=movePlayer(currentPlayer,{x:data.x,y:data.y},roomFurniture(store.state),[...state.players.values()]);
      if(!result.ok){socket.emit('player:correct',currentPlayer.position);socket.emit('player:posture',currentPlayer);return;}
      const p=result.player;state.players.set(socket.id,p);
      if(p.seat)io.emit('player:posture',p);else io.emit('player:move',{id:p.id,x:p.position.x,y:p.position.y,direction:p.direction});
    });

    function changePosture(sitting:boolean,data:any){
      const player=state.players.get(socket.id);if(!player)return;
      if(!store.state.room||data?.roomId!==store.state.room.id){socket.emit('player:posture-blocked','This room is no longer open.');return;}
      const result=sitting?sitPlayer(player,data.id,data.index,roomFurniture(store.state),[...state.players.values()]):standPlayer(player,roomFurniture(store.state));
      if(!result.ok){socket.emit('player:posture-blocked',result.error);return;}
      state.players.set(socket.id,result.player);io.emit('player:posture',result.player);
    }
    socket.on('player:sit',data=>changePosture(true,data));socket.on('player:stand',data=>changePosture(false,data));

    function changeWorld(type:'move'|'rotate'|'place'|'pickup'|'delete-room'|'create-room',data:unknown) {
      if(!sessions.has(socket.id))return;
      const request={...(data&&typeof data==='object'?data:{}),type,...(type==='create-room'?{newRoomId:randomUUID()}: {})};
      const result=applyWorldCommand(store.state,userId,request,[...state.players.values()].map(p=>p.position));
      if(!result.ok){socket.emit('furniture:blocked',result.error);return;}
      try{store.commit(result.world);}catch{socket.emit('furniture:blocked','Could not save this change. Nothing was changed.');return;}
      if(type==='create-room'||type==='delete-room'){
        for(const player of state.players.values()){player.position=findSpawn(roomFurniture(store.state));delete player.seat;}
        io.emit('room:state',Object.fromEntries(state.players));
      }
      if(type==='delete-room'){
        state.pomodoro=null;stopPomodoroTimer();io.emit('pomodoro:end');
        state.dj={...createDJState(),playlist:DEFAULT_PLAYLIST};io.emit('dj:state',state.dj);
      }
      publishWorld();
      if(type==='move'||type==='place'||type==='rotate')for(const player of seatPlayersUnderFurniture([...state.players.values()],roomFurniture(store.state))){
        if(player!==state.players.get(player.id)){state.players.set(player.id,player);io.emit('player:posture',player);}
      }
      if(type==='delete-room')io.emit('world:notice','Room deleted. All furniture has been returned to its owners’ inventories.');
      else if(type==='pickup')socket.emit('world:notice','Furniture returned to its owner’s inventory.');
    }
    socket.on('furniture:rotate',data=>changeWorld('rotate',data));
    socket.on('furniture:move',data=>changeWorld('move',data));
    socket.on('furniture:place',data=>changeWorld('place',data));
    socket.on('furniture:pickup',data=>changeWorld('pickup',data));
    socket.on('room:delete',data=>changeWorld('delete-room',data));
    socket.on('room:create',data=>changeWorld('create-room',data));

    // ─── Chat ─────────────────────────────────────
    socket.on("chat:send", (data: { content: string }) => {
      if (!store.state.room || !data || typeof data.content!=="string" || !data.content || data.content.length > 200) return;
      // During focus phase, only allow chat from the pomodoro starter
      if (state.pomodoro?.phase === "focus") return;
      const msg: ChatMessage = {
        id: `${socket.id}-${Date.now()}`,
        playerId: socket.id,
        playerName: name,
        content: data.content,
        timestamp: Date.now(),
      };
      io.emit("chat:message", msg);
    });

    // ─── DJ ───────────────────────────────────────
    socket.on("dj:claim", () => {
      state.dj = claimDJ(state.dj, socket.id, name);
      io.emit("dj:state", state.dj);
    });

    socket.on("dj:release", () => {
      state.dj = releaseDJ(state.dj, socket.id);
      io.emit("dj:state", state.dj);
    });

    socket.on("dj:play", () => {
      if (!isDJ(state.dj, socket.id)) return;
      state.dj = playTrack(state.dj, Date.now());
      io.emit("dj:state", state.dj);
    });

    socket.on("dj:pause", () => {
      if (!isDJ(state.dj, socket.id)) return;
      state.dj = pauseTrack(state.dj);
      io.emit("dj:state", state.dj);
    });

    socket.on("dj:next", () => {
      if (!isDJ(state.dj, socket.id)) return;
      state.dj = nextTrack(state.dj, Date.now());
      io.emit("dj:state", state.dj);
    });

    socket.on("dj:prev", () => {
      if (!isDJ(state.dj, socket.id)) return;
      state.dj = prevTrack(state.dj, Date.now());
      io.emit("dj:state", state.dj);
    });

    socket.on("dj:volume", (data: { volume: number }) => {
      if (!isDJ(state.dj, socket.id)) return;
      state.dj = setVolume(state.dj, data.volume);
      io.emit("dj:state", state.dj);
    });

    socket.on("dj:addtrack", (data: { url: string }) => {
      if (!isDJ(state.dj, socket.id)) return;
      if (!data.url || typeof data.url !== "string") return;
      state.dj = addTrackFromUrl(state.dj, data.url);
      io.emit("dj:state", state.dj);
    });

    socket.on("dj:updatetitle", (data: { youtubeId: string; title: string }) => {
      // Anyone can send title updates (fetched from YouTube API client-side)
      state.dj = updateTrackTitle(state.dj, data.youtubeId, data.title);
      io.emit("dj:state", state.dj);
    });

    // ─── Pomodoro ─────────────────────────────────
    socket.on("pomodoro:start", (data?: { preset?: "default" | "long" }) => {
      if (state.pomodoro) return; // Already running
      const config: PomodoroConfig = data?.preset === "long" ? LONG_CONFIG : DEFAULT_CONFIG;
      state.pomodoro = createPomodoroState(socket.id, config, Date.now());
      io.emit("pomodoro:update", state.pomodoro);
      startPomodoroTimer();
    });

    socket.on("pomodoro:stop", () => {
      // Only the person who started or if nobody cares
      if (state.pomodoro && (state.pomodoro.startedBy === socket.id || state.players.size <= 1)) {
        state.pomodoro = null;
        io.emit("pomodoro:end");
        stopPomodoroTimer();
      }
    });

    // ─── WebRTC ───────────────────────────────────
    socket.on("peer:id", (data: { peerId: string }) => {
      socket.broadcast.emit("peer:id", { playerId: socket.id, peerId: data.peerId });
    });

    // ─── Disconnect ───────────────────────────────
    socket.on("disconnect", () => {
      state.players.delete(socket.id);
      sessions.delete(socket.id);
      io.emit("player:leave", socket.id);

      // Release DJ if the DJ disconnects
      if (isDJ(state.dj, socket.id)) {
        state.dj = releaseDJ(state.dj, socket.id);
        io.emit("dj:state", state.dj);
      }

      // Stop pomodoro if starter disconnects
      if (state.pomodoro?.startedBy === socket.id) {
        state.pomodoro = null;
        io.emit("pomodoro:end");
        stopPomodoroTimer();
      }
    });
  });

  return io;
}

function isValidPosition(x: number, y: number): boolean {
  return (
    Number.isInteger(x) &&
    Number.isInteger(y) &&
    x >= 1 &&
    x < 10 &&
    y >= 1 &&
    y < 10
  );
}
