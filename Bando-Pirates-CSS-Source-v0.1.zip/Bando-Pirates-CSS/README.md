# Bando Pirates — CSS Art Edition (0.1)

A separate source fork of [Coco Working](https://github.com/cocolocow/cocoworking), with original live HTML/CSS artwork in place of its commercial image packs. This is an initial artwork and renderer implementation, not a hosted public hotel.

## Play the furniture room

Open `artwork-preview/Bando-Pirates-CSS-Game.html` in a browser for a standalone local game preview. Click floor tiles or use the arrow keys/WASD to walk, select, move and rotate the Base sofa, Base table and Stool, and try local chat. This preview runs offline and does not simulate other online players. The source project below provides live multiplayer.

The catalogue contains **Base sofa**, in natural cotton/off-white with no loose pillows, **Base table**, a simple brown wooden table, and a lower brown **Stool**. All three have four rotations. The sofa occupies two tiles; tables and Stools occupy one.

Tables are two height levels tall and Stools one (one level = 16 rendered pixels). Place or move an item onto a table or Stool to stack it automatically. Tables can stack on other tables, and a sofa can rest on a single table at its anchor tile with the other half overhanging. Overhanging furniture still cannot intersect another piece at the same height. Remove the items on top before moving, rotating or collecting their support; furniture cannot be moved or collected while a player stands on it.

Click floor tiles, tables or Stools to follow a route of adjacent tiles, or use the arrow keys/WASD. Players can climb **one level upward per tile**: floor → Stool → table. An isolated table cannot be climbed from the floor. A taller stack needs matching intermediate steps. Players can walk across tables/Stools and step down to the floor. Sofa cushions are seating destinations; walking routes do not pass through them. Walking onto a free sofa cushion automatically seats the avatar. Clicking a sofa finds a route to a free cushion; there is no Sit button. Placing, moving or turning a sofa beneath standing avatars seats them automatically, with one avatar per cushion. The sofa must meet each avatar’s current standing level and leave a usable adjacent exit; duplicate occupants on one tile are rejected. Each sofa has two seats, with correct facing in all four rotations. **Stand up**, an arrow key or clicking a floor tile gets the avatar out of the seat; a tile click then continues to its destination. Sofa seating is synchronized for live players and late joins, and works for both original CSS and Habbo figures. Seats cannot be shared by two avatars. A sofa cannot be moved, rotated or collected while occupied. Sitting on an elevated sofa requires a reachable adjacent approach at its base level or one level above. Any safe side or diagonal can be used to enter or leave a seat; clicking a destination or pressing a direction chooses a suitable exit toward it. A blocked front does not prevent standing when another safe exit exists. Room deletion returns the furniture and resets seated postures. Both server and offline preview validate each step; clicks cannot teleport through furniture or bypass height limits. Eight-direction walking includes diagonal routes, with both neighbouring routes checked so players cannot cut through corners or skip a required height step.

Furniture has a persistent player owner. Each new profile receives one sofa, two tables and one Stool, issued once. The first player gets a welcome room with a sofa, table and Stool already placed, with the spare table in inventory. Existing profiles receive the new Stool and spare table once without changing their earlier items or layout.

- Select a player profile in the lobby, or choose **New player**. Profiles are remembered on that browser; names alone do not grant access to another player's furniture.
- Room ownership stays with its creator across disconnects and restarts. The room owner can move and rotate placed pieces, and collect them back to their rightful owners.
- Open **Inventory**, select one of your items and choose **Place from inventory**, then tap/click a valid floor tile, table or Stool. Visitors can place their own inventory pieces and collect their own placed pieces.
- **Pick up** always returns an item to its existing owner's inventory. It never transfers ownership to the room owner.
- **Delete room** asks for confirmation, then removes the room and returns every placed item to its own owner, including players who are offline. These changes are saved together. A repeated/stale deletion cannot return items twice or delete a later room.
- After deletion, anyone can create a new, empty room and reuse their inventory. This prototype currently has one shared room at a time.

The standalone preview uses one local Heather profile and saves its room/inventory in browser storage. The multiplayer source stores the world on disk and uses saved anonymous browser profiles. It has no cross-device sign-in or profile recovery flow yet.

## MetaMask and owned collectibles

The hosted game now has **Wallet & collectibles**. Connect MetaMask and sign a login message to verify your owned Genesis/Crafted avatars and supported Immutable zkEVM collectibles. On mobile, open the HTTPS game in MetaMask’s app browser using the link in the wallet window.

Owned, supported furniture NFTs now appear as actual floor furniture, using transparent native sprites, real tile footprints, available rotations, height, collision, seating and stacking flags. In **Wallet & collectibles**, select a furniture NFT, choose **Place furniture…**, then tap a room tile. Select the placed piece to move, rotate or pick it up through the room window. The room owner controls movement and rotation; an item owner can collect their own piece. Furniture with multiple available sprite states also has **Use / change state**.

Native floor furniture is matched to Habbo's live catalogue and rendered by the public HabboAssets imager. Unknown items and wall furniture report that they are unsupported. NFT placements remain temporary: disconnecting, deleting the room, expiration or detected ownership loss removes them. Dependent NFT stacks are removed safely and occupied seats release their avatars. Permanent CSS inventory items must use permanent supports; they cannot be stacked on temporary NFT furniture. Up to 32 furniture NFTs can be placed per wallet session.

Supported NFT avatars wear the figure resolved from their published traits and use the same standing, walking, turning and sitting sprites as a typed Habbo figure code. Wallet icons use layered CSS colour, ornament and sparkles, a Habbo corner mark and native artwork where available. Wallet use requests no token approvals or transactions; verified sessions check ownership on the server before placement and recheck it during use. Unsigned testing uses session-scoped demo snapshots described below.

For signature-free testing, choose a collection and click **Try Heather’s wallet**. The prefilled public sample is `0x71a780c3a25dd7a22901781764f1200fa24e8e15`. You can also paste another address and choose **Test wallet address**, then **Load wallet collectibles**. This previews supported avatars and floor furniture with **test wallet** labels. Server-fetched items become demo copies for the one-hour test session; reload the test wallet to refresh its inventory. Background RPC failures do not interrupt these demo copies. This mode does not prove control of the address or evict a verified MetaMask session. Switching addresses, expiry or disconnect clears its NFT appearances and placements. Signed sessions retain ownership checks.

In the downloaded HTML, open **Start → Wallet & collectibles**, choose **Genesis avatars** or **Furniture**, and click **Try Heather’s wallet** (or use the prefilled address button). The 8 November 2026 snapshot has three avatars and the first 12 furniture records, with ten placeable examples across five native floor designs. Choose **Wear selected avatar** or **Place furniture…**. Sample copies are labelled and remain only in the current local session. **Clear sample** removes them. Live inventory, other pasted addresses and signed MetaMask use are available through the multiplayer game linked in the window.

See [Habbo compatibility and wallet hosting settings](docs/HABBO-COMPATIBILITY.md). Render’s default URL is detected; set `BANDO_PUBLIC_URL` for a custom domain. Public RPC defaults are provided and can be replaced with dedicated server-side endpoints. The standalone HTML includes a saved copy of Heather’s public sample inventory. It does not contact a wallet service.

## Walking and movable controls

Avatars move continuously between validated grid positions. Among equally short safe routes, walking prefers fewer changes of direction and stays closer to the direct line. Clear rows and diagonals stay straight; obstacles and height limits still require safe detours. A frame animation interpolates their screen position and height, including remote players; keyboard holds use the same steady step clock as click/touch routes instead of waiting for OS key repeat. Collision, one-level climbs and seat occupancy remain server-authoritative.

Chat opens as a larger, title-free panel covering the full width of the top of the game. It follows viewport width until you move or resize it yourself. There is no title bar or extra grip strip. Drag the blank frame or unused panel space to move it; the utility controls sit below it. Drag a panel's blank space or caption to move it; resize chat and DJ with the bottom-left grip. Inputs, buttons, playlists and chat scrolling keep their normal interactions. DJ starts as a compact 44×44 music-note button without extra panel padding or resize handles. Click it once to expand, or drag directly on the icon to move it; dragging does not open the panel. Use **Collapse DJ** to return to the icon without stopping playback. Online count, player controls and volume are also movable; room tools are in the Start menu. The chat, DJ and compact widgets use the same HeatherOS Modern controls and Bando palette without title bars. Room scale uses the shared child-window title bar, close button and bottom-left resize grip. All panels and child windows share stacking order so the active one can come to the front. Pomodoro and the in-game GitHub link have been removed; chat is always available.

The narrow **Room scale** child window opens on the left by default. Close it with its title-bar × button and reopen it through **Start → Scale**. The lower selector has **eight perspective levels**, Level 1–8: each doubles the base view scale (1× through 128×). Selecting a level resets the separate zoom to **100%**. Higher levels follow your avatar smoothly, so tiny Microverse cells stay usable while walking. The vertical slider, arrow buttons and typed percentage adjust zoom from 25–250% within the chosen perspective. Controls and game coordinates keep their original size and meaning; view settings are local.

Messages use a server-recorded snapshot of the sender's tile. Each receiving client projects that tile onto its room view when the chat arrives, then keeps that horizontal anchor fixed as the avatar moves or the view zooms. Speech bubbles appear in the top chat history instead of following the avatar around the room. The latest 50 messages retain arrival order, with at most two pixels of vertical overlap. Wrapped text is measured again when resized, so newer bubbles stay below older ones. History scrolls upward as messages accumulate; scrolling back pauses automatic following until you return to the bottom.

The standalone HTML uses the same controls. Local movement, chat and sample-wallet selection work without a multiplayer server; collectible images still need internet. DJ, live wallet lookups and MetaMask verification require the hosted game.

## Shared HeatherOS Modern theme

Buttons and child-window chrome use the actual HeatherOS Modern rules from HeatherOS Site version 254, source commit `a630054aab2d206cda458703d2b28be045035809`. The shared `controls.css` is retained byte for byte. Base window/control rules and the full Modern finish are extracted without changing their selectors or declarations. Bando Pirates uses the same title-bar structure, close glyph, bevels, hover/pressed/disabled states, Tahoma font family and native control styling.

Heather pink, lavender and periwinkle colours are separate in `packages/client/src/theme/hotel-palette.css`; the original shared styles remain in `heatheros-controls.css` and `heatheros-modern.css`. All game, wardrobe and artwork-studio controls load that central theme. `source.json` records the source and checksums. The HeatherOS project itself was read as a reference and was not changed.

Avatar geometry uses flat solid colours and a restored oval shadow at the walking surface. The friendlier two-eye face uses real CSS geometry, with mirrored eyes/brows and a centred smile. The original CSS avatar is scaled to 1.15 instead of 1.45 (about 21% smaller), matching the roughly 84-pixel visible height of a normal Habbo figure inside its unchanged 64×110 canvas. Full side views use a continuous rounded scalp and shaped rear hair, mirrored for left/right. A foreground hair cap covers the rear scalp in back, quarter-back and side views when hair is selected; short and long hair no longer leave bald patches at the back. The front/back rig and wardrobe layers are symmetric; left and right quarter/side views are mirrored counterparts. Window chrome retains HeatherOS's own highlights and shadows.

Child windows share `theme/ChildWindow.ts`: drag the title bar with a mouse or touch and resize with the single bottom-left grip. Only Wardrobe supports Maximise/Restore and title-bar double-click maximising. Keyboard arrows resize the focused grip. Headers are 28 pixels tall with compact controls. Bounds remain inside the available viewport and adapt after rotation or resizing; contents scroll inside small windows. The wardrobe and room information/furniture controls are child windows. **Room info** reopens the room window after closing it. Both windows are non-modal: opening them adds no dark overlay and the room remains interactive. Clicking or focusing a child window brings it to the front.

## Blank avatar and wardrobe

Choose **Wardrobe** in the game. **Blank base** starts with an original neutral, hairless CSS mannequin. Skin colour, face, hair, top, bottoms, shoes and accessory are independent layers. The **Breast size** slider runs from 0% (flat) to 100%, keeps the front view symmetrical, adjusts side/quarter views and follows the selected skin or top colour. This shape control edits the original CSS avatar; external Habbo figures remain intact. The value previews immediately and saves with the appearance. Existing version-1 appearances without it still load with a flat default. Turn through eight 45-degree directions or toggle the walk preview. Walking stays animated between consecutive tiles, including touch-driven routes on mobile. Reduced-motion mode removes optional bobbing while keeping the limb movement that communicates walking. Edits remain a draft until **Wear in room**; the saved look belongs to the authenticated player profile, persists after reload/restart, and is sent to the other live players. Closing the wardrobe without saving leaves the room avatar unchanged. **Heather preset** restores the familiar dressed appearance. **Export avatar JSON** downloads the versioned appearance data.

`artwork-preview/Bando-Pirates-Avatar-Wardrobe.html` is a separate self-contained base-design workbench. It starts blank, saves its design locally, and exports JSON. Its Save action does not change a multiplayer profile. The same workbench is available at `?wardrobe` in the source app. Avatar JSON import is not implemented yet.

The Stool top is now 52×52 model pixels (previously 86×86), with its one-level height and one-tile walking footprint preserved.

Choose **Avatar artwork → Habbo figure**. Either enter a figure string and choose **Preview figure**, or choose Habbo.com/Habbo.nl, enter a **Habbo name** and choose **Look up outfit**. Name lookup calls the selected hotel’s public API, validates its `figureString` and previews that outfit. **Wear in room** / **Save base design** commits the fetched figure. Names are hotel-specific. A missing name, request timeout or connection problem leaves the current appearance unchanged, and stale lookups are discarded when you close the window or change modes. Only the resulting outfit is saved; the profile’s other public details are not stored. The optional adapter loads the intact figure from Habbo's online avatar-image service, using native directions 0–7, standing, sitting and four cached walking frames on a 64×110 canvas. Saving keeps the figure string in the player appearance; the original CSS renderer remains the fallback when an image fails. This mode needs internet access. It does not apply CSS clothes to external artwork.

Raw SWF/`.nitro` clothing-pack imports and individual NFT clothing in the wardrobe are not included. Verified furniture NFTs use the separate native sprite adapter described in [the compatibility notes](docs/HABBO-COMPATIBILITY.md).

## Open the artwork studio

Open `artwork-preview/Bando-Pirates-CSS-Artwork.html` in a browser. This self-contained offline studio needs no installation, server, account or internet connection. Change the room and avatar colour controls, add/select furniture, nudge or rotate selected items, download colour CSS, or export furniture positions as JSON. Click a floor tile to move the sample avatar. The studio does not connect to multiplayer.

## Run the multiplayer source

Requires Node.js 20+ and pnpm. From the project folder:

```sh
pnpm install --frozen-lockfile
pnpm dev
```

Open the printed client URL (normally `http://127.0.0.1:3000`). Join from two tabs to test movement and chat. The Node Socket.IO server runs on port 2567 and Vite proxies its connection. In development, the entry point starts both processes and accepts standard `--host` and `--port` arguments. Ownership, inventories and the current room are saved to disk. Online avatar positions remain in memory.

For a production client build and Node server:

```sh
pnpm --filter @cocoworking/client build
pnpm --filter @cocoworking/server start
```

The server serves the built client and Socket.IO from port 2567 (or `PORT`). A static-only host can display the artwork studio; the multiplayer app needs the Node server or a deliberate backend port. Optional YouTube music and PeerJS features still use their external services; they were not replaced or guaranteed by this artwork change.

## Where to draw your artwork

| File | Purpose |
| --- | --- |
| `packages/client/src/artwork/artwork.css` | Original floor/wall, furniture and avatar shapes, colours and animations |
| `packages/client/src/artwork/elements.ts` | HTML parts and artwork keys; no images, SVG or canvas |
| `packages/shared/src/furniture.ts` | Model types, collision footprints and placement checks |
| `packages/server/src/wallet/HabboFurniture.ts` | Verified furniture classname, live floor geometry and pinned sprite revision |
| `packages/client/src/artwork/habboFurniture.ts` | Transparent native NFT furniture sprites and room-scale anchors |
| `packages/client/src/artwork/avatar.ts` and `avatar.css` | Original skin rig and removable wardrobe layers |
| `packages/client/src/artwork/habboLookup.ts` | Allowlisted public name lookup and validated outfit extraction |
| `packages/client/src/artwork/Wardrobe.ts` | Draft editor, preview rotations, local export and Wear action |
| `packages/shared/src/avatar.ts` | Versioned appearance schema and authenticated profile update |
| `packages/shared/src/avatarDirections.ts` | Eight-direction mapping, bounded Habbo figure parsing and online image URLs |
| `packages/client/src/theme/ChildWindow.ts` | Shared mouse/touch drag, resize, maximise and restore behaviour |
| `packages/shared/src/seating.ts` | Two seats, any-side approaches/exits, occupancy, standing validation and cushion anchors |
| `packages/shared/src/walking.ts` | Surface heights, one-level climbs and adjacent-tile pathfinding |
| `packages/shared/src/ownedWorld.ts` | Unique item ownership, inventories, room creation and atomic deletion returns |
| `packages/server/src/state/WorldStore.ts` | Durable world storage and private guest profile credentials |
| `packages/client/src/scenes/roomLayout.ts` | Initial artwork studio layout |
| `packages/client/src/scenes/CoworkingScene.ts` | CSS room drawing and integration with the existing networking API |
| `packages/client/src/scenes/RoomEditor.ts` | Artwork studio, colour controls and exports |
| `packages/client/src/game-logic/NetworkManager.ts` | Upstream Socket.IO client plus saved player identity, inventories, room lifecycle and an offline preview mode |

The original 64×32 isometric grid is retained. Artwork is constructed from CSS borders, clipping, gradients and positioned HTML parts. The shared window-control icons use the original HeatherOS inline SVG masks. Avatars have editable hair, clothing and skin variables, eight facing states and a continuous CSS walk animation. Room depth follows grid position; the catalogue contains only `base-sofa`, `base-table` and `stool`; the earlier furniture and decorative props remain removed.

The studio is also available at `?editor` when running the app. An exported room JSON is a design file: to change the studio layout, replace `ROOM_LAYOUT` in `roomLayout.ts`. The initial live welcome room and starter inventory are defined in `packages/shared/src/ownedWorld.ts`; arbitrary studio exports are not yet imported by the server. The initial studio intentionally does not persist edits between reloads. Download colour CSS before closing to retain changes. The exported override file can be imported after `artwork.css` when applying a palette to the live app.

To regenerate the standalone preview after editing artwork:

```sh
pnpm artwork:preview
```

## Checks

```sh
pnpm --filter @cocoworking/client test:unit
pnpm --filter @cocoworking/shared test:unit
pnpm --filter @cocoworking/server test:unit
pnpm --filter @cocoworking/client build
```

Current checks pass **73 client tests**, **147 shared tests** and **69 server-specific tests** (216 in the server runner, 289 unique tests overall), server TypeScript and the production client build. New regression coverage checks perspective reset and camera following, inverse floor picking beneath artwork, all four sofa rotations with any-side entry/exit, blocked-front fallback, public sample-wallet controls, strict GIF/PNG metadata allowlisting, exact native floor matching and isolated unsigned demo snapshots. Existing checks continue to cover authoritative movement/height limits, Microverse persistence, ownership, stacking, chat ordering, wardrobe, taskbar and call signaling.

Current browser checks loaded the sample through both test buttons in the standalone preview, wore Habbo #8599 and placed Bronze Cornucopia with its native sprite. At 390 pixels, three and five tasks fit in one 44-pixel row; the sixth added an 81-pixel two-row bar and closing it restored 44 pixels, with no horizontal overflow. Regression tests cover straight rows and diagonals, fewer turns on equal-length routes, safe detours and sample furniture collision/cleanup.

Browser QA confirmed 20-pixel single-line chat bubbles without a title bar or grip strip, a 30-pixel wrapped bubble at a 390-pixel viewport, Level 1–8 with a 100% zoom reset, smooth following while walking across quarter-size tiles, walking to a clear tile underneath table artwork, rear sofa entry and diagonal exit, a 28-pixel child header, and a flush, raised HeatherOS Start button. Using only the supplied public address, live read-only inventory returned three Genesis avatars and a first page of 12 furniture items. Habbo #8599 was worn without a signature; Bronze Cornucopia was placed at tile 6,6 as a labelled demo with its native transparent sprite loaded. No token approval, transfer or financial transaction was performed. Five real floor definitions were checked, including the two Cornucopias, Birthday Cake, Bigger Birthday Cake and Confetti Bomb. Unknown items and wall furniture remain unsupported.

The mobile check used a 390-pixel browser viewport rather than native mobile hardware. External music playback and real two-device audio/video delivery were not retested; calls still need deployment and relay testing. These files do not update the external Render service automatically.

## Saved world

The multiplayer server writes `packages/server/data/world.json` by default. Set `HEATHER_WORLD_FILE` to an absolute path to use another location. The file contains the room, profiles, uniquely owned furniture (including stack heights and support links) and hashes of private profile credentials. Writes use a synced temporary file and atomic rename; an unsuccessful save does not apply the in-memory change. Keep this location on persistent disk when hosting. The save directory is ignored by Git, excluded from this source ZIP, and denied by the development file server. Back up that private save separately rather than publishing it.

The rename from Heather Hotel / Bando Hotel to Bando Pirates preserves the existing browser storage keys, player credentials, owned items and saved appearances. Existing saves remain compatible.

Guest profile credentials are stored by the browser and sent only on the player's private socket connection; ownership is checked on the server using the saved player identity. Moving an item does not change its owner. Clearing the browser's profile data removes that browser's access credential; account recovery is not implemented in this prototype.

## Artwork and licence

Upstream's software is MIT-licensed; its commercial pixel-art packs are not covered by that licence. This source working tree and the distributed ZIP omit all files from the upstream `public/assets/tinyhouse/` pack and the upstream screenshot. Those assets are neither loaded nor needed by this version. The new artwork was authored as CSS geometry without tracing or converting the excluded packs. The archived source does not include upstream Git history.

Keep `LICENSE` and `ARTWORK-LICENSE.txt` when sharing this version. Do not restore the excluded packs without obtaining their relevant licences.

Upstream base: commit `947494f933e40812051ed7f3905602b04b9c5fe4` from `cocolocow/cocoworking`. The source ZIP is prepared for creating your own GitHub repository/fork; this work has not created a repository in your GitHub account.


## Voice and webcam calls

Open **Calls** in Room tools. Choose one of three modes:

| Mode | Who joins | Sharing |
| --- | --- | --- |
| Private call / group | Invited players accept individually; any member can invite more players | Each participant chooses microphone, camera, both, or listening only |
| Room call | Anyone in the current room can explicitly join; there is no six-person limit | Each participant chooses their devices or listening only |
| Room broadcast | One presenter; anyone in the room can choose Watch or Listen | Only the presenter can share microphone/camera; viewers never request device access |

Invitations expire after 45 seconds. Declining an added invitation does not end an established private group. A departing inviter's pending invitations are cancelled. Broadcast viewers connect only to the presenter; there are no viewer-to-viewer media connections. When the presenter leaves or disconnects, the broadcast ends for every viewer. One broadcast and one room call can coexist. Each player belongs to one call or broadcast at a time. Private membership is sent only to its members; the room roster exposes public call counts and the broadcast presenter.

Opening the panel, receiving an invitation or watching a broadcast does not request devices. Starting/joining/accepting requests only selected devices; leaving both choices off joins a two-way call as a listener. Mute disables the audio track; turning off camera stops its capture track. Closing Calls, leaving, changing player, a disconnect, or room deletion ends local capture. A browser playback button appears if automatic remote audio/video playback is blocked. The offline HTML includes the controls but requires the hosted multiplayer game for calls. Calls are session-only and are not recorded or saved by this application.

Room/private calls use a WebRTC mesh and the existing Socket.IO server for signaling. Broadcasts use a presenter-to-viewer star. Membership has no artificial six-person cap; actual capacity depends on participants' devices and bandwidth. For busy rooms, an SFU media server would be needed to reduce each participant's connection and upload load. No SFU service is provisioned by this source update.

Only the wardrobe has a maximise/restore button or title-bar double-click maximising. Other child windows retain dragging, resizing and close controls. Scale is a compact 88-pixel-wide vertical window with slimmer padding, an editable percentage spinbox, and eight perspective levels.

Use HTTPS (localhost also works). If Bando Pirates is embedded in HeatherOS, the iframe needs `allow="camera; microphone; autoplay"`, and the parent must permit those features in its Permissions Policy. Browser microphone/camera permission remains the user's choice. Open the game directly if the embedding host cannot grant these permissions.

### TURN relay setup for restrictive networks

A public STUN server is included. Direct connections will not work on every mobile or restricted network. Configure a separately reachable coturn-compatible TURN server for wider connectivity; the Render web service handles signaling, not TURN media transport. Add these **server-side** Render environment variables:

| Variable | Value |
| --- | --- |
| BANDO_TURN_URLS | Comma-separated TURN URLs, for example `turn:your-relay.example:3478,turns:your-relay.example:5349` |
| BANDO_TURN_SECRET | The matching coturn shared authentication secret |

Enable coturn's `use-auth-secret` and configure its matching `static-auth-secret`, realm, TLS certificate and reachable relay ports. Prefer a TLS/TCP listener on a port permitted by the target networks. Do not put the shared secret in client files or in a Vite environment variable. The server issues one-hour HMAC credentials to current players; the shared secret stays on the server. No TURN service or credential is bundled.

Protocol checks cover invitation acceptance, outsider/spoofed signaling, malformed SDP, room calls past six members, private-group invitations, one-way broadcast roles, stale requests, disconnect/room cleanup and expiring TURN credentials. Capture lifecycle checks cover opening without capture, permission denial, cancelled late capture, full-group failure and disconnect races. Browser QA verified presenter sendonly/viewer recvonly negotiation, no viewer capture, camera stop/restart, private group expansion by invitations, added-invitation declines, member departure, and four-player room-call negotiation with generated media. Earlier browser QA exchanged bidirectional native offer/answer descriptions and remote track events for all six peer connections in a three-person mesh using generated media. It also checked microphone muting, camera stop/restart, no capture on invitation, private voice negotiation and disconnect cleanup. This environment returned no ICE candidates, so RTP audio/video delivery could not be verified; no personal microphone or camera was opened. Test two real devices after deployment and relay configuration.

Primary implementation references: https://webrtc.org/getting-started/turn-server , https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia , https://github.com/coturn/coturn/blob/master/README.turnserver .

Chat uses 20-pixel minimum single-line bubbles with the existing 13-pixel text, 18-pixel head portraits, tighter wrapped lines and a two-pixel maximum chronological overlap. Each message carries a server-authoritative appearance snapshot, displayed as an original CSS head or Habbo head-only renderer image. The head background and hard bubble shadow use the selected T-shirt colour; Habbo figures use the official shirt palette fetched from https://www.habbo.com/gamedata/figuredata/1 on 2026-11-08, with wardrobe colour as a fallback for future unmapped colours. NFT avatar rendering and ownership rules are unchanged; NFT users' chat heads use their underlying wardrobe look.

## Microverse floor tiles

Open **Microverse** in Room tools. Select a root tile, or use **Pick tile in room**, and choose **Divide into 4**. Select any of the four child buttons to enter that child and divide it again. **Parent tile** goes up one level. Only the room owner can divide tiles; other players can inspect and focus the same floor.

Each leaf is a real floor cell. Walking routes and arrow keys cross neighboring cells of different sizes. Avatars scale to their current tile. Moving or placing furniture chooses the destination tile's scale; a sofa still needs two matching cells, tables/Stools retain their relative heights, stacking works at the smaller scale, and sofas retain two usable seats. Furniture can be moved back onto a full-size tile to return it to full size. Owned items return to inventory on room deletion as before. NFT furniture uses the same scaled footprints, heights, seating and rendered sprite container.

A tile containing furniture or an avatar must be cleared before it can be divided. Dividing a parent replaces it with four children at the same total floor area. There is currently no merge action. The prototype supports **eight nested division levels** (minimum edge 1/256 of a root tile) and a **4,096-leaf room budget** (the 81-root room reaches 4,095 leaves in steps of three). These bounds protect saved worlds and rendering. Divisions belong to the room; deleting it removes its divided floor.

**Focus tile** selects a suitable perspective level and centres the selected cell at 100% zoom. **View room** restores Level 1 at 100%. Selecting a perspective manually follows the avatar at higher levels. Camera focus is local to each player and does not change room coordinates.

The multiplayer server validates tile ownership, room ID, canonical leaf-center coordinates, adjacency, collision, stepping and placement scale. Clients cannot walk to arbitrary fractional coordinates or teleport across a divided room. Divisions and native furniture scale persist across server restarts, are sent to late joiners, and are also saved in the standalone HTML preview.

Automated Microverse checks cover recursive area conservation, mixed-size routes, malformed trees and depth/leaf budgets, occupied-tile and guest rejection, scaled table/Stool climbs, stacking, both sofa seats, multiplayer leaf-coordinate validation, late joins and real disk restart persistence.

Browser verification confirmed three subdivision levels, the occupied-avatar guard, scaled table/Stool placement and climbing, a half-size sofa with automatic seating, and restoration of divided furniture in a new mobile-width preview. Focus keeps small cells usable below the top chat area. Native mobile hardware was not available; the mobile check used a 390-pixel iframe viewport.

Scale has no visible “Room zoom” label. Type a percentage from 25–250 and press Enter or leave the field; custom percentages are preserved to the nearest whole percent. The lower selector contains Level 1–8, with no percentage presets or Custom placeholder. Changing perspective resets the percentage to 100. Inputs, small up/down arrows and the selector use the shared HeatherOS Modern control classes. Browser checks confirmed the reset after typing 137% on desktop and 123% at a 390-pixel viewport.

### Start menu and compact windows

The bottom-left Start button uses the existing Bando Pirates desktop icon and HeatherOS Modern menu styling in the game palette. Wardrobe, Room info, Wallet & collectibles, Scale, Calls and Microverse are now in Start; the floating Room tools panel is removed. Click outside or press Escape to dismiss, or use Ctrl+Escape and the arrow keys to navigate. Mobile keeps the pirate icon and hides the Start text. Music starts just above the taskbar; volume is in the system tray.

Scale defaults to 88 pixels wide; its eight perspective choices show Level 1–8. All resizable windows and panels now have a single visible bottom-left grip for pointer/touch resizing (also keyboard accessible). Other edges move the window instead of resizing it. Non-resizable icons stay fixed in size; only Wardrobe retains maximise.

Earlier Start-menu verification passed the then-current 63 client tests and production build. Browser checks at desktop and 390-pixel widths confirmed the Start menu and existing actions, 88-pixel Scale layout, typed/custom and preset zoom, bottom-left resizing with the opposite corner anchored, and side-edge dragging without resizing.

### HeatherOS taskbar and program icons

The game now has the full-width HeatherOS Modern taskbar in the Bando Pirates palette, without Show desktop. The Bando Start button opens the existing room tools. Open programs appear as task buttons: click to bring forward or restore, or click the active task to minimise it. Minimise keeps the program running, including DJ playback and an ongoing call. Drag task buttons to reorder them; Ctrl+Shift+Left/Right also changes their order.

The right-hand tray contains live room connection status, the volume icon and a seconds clock. Click the clock for a draggable, resizable Date and time window with month navigation and Today. The volume icon opens a draggable mixer with a vertical Master slider, a DJ channel slider and Mute. Changes affect your local music playback; effective music level combines the room's shared DJ volume with your two local mixer levels. Click outside to dismiss the mixer, or drag it to keep it open until closed.

The taskbar reserves space underneath the room and floating windows. Mobile uses program icons instead of labels and keeps the tray and clock visible. Both layouts begin at one 44-pixel row. Another row is added only when the available width is full, and closing programs shrinks the bar again. Room and window bounds adjust to the actual bar height. The original HeatherOS taskbar/tray CSS and Modern finish are retained, with game-specific placement and colour overrides.

Start menu entries, program task buttons and window title bars share a colourful, outlined icon set. Existing HeatherOS house, network and music images are reused; wardrobe, wallet, scale, calls, Microverse, chat and calendar have matching original vector icons. Everything needed by the preview is embedded in its HTML.

Earlier taskbar validation passed the then-current 63 client tests and production build. Browser checks confirmed task switching, minimise/restore, task-button dragging without activation, the clock and calendar navigation, mixer levels/mute and dragged-popup behaviour, new menu/header icons, a 390-pixel mobile taskbar, and window bounds that stop above the taskbar. Offline preview was used for these UI checks; live audio and two-device calls were not retested.


### Ghost floor and covered-square navigation

The floor uses basic CSS diamond lines with a translucent lavender/plum checker pattern. Walls are faint and tile edges stay thin when magnified. Pointer movement is resolved against the projected floor square, not the object covering it. You can click an available square through another tile’s furniture, an avatar or wall artwork. Actual collision and reachable-route checks still apply; a blocked square remains blocked. The same floor picking works for furniture placement and the Microverse tile picker.

The palette is Heather pink, lavender and periwinkle. Child-window headers are slimmer, and Start uses the retained HeatherOS Modern taskbar geometry: flush with the left frame and slightly raised above the bar. Program task buttons, clock, volume tray and single bottom-left resize grips remain available.
