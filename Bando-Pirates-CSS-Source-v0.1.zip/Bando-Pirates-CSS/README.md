# Bando Pirates — CSS Art Edition (0.1)

A separate source fork of [Coco Working](https://github.com/cocolocow/cocoworking), with original live HTML/CSS artwork in place of its commercial image packs. This is an initial artwork and renderer implementation, not a hosted public hotel.

## Play the furniture room

Open `artwork-preview/Bando-Pirates-CSS-Game.html` in a browser for a standalone local game preview. Click floor tiles or use the arrow keys/WASD to walk, select, move and rotate the Base sofa, Base table and Stool, and try local chat. This preview runs offline and does not simulate other online players. The source project below provides live multiplayer.

The catalogue contains **Base sofa**, in natural cotton/off-white with no loose pillows, **Base table**, a simple brown wooden table, and a lower brown **Stool**. All three have four rotations. The sofa occupies two tiles; tables and Stools occupy one.

Tables are two height levels tall and Stools one (one level = 16 rendered pixels). Place or move an item onto a table or Stool to stack it automatically. Tables can stack on other tables, and a sofa can rest on a single table at its anchor tile with the other half overhanging. Overhanging furniture still cannot intersect another piece at the same height. Remove the items on top before moving, rotating or collecting their support; furniture cannot be moved or collected while a player stands on it.

Click floor tiles, tables or Stools to follow a route of adjacent tiles, or use the arrow keys/WASD. Players can climb **one level upward per tile**: floor → Stool → table. An isolated table cannot be climbed from the floor. A taller stack needs matching intermediate steps. Players can walk across tables/Stools and step down to the floor. Sofa cushions are seating destinations; walking routes do not pass through them. Walking onto a free sofa cushion automatically seats the avatar. Clicking a sofa finds a route to a free cushion; there is no Sit button. Placing, moving or turning a sofa beneath standing avatars seats them automatically, with one avatar per cushion. The sofa must meet each avatar’s current standing level and leave a usable front exit; duplicate occupants on one tile are rejected. Each sofa has two seats, with correct facing in all four rotations. **Stand up**, an arrow key or clicking a floor tile gets the avatar out of the seat; a tile click then continues to its destination. Sofa seating is synchronized for live players and late joins, and works for both original CSS and Habbo figures. Seats cannot be shared by two avatars. A sofa cannot be moved, rotated or collected while occupied. Sitting on an elevated sofa requires a reachable front approach at its base level or one level above; a blocked front exit must be cleared before standing. Room deletion returns the furniture and resets seated postures. Both server and offline preview validate each step; clicks cannot teleport through furniture or bypass height limits. Eight-direction walking includes diagonal routes, with both neighbouring routes checked so players cannot cut through corners or skip a required height step.

Furniture has a persistent player owner. Each new profile receives one sofa, two tables and one Stool, issued once. The first player gets a welcome room with a sofa, table and Stool already placed, with the spare table in inventory. Existing profiles receive the new Stool and spare table once without changing their earlier items or layout.

- Select a player profile in the lobby, or choose **New player**. Profiles are remembered on that browser; names alone do not grant access to another player's furniture.
- Room ownership stays with its creator across disconnects and restarts. The room owner can move and rotate placed pieces, and collect them back to their rightful owners.
- Open **Inventory**, select one of your items and choose **Place from inventory**, then tap/click a valid floor tile, table or Stool. Visitors can place their own inventory pieces and collect their own placed pieces.
- **Pick up** always returns an item to its existing owner's inventory. It never transfers ownership to the room owner.
- **Delete room** asks for confirmation, then removes the room and returns every placed item to its own owner, including players who are offline. These changes are saved together. A repeated/stale deletion cannot return items twice or delete a later room.
- After deletion, anyone can create a new, empty room and reuse their inventory. This prototype currently has one shared room at a time.

The standalone preview uses one local Heather profile and saves its room/inventory in browser storage. The multiplayer source stores the world on disk and uses saved anonymous browser profiles. It has no cross-device sign-in or profile recovery flow yet.

## Shared HeatherOS Modern theme

Buttons and child-window chrome use the actual HeatherOS Modern rules from HeatherOS Site version 254, source commit `a630054aab2d206cda458703d2b28be045035809`. The shared `controls.css` is retained byte for byte. Base window/control rules and the full Modern finish are extracted without changing their selectors or declarations. Bando Pirates uses the same title-bar structure, close glyph, bevels, hover/pressed/disabled states, Tahoma font family and native control styling.

The Hotel's teal/cream colours are separate in `packages/client/src/theme/hotel-palette.css`; the original shared styles remain in `heatheros-controls.css` and `heatheros-modern.css`. All game, wardrobe and artwork-studio controls load that central theme. `source.json` records the source and checksums. The HeatherOS project itself was read as a reference and was not changed.

Avatar geometry uses flat solid colours and a restored oval shadow at the walking surface. The friendlier two-eye face uses real CSS geometry, with mirrored eyes/brows and a centred smile. The original CSS avatar is scaled to 1.15 instead of 1.45 (about 21% smaller), matching the roughly 84-pixel visible height of a normal Habbo figure inside its unchanged 64×110 canvas. Full side views use a continuous rounded scalp and shaped rear hair, mirrored for left/right. A foreground hair cap covers the rear scalp in back, quarter-back and side views when hair is selected; short and long hair no longer leave bald patches at the back. The front/back rig and wardrobe layers are symmetric; left and right quarter/side views are mirrored counterparts. Window chrome retains HeatherOS's own highlights and shadows.

Child windows share `theme/ChildWindow.ts`: drag the title bar with a mouse or touch, resize from any edge or corner, or use Maximise/Restore and title-bar double-click. Keyboard arrows resize a focused edge handle. Bounds remain inside the available viewport and adapt after rotation or resizing; contents scroll inside small windows. The wardrobe and room information/furniture controls are child windows. **Room info** reopens the room window after closing it. Both windows are non-modal: opening them adds no dark overlay and the room remains interactive. Clicking or focusing a child window brings it to the front.

## Blank avatar and wardrobe

Choose **Wardrobe** in the game. **Blank base** starts with an original neutral, hairless CSS mannequin. Skin colour, face, hair, top, bottoms, shoes and accessory are independent layers. The **Breast size** slider runs from 0% (flat) to 100%, keeps the front view symmetrical, adjusts side/quarter views and follows the selected skin or top colour. This shape control edits the original CSS avatar; external Habbo figures remain intact. The value previews immediately and saves with the appearance. Existing version-1 appearances without it still load with a flat default. Turn through eight 45-degree directions or toggle the walk preview. Walking stays animated between consecutive tiles, including touch-driven routes on mobile. Reduced-motion mode removes optional bobbing while keeping the limb movement that communicates walking. Edits remain a draft until **Wear in room**; the saved look belongs to the authenticated player profile, persists after reload/restart, and is sent to the other live players. Closing the wardrobe without saving leaves the room avatar unchanged. **Heather preset** restores the familiar dressed appearance. **Export avatar JSON** downloads the versioned appearance data.

`artwork-preview/Bando-Pirates-Avatar-Wardrobe.html` is a separate self-contained base-design workbench. It starts blank, saves its design locally, and exports JSON. Its Save action does not change a multiplayer profile. The same workbench is available at `?wardrobe` in the source app. Avatar JSON import is not implemented yet.

The Stool top is now 52×52 model pixels (previously 86×86), with its one-level height and one-tile walking footprint preserved.

Choose **Avatar artwork → Habbo figure**. Either enter a figure string and choose **Preview figure**, or choose Habbo.com/Habbo.nl, enter a **Habbo name** and choose **Look up outfit**. Name lookup calls the selected hotel’s public API, validates its `figureString` and previews that outfit. **Wear in room** / **Save base design** commits the fetched figure. Names are hotel-specific. A missing name, request timeout or connection problem leaves the current appearance unchanged, and stale lookups are discarded when you close the window or change modes. Only the resulting outfit is saved; the profile’s other public details are not stored. The optional adapter loads the intact figure from Habbo's online avatar-image service, using native directions 0–7, standing, sitting and four cached walking frames on a 64×110 canvas. Saving keeps the figure string in the player appearance; the original CSS renderer remains the fallback when an image fails. This mode needs internet access. It does not apply CSS clothes to external artwork.

Raw SWF/`.nitro` clothing-pack imports, Habbo furniture imports and NFT wallet/ownership verification are not included. See [the compatibility notes](docs/HABBO-COMPATIBILITY.md) for the implemented boundary and the separate NFT proposal.

## Open the artwork studio

Open `artwork-preview/Bando-Pirates-CSS-Artwork.html` in a browser. This self-contained offline studio needs no installation, server, account or internet connection. Change the room and avatar colour controls, add/select furniture, nudge or rotate selected items, download colour CSS, or export furniture positions as JSON. Click a floor tile to move the sample avatar. The studio does not connect to multiplayer.

## Run the multiplayer source

Requires Node.js 20+ and pnpm. From the project folder:

```sh
pnpm install --frozen-lockfile
pnpm dev
```

Open the printed client URL (normally `http://127.0.0.1:3000`). Join from two tabs to test movement and chat. The Node Socket.IO server runs on port 2567 and Vite proxies its connection. In development, the entry point starts both processes and accepts standard `--host` and `--port` arguments. Ownership, inventories and the current room are saved to disk. Online avatar positions remain in memory.

For a production client build and Node server:

```sh
pnpm --filter @cocoworking/client build
pnpm --filter @cocoworking/server start
```

The server serves the built client and Socket.IO from port 2567 (or `PORT`). A static-only host can display the artwork studio; the multiplayer app needs the Node server or a deliberate backend port. Optional YouTube music and PeerJS features still use their external services; they were not replaced or guaranteed by this artwork change.

## Where to draw your artwork

| File | Purpose |
| --- | --- |
| `packages/client/src/artwork/artwork.css` | Original floor/wall, furniture and avatar shapes, colours and animations |
| `packages/client/src/artwork/elements.ts` | HTML parts and artwork keys; no images, SVG or canvas |
| `packages/shared/src/furniture.ts` | Model types, collision footprints and placement checks |
| `packages/client/src/artwork/avatar.ts` and `avatar.css` | Original skin rig and removable wardrobe layers |
| `packages/client/src/artwork/habboLookup.ts` | Allowlisted public name lookup and validated outfit extraction |
| `packages/client/src/artwork/Wardrobe.ts` | Draft editor, preview rotations, local export and Wear action |
| `packages/shared/src/avatar.ts` | Versioned appearance schema and authenticated profile update |
| `packages/shared/src/avatarDirections.ts` | Eight-direction mapping, bounded Habbo figure parsing and online image URLs |
| `packages/client/src/theme/ChildWindow.ts` | Shared mouse/touch drag, resize, maximise and restore behaviour |
| `packages/shared/src/seating.ts` | Two seats, front approaches, occupancy, standing validation and cushion anchors |
| `packages/shared/src/walking.ts` | Surface heights, one-level climbs and adjacent-tile pathfinding |
| `packages/shared/src/ownedWorld.ts` | Unique item ownership, inventories, room creation and atomic deletion returns |
| `packages/server/src/state/WorldStore.ts` | Durable world storage and private guest profile credentials |
| `packages/client/src/scenes/roomLayout.ts` | Initial artwork studio layout |
| `packages/client/src/scenes/CoworkingScene.ts` | CSS room drawing and integration with the existing networking API |
| `packages/client/src/scenes/RoomEditor.ts` | Artwork studio, colour controls and exports |
| `packages/client/src/game-logic/NetworkManager.ts` | Upstream Socket.IO client plus saved player identity, inventories, room lifecycle and an offline preview mode |

The original 64×32 isometric grid is retained. Artwork is constructed from CSS borders, clipping, gradients and positioned HTML parts. The shared window-control icons use the original HeatherOS inline SVG masks. Avatars have editable hair, clothing and skin variables, eight facing states and a continuous CSS walk animation. Room depth follows grid position; the catalogue contains only `base-sofa`, `base-table` and `stool`; the earlier furniture and decorative props remain removed.

The studio is also available at `?editor` when running the app. An exported room JSON is a design file: to change the studio layout, replace `ROOM_LAYOUT` in `roomLayout.ts`. The initial live welcome room and starter inventory are defined in `packages/shared/src/ownedWorld.ts`; arbitrary studio exports are not yet imported by the server. The initial studio intentionally does not persist edits between reloads. Download colour CSS before closing to retain changes. The exported override file can be imported after `artwork.css` when applying a palette to the live app.

To regenerate the standalone preview after editing artwork:

```sh
pnpm artwork:preview
```

## Checks

```sh
pnpm --filter @cocoworking/client test:unit
pnpm --filter @cocoworking/shared test:unit
pnpm --filter @cocoworking/server test:unit
pnpm --filter @cocoworking/client build
```

The current checks passed on 8 November 2026: 31 client tests, 131 shared tests, and 30 server tests (the server runner also discovers shared tests), plus server TypeScript and the production client build. Tests cover avatar schema validation, independent skin/clothing layers, profile-only appearance saves, live appearance broadcasts, persisted skins after restart, automatic stacking, sofa overhang and intersections, support removal guards, one-level climbs and pathfinding, raw server teleport/direct-climb rejection, stack persistence after restart, mixed-owner room deletion, and idempotent upgrade grants. Earlier ownership checks cover distinct profiles, private inventories, stale room IDs, unauthorized collection/deletion, failed-save rollback, corrupt-save preservation and the old stool-to-table name migration. Current checks also cover encoded Habbo-name requests, missing/invalid outfits, cancelled lookup races, automatically entering seat tiles, seating avatars beneath new furniture, matching support heights, duplicate seat rejection and failed-save rollback. Current checks cover server-authoritative seating, two-player occupancy, late-join posture, standing/disconnect releases, room deletion while seated, raised-sofa approach heights and CSS/Habbo sitting actions. Browser checks confirmed all four sofa rotations, correct foreground/backrest layering, approach walking and standing, native Habbo sitting images, and left/right CSS head profiles. Earlier browser checks additionally confirmed the breast-size slider at 70%, Wear and reload persistence, the draggable/resizable room info window, maximise/restore, close/reopen with retained bounds, two non-modal child windows without a backdrop, and walking while both remain open. Earlier browser checks confirmed all eight avatar poses, the restored floor shadow and symmetric friendly face, live Habbo figure images and changing walking frames, CSS walking at a 454-pixel viewport, physically dragging/resizing the child window, maximise/restore, the Modern title bar and shared button fonts/borders throughout multiplayer, draft/blank appearance saving and reload persistence, independent profile appearance synchronization in two live tabs, Stool-to-table climbing, rejection after removing the step, stacking a sofa above two tables, preservation after reload, and synchronized table heights and mixed-owner stacks across two live clients. Native mobile hardware and OS reduced-motion settings were not available in the browser test; the touch controls and reduced-motion animation rules were inspected and the continuous gait is regression-tested. External media playback and proximity calls were not verified.

## Saved world

The multiplayer server writes `packages/server/data/world.json` by default. Set `HEATHER_WORLD_FILE` to an absolute path to use another location. The file contains the room, profiles, uniquely owned furniture (including stack heights and support links) and hashes of private profile credentials. Writes use a synced temporary file and atomic rename; an unsuccessful save does not apply the in-memory change. Keep this location on persistent disk when hosting. The save directory is ignored by Git, excluded from this source ZIP, and denied by the development file server. Back up that private save separately rather than publishing it.

The rename from Heather Hotel / Bando Hotel to Bando Pirates preserves the existing browser storage keys, player credentials, owned items and saved appearances. Existing saves remain compatible.

Guest profile credentials are stored by the browser and sent only on the player's private socket connection; ownership is checked on the server using the saved player identity. Moving an item does not change its owner. Clearing the browser's profile data removes that browser's access credential; account recovery is not implemented in this prototype.

## Artwork and licence

Upstream's software is MIT-licensed; its commercial pixel-art packs are not covered by that licence. This source working tree and the distributed ZIP omit all files from the upstream `public/assets/tinyhouse/` pack and the upstream screenshot. Those assets are neither loaded nor needed by this version. The new artwork was authored as CSS geometry without tracing or converting the excluded packs. The archived source does not include upstream Git history.

Keep `LICENSE` and `ARTWORK-LICENSE.txt` when sharing this version. Do not restore the excluded packs without obtaining their relevant licences.

Upstream base: commit `947494f933e40812051ed7f3905602b04b9c5fe4` from `cocolocow/cocoworking`. The source ZIP is prepared for creating your own GitHub repository/fork; this work has not created a repository in your GitHub account.
