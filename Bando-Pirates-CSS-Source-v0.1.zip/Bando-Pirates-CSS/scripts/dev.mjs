// One development entry point with standard --host / --port support.
import { createRequire } from 'node:module';
import { spawn } from 'node:child_process';
import { dirname, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const client = resolve(root, 'packages/client');
const server = resolve(root, 'packages/server');
const serverRequire = createRequire(resolve(server, 'package.json'));
const clientRequire = createRequire(resolve(client, 'package.json'));
const args = process.argv.slice(2);
function option(name, fallback) { const i = args.indexOf(name); return i >= 0 && args[i + 1] && !args[i + 1].startsWith('--') ? args[i + 1] : fallback; }
const child = spawn(process.execPath, ['--import', serverRequire.resolve('tsx/esm'), resolve(server, 'src/index.ts')], { cwd: server, env: { ...process.env, PORT: '2567' }, stdio: 'inherit' });
const { createServer } = await import(pathToFileURL(clientRequire.resolve('vite')).href);
const vite = await createServer({ root: client, server: { host: option('--host', '127.0.0.1'), port: Number(option('--port', '3000')) } });
let stopping = false;
async function stop() { if (stopping) return; stopping = true; child.kill(); await vite.close(); process.exit(0); }
process.on('SIGINT', stop); process.on('SIGTERM', stop);
child.on('error', error => { console.error(error); void stop(); });
child.on('exit', code => { if (!stopping) { console.error('Room server stopped:', code); void stop(); } });
await vite.listen(); vite.printUrls();
