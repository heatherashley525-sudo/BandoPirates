import { createRequire } from 'node:module';
import { writeFile, mkdir, realpath } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const require = createRequire(await realpath(path.join(root, 'packages/client/node_modules/vite/package.json')));
const { build } = require('esbuild');
await mkdir(path.join(root,'artwork-preview'),{recursive:true});
for (const [entry,name,title] of [
  ['preview.ts','Bando-Pirates-CSS-Artwork.html','Bando Pirates — Furniture studio'],
  ['wardrobePreview.ts','Bando-Pirates-Avatar-Wardrobe.html','Bando Pirates — Blank avatar wardrobe'],
  ['gamePreview.ts','Bando-Pirates-CSS-Game.html','Bando Pirates — Furniture game preview'],
]) {
  const output = await build({
    entryPoints:[path.join(root,'packages/client/src/artwork',entry)],bundle:true,write:false,outfile:'preview.js',minify:true,
    loader:{'.html':'text'},
  });
  const script=output.outputFiles.find(f=>f.path.endsWith('.js')).text;
  const css=output.outputFiles.find(f=>f.path.endsWith('.css')).text;
  const html=`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title}</title><style>*{box-sizing:border-box}body{margin:0}${css}</style></head><body><div id="app"></div><script>${script.replaceAll('</script','<\\/script')}</script></body></html>`;
  await writeFile(path.join(root,'artwork-preview',name),html);
  if (entry === 'wardrobePreview.ts') await writeFile(path.join(root,'packages/client/public/wardrobe-preview.html'),html);
  if (entry === 'gamePreview.ts') {
    await mkdir(path.join(root,'packages/client/public'),{recursive:true});
    await writeFile(path.join(root,'packages/client/public/offline-preview.html'),html);
  }
  console.log('Built:',name);
}
